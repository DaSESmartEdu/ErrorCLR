int main(){
    char *a[]={"0","January","February","March","April","May","June","July","August","september","October","Novemebr","December"};
    int i;
    scanf("%d",&i);
    if(i<1 || i>12){
        printf("wrong input!");
    }
    else printf("%s",a[i]);
    return 0;
}