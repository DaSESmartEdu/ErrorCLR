#include <stdio.h>
#include <math.h>
int main (void)
{
	int a;
	int n;
	scanf("%d %d",&a,&n);
	double i=0;
	int sum=0;
	int sumx=0;
	while (i<n)
	{
		int m=pow(10,i);
		int x=a*m;
		sum=sum+x;
		sumx=sumx+sum;
		i=i+1;
	}
	printf("%d",sum);
	return 0;
}