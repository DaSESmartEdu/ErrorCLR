#include <bits/stdc++.h>
using namespace std;
struct Node 
{
	int x,y;
};
bool compare(Node A,Node B)
{
    if(A.x>B.x) return true;
    else if((A.x==B.x) && (A.y>B.y)) return true;
    return false;
}
class Heap
{
    public:
        int size;
        void HeapSort(Node a[])
        {
            Maxheap(a);
            for(int i=size-1;i>0;i--)
            {
                swap(a[0],a[i]);
                Heapify(a,1);
            }
        }
        void Maxheap(Node a[])
        {
            for(int i=size/2;i>0;i--)
            {
                Heapify(a,i);
            }
        }
        void Heapify(Node a[],int n)
        {
            int leftchild=2*n;
            int rightchild=2*n+1;
            int largest;
            if(leftchild<=size && compare(a[leftchild-1],a[n-1])) largest=leftchild;
            else largest=n;
            if(rightchild<=size && compare(a[rightchild-1],a[largest-1])) largest=rightchild;
            if(largest!=n)
            {
                swap(a[largest-1],a[n-1]);
                Heapify(a,largest);
            }
        }
    private:
};
int main()
{
    Node a[100];
    Heap myheap;
    int size;
    cin>>size;
    myheap.size=size;
    for(int i=0;i<size;i++)
    {
        cin>>a[i].x>>a[i].y;
    }
    myheap.HeapSort(a);
    for(int i=0;i<size;i++)
    {
        cout<<"("<<a[i].x<<","<<a[i].y<<")";
        if(i!=size-1) cout<<endl;
    }
    return 0;
}