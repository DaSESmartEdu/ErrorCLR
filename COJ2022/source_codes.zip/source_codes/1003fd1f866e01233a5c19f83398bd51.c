#include<stdio.h>
struct m{
	int a1;
	int b1;
	int a2;
	int b2;
};
int main()
{
	struct m m1;
	m1.a1=0;
	m1.b1=0;
	m1.a2=0;
	m1.b2=0;
	scanf("%d%d%d%d",&m1.a1,&m1.b1,&m1.a2,&m1.b2);
	int c=m1.a1*m1.a2-m1.b1*m1.b2;
	int d=m1.a1*m1.b2+m1.a2*m1.b1;
	printf("(%d+%di) * (%d+%di)=%d+%di",m1.a1,m1.b1,m1.a2,m1.b2,c,d);
	return 0;
}