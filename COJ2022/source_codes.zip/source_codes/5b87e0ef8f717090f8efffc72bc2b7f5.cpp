#include <stdio.h>
#include<iostream>
using namespace std;
#define MAX 100
int preOrder[MAX];
int inOrder[MAX];
void getPostOrder(int preLeft, int preRight, int inLeft, int inRight) {
         if(preLeft > preRight || inLeft > inRight) {
            return ;
         }
      char root = preOrder[preLeft];
         int i = inLeft;
       for( ; i <= inRight; i++) {
          if(inOrder[i] == root)
                 break;
      }
        int leftLen = i - inLeft;
        int rightLen = inRight - i;
         if(leftLen > 0)
            getPostOrder(preLeft+1, preLeft + leftLen, inLeft, i-1);
        if(rightLen > 0)
         getPostOrder(preLeft + leftLen + 1, preRight, i+1, inRight);
          printf("%d ", preOrder[preLeft]);
        return ;
    }
     int main() {
     	int m;
    cin>>m;
    for(int i=0; i<m; i++){
    	cin>>preOrder[i];
	}
	for(int i=0; i<m; i++){
    	cin>>inOrder[i];
	}
        getPostOrder(0, 6, 0, 6);
   }