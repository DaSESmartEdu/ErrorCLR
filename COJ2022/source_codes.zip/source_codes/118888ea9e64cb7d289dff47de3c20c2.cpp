#include<iostream>
using namespace std;
#define INF 10000000
#define min(a,b) a<b?a:b
int **graph;
int find_min_no0(int *cost,int numVeterx,int *visited,int &count)
{
    int Min = INF;
    int Min_index;
    for (int i = 0; i < numVeterx; i++)
    {
        if (visited[i]!=1&&cost[i]!=INF)
        {
            int tmp=Min;
            Min = min(Min,cost[i]);
            if (tmp != Min)
            {
                Min_index = i;
            }
        }
    }
    visited[Min_index]=1;
    cost[Min_index]=0;
    for (int i = 0; i < numVeterx; i++)
    {
        if (visited[i]!=1&&graph[Min_index][i]!=INF)
        {
            cost[i]=min(cost[i],graph[Min_index][i]);    
        }
    }
    count++;
    return Min;
}
int main()
{
    int numVeterx;
    int numEdge;
    int a,b,w;
    int *visited;
    int *cost;
    int res;
    cin>>numVeterx>>numEdge;
    graph = new int*[numVeterx+1];
    visited = new int[numVeterx+1];
    cost = new int[numVeterx+1];
    res = 0;
    for (int i = 0; i < numVeterx; i++)
    {
        graph[i]=new int [numVeterx+1];
    }
    for (int i = 0; i < numVeterx; i++)
    {
        visited[i] = 0;
        for (int j = 0; j < numVeterx; j++)
        {
            if (i==j)
            {
                graph[i][j]=0;
            }
            else
            {
                graph[i][j]=INF;
            } 
        }        
    }
    for (int i = 0; i < numEdge; i++)
    {
        cin>>a>>b>>w;
        graph[a-1][b-1]=min(graph[a-1][b-1],w);
        graph[b-1][a-1]=min(graph[b-1][a-1],w);
    }
    visited[0]=1;
    cost = *graph;
    int count = 1;
    while (count<numVeterx)
    {
        res+=find_min_no0(cost,numVeterx,visited,count);   
    }
    cout<<res;
}