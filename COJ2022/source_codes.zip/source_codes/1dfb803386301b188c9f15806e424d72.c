#include<stdio.h>
int main(){
	int n;
	double sum=0;
	int i;
	double a=2.0,b=1.0,c=0;
	scanf("%d",&n);
	for(i=1;i<=n;i++){
		sum=sum+a/b;
		c=a;
		a=a+b;
		b=c;
	}
	printf("%.4f\n",sum);
}