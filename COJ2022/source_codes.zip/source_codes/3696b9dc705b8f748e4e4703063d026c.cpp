#include<iostream>
#include<math.h>
using namespace std;
typedef struct point{
    int x;
    int y;
}point;
int main(void)
{
    int n;
    cin >> n;
    struct point a[n];
    float length[n];
    for (int i = 0; i < n; i++)
    {
        cin >> a[i].x;
        cin >> a[i].y;
    }
    int d;
    cin >> d;
    for (int i = 0; i < n; i++)
    {
        length[i]=sqrt(pow(a[i].x,2)+pow(a[i].y,2));
    }
    int m;
    for (int  i = 0; i < n-1; i++)
    {
        for (int k = 0; k < n-1; k++)
        {
            if (length[k]>length[k+1])
            {
                m=length[k];
                length[k]=length[k+1];
                length[k+1]=m;
            }
        }
    }
    for (int i = 0; i < n; i++)
    {
        float b=sqrt(pow(a[i].x,2)+pow(a[i].y,2));
        if(length[d-1]==b)
        {
            cout << a[i].x <<" "<<a[i].y << endl;
            break;
        }
    }
    return 0;
}