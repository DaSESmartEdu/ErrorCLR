#include <stdio.h>
#include <stdlib.h>
int even(int n){
    return (n+1)%2;
}
int OddSum(int List[], int N){
    int s=0;
    for (int i=0; i<N; i++){
        if(even(List[i])) s+=List[i];
    }
    return s;
}
int main(){
    int n;
    scanf("%d", &n);
    int* List = (int*)malloc(sizeof(int)*n);
    for (int i=0; i<n; i++){
        scanf("%d", &List[n]); 
    }
    printf("%d", OddSum(List, n));
    return 0;
}