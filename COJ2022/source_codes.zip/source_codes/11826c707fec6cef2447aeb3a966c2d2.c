#include <stdio.h> 
#include <string.h>
#include <stdlib.h>
#include <stdbool.h>
#include <math.h>
void jinzhi(int n)
{	int result;
	 if(n==1) printf("1");
	 else if(n==0) printf("0");
	 else {
	 	jinzhi(n/2);
	 	result=n%2;
	 	printf("%d",result);
	 }
}
int main()
{
	int n;
	scanf("%d",&n);
	jinzhi(n);	
}