#include<stdio.h>
int main()
{int a;
float b;
if (a<=50) {b=0.53*a;}
else 
b=50*0.53+0.58*(a-50);
printf("%f\n",b);
 return 0;
}