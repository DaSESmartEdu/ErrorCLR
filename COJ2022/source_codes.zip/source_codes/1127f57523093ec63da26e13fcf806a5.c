#include<stdio.h>
int main()
{
    int n,a[7][7],max,min,ret;
    scanf("%d",&n);
    for(int i=0;i<n;i++)
    {
        for(int j=0;j<n;j++)
        {
            scanf("%d",&a[i][j]);
        }
    }
    for(int i=0;i<n;i++)
    {
        ret=1;
        max=0;
        for(int j=0;j<n;j++)
        {
            if(a[i][j]>a[i][max])
            {
                max=j;
            }
        }
        min=i;
        for(int i1=0;i1<n;i1++)
        {
            if(a[min][max]>a[i1][max])
            {
                ret=0;
                break;
            }
        }
        if(ret)
        {
            printf("%d %d",i,max);
            break;
        }
    } 
    if(ret==0)
    {
        printf("NO");
    }
    return 0;
}