#include<stdio.h>
int main()
{
    int i=1,m,n;
    scanf("%d%d",&m,&n);
    for(i=2;i<=500;i++)
        {
            if(m%i==0&&n%i==0)
                {
                    printf("%d",i);
                    break;
                }
        }
        while(i)
        {
            if(i%n==0&&i%m==0)
            {
                printf(" %d",i);
                break;
            }
            i++;
        }
        return 0;
}