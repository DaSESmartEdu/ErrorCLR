#include<stdio.h>
#include<math.h>
int main()
{
    int a,s=0;
    for(;;){ 
        if(a<=0)
        break;
        scanf("%d",&a);
        if(floor(a/2.0)!=a/2.0)
        s=s+a;
    }
    printf("%d",s);
    return 0;
}