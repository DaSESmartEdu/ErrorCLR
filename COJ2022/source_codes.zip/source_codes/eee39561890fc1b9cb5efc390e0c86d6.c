#include<stdio.h>
#include<math.h>
double c_pow(double a,double b){
	double tmp=1;
	for(int i=1;i<=b;i++){
		tmp=tmp*a;
	}
	return tmp;
}
int main(){
	double height,n;
	scanf("%lf%lf",&height,&n);
	double m;
	m=c_pow(0.5,n)*height;
	printf("%.2lf",m+0.005);
	return 0;
}