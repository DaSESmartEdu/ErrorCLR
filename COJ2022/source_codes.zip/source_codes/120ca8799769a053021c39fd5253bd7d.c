#include<stdio.h>
struct fri{
    char name[30];
    int bir;
    char tel[18];
};
int main(){
    int n,i,j;
    struct fri k;
    scanf("%d",&n );
    struct fri fris[n];
    for(i=0;i<n;i++){
        scanf("%s %d %s",&fris[i].name,&fris[i].bir,&fris[i].tel);
    }
    for(i=0;i<n;i++){
        for(j=i;j<n;j++){
            if(fris[i].bir>fris[j].bir){
                k = fris[j];
                fris[j] = fris[i];
                fris[i] = k;
            }
        }
    }
    for(i=0;i<n;i++){
        printf("%s %d %s\n",fris[i].name,fris[i].bir,fris[i].tel);
    }
}