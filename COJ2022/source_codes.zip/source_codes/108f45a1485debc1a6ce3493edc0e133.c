#include<stdio.h>
#include<string.h>
#include<stdlib.h>
char *match( char *s, char str1, char str2 )
{
    int i=0,j=0;
    for(i=0;i<strlen(s);i++)
    {
        if(str1==s[i])
            break;
    }
    if(i==strlen(s))
        return NULL;
    for(j=i-1;s[j]!='\0';j++)
    {
        if (str2==s[j])
            break;
    }
    if(j==strlen(s))
        printf("%s\n",s+i);
    else
    {
        for(int l=i;l<=j;l++)
            printf("%c",s[l]);
        printf("\n");
    }
    printf("%s",s+i);
    return s+i;
}
int main()
{
    char str1,str2;    
    char *s=(char*)malloc(100);
    scanf("%s\n",s);
    scanf("%c %c",&str1,&str2);
    match(s,str1,str2);
    return 0;
}