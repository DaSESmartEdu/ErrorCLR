#include<stdio.h>
#include<stdlib.h>
struct ListNode *readlist();
struct ListNode *deletem(struct ListNode *L,int m);
struct ListNode
{
    int data;
    struct ListNode *next;
};
int main()
{
    int m;
    struct ListNode *L,*p;
    L=readlist();
    scanf("%d",&m);
    p=deletem(L,m);
    while(p)
    {
        printf("%d ",p->data);
        p=p->next;
    }
    return 0;   
}
struct ListNode *readlist()
{
    struct ListNode *head,*p,*tail;
    int t;
    head=NULL;
    tail=NULL;
    scanf("%d",&t);
    while(t!=-1)
    {
        p=(struct ListNode*)malloc(sizeof(struct ListNode));
        p->data=t;
        p->next=NULL;
        if(head==NULL)
        head=p;
        else
        tail->next=p;
        tail=p;
        scanf("%d",&t);
    }
    return head;
}
struct ListNode *deletem(struct ListNode *L,int m)
{
    struct ListNode *p,*q,*head;
    head=L;
    while(head->next!=NULL&&head->data==m)
    { 
        q=head;
        head=head->next;
        free(q);
    }
    if(head==NULL)
    return NULL;
    p=head;
    while(p->next!=NULL)
    {
        if(p->next->data==m)
        {
         q=p->next;
         p->next=q->next;
         free(q);
        }
        else
        p=p->next;
    }
    if(p->data==m)
    return NULL;
    return head;
}