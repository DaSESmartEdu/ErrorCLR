#include<bits/stdc++.h>
using namespace std;
int father[20000];
void init(int n)
{
    for(int i=1;i<=n;i++) father[i]=i;
}
int find(int x)
{
    while(father[x]!=x) x=father[x];
    return x;
}
void join(int a,int b)
{
    int t1=find(a);
    int t2=find(b);
    if(t1!=t2) father[t1]=t2;
}
int main()
{
    int n,m;
    int a,b;
    while(cin>>n)
    {
        if(n==0) break;
        else
        {
            cin >> m;
            init(n);
            for(int i=1;i<=m;i++)
            {
                cin >> a >> b;
                join(a,b);
            }
            int cnt=0;
            for(int i=1;i<=n;i++)
                if(father[i]==i) cnt++;
            cout << cnt-1 << endl;
        }
    }
    return 0;
}