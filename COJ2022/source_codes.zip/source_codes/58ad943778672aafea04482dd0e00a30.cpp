#include <iostream>
#include <math.h>
#define N 100010
using namespace std;
int n,k,i;
struct node
{
    int x,y,dis;
}poi[99999];
void quick_sort(int l,int r)
{
    if(l>=r)return;
    int i=l-1,j=r+1;
    int x=poi[(l+r)>>1].dis;
    while(i<j)
    {
        do i++;while(poi[i].dis<x);
        do j--;while(poi[j].dis>x);
        if(i>=j)break;
        int t=poi[i].x;
        poi[i].x=poi[j].x;
        poi[j].x=t;
        t=poi[i].y;
        poi[i].y=poi[j].y;
        poi[j].y=t;
        t=poi[i].dis;
        poi[i].dis=poi[j].dis;
        poi[j].dis=t;
    }
    quick_sort(l,j);
    quick_sort(j+1,r);
}
int main()
{
    scanf("%d",&n);
    for(i=0;i<n;i++)
    {
        scanf("%d%d",&poi[i].x,&poi[i].y);
        poi[i].dis=sqrt(pow(poi[i].x,2)+pow(poi[i].y,2));
    }
    scanf("%d",&k);
    quick_sort(0,n-1);
    printf("%d %d",poi[k-1].x,poi[k-1].y);
    return 0;
}