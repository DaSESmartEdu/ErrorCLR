#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
int main (){
    char str[1000];
    gets(str);
    int n=strlen(str);
    n--;
    int num,sign=1;
    for (int i=0;i<n;i++){
        if ((str[i]>='0'&&str[i]<='9')||(str[i]>='a'&&str[i]<='f')||(str[i]>='A'&&str[i]<='F')){
            num=i;
            break;
        }
    }
    for (int i=0;i<num;i++){
        if (str[i]=='-'){
            sign=-1;
            break;
        }
    }
    char d[1000];
    int k=0;
    for (int i=0;i<n;i++){
        if ((str[i]>='0'&&str[i]<='9')||(str[i]>='a'&&str[i]<='f')||(str[i]>='A'&&str[i]<='F')){
            d[k]=str[i];
            k++;
        }
    }
    int sum=0;
    for (int i=0;i<k;i++){
        if (d[i]>='0'&&d[i]<='9'){
            sum=sum+(d[i]-'0')*pow(16,k-i-1);
        }
        else if (d[i]>='a'&&d[i]<='f'){
            sum=sum+(d[i]-'a'+10)*pow(16,k-i-1);
        }
        else if (d[i]>='A'&&d[i]<='F'){
            sum=sum+(d[i]-'A'+10)*pow(16,k-i-1);
        }        
    }
    sum*=sign;
    printf ("%d",sum);
    return 0;
}