#include <stdio.h>
int main()
{
	int m, n;
    scanf("%d%d", &m, &n);
	int s[m][n];
	for(int i = 0; i < m; i++)
	{
		for(int j = 0; j < n; j++)
		{
			scanf("%d", &s[i][j]);
		}
	}
	int a[m];
    for(int i = 0; i < m; i++)
    {
        a[i] = 0;
    }
	for(int i = 1; i < m; i++)
	{
		for(int j = 0; j < n; j++)
		{
			a[i] += s[i][j];
		}
	}
	for(int i = 0; i < m; i++)
	{
		printf("%d ", a[i]);
	}
	return 0;
}