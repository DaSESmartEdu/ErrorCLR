#include<stdio.h>
int main(){
    int a[59];
    a[1]=1,a[2]=1,a[3]=1;
    int n;
    scanf("%d",&n);
    for(int i=4;i<=n;i++){
        a[i]=a[i-1]+a[i-3];
    }
    printf("%d",a[n]);
    return 0;
}