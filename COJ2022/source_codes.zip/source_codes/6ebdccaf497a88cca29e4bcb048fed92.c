#include<stdio.h>
int main()
{
    int i=3,n,a=1,b=1,sum;
    sum=a+b;
    scanf("%d",&n);
    if (n=1)
    {
        i=1;
    }
    while (sum<n)
    {
        a=b;
        b=sum;
        sum=b+a;
        i++;
    }
    printf("%d",i);
}