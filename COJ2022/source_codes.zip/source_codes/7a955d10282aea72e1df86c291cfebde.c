#include <stdio.h>
int main(){
    int n,m;
    scanf("%d %d",&n,&m);
    if (0<=n&&n<1*m){
        printf("normal");
    }
    else if (1*m<=n&&n<1.5*m){
        printf("200");
    }
    else if (1.5*m<=n){
        printf("revoke");
    }
    return 0;
}