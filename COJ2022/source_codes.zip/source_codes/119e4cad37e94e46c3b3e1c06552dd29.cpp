#include <bits/stdc++.h>
using namespace std;
int main()
{
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    vector<int> a,dp;
    int k,n;
    cin>>k;
    for (int i = 0; i < k; i++)
    {
        cin>>n;
        int temp;
        for (int j = 0; j < n; j++)
        {
            cin>>temp;
            a.push_back(temp);
        }
        dp.push_back(a[0]);
        int dpn=0;
        for (int t = 1; t < n; t++)
        {
            if (a[t]>dp[dpn])
            {
                dp.push_back(a[t]);
                dpn++;
            }
            else
            {
                int l=0,r=dpn;
                while (l<=r)
                {
                    int mid = l+(r-l)/2;
                    if (dp[mid]<=a[t])
                        l=mid+1;
                    else
                        r=mid-1;
                }
                dp[l]=a[t];
            }
        }
        int flag=k-i;
        cout<<(dpn+1);
        cout<<" ";
        a.clear();
        dp.clear();
    }
    return 0;
}