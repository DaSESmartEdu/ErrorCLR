#include <stdio.h> 
#include <string.h>
#include <stdlib.h>
#include <stdbool.h>
#include <math.h>
void dayin(int n)
{
	if (n==1) 
	{
		printf("A");return;
	}
	else 
	{
		dayin(n-1);
		printf("%c",'A'+n-1);
		dayin(n-1);
		return;
	}
}
int main()
{
	int n;
	scanf("%d",&n);
	dayin(n);
}