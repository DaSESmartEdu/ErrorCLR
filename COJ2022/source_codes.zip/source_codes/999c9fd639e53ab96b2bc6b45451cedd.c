#include <stdio.h>
#include <math.h>
double fact(int n);
int main(){
    double sum=1;
    double x;
    int n=1;
    scanf("%lf",&x);
    do{
        sum=sum+pow(x,n)/fact(n);
        n++;
    }while (fabs(pow(x,n)/fact(n))>=0.00001);
    printf("%.4f",sum);
    return 0;
}
double fact(int n)
{
    int i;
    double product=1;
    for (i=1;i<=n;i++){
        product=product*i;
    }
    return product;
}