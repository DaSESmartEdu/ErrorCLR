#include<bits/stdc++.h>
using namespace std;
int ss[10000]={0};
void cal(){
    int s[100000]={0};
    for(int i=2;i<100000;i++)
        for(int j=2;j*i<100000;j++){
            s[i*j]=1;
        }
    int count=0;
    for(int i=2;i<10000;i++)
        if(!s[i])
            ss[count++]=i;
}
void print(int n){
    int a=0,temp=n;
    if(n==1)
        cout<<"1=1";
    cout<<n<<"=";
    while(n!=1){
        if(n%ss[a]==0){
            if(temp!=n)cout<<"*";
            cout<<ss[a];
            n=n/ss[a];
        }else
            a++;
    }
    cout<<endl;
}
int main(){
    cal();
    int a,b;
    cin>>a>>b;
    for(int i=a;i<=b;i++)
        print(i);
    return 0;
}