#include <bits/stdc++.h>
using namespace std;
class TreeNode {
    public:
    TreeNode *l, *r;
    char val;
    TreeNode() {}
    TreeNode(TreeNode* r, TreeNode* l, char val) : l(l), r(r), val(val) {}
};
class BiTree {
    private:
    TreeNode* root;
    TreeNode* Build_(string& str, int& index) {
        if (index < 0 || str[index] == '#') return nullptr;
        char val = str[index];
        return new TreeNode(Build_(str, --index), Build_(str, --index), val);
    }
    TreeNode*& Find_(TreeNode*& x, char val) {
        if (!x) return x;
        if (x->val == val) return x;
        if (x->val > val) return Find_(x->l, val);
        if (x->val < val) return Find_(x->r, val);
        return x;
    }
    void Output_(TreeNode* n) {
        if (!n) return;
        Output_(n->l);
        cout << n->val << " ";
        Output_(n->r);
    }
    public:
    void Input() {
        string str;
        cin >> str;
        int n = str.size() - 1;
        root = Build_(str, n);
        Output();
    }
    void Find(char val) {
        TreeNode* tmp = root;
        while (tmp) {
            cout << tmp->val;
            if (tmp->val == val) break;
            cout << " ";
            if (tmp->val < val)
                tmp = tmp->r;
            else
                tmp = tmp->l;
        }
        cout << endl;
    }
    void Erase(char val) {
        TreeNode* rroot = root;
        TreeNode*& tmp = Find_(rroot, val);
        if (tmp->r) {
            if (tmp->r->l) {
                TreeNode* tmpr = tmp->r;
                while (tmpr->l->l) tmpr = tmpr->l;
                tmp->val = tmpr->l->val;
                delete tmpr->l;
                tmpr->l = nullptr;
            } else {
                tmp->val = tmp->r->val;
                delete tmp->r;
                tmp->r = nullptr;
            }
        } else if (tmp->l) {
            tmp = tmp->l;
        } else {
            delete tmp;
            tmp = nullptr;
        }
    }
    void Output() {
        Output_(root);
        cout << endl;
    }
};
int main() {
    BiTree solution;
    solution.Input();
    char x, y;
    cin >> x >> y;
    solution.Find(x);
    solution.Erase(y);
    solution.Output();
}