#include<stdio.h>
#include<string.h>
#include<stdlib.h>
int max_len(char *s[],int n);
int main(void)
{
    char *s[10]={NULL};
    int n;
    scanf("%d",&n);
    int i=0;
    for(i=0;i<n;i++)
    {
        s[i]=(char*)malloc(sizeof(char)*100);
        scanf("%s",s[i]);
    }
    printf("%d",max_len(s,n));
    return 0;
}
int max_len(char *s[],int n)
{
    int max=0;
    for(int i=0;i<n;i++)
    {
        if(strlen(s[i])>max)
        max=strlen(s[i]);
    }
    return max;
}