#include<iostream>
using namespace std;
int main()
{
    int k=0,x=0,y=0;
    int arr[8][8];
    int arr2[8][8];
    for(int i=0;i<8;i++)
    {
        for(int j=0;j<8;j++)
        {
            arr[i][j]=0;
            arr2[i][j]=0;
        }
    }                      
    cin>>k;
    cin>>x>>y;
    while(x!=-1 && y!=-1){
        arr[x][y]=1;
        cin>>x>>y;
    }                       
    while(k--)
    {
        for(int i=1;i<7;i++)
        {
            for(int j=1;j<7;j++)
            {
                int num=0;
                for(int a=i-1;a<=i+1;a++)
                {
                for(int b=j-1;b<=j+1;b++){
                    num+=arr[a][b];}
                }
                num-=arr[i][j];
                if(arr[i][j]==1)
                {
                if(num==2 || num==3) arr2[i][j]=1;
                else arr2[i][j]=0;
                }
                if(arr[i][j]!=1)
                {
                if(num==3) arr2[i][j]=1;
                else arr2[i][j]=0;
                }
            }
        }
        for(int i=0;i<8;i++)
        {
            for(int j=0;j<8;j++)
        {
            arr[i][j]=arr2[i][j];
        }
        }                         
    }
    for(int i=1;i<7;i++)
    {
        for(int j=1;j<7;j++)
        {
        if(j!=6)
        cout<<arr[i][j]<<" ";
        else cout<<arr[i][j]<<endl;        
        }
    }
    return 0;
}