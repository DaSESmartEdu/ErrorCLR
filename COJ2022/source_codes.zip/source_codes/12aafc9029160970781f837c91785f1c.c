#include <stdio.h>
void jiekouhanshu( float x, int *intpart, float *fracpart );
int main()
{
    float x, fracpart;
    int intpart;
    scanf("%f", &x);
    jiekouhanshu(x, &intpart, &fracpart);
    printf("%d ", intpart);
    printf("%.3f\n", fracpart);
    return 0;
}
void jiekouhanshu( float x, int *intpart, float *fracpart ){
	*intpart = (int)x;
	*fracpart = x- (*intpart);	
}