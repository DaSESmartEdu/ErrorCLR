#include <stdio.h>
int main()
{
    int n=0,sum=0;
    scanf("%d",&n);
    while(n>0){
        if((n%2)!=0){
            sum=sum+n;
        }
        else{}
        scanf("%d",&n);
    }
    printf("%d",sum);
    return 0;
}