#include <bits/stdc++.h>
int dir[4][2]={{1,0},{0,1},{-1,0},{0,-1}};
int flag[10][10];
int map[10][10];
int m,n;
int harf;
int min=100;
int check(int x,int y){
	if(x<0 || x>=m ||y<0 ||y>=n){
		return 1;
	}
	return 0;
}
void dfs(int sum, int x, int y, int count){
    int i;
    int sx,sy;
    if(sum==harf && flag[0][0]==1)
    {
        min=(min>count )? count:min;   
        return;
    }
  	else
    {
        for(i=0;i<4;i++)
        {
            sx=x+dir[i][0];
            sy=y+dir[i][1];
            if(!flag[sx][sy] && !check(sx,sy))
            {
                flag[sx][sy]=1;
                dfs(sum+map[sx][sy],sx,sy,count+1);
                flag[sx][sy]=0;
            }
        }
    }
}
int main(){
	int i,j;
    int sum=0;
    scanf("%d%d",&m,&n);
    for(i=0;i<m;i++)
        for(j=0;j<n;j++)
        {
            scanf("%d",&map[i][j]);
            sum+=map[i][j];
        }
    if(sum%2!=0)
        printf("0\n");
    else
    {
        harf=sum/2;
        for(i=0;i<m;i++)
            for(j=0;j<n;j++)
            {
                dfs(map[i][j],i,j,1);
            }
        if(min==100)
            printf("0\n");
        else
            printf("%d\n",min);
    }
    return 0;
}