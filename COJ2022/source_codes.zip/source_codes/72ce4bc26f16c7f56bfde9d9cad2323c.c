#include <stdio.h>
void delchar( char *str, char c );
int main()
{
    char c,ch;
    scanf("%c",&c);
    char *str=(char*)malloc(10000);
    int i=0;
    getchar();
    while((ch=getchar())!=EOF){
        str[i++]=ch;
    }
    str[i]='\0';
    delchar(str,c);
    return 0;
}
void delchar( char *str, char c )
{
    int j=0,i=0;
    char *str2=(char*)malloc(10000);
    for(j=0;str[j]!='\0';j++){
        if(str[j]!=c){
            str2[i]=str[j];
            i++;
        }
    }
    printf("%s",*str2);
}