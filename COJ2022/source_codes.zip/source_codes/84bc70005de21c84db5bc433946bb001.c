#include<stdio.h>
#include<math.h>
int main(){
    int a,n,k;
    int sum=0;
    int y=0,i=0;
    scanf("%d%d",&a,&n);
    for(k=n;k>=1;k--){
    for(i=k;i>=1;i--){
        sum+=a*pow(10,i-1);
    }
    }
    printf("%d",y);
    return 0;
}