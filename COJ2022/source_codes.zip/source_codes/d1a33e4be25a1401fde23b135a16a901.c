#include<stdio.h>
int main()
{
    int n,temp0,temp1,i,j;
    scanf("%d",&n);
    temp0 = (n+1)/2;
    temp1 = temp0 -1;
    for(i=1;i<=temp0;i++){
        for(j=1;j<=temp0-i;j++){
            printf(" ");
        }
        for(j=1;j<=2*i-1;j++){
            printf("*");
        }
        printf("\n");
    }
    for(i=1;i<=temp0-1;i++){
        for(j=1;j<=i;j++){
            printf(" ");
        }
        for(j=1;j<=temp0-2*i+3;j++){
            printf("*");
        }
        printf("\n");
    }
}