#include<stdio.h>
int main(){
    int n,m;
    scanf("%d%d",&n,&m);
    if(n<=m){
        printf("normal");
    }
    if(n>=m*1.1 && n<m*1.5){
        printf("200");
    }
    if(n>=m*1.5){
        printf("revoke");
    }
    return 0;
}