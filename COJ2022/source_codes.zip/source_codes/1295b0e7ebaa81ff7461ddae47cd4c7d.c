#include<stdio.h>
#include<stdlib.h>
struct point{
	int x;
	int y;
	int z;
};
int main()
{
	int n;
	scanf("%d",&n);
	struct point p[n];
	int i;
	for(i=0;i<n;++i){
		scanf("%d %d %d",&p[i].x,&p[i].y,&p[i].z);
	}
	int j;
	struct point tmp;
	for(i=0;i<n-1;++i){
		for(j=0;j<n-i-1;++j){
			if(p[j].x==p[j+1].x){
				if(p[j].y==p[j+1].y){
					if(p[j].z>p[j+1].z){
						tmp=p[j];
						p[j]=p[j+1];
						p[j+1]=tmp;
					}
				}else{
					if(p[j].y>p[j+1].y){
						tmp=p[j];
						p[j]=p[j+1];
						p[j+1]=tmp;
					}
				}
			}else{
				if(p[j].x>p[j+1].x){
					tmp=p[j];
					p[j]=p[j+1];
					p[j+1]=tmp;
				}
			}
		}
	} 
	for(i=0;i<n;++i){
		printf("%d %d %d\n",p[i].x,p[i].y,p[i].z);
	}
	return 0;
}