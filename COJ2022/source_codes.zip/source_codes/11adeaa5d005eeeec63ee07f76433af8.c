#include <stdio.h>
void CountOff(int n,int m,int out[])
{
    int order[n];
    for (int k=0;k<n;k++)
    {
        order[k]=0;
    }
    int place=1;
    int number=0;
    for (int i=1;i<=n;i++)
    {
        while (number<m)
        {
            if (order[place-1]==1)
            {  
                place++;
            }
            else
            {
                number++;
                if (number==m)
                {
                    out[place-1]=i;
                    number=0;
                    order[place-1]=1;
                    break;
                }
                place++;
            }
            if (place>n)
            {
                place=1;
            }
        }
    }
}
int main()
{
    int n,m;
    scanf("%d %d",&n,&m);
    int out[n];
    for (int j=0;j<n;j++)
    {
        out[j]=0;
    }
    int *p=out;
    CountOff(n,m,out);
    for (int i=0;i<n;i++)
    {
        printf("%d ",*(p+i));
    }
    return 0;
}