#include <stdio.h>
#include <string.h>
void StringCount(char str[]);
void StringCount(char str[])
{
    int z=0,k=0,s=0,q=0;
    int length=strlen(str);
    for(int i=0;  i<length-1;  i++)
    {
        if(str[i]>='A' && str[i]<='Z' || str[i]>='a'&& str[i]<='z')
        {
            z++;
        }
        else if(str[i]==' '||str[i]=='\n')
            k++;
        else if(str[i]>='0'&&str[i]<='9')
            s++;
        else q++;
    }
    printf("%d %d %d %d",z,k,s,q);
}
int main()
{
    char str[10000000];
    int i=0;
    while((str[i]=getchar()) != EOF)
    {
        i++;
    }
    StringCount(str);
    return 0;
}