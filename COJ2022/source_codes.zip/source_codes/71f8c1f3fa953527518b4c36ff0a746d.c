#include<stdio.h>
int main()
{int a,b;
 scanf("%d %d",&a,&b);
if (a<b){printf("normal");}
if (a>=(b*1.09)&&a<(b*1.5)){printf("200");}
	if (a>=(b*1.5)){printf("revoke");}
return 0;}