#include <stdio.h>
int main()
{
    int n, m;
    scanf("%d%d", &n, &m);
    if( n * 10 <= m * 11)
        printf("normal");
    else if (n * 10 <= m * 15)
        printf("200");
    else
        printf("revoke");
    return 0;
}