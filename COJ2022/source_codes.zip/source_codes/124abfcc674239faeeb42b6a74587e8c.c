#include<stdio.h>
#include<math.h>
int main()
{
	int m,n;int sum;
	scanf("%d %d\n",&m,&n);
	int a[m][n];
	for(int i=0;i<=m-1;i++)
	{
		for(int j=0;j<=n-1;j++)
		{
			scanf("%d ",&a[i][j]);
		}
	}
	for(int k=0;k<=m-1;k++)
	{
		sum=0;
		for(int l=0;l<=n-1;l++)
		{   
			sum+=a[k][l];
		}
		printf("%d ",sum);
	}
	return 0;
}