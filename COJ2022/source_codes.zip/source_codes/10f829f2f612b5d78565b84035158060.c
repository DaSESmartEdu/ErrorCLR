#include <stdio.h>
int main()
{
    int x;
    float price;
    scanf("%d",&x);
    if (x<=50)
  {
      price=x*0.53;
  } else{
      price=(x-50)*0.53+x*(0.53+0.05);
  }
printf("%f",price);
   return 0;
}