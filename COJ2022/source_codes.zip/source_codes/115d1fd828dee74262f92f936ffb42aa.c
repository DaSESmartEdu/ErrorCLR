#include <stdio.h>
int main()
{
    int a,b,c,e,f;
    scanf("%d %d %d %d",&a,&b,&c,&e);
    f=a+b+c+e;
    float g;
	g=f/4.0;
    printf("%d %.1f",f,g);
    return 0;
}