#include <stdio.h>
int main(int argc, char **argv) {
    int w=0 ;
    printf("w=:");
    scanf("%d",&w);
    float e=0;
    if (w<=50 ) 
    {
        e=0.53*w;
    }
    else 
    {
    e=0.53*50+(w-50)*0.58;
    }
    printf("%.1f",e);
    return 0;
}