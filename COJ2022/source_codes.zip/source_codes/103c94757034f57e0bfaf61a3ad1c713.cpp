#include <iostream>
#include <string.h>
using namespace std;
typedef char Stack_entry;
enum Error_code{underflow, overflow, success};
const int maxstack = 100; 
class MyStack {
public:
   MyStack();
   int size(){return count;};
   bool empty();
   Error_code pop();
   Error_code top(Stack_entry &item) ;
   Error_code push(Stack_entry &item);
private:
   int count;
   Stack_entry entry[maxstack];
};
MyStack::MyStack()
{
    count = 0;
}
Error_code MyStack::pop()
{
    Error_code outc = success;
    if(count == 0)
    {
        outc = underflow;
    }
    else
    {
        count--;
    }
    return outc;
}
Error_code MyStack::top(Stack_entry &item)
{
    Error_code outc = success;
    if(count == 0)
    {
        outc = underflow;
    }
    else
    {
        item = entry[count - 1];
    }
    return outc;
}
Error_code MyStack::push(Stack_entry &item)
{
    Error_code outc = success;
    if(count >= maxstack)
    {
        outc = overflow;
    }
    else
    {
        entry[count] = item;
        count++;
    }
    return outc;
}
bool MyStack::empty()
{
    bool outc = true;
    if (count > 0)
    {
        outc = false;
    }
    return outc;
}
int main()
{
    MyStack stack;
    string s;
    cin >> s;
    int flag = 0;
    for(int i = 0;i<=s.length();i++)
    {
        if(s[i] == '(' || s[i] == '[')
        {
            stack.push(s[i]);
        }
        else if(s[i] == ')')
        {
            char op1;
            stack.top(op1);
            if(op1 == '(')
            {
                stack.pop();
            }
            else
            {
                flag = 1;
            }
        }
        else if(s[i] == ']')
        {
            char op2;
            stack.top(op2);
            if(op2 == '[')
            {
                stack.pop();
            }
            else
            {
                flag = 1;
            }
        }         
    }
    if(stack.empty() == false)
        {
            flag = 1;
        }
    cout<<flag;
    return 0;
}