#include <stdio.h>
int main()
{
    int n,i,j,u;
    scanf("%d",&n);
    for (i=1;i<=n;i++)
    {
        for (j=1;j<=n;j++)
        {
            if (i<=(n+1)/2)
            {
                if (j>=(n+1)/2-i+1&&j<=(n+1)/2+i-1)
                {
                    printf("*");
                }
                else
                {
                    printf(" ");
                }
            }
            else
            {
                if (j>=i-(n-1)/2&&j<=(3*n+1)/2-i)
                {
                    printf("*");
                }
                else
                {
                    printf(" ");
                }
            }
        }
        printf("\n");
    }
    return 0;
}