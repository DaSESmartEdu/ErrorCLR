#include <stdio.h>
int search(int n)
{
  int i,j;
  int a,b,c;
  int cnt=0;
  for(i=101;i<=n;i++)
  {
    for(j=11;j<=40;j++)
    {
      if(j*j==i)
      {
        a=i%10;
        c=i/100;
        b=((i-a)/10)%10;
        if(a==b&&a==c&&b==c)
        {
          cnt++;
        }
      }
    }
  }
  return cnt;
}
int main()
{
  int n;
  scanf("%d",&n);
  printf("%d",search(n));
  return 0;
}