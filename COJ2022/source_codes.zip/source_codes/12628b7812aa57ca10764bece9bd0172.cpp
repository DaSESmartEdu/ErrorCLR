import java.util.Scanner;
public class Main {
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		int num = scanner.nextInt();
		if (num == 0) {
			System.out.println(0);
		} else {
			boolean f = num < 0 ? true : false;
			num = Math.abs(num);
			char[] cs = Integer.toString(num).toCharArray();
			int re = 0;
			int mul = 1;
			for (int i = 0; i < cs.length; i++) {
				re += (cs[i] - '0') * mul;
				mul *= 10;
			}
			if (f) {
				System.out.print("-");
			}
			System.out.println(re);
		}
	}
}