#include <stdio.h>
int main()
{
    int a=0;
    scanf("%d",&a);
    if(a<=50)
    {
        printf("%f",a*0.53);
    }
    else
    {  
        printf("%f",50*0.53+(a-50)*0.58);
    }
    return 0;
}