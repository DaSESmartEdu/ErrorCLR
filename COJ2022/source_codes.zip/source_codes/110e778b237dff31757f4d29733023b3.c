#include<stdio.h>
struct book
{
    char name[100];
    double price;
};
int main ()
{
    int n,i;
    int p=0,q=0;
    scanf("%d\n",&n);
    double max,min;
    struct book b[10];
    max=0.0;
    min=99999;
    for(i=0;i<n;i++)
    {
        scanf("\n");
        gets(b[i].name); 
        scanf("%lf",&b[i].price);
        if(b[i].price<min)
        {
            min = b[i].price;
            p=i;
        }
        if(b[i].price>max)
        {
            max = b[i].price;
            q=i;
        }
    }
    printf("%.2lf,%s\n",max,b[q].name);
    printf("%.2lf,%s",min,b[p].name);
    return 0;
}