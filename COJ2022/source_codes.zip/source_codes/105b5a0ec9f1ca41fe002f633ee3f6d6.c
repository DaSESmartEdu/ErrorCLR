#include <stdio.h>
int main()
{
  int a,i,t,sum,n;
  scanf ("%d &d",&a,&n);
  t=a;
  sum=t;
  for(i=2;i<=n;i++){
    a=10*a+t;
    sum=sum+a;
  }
  printf ("%d",sum);
  return 0;
}