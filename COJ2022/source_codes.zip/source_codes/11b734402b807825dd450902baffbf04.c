#include <stdio.h>
#include <stdlib.h>
#include <string.h>
void StringCount(char str[])
{
    int length = strlen(str);
    int letter = 0;
    int space = 0;
    int digit = 0;
    int other = 0;
    for (int i = 0; i < length; i++)
    {
        if (str[i] >= 'A' && str[i] <= 'Z' || str[i] >= 'a' && str[i] <= 'z')
            letter++;
        else if (str[i] == ' ' || str[i] == '\n')
            space++;
        else if (str[i] >= '0' && str[i] <= '9')
            digit++;
        else
        {
            if (str[i] != EOF)
                other++;
        }
    }
    printf("%d %d %d %d ", letter, space, digit, other);
}
int main()
{
    char str[100000];
    int i = 0;
    while ((str[i] = getchar()) != EOF)
    {
        i++;
    }
    StringCount(str);
}