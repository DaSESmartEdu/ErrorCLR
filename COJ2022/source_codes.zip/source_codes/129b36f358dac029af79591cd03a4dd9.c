#include<stdio.h>
int main()
{
  double a,b,c,d;
  scanf("%lf%lf%lf%lf",&a,&b,&c,&d);
  if(a*c+b*d==0)
    printf("1");
  else if(a*d==b*c)
    printf("2");
  else{
    printf("0");
  }
  return 0;
}