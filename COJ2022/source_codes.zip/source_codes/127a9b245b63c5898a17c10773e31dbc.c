#include <stdio.h>
#include <stdlib.h>
int** initMat(int m, int n){
    int** mat = (int**)malloc(sizeof(int*)*m);
    for (int i=0; i<m; ++i){
        mat[i] = (int*)malloc(sizeof(int)*n);
        if (mat[i] == NULL) printf("ERROR!");
    }
    return mat;
}
void printMat(int** mat, int m, int n){
    for (int i=0; i<m; ++i){
        printf("%d", mat[i][0]);
        for (int j=1; j<n; ++j){
            printf(" %d", mat[i][j]);
        }
        printf("\n");
    }
}
void addMat(int** dst, int** src, int m, int n){
    for (int i=0; i<m; ++i){
        for (int j=0; j<n; ++j){
            dst[i][j] += src[i][j];
        }
    }
}
void setMat(int** dst, int** src, int m, int n, int rOff, int cOff){
    for (int i=0; i<m; ++i){
        for (int j=0; j<n; ++j){
            dst[rOff+i][cOff+j] = src[i][j];
        }
    }
}
void multMat_naive(int** dst, int** A, int** B, int m, int p, int n){
    for (int i=0; i<m; ++i){
        for (int j=0; j<n; ++j){
            dst[i][j] = 0;
            for (int k=0; k<p; ++k){
                dst[i][j] += A[i][k] * B[k][j];
            }
        }
    }
}
void multMat_DCR(int** dst, int** A, int** B, int m, int p, int n){
    if ( (m != p) || (p != n) || (m<=64) ){
        multMat_naive(dst, A, B, m, p, n);
        return;
    }
    int r_u = m / 2;
    int r_d = m - r_u;
    int c_l = n / 2;
    int c_r = n - c_l;
    int **a = initMat(r_u, c_l);
    int **b = initMat(r_u, c_r);
    int **c = initMat(r_d, c_l);
    int **d = initMat(r_d, c_r);
    int **e = initMat(r_u, c_l);
    int **f = initMat(r_u, c_r);
    int **g = initMat(r_d, c_l);
    int **h = initMat(r_d, c_r);
    for (int i=0; i<r_u; ++i){
        for (int j=0; j<c_l; ++j){
            a[i][j] = A[i][j];
            e[i][j] = B[i][j];
        }
        for (int j=0; j<c_r; ++j){
            b[i][j] = A[i][j+c_l];
            f[i][j] = B[i][j+c_l];
        }
    }
    for (int i=0; i<r_d; ++i){
        for (int j=0; j<c_l; ++j){
            c[i][j] = A[i+r_u][j];
            g[i][j] = B[i+r_u][j];
        }
        for (int j=0; j<c_r; ++j){
            d[i][j] = A[i+r_u][j+c_l];
            h[i][j] = B[i+r_u][j+c_l];
        }
    }
    int **ae = initMat(r_u, c_l);
    int **bg = initMat(r_u, c_l);
    multMat_DCR(ae, a, e, r_u, c_l, c_l);
    multMat_DCR(bg, b, g, r_u, c_r, c_l);
    addMat(ae, bg, r_u, c_l); free(bg);
    setMat(dst, ae, r_u, c_l, 0, 0); free(ae); 
    int **af = initMat(r_u, c_r);
    int **bh = initMat(r_u, c_r);
    multMat_DCR(af, a, f, r_u, c_l, c_r); free(a);
    multMat_DCR(bh, b, h, r_u, c_r, c_r); free(b);
    addMat(af, bh, r_u, c_r); free(bh); 
    setMat(dst, af, r_u, c_r, 0, c_l); free(af);  
    int **ce = initMat(r_d, c_l);
    int **dg = initMat(r_d, c_l);
    multMat_DCR(ce, c, e, r_d, c_l, c_l); free(e);
    multMat_DCR(dg, d, g, r_d, c_r, c_l); free(g);
    addMat(ce, dg, r_d, c_l); free(dg);
    setMat(dst, ce, r_d, c_l, r_u, 0); free(ce);
    int **cf = initMat(r_d, c_r);
    int **dh = initMat(r_d, c_r);
    multMat_DCR(cf, c, f, r_d, c_l, c_r); free(c); free(f);
    multMat_DCR(dh, d, h, r_d, c_r, c_r); free(d); free(h); 
    addMat(cf, dh, r_d, c_r); free(dh);
    setMat(dst, cf, r_d, c_r, r_u, c_l); free(cf);
}
int main(){
    int N, M;
    scanf("%d %d", &N, &M);
    for (int cnt=0; cnt<N; ++cnt){
        int** A = initMat(M, M);
        int** B = initMat(M, M);
        for (int i=0; i<M; ++i){
            for (int j=0; j<M; ++j){
                scanf("%d", &A[i][j]);
            }
        }
        for (int i=0; i<M; ++i){
            for (int j=0; j<M; ++j){
                scanf("%d", &B[i][j]);
            }
        }
        int** C2 = initMat(M, M);
        multMat_DCR(C2, A, B, M, M, M);
        printMat(C2, M, M);
        free(C2);
        free(A); free(B);
    }
    return 0;
}