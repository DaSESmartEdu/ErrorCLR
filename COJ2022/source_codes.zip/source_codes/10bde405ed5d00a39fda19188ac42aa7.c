#include<stdio.h>
#include<stdlib.h>
#include<string.h>
int main()
{
	char *s[10];
	int n;
	scanf("%d",&n);
	int i=0;
	while(i<10)
	{
		s[i]=(char *)malloc(100*sizeof(char));
		i=i+1;
	}
	i=0;
	int t1=0;
	int t2=0;
	while(i<n)
	{
		scanf("%s",s[i]);
		t1=strlen(s[i]);
		if(t1>t2)
		{
			t2=t1;
		}
		i=i+1;
	}
	printf("%d",t2);
	return 0;
}