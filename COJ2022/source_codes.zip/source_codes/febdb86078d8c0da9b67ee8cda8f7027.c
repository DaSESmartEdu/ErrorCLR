#include <stdio.h>
int main()
{
    char a[80],b[80],c[80],d[80],e[80];
    scanf("%s %s %s %s %s",&a,&b,&c,&d,&e);
    char *list[6]={a,b,c,d,e};
    char *k;
    int i,j;
    for(i=0;i<5;i++)
    {
        for(j=1;j<(5-i);j++)
        {
            if(*list[j]<*list[j-1])
            {
                k=list[j];
                list[j]=list[j-1];
                list[j-1]=k;
            }
        }
    }
    list[i]='\0';
    printf("After sorted:\n");
    for(i=0;i<5;i++)
    printf("%s\n",list[i]);
    return 0;
}