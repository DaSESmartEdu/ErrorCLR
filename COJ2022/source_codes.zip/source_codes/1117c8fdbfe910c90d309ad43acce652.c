#include<stdio.h>
int fib( int n );
void PrintFN( int m, int n );
int main()
{
    int m,n;
    scanf("%d %d",&m,&n);
    int t;
    scanf("%d",&t);
    printf("%d\n",fib(t));
    PrintFN(m,n);
    return 0;
}
int fib( int n )
{
    int a[n],i;
    a[1]=1;
    a[2]=1;
    for ( i =3; i <=n; i++)
    {
        a[i]=a[i-1]+a[i-2];
    }
    return a[n];
}
void PrintFN( int m, int n )
{
    int count=0;
    int i=1;
    for(i=1;i<=n;i++)
    {
        if(fib(i)>=m&&fib(i)<=n)
        {
           count++;
        }
    }
    int j;int flag=0;
    for ( i = 1; i <=n-m; i++)
        {
            if (fib(i)>=m&&fib(i)<=n)
            {
                printf("%d",fib(i));
                if (count>1)
                {
                    printf(" ");
                    count--;
                }
                flag=1;
            }
        }
      if (flag==0)
      {
          printf("No Fibonacci number");
      }
 }