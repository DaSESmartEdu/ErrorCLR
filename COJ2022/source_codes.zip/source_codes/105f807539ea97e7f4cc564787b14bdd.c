#include <stdio.h>
int main(){
    int x;
    int s = 0;
    while(1){
        scanf("%d", &x);
        if (x<=0) break;
        if (x%2) s += x;
    }
    printf("%d", s);
    return 0;
}