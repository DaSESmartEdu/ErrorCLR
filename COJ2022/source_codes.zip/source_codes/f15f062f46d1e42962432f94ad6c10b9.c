#include<stdio.h>
#include<math.h>
int prime(int p){
    if(p<2)return 0;
    else{
        int i=2;
        while(i<=sqrt(p)){
            if(p%i==0){
                return 0;
                break;
            }
            i++;
        }
        if(i>sqrt(p))return 1;
    }
}
int PrimeSum(int m,int n){
    int i=m,sum;
    while(i<=n){
        if (prime(i)==1)sum+=i;
        i++;
    }
    return sum;
}
int main(){
    int m,n;
    scanf("%d %d",&m,&n);
    printf("%d",PrimeSum(m,n));
    return 0;
}