#include <stdio.h> 
#include <math.h>
void rank(int s[],int e[],int n){
	int m,k,i,j;
	for(i=n-1;i>=0;i--){
		for(j=0;j<i;j++){
			if(e[j]>e[i]){
				m=e[i];
				e[i]=e[j];
				e[j]=m;
				k=s[i];
				s[i]=s[j];
				s[j]=k;
			}
		}
    }
}
int main(void){
	int n,i,j;
	while((scanf("%d",&n))!=-1&&n!=0){
	    int s[100]={0},e[100]={0},pros,proe;
		for(i=0;i<n;i++)
		scanf("%d%d",&s[i],&e[i]);
		rank(s,e,n);
		pros=s[0];
		proe=e[0];
		int now=1;
		for(j=0;j<=n-1;j++){
			if(s[j]>=proe){
				now++;
				pros=s[j];
				proe=e[j];
			}
		}
		printf("%d\n",now);
	}
	return 0;
}