#include<stdio.h>
int main()
{
    int a,b;
    scanf("%d %d",&a,&b );
    if (a<=b)
    {
        printf("normal");
    }
    else if (1.1*b <a && a<1.5*b)
    {
        printf("200");
    }
    else if (a>=1.5*b)
    {
        printf("revoke");
    }
    else
    {
        printf("你超速啦！");
    }
}