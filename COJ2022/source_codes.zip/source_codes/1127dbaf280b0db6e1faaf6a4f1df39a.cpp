#include <bits/stdc++.h>
#define rep(i, l, r) for(int i = l, i##end = r; i <= i##end; ++i)
#define per(i, l, r) for(int i = r, i##end = l; i >= i##end; --i)
#define repo(i, l, r) for(int i = l, i##end = r; i < i##end; ++i)
#define debug(x) cerr << #x << " : " << x << " " << endl
using namespace std;
struct node {
	int v;
	node *nxt;
};
struct LinkList {
	node *head;
	LinkList() {
		head = new node;
		head->nxt = NULL;
	}
	void del(node *p) {
		node *q = p->nxt;
		p->nxt = q->nxt;
		delete q;
	}
	node* insert(node *p, int v) {
		node *q = new node;
		q->v = v;
		q->nxt = p->nxt;
		p->nxt = q;
		return q;
	}
	bool empty() {
		return head->nxt == NULL;
	}
	char first() {
		return head->nxt->v;
	}
	node* find(int x) {
		node* p = head->nxt;
		while (p && p->v != x) p = p->nxt;
		return p;
	}
} LL;
int main() {
	int n, m;
	cin >>n >>m;
	map <int, bool> S;
	node *p = LL.head;
	rep (i, 1, n) {
		int x;
		scanf("%d", &x);
		p = LL.insert(p, x);
	}
	int res = 0;
	p = NULL;
	rep (i, 1, m) {
		int x;
		scanf("%d", &x);
		if (p == NULL || p->nxt == NULL || p->nxt->v != x) {
			p = LL.find(x);
			res++;
		}
		else p = p -> nxt;
	}
	cout << res << endl;
	return 0;
}