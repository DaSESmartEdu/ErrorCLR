#include <stdio.h>
int pow(int a,int b){
    int s=1,i=1;
    for(i=1;i<=b;i++){
        s*=a;
    }
    return s;
}
int main(){
    int n,sum=0,count=0;
    int i=pow(10,n-1);
    int a,b;
    scanf("%d",&n);
for(i=pow(10,n-1);i<=pow(10,n)-1;i++){
    b=i;
    sum=0;
    int k;
    for(k=n;k>=1;k--){
        a=b/pow(10,k-1);
        sum+=pow(a,n);
        b=i%pow(10,k-1);
    }
    if(sum==i) count+=1;
    printf("%d %d\n",i,sum);
}
    printf("%d",count);
}