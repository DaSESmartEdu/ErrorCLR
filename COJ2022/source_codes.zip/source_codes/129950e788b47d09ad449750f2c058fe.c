#include<stdio.h>
#include<string.h>
void delchar(char *str,char c);
int main(void)
{
    char c,t[100];
    scanf("%c\n",&c);
    gets(t);
    delchar(t,c);
    return 0;
}
void delchar(char *str,char c)
{
    int i,j;
    for(i=j=0;str[i]!='\0';i++)
    {
        if(str[i]!=c)
        {
            str[j++]=str[i];
        }
    }
    str[j]='\0';
    puts(str);
}