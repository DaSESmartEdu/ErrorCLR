#include<stdio.h>
int str(int N)
{
	if (N==1)
	printf("A");
	else
	{
		str(N-1);
		printf("%c",N+'A'-1);
		str(N-1);
	}
return 0;
}
int main()
{
	int N;
	scanf("%d",&N);
	str(N);
	return 0;
}