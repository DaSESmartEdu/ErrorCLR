#include <stdio.h>
int main()
{
    int n,i;
    double b=2,c=1,a=0,d=0;
    double sum=2.0;
    scanf("%d",&n);
    for(i=1;i<n;i++)
    {
        a=(b+c)/b;
        d=b,b=b+c;
        c=d;
        sum+=a;
    }
    printf("%.2f",sum);
    return 0;
}