#include <stdio.h>
int even(int n)
{
    if(n%2==0){
        return 1;
    }
    else 
    {
        return 0;
    }
}
int OddSum( int List[], int t )
{
	int sum=0,m;
	for(m=0;m<t;m++)
	{
		if(even(List[m])==0)
		sum+=List[m];
	}
	return sum;
}
int main()
{    
    int List[10], n, i;
    scanf("%d", &n);
    for ( i=0; i<n; i++ ) {
        scanf("%d", &List[i]);
    }
    printf("%d", OddSum(List, n));
    return 0;
}