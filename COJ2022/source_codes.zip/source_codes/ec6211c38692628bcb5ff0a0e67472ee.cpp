#include <iostream>
using namespace std;
struct node{
    int x, y;
};
typedef struct node pt;
int n;
bool cmp(pt a, pt b) {
    return (a.x*a.x + a.y*a.y) >= (b.x*b.x+b.y*b.y);
}
pt find_pivot(pt b[], int left, int right){
    int mid = (left + right) / 2;
    if (cmp(b[left], b[mid])) swap(b[left], b[mid]);
    if (cmp(b[mid], b[right])) swap(b[right], b[mid]);
    if (cmp(b[left], b[mid])) swap(b[left], b[mid]);
    swap(b[mid], b[right-1]);
    return b[right-1];
}
void b_s(pt b[], int left, int right){
    if (left >= right) return;
    pt pivot = find_pivot(b, left, right);
    int low = left, high =  right-1;
    int mid = (left+right) / 2;
    while (low <= high){
        while (cmp(pivot,b[low])) low++;
        while (cmp(b[high], pivot)) high--;
        if (low > high){break;}
        swap(b[low],b[high]);
    }
    swap(b[low], b[right-1]);
    b_s(b, left, low);
    b_s(b, low+1, right);
}
int main(){
    cin >> n;
    pt b[n];
    for (int i = 0; i < n; i++){
        cin >> b[i].x >> b[i].y;
    }
    int k; cin >> k;
    b_s(b, 0, n-1);
    cout << b[k-1].x << " " << b[k-1].y;
}