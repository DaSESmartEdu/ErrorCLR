#include<stdio.h>
#include<math.h>
int main()
{
    double a,b,c;
    scanf("%lf %lf",&a,&b);
    if(a<=3)
    c=10+b/5.0*2;
    else if(a<=10)
    c=10+(a-3)*2+b/5.0*2;
    else if(a>10)
    c=24+(a-10)*3+b/5.0*2;
    if(floor(c)==floor(c+0.5))
    c=floor(c);
    else
    c=floor(c+0.5);
    printf("%.0f",c);
    return 0;
}