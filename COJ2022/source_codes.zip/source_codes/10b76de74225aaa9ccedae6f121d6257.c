#include<stdio.h>
struct cp
{
    double a;
    double b;
};
int main()
{
    struct cp c[3];
    scanf("%lf %lf %lf %lf",&c[0].a,&c[0].b,&c[1].a,&c[1].b);
    printf("(%.1f, %.1f)",c[0].a+c[1].a,c[0].b+c[1].b);
    return 0;
}