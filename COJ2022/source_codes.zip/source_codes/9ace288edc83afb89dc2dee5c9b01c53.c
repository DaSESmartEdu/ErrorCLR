#include <stdio.h>
int main ()
{
	int a,b,c,d;
    scanf("%d",&a);
    scanf("%d",&b);
    scanf("%d",&c);
    scanf("%d",&d);
    int y=(a+b+c+d);
    float x=y/4.0;
    printf("%d\n %.1f\n" ,y,x);
    return 0;
}