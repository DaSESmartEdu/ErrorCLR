#include<stdio.h>
int main()
{
	int n;int t;
	scanf("%d",&n);
	double sum=0;
	int i;
	double x,y;
	x=2.0;y=1.0;
	for (i=1;i<=n;i++) {sum+=x/y;t=x;x=x+y;y=t;}
	printf("%.4f",sum);
	return 0;
}