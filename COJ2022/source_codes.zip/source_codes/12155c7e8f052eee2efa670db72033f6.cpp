#include<iostream>
using namespace std;
int main(){
	double v1,v2,t,s,l1;cin>>v1>>v2>>t>>s>>l1;double l2=l1;int time=0;
	while(l1&&l2>0){
		if(l2-l1>=t){
			if(l2/v2>=s)
				time+=s;
			else time+=l2/v2;
			l2-=v2*s;
		}
		else if(l2-l1<t){
			l1-=v1;l2-=v2;time++;
		}
	}
	if(l1<=0&&l2>0){
		cout<<"R"<<endl;
		cout<<time;
	}
	else if(l1>0&&l2<=0){
		cout<<"T"<<endl;
		cout<<time;
	}
	else if(l1==0&&l2==0){
		cout<<"D"<<endl;
		cout<<time;
	}
	return 0;
}