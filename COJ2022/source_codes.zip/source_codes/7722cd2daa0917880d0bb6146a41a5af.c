#include <stdio.h>
int main()
{
  int a,n,i;
  double sum,result,x;
  sum=0;
  result=0;
  scanf("%d %d",&a,&n);
  for(i=0;i<n-1;i++)
  {
    result=result*10+a;
    sum=sum+result;
  }
  printf("%d",sum);
  return 0;
}