#include<stdio.h>
int main()
{
	int n;
	int i;
	double sum=0;
	scanf("%d",&n);
	for(i=1;i<=n;i++)
	{
		if(i%2!=0)
			sum=sum+i/(2*i-1);
		else
			sum=sum-i/(2*i-1);
	}
	printf("%.6f",sum);
	return 0;
}