#include<iostream>
using namespace std;
int arr1[1000][1000];
int arr2[1000][1000];
int main()
{
    ios::sync_with_stdio(false); 
    int n,m,arr;
    cin>>n>>m;
    for(int i=0;i<n;i++)
    {
        for(int a=0;a<m;a++)
        {
            for(int b=0;b<m;b++)
            cin>>arr1[a][b];
        }
        for(int a=0;a<m;a++)
        {
            for(int b=0;b<m;b++)
            cin>>arr2[a][b];
        }
        for(int a=0;a<m;a++)
        {
            for(int b=0;b<m;b++)
            {
                arr=0;
                for(int c=0;c<m;c++)
                {
                    arr=arr+arr1[a][c]*arr2[c][b];
                }
                cout<<arr;
                if(b!=m-1) cout<<" ";
            }
            cout<<"\n";
        }
    }
    return 0;
}