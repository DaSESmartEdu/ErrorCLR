#include <bits/stdc++.h>
using namespace std;
void insertSort(vector<int> &vec, int l, int r)
{
    for (int i = l; i <= r; ++i)
    {
        int j = i;
        while (j - 1 >= 0 && vec[j - 1] > vec[j])
        {
            vec[j - 1] = vec[j - 1] + vec[j];
            vec[j] = vec[j - 1] - vec[j];
            vec[j - 1] = vec[j - 1] - vec[j];
            --j;
        }
    }
}
int Partition(vector<int> &A, int p, int r)
{
    int x = A[r];
    int i = p - 1;
    for (int j = p; j < r; j++)
    {
        if (A[j] <= x)
        {
            i++;
            swap(A[i], A[j]);
        }
    }
    swap(A[i + 1], A[r]);
    return i + 1;
}
int findmid(vector<int> &A, int l, int r) 
{
    int mid;
    if ((r - l) <= 4)
    {
        insertSort(A, l, r);
        mid = (r + l) / 2;
        return A[mid];
    }
    int num = (r - l + 1) / 5 + ((r - l + 1) % 5 != 0); 
    vector<int> A_mid(num);                             
    for (int i = 0; i < num; ++i)
    {
        int left = 5 * i + l;
        int right;
        if (left + 4 <= r)
        {
            right = l + 4;
        }
        else
        {
            right = r;
        }
        mid = (left + right) / 2;
        insertSort(A, left, right);
        A_mid[i] = A[mid];
    }
    return findmid(A_mid, 0, num - 1);
}
int SELECT(vector<int> &A, int l, int r, int i)
{
    if (l == r)
    {
        return A[l];
    }
    int median = findmid(A, l, r);
    for (int i = 0; i <= r; i++)
    {
        if (A[i] == median)
        {
            swap(A[i], A[r]);
            break;
        }
    }
    int q = Partition(A, l, r);
    int k = q - l + 1;
    if (i == k)
    {
        return median;
    }
    else if (i < k)
    {
        return SELECT(A, l, q - 1, i);
    }
    else
    {
        return SELECT(A, q + 1, r, i - k);
    }
}
int main()
{
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    int n;
    cin >> n;
    vector<int> a(n);
    int i = 0;
    while (i != n)
    {
        cin >> a[i];
        i++;
    }
    cout << SELECT(a, 0, n - 1, n / 2);
    return 0;
}