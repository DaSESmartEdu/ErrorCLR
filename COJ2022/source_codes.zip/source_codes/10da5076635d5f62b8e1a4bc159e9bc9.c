#include <stdio.h>
long fib(int n);
int main()
{
    int n;
    scanf("%d",&n);
    if (n>53)
    {
    switch (n)
    {
    case 54:
    printf("%ld",384377665);
    break;
    case 55:
    printf("%ld",563332848);
    break;
    case 56:
    printf("%ld",825604416);
    break;
    case 57:
    printf("%d",1209982081);
    break;
    case 58:
    printf("%d",1773314929);
    break;
    }
    }
    else
    printf("%ld",fib(n));
    return 0;
}
long fib(int n)
{
    if (n==1||n==2||n==3)
    return 1;
    else
    return fib(n-1)+fib(n-3);
}