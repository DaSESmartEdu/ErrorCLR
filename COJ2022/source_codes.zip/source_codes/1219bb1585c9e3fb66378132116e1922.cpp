#include<bits/stdc++.h>
using namespace std;
vector<string> split(const string &str, const char &todel)
{
    vector<string> tmp;
    stringstream s0(str);
    static string s1;
    while (getline(s0, s1, todel))
    {
        tmp.emplace_back(s1);
    }
    return tmp;
}
class node
{
    public:
    node(vector<string> list):num(list[0]),spa(list[1]),name(list[2]),add(list[3]),
    tel(list[4]),time(list[5]),price(list[6]){left = NULL; right = NULL;}
    node(string num, string spa, string name, string add, string tel, string time, string price):num(num),spa(spa),name(name),add(add),
    tel(tel),time(time),price(price){left = NULL; right = NULL;}
    string num;
    string spa, name, add, tel, time, price;
    node *left;
    node *right;
    void print()
    {
        cout << "{\"序号\":\"" +num+\
         "\",\"区县\":\"" +spa+\
         "\",\"场馆名称\":\"" +name+\
        "\",\"地址\":\"" +add+ \
        "\",\"联系电话\":\"" +tel+ \
        "\",\"开放时间\":\"" +time+ \
        "\",\"收费标准\":\"" +price+ "\"}";
    }
    node* insert(node* tmp)
    {
        if (this == NULL) return tmp;
        if (tmp->name < this->name)
        {
            this->left = this->left->insert(tmp);
            return this;
        }
        else
        {
            this->right = this->right->insert(tmp);
            return this;
        }
    }
};
bool compare(string a, string b)
{
    if (a.length() < b.length())
    return false;
    for (int i = 0; i < b.length(); i++)
    {
        if (a[i] != b[i])
        return false;
    }
    return true;
}
void search(node* root, string target, int &num)
{
    if (root == NULL)
    return;
    search(root->left, target, num);
    if (target<=root->name)
    {
        if (compare(root->name,target))
        {
            if (num != 0)
            {
                cout << ",";
            }
            num++;
            root->print();
        }
    }
    search(root->right, target, num);
}
int main()
{
	cin.tie(0);
    int n;
    cin >> n;
    getchar();
    node* root = NULL;
    for (int i = 0; i < n; i++)
    {
        string temp;
        getline(cin,temp);
        vector<string> use = split(temp,',');
        if (i == 0)
        root = new node(use);
        else
        {
        node* s = new node(use);
        root->insert(s);
        }
    }
    int m;
    cin >> m;
    getchar();
    for (int i = 0; i < m; i++)
    {
        string temp;
        int num = 0;
        cin >> temp;
        cout << '[';
        search(root, temp, num);
        cout << ']' << endl;
    }
    return 0;
}