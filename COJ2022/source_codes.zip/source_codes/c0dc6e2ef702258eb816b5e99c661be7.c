#include<stdio.h>
int main()
{
    int sum;
    scanf("%d",&sum);
    if (sum <= 50)
    {
        printf("%f",sum * 0.53) ;
    }
    else
    {
       printf("%f",50 * 0.53 + (sum - 50) * 0.58); 
    }
    return 0;
}