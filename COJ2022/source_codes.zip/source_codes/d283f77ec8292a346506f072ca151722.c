#include <stdio.h>
int main()
{
    double s=0;
    double t=0;
    double m=0;
    int  n=0;
    double sum=0;
    scanf("%lf %lf",&s,&t);   
    if(s<=3.0)
    {m=10.0;}
    else if(s>3.0 && s<=10.0)
    {m=10.0+(s-3.0)*2;}
    else if (s>10.0)
    {m=10.0+7*2.0+(s-10.0)*3.0;}
    if (t<5)
    {n=0;}
    if (t>=5)
    { while(t>5)
    { t=t-5;
    n=n+2;
    }
        ;}
    sum=m+n;
    int u=(sum*10+5)/10;
    printf("%d",u);
}