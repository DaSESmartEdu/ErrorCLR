#include <stdio.h>
int CountDigit(int number,int digit);
int main(){
     int number,digit,num;
     scanf("%d %d",&number,&digit);
     num=CountDigit(number,digit);
     printf("%d",num);
     return 0;
}
int CountDigit(int number,int digit){
    int result=0,f;
    while(number!=0){
        f=number%10;
        if(f==digit) result+=1;
        number/=10;
    }
    return result;
}