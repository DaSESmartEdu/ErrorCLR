#include<iostream>
using namespace std;
int main() {
	int n;
	char a = 'A';
	string str="A";
	cin >> n;
	for (int i = 0; i < n-1; ++i) {
		a = char(a + 1);
		str = str + string(1,a) + str;
	}
	cout << str;
}