#include<stdio.h>
struct friend
{
    char name[10];
    int birthday;
    char phnum[30];
}; 
int main()
{
    int n;
    struct friend friends[10],temp;
    scanf("%d",&n);
    int i=0;
    for(i=0;i<n;i++)
    {
        scanf("%s %d %s",&friends[i].name,&friends[i].birthday,&friends[i].phnum);
    }
    int index=0;
    int j=0,k=0;
    for(j=0;j<n-1;j++)
    {
        index=j;
        for(k=j+1;k<n;k++)
        {
            if(friends[k].birthday>friends[index].birthday)
            {
                index=k;
            }
        }
        temp=friends[index];
        friends[index]=friends[j];
        friends[j]=temp;
    }
    for(int m=0;m<n;m++)
    {
        printf("%s %d %s\n",friends[m].name,friends[m].birthday,friends[m].phnum);
    }
    return 0;
}