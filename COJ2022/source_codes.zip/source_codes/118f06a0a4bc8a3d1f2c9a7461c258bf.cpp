#include <bits/stdc++.h>
using namespace std;
void ANUM(int x) {
	map<int, string> AT = {
		{0,"zero"},
		{1,"one"},
		{2,"two"},
		{3,"three"},
		{4,"four"},
		{5,"five"},
		{6,"six"},
		{7,"seven"},
		{8,"eight"},
		{9,"nine"},
		{10,"ten"},
		{11,"eleven"},
		{12,"twelve"},
		{13,"thirteen"},
		{14,"fourteen"},
		{15,"fifteen"},
		{16,"sixteen"},
		{17,"seventeen"},
		{18,"eighteen"},
		{19,"nineteen"},
		{20,"twenty"},
		{30,"thirty"},
		{40,"forty"},
		{50,"fifty"}
	};
	if(x>=0 && x<=20) cout<<AT[x];
	else{
		int shi = (x/10) * 10;
		int ge = x % 10;
		cout<<AT[shi]<<" "<<AT[ge];
	}
}
void Announce(int h,int m){
	if(m==0) {
		ANUM(h);
		cout<<" o'clock\n";
	}else{
		ANUM(h);
		cout<<" ";
		ANUM(m);
	}
}
int main(){
	int m,h;
	cin>>h>>m;
	Announce(h,m);
	cout<<endl;
	return 0;
}