#include<stdio.h>
#include<string.h>
char* mycat(char* a1,char* a2){
	int n1=strlen(a1);
	int n2=strlen(a2);
	int i=0;
	char *a3=(char*)malloc((n1+n2+1)*sizeof(char));
	for(i;i<n1+n2;i++){
		if(i<n1){
			*(a3+i)=*(a1+i);
		}
		else{
			*(a3+i)=*(a2+i-n1);
		}
		*(a3+n1+n2)='\0';
	}
	return a3;
}
char* link(int x){
	char* a;
	if(x==1){
		a="A\0";
		return a;
	}
	else{
		char* b=(char*)malloc(2*sizeof(char));
		b[0]=(char)(x+64);
		*(b+1)='\0';
		a=mycat(mycat(link(x-1),b),link(x-1));
		free(b);
		return a;
	}
}
int main(){
	int n;
	scanf("%d",&n);
	char *s=link(n);
	puts(s);
	return 0;
}