#include<stdio.h>
int sign(int x);
int main()
{
    int x;
    scanf("%d",&x);
    int result=sign(x);
    printf("%d",result);
}
int sign(int x)
{
    int result;
    if(x>0)
        result=1;
    else if(x=0)
        result=0;
    else
        result=-1;
        return result;
}