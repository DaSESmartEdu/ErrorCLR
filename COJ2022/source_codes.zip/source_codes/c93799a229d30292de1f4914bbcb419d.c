#include<stdio.h>
int main()
{
    double mile, time;
    scanf("%lf", "%lf", &mile, &time);
    double price1, price2, total;
    if(mile<=3){
        price1=10;
    }
    else if(mile>3&&mile<=10){
        price1=10+(mile-3)*2;
    }
    else if(mile>10){
        price1=24+3*(mile-10);
    }
    price2=((int)(time))/5*2;
    total=price1+price2;
    printf("%d", (int)(total+0.5));
    return 0;
}