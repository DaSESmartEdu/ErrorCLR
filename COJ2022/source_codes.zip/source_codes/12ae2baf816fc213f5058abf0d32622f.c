#include <stdio.h>
#include <stdlib.h>
int main()
{
    int a[1000]={0};
    int m,n;
    scanf("%d %d",&n,&m);
    while(m>n)
       {
           m=m-n;
       }
    int ArrayShift( int a[], int n, int m );
    ArrayShift(a,n,m);
    return 0;
}
int ArrayShift( int a[], int n, int m )
{
    for(int i=0;i<n;i++)
    {
        scanf("%d",&a[i]);
    }
    for(int i=n-1;i>=0;i--)
    {
        a[i+m]=a[i];
    }
    for(int i=0;i<m;i++)
    {
        a[i]=a[i+n];
    }
    for(int i=0;i<n-1;i++)
        printf("%d ",a[i]);
    printf("%d",a[n-1]);
    return 0;
}