#include<stdio.h>
int main()
{ 
    int m;
    scanf("%d",&m);
    getchar();
    char str[100];
    gets(str);
    char *t=str;
    puts(t+m-1);
}