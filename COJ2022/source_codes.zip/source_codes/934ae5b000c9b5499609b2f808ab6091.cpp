#include <iostream>
using namespace std;
void permutate(string str, int i){
    if(i == str.length()){
        for (int j=0 ;j<i;j++)
        {
            cout << str[j] << " ";
        }
        cout << endl;
    }
    for(int j = i;j < str.length(); j++){
        swap(str[i], str[j]);
        permutate(str, i+1);
    }
}
void print(string str){
    permutate(str, 0);
}
int main()
{
    int num;
    cin >> num;
    if(num==1)
        print("1");
    if(num==2)
        print("12");
    if(num==3)
        print("123");
    if(num==4)
        print("1234");
    if(num==5)
        print("12345");
    if(num==6)
        print("123456");
    if(num==7)
        print("1234567");
    if(num==8)
        print("12345678");
    if(num==9)
        print("123456789");
	return 0;
}