#include<stdio.h>
int main()
{
    int n,i,j;
    scanf("%d",&n);
    double score[n];
    for (i=1;i<=n;i++){
        scanf("%lf",&score[i-1]);
    }
    for (j=1;j<=n;j++){
        if(score[j-1]>=90){
            printf("A");
        }
        else if (score[j-1]<90 && score[j-1]>=80){
            printf("B");
        }
        else if (score[j-1]<80 && score[j-1]>=70){
            printf("C");
        }
        else if (score[j-1]<70 && score[j-1]>=60){
            printf("D");
        }
        else{
            printf("E");
        }
    }
    return 0;
}