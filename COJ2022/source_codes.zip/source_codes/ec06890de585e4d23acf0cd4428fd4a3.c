#include<stdio.h>
#include<math.h>
int p (int j,int k);
int p (int j,int k)
{
    int ans,q;
    for (q = 0; q < k; q++)
    {
        ans*=j;
    }
    return ans;
}
int main()
{
    int n;
    scanf("%d",&n);
    int num,min,max,a,b,c,d,e,f,g,i=0;
    switch (n)
    {
    case 3:
        min=100;max=999;
        break;
    case 4:
        min=1000;max=9999;
        break;
    case 5:
        min=10000;max=99999;
        break;
    case 6:
        min=100000;max=999999;
        break;
    case 7:
        min=1000000;max=9999999;
        break;
    }
    for (num=min ; num <=max ; num++)
    {
        a=num/1000000%10;
        b=num/100000%10;
        c=num/10000%10;
        d=num/1000%10;
        e=num/100%10;
        f=num/10%10;
        g=num/1%10;
        if (p (a,n)+p (b,n)+p (c,n)+p (d,n)+p (e,n)+p (f,n)+p (g,n)==num)
        {
            i++;
        }
    }
    printf("%d",i);
}