#include <stdio.h>
int main ()
{
	double hight;
	scanf("%lf",&hight);
	int n;
	scanf("%d",&n);
	double x=hight;
	int i=1;
	while (i<=n)
	{
		x=hight*0.5;
		i=i+1;
	}
	printf("%.2lf",x);
	return 0;
}