#include <stdio.h>
double fact(int t);
int main(){
    int m;
    double w=0;
    int k;
    scanf("%d",&m);
    for(k=1;k<m+1;k++){
       w+=fact(k);
    }
    printf("%f\n",w);
    return 0;
}
double fact(int t){
     double result=1;
     int v;
     for(v=1;v<t+1;v++){
        result*=v;
     }
     return result;
}