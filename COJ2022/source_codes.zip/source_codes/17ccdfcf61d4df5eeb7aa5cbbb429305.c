#include<stdio.h>
int main()
{
    double height,sum=0;
    int n;
    scanf("%lf%d",&height,&n);
    for(int i=1;i<=n;i++){
        sum+=height;
        height/=2.0;
    }
    printf("%.2lf",sum);
    return 0;
}