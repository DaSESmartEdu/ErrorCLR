#include<stdio.h>
int CountDigit(int number, int digit) {
	int sum = 0;
	while (number / 10 != 0) {
		if (number % 10 == digit || number % 10 == digit * (-1)) {
			sum++;
		}
		number = number / 10;
	}
	return sum;
}
int main() {
	int number, digit;
	scanf("%d%d",&number,&digit);
	printf("%d\n",CountDigit(number,digit));
	return 0;
}