#include <stdio.h>
#include <math.h>
double fact(double n){
	double s=1.0;
	while (n>0) {
		s*=n;
		n--;
	}
	return s;
}
double sswr(double n){
	n=(int)(n*100000+0.5)/100000.0;
	return n;
}
int main(){
	double x,S=0,n=0;
	scanf("%lf",&x);
	while(pow(x,n)/(fact(n))>=0.00001){
		S+=pow(x,n)/(fact(n));
		n+=1;
	}
	printf("%.4f",sswr(S));
	return 0;
}