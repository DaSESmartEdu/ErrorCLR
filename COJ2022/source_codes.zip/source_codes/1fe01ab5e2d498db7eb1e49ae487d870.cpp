#include<iostream>
#include<stdio.h>
#include<math.h>
#include<algorithm>
#include<cstring>
#include<stdlib.h>
using namespace std;
int n;
int w[10];
int temp[10];
int jc(int n){
   int ans=1;
   for(int i=1;i<=n;i++) ans*=i;
   return ans;
}
void per(int m,int n,int a[],int b[],int acount){
    if(m>n){
        for(int i=1;i<=n;i++){
            printf("%d ",a[i]);
        }
        acount++;
        if(acount<jc(n)) printf("\n");
    }
    else{
        for(int i=1;i<=n;i++){
            if(temp[i]==0){
                temp[i]=1;
                a[m]=i;
                per(m+1,n,a,b,acount);
                temp[i]=0;
            }
        }
    }
}
int main(){
    scanf("%d",&n);
     for(int i=1;i<=n;i++){
         temp[i]=0;
         w[i]=i;
    }
    per(1,n,w,temp,0);
    return 0;
}