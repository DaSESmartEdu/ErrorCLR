#include <stdio.h>
int main()
{
    int m,n,a,b;
    double p,q;
    scanf("%d %d",&a,&b);
    m=a;
    n=b;
    if (m>n)
    {
        m=b;
        n=a;
    }
    q=m*m+1/m;
    while (m<n)
    { 
        m++;
        p=m*m+1.0/m;
        q=q+p;
    }
    printf ("%lf",q);
    return 0;
}