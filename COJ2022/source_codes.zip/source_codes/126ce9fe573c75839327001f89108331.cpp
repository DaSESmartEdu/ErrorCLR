#include<cstdio>
#include<cstring>
#include<iostream>
using namespace std;
const int max1=1e5+10;
const int max2=1e6+10;
int C[max2];
long long tol[max1];  
int num[max1]; 
int a[max1];  
int n;
void init(){
	tol[0]=0;
	for(int i=1;i<=max1;i++)
	tol[i]=i+tol[i-1];
}
int lowbit(int i){
	return i&(-i);
}
int Sum(int i){
	int ans=0;
	while(i){
		ans+=C[i];
		i-=lowbit(i);
	}
	return ans;
}
void add(int i){
	while(i<=max2){
		C[i]++;
		i+=lowbit(i);
	}
}
int main(){
	init();
    while(scanf("%d",&n)==1){
    	memset(C,0,sizeof(C));
    	memset(num,0,sizeof(num));
    	for(int i=0;i<n;i++){
    		scanf("%d",&a[i]);
    		add(a[i]+1); 
			num[i]=(i+1)-Sum(a[i]+1); 
		}
		memset(C,0,sizeof(C));
		for(int i=n-1;i>=0;i--){
		add(a[i]+1); 
		num[i]+=Sum(a[i]);  
		} 
		long long ans=0;
		for(int i=0;i<n;i++){
			ans+=tol[num[i]];
		}
		printf("%lld\n",ans);    
	}	
	return 0;
}