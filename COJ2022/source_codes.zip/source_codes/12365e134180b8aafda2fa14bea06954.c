#include <stdio.h>
#include <string.h>
char* strcat1(char* str1, char* str2);
int main()
{
	char str1[100];
	char str2[100];
	gets(str1);
	gets(str2);
	char* p = strcat1(str1, str2);
	printf("%s  \n%s", p, str1);
	return 0;
}
char* strcat1(char* str1, char* str2)
{
	char* p = (char*)malloc(sizeof(char) * (1 + strlen(str1) + strlen(str2)));
	strcpy(p, str1);
	for (int i = 0; i < strlen(str2); i++)
	{
		p[strlen(str1) + i] = str2[i];
	}
	p[strlen(str1) + strlen(str2)] = '\0';
	str1 == (char*)malloc(sizeof(char) * (1 + strlen(str1) + strlen(str2)));
	strcpy(str1, p);
	return p;
}