#include <stdio.h>
#include <math.h>
int main()
{
    int x1,y1,x2,y2,x3,y3;
    scanf("%d %d %d %d %d %d",&x1,&y1,&x2,&y2,&x3,&y3);
    double c,s,l1,l2,l3;
    l1=sqrt(pow(x2-x1,2)+pow(y2-y1,2));
    l2=sqrt(pow(x3-x2,2)+pow(y3-y2,2));
    l3=sqrt(pow(x3-x1,2)+pow(y3-y1,2));
    double e=(l1+l2+l3)/2;
    if((y3-y2)*(x2-x1)==(y2-y1)*(x3-x2))
    {
        printf("impossible");
    }
    else {
        printf("%.2lf %.2lf",c=l1+l2+l3,s=sqrt(e*(e-l1)*(e-l2)*(e-l3)));
    }
    return 0;
}