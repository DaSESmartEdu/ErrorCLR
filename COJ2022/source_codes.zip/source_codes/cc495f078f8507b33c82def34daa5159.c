#include<stdio.h>
int main(){
    int flag=0,n,i=0,j=0;
    scanf("%d",&n);
    int a[n][n];
    while(i<n){
        while(j<i){
            scanf("%d",&a[i][j]);
            if(!a[i][j])flag=1;
            j++;
        }
        j=0;
        i++;
    }
    if(flag==0)printf("YES");
    else printf("NO");
    return 0;
}