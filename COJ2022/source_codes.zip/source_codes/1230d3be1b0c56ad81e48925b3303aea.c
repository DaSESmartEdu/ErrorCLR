#include <stdio.h>
#include <stdlib.h>
struct information 
{
	char *name;
	int birth;
	char *number;
};
int min(struct information friends[] , int n )
{
	int res=0;
	int i;
	for (i=0;i<n;i++)
	{
		if (friends[i].birth<friends[res].birth)
		res=i;
	}
	return res;
}
int main()
{   int n;
scanf("%d ",&n);
	struct information friends[n];
	int i;
	for (i=0;i<n;i++)
	{
		friends[i].name=(char*)malloc(10*sizeof(char));
		friends[i].number=(char*)malloc(17*sizeof(char));
		scanf("%s",&friends[i].name);
		scanf("%d",&friends[i].birth);
		scanf("%s",&friends[i].number);
	}
	struct information a;
	int j;
	for (j=n;j>1;j--)
	{
		a=friends[min(friends ,j)];
		friends[min(friends ,j)]=friends[j-1];
		friends[j-1]=a;
	}
	int r;
	for (r=0;r<n;r++)
	{
		printf("%s %d %s\n",friends[r].name,friends[r].birth,friends[r].number);
	}
	return 0;
}