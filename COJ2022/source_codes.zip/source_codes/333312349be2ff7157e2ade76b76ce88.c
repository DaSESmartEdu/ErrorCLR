#include <stdio.h>
int main()
{
    int n,i;
    scanf("%d",&n);
    int a[n];
    for(i=0;i<n;i++){
        scanf("%d",&a[i]);
    }
    int m;
    scanf("%d",&m);
    for(i=0;i<m;i++){
        int x,y;
        scanf("%d %d",&x,&y);
        int k=y-1;
        if(x==0){
            if(a[k]>0){
                a[k]--;
                printf("There are %d books of kind %d,success!",a[k],y);
            }else{
                printf("There is no book of kind %d,sorry!",y);
            }
        }else{
            a[k]++;
            printf("Success!There are %d books of kind %d now.",a[k]);
        }
    }
    return 0;
}