#include <stdio.h>
int main()
{
    double km=0,min=0;
    double sum1=0,sum2=0,result=0;
    int sum3=0;
    scanf("%lf %lf",&km,&min);
    if(km>3){
        if(km>10) sum1=(24+3*(km-10));
        else sum1=(10+2*(km-3));
    }
    else sum1=10;
    if(min>=5) sum2=2*((int)min/5);
    else sum2=0;
    result=sum1+sum2;
    result=(result+0.5);
    printf("%.0f",result);
    return 0;
}