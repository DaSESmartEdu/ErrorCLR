#include <stdio.h>
struct time
{
	int hour;
	int min;
	int second;
};
int main()
{
	int n;
	struct time t;
	scanf("%d:%d:%d",&t.hour,&t.min,&t.second);
	scanf("\n%d",&n);
	t.second=t.second+n;
	if(t.second>=60)
	{
		int p1=t.second/60;
		t.min+=p1;
		t.second=t.second%60;
	}
	if(t.min>=60)
	{
		int p2=t.min/60;
		t.hour+=p2;
		t.min=t.min%60;
	}
	if(t.hour>23)
	{
		t.hour=t.hour%24;
	}
	printf("%02d:%02d:%02d",t.hour,t.min,t.second);
	return 0;
}