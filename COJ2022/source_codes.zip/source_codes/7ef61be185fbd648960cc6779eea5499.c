#include <stdio.h>
int main()
{
    int a,s=0;
    scanf("%d",&a);
        if(a>0){
            if(a%2!=0){
                s=s+a;
            }
            scanf("%d",&a);
        }
        else{
            printf("%d",s);
        }
    return 0;
}