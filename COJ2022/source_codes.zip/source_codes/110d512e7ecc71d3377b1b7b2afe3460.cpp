#include <iostream>
#include <algorithm>
#include <string>
using namespace std;
int a[1000 + 5];
int main()
{
    int n;
    cin >> n;
    int i;
    for ( i= 0; i < n; ++i) {
        cin >> a[i];
    }
    sort(a, a+n);
    for (i = n-1; i >= 0; --i) {
        cout << a[i];
        if (i != 0) cout << " ";
        else cout << endl;
    }
    return 0;
}