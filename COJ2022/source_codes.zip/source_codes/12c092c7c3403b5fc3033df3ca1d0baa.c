#include<stdio.h>
int wanshu(int n)
{
    int i,sum=0;
    if(n==1)
    {
        return 1;
    }
    if(n!=1){
    for(i=1;i<n;i++)
    {
        if(n%i==0)
        {
            sum+=i;
        }
    }
    if(sum==n)
    {
        return 1;
    }
    else
    {
        return 0;
    }
    }
}
int main()
{
    int m,n,i,sign=0;
    scanf("%d %d",&m,&n);
    for(i=m;i<=n;i++)
    {
        if(wanshu(i)==1)
        {
            sign++;
        }
    }
    if(sign==0)
    {
        printf("No perfect number");
    }
    else
    {
        printf("%d",sign);
    }
}