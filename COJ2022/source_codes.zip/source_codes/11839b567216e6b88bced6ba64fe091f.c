#include<stdio.h>
#include<string.h>
int main()
{
    char A[1000],B[1000];
    int ca[128],cb[128];
    double sim;
    for(int i=0;i<128;i++)
    {
    ca[i]=0;
    cb[i]=0;
    }
    gets(A);
    gets(B);
    for(int i=0;i<strlen(A);i++)
    {
        ca[A[i]]+=1;
    }
    for(int i=0;i<strlen(B);i++)
    {
        cb[B[i]]+=1;
    }
    int sum=0;
    for(int i=0;i<128;i++)
    {
        sum+=ca[i]<cb[i]?ca[i]:cb[i];
    }
    sim=(sum+0.0)/strlen(A);
    if(sim>=0.5)
    printf("Yes");
    else 
    printf("No");
    return 0;
}