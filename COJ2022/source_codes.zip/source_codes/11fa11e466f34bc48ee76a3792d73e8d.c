#include<stdio.h>
int sign(int a)
{
	if(a>0)
	return 1;
	if(a==0)
		return 0;
	return -1;
}
int main()
{  int x;
	scanf("%d",&x);
		printf("%d",sign(x));
 return 0;
}