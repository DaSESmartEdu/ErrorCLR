#include <stdio.h>
   #include <math.h>
   int main()
   {
  int n,x,y;
  x=0;
  scanf("%d",&n);
  int m=n-8;
  int u=m/5;
  if (u==0)
  { x=m/2+1;printf("%d",x);}
  else {
      for (int i=1;i<=u;i++)
      {  y= (m-i*5)/2+1;
      x=x+y;
  }
  printf("%d",x);}
    return 0;
}