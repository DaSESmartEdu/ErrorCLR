#include<stdio.h>
int even( int n );
int OddSum( int List[], int N );
int main(){
    int n,N ,i;
    scanf("%d/n",&N);
     int List[N];
    for(i=0;i<N;i++){
        scanf("%d",&List[i]);
    }
     printf("%d",OddSum(List,N));
}
int OddSum( int List[],int N ){
    int j,sum;
    sum=0;
    for(j=1;j<=N;j++){
        if(even(List[j])==0){
            sum+=List[j];
        }
    }
    return sum;
}
int even( int n ){
    if(n%2==0) return 1;
    else return 0;
}