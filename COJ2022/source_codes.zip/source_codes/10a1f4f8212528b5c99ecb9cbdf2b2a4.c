#include <stdio.h>
int main()
{
	int a,b;
	scanf("%d %d",&a,&b);
	int n;
	scanf("%d",&n);
	int set[n][4];
	int i;
	for(i=0;i<n;i++){
		scanf("%d %d %d %d",&set[i][0],&set[i][1],&set[i][2],&set[i][3]);
	}
	int adrink=0,bdrink=0;
	int flag=0;
	for(i=0;i<n;i++){
		int sum;
		sum=set[i][0]+set[i][2];
		if(set[i][1]==sum && set[i][3]!=sum){
			adrink++;
		}
		if(adrink>a){
			printf("A\n");
			flag=1;
			break;
		}
		if(set[i][1] !=sum && set[i][3]==sum){
			bdrink++;
		}
		if(bdrink>b){
			printf("B\n");
			flag=2;
			break;
		}	
	}
	if(flag==1){
		printf("%d",bdrink);
	}else if(flag==2){
		printf("%d",adrink);
	}
	return 0;
}