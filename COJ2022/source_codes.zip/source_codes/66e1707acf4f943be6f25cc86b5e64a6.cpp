#include <iostream>
#include <string>
using namespace std;
struct Node
{
	char data;
	Node* left=NULL;
	Node* right=NULL;
};
void insert(Node *(&root),char value)
{
	Node *node=new Node;
	node->data=value;
	node->left=NULL;
	node->right=NULL;
	if(root==NULL)
	{
		root=node;
	}
	else
	{
		Node *temp=root;
		while(temp!=NULL)
		{
			if(value<temp->data)
			{
				if(temp->left==NULL)
				{
					temp->left=node;
					return;
				}
				else
				{
					temp=temp->left;
				}
			}
			else
			{
				if(temp->right==NULL)
				{
					temp->right=node;
					return;
				}
				else
				{
					temp=temp->right;
				}
			}
		}
	}
	return;
}
int pre_create(Node* (&root)) 
{
    char data;
	cin>>data;
    if (data == '#') 
	{
        root = NULL;
    } 
	else 
	{
        root = new Node;
        root->data = data;         
        pre_create(root->left);
        pre_create(root->right);
    }
    return 0;
}
int in_create(Node* (&root)) 
{
    char data;
	cin>>data;
    if (data == '#') 
	{
        root = NULL;
    } 
	else 
	{
        root = new Node;
        in_create(root->left);
		root->data = data;         
        in_create(root->right);
    }
    return 0;
}
int post_create(Node* (&root)) 
{
    char data;
	cin>>data;
    if (data == '#') 
	{
        root = NULL;
    } 
	else 
	{
        root = new Node;
        post_create(root->left);
        post_create(root->right);
		root->data = data;         
    }
    return 0;
}
void build_post(Node* (&root),string &temp,int &index)
{
    if(index>0)
    {
        if(temp[index]=='#')
        root=NULL;
        else
        {
            root=new Node;
            root->data=temp[index];
            build_post(root->right,temp,--index);
            build_post(root->left,temp,--index);
        }
    }
}
void preorder(Node *node)
{
	if(node==NULL)
	return;
	else
	{
		preorder(node->left);
		preorder(node->right);
		cout<<node->data<<" ";
	}
}
void inorder(Node *node)
{
	if(node==NULL)
	return;
	else
	{
		inorder(node->left);
		cout<<node->data<<" ";
        inorder(node->right);
	}
}
void postorder(Node *node)
{
	if(node==NULL)
	return;
	else
	{
		postorder(node->left);
		postorder(node->right);
		cout<<node->data<<" ";
	}
}
void remove(Node *(&sub_root),char target)
{
    if(sub_root==NULL||sub_root->data==target)
    {
        if(sub_root==NULL)
        return;
		Node *to_delete=sub_root;
        if(sub_root->left==NULL)
        {
            sub_root=sub_root->right;
        }
        else if(sub_root->right==NULL)
        {
            sub_root=sub_root->left;
        }
        else
        {
            to_delete=sub_root->left;
            Node* parent=sub_root;
            while(to_delete->right!=NULL)
            {
                parent=to_delete;
                to_delete=to_delete->right;
            }
            sub_root->data=to_delete->data;
            if(parent==sub_root)
                sub_root->left = to_delete->left;  
		    else 
			    parent->right = to_delete->left;  
        }
		delete to_delete;
    }
    else if (target<sub_root->data)
		remove(sub_root->left, target);
	else
		remove(sub_root->right, target);
}
void search_tree(Node* (&root),char target)
{
    if(root==NULL||root->data==target)
    {
        cout<<root->data<<" ";
        return;
    }
    else if(root->data<target)
    {
        cout<<root->data<<" ";
        search_tree(root->right,target);
    }
    else if(root->data>target)
    {
        cout<<root->data<<" ";
        search_tree(root->left,target);
    }
}
int main()
{
    Node* root=NULL;
    string temp;
    cin>>temp;
    int length=temp.size()-1;
    build_post(root,temp,length);
    char a;
    cin>>a;
    search_tree(root,a);
    cout<<endl;
    char b;
    cin>>b;
    remove(root,b);
    inorder(root);
    return 0;
}