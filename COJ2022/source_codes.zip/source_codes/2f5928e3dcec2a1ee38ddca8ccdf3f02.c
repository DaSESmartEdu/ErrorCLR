# include <stdio.h>
int main()
{
    int num1[100000];
    int num2[100000];
    int m,n;
    scanf("%d, %d", &n, &m);
    for (int  i = 0; i < n; i++)
    {
        scanf("%d",&num1[i]);
    }
    for (int i = 0; i < m; i++)
    {
        scanf("%d",&num2[i]);
    }
    int i = 0;
    int j = m - 1;
    if (num1[i] < num2[j])
    {
        printf("%d",num1[i]);
        i++;
    }
    else
    {
        printf("%d",num2[j]);
        j--;
    }
    while (i < n && j >= 0)
    {
        if (num1[i] < num2[j])
        {
            printf(" %d",num1[i]);
            i++;
        }
        else
        {
            printf(" %d",num2[j]);
            j--;
        }
    }
    if (i == n)
    {
        while (j >= 0)
        {
            printf(" %d",num2[j]);
            j--;
        }
    }
    else
    {
        while (i < n)
        {
            printf(" %d",num1[i]); 
            i++;
        }
    }
    return 0;
}