#include <iostream>
#include<stdio.h>
#include<math.h>
#include<string.h>
#include<algorithm>
using namespace std;
typedef long long ll;
ll n;
ll v[100005];
int main()
{
    scanf("%ld",&n);
    for(ll i=0;i<n;i++){
        scanf("%ld",&v[i]);
    }
    ll maxx,mmin;
    maxx=mmin=-1;
    ll ans=0;
    ll num=0;
    for(ll i=0;i<n;i++){
        if(v[i]!=0){
            num++;
            if(maxx==-1){
                maxx=v[i];
                mmin=v[i];
            }
            else{
                maxx=max(maxx,v[i]);
                mmin=min(mmin,v[i]);
            }
        }
        else{
            if(maxx!=-1&&maxx>=mmin*100&&num>=30){
                ans++;
            }
            maxx=mmin=-1;
            num=0;
        }
    }
    if(maxx!=-1&&maxx>=mmin*100&&num>=30){
        ans++;
    }
    printf("%ld\n",ans);
    return 0;
}