#include<stdio.h> 
#include<string.h>
int max_len(char s[][100],int n)
{
    int len[n];
    for(int i=0;i<n;i++)
    {
        len[i]=strlen(s[i]);
    }
    int max=len[0];
    for(int i=1;i<n;i++)
    {
        if(len[i]>max)
        max=len[i];
    }
    return max;
}
int main()
{
    int n;
    scanf("%d",&n);
    char s[n][100];
    for(int i=0;i<n;i++)
    {
        scanf("%s",s[i]);
    }
    printf("%d",max_len(s,n));
    return 0;
}