#include<stdio.h>
int main()
{
    int n;
    scanf("%d",&n);
    int s[n];
    for (int i = 0; i < n; i++)
    {
       scanf("%d",&s[i]);
    }
    int m;
    scanf("%d",&m);
    for (int i = 1; i <= m; i++)
    {
        int a,b;
        scanf("%d %d",&a,&b);
        if (!a)
        {
            if (s[b-1]>0)
            {
                printf("There are %d books of kind %d,success!",s[b-1],b);
                s[b-1]--;
            }
            else
            {
               printf("There is no book of kind %d,sorry!",b); 
            }  
        }
        if (a)
        {
            s[b-1]++;
            printf("Success!There are %d books of kind %d now.",s[b-1],b);
        }  
    }   
}