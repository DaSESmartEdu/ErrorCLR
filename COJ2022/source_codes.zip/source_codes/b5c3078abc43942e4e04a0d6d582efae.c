#include<stdio.h>
int main()
{
int amount ;
float bill;
if (amount<=50) bill = amount * 0.53;
else bill = 50 * 0.53 + (amount-50) * 0.58;
printf("%f",bill);
return 0;
}