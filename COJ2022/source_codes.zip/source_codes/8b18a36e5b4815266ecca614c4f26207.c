#include <stdio.h>
int main()
{
    int n;
    int m;
    scanf("%d %d",&n,&m);
    int a;
    a=200;
    if (n<=m)
    {
        printf("normal\n");
    }
    else if (1.1*m<=n&&n<1.5*m)
    {
        printf("%d\n",a);
    }
    else if (n>=1.5*m)
    {
        printf("revoke\n");
    }
    return 0;
}