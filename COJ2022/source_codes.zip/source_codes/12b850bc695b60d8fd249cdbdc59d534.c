#include <stdio.h>
#include <math.h>
#include <string.h>
char s[15];
char Std[] = "2147483648";
int main() {
	int n;
	scanf("%d", &n);
	while (n--) {
		scanf("%s", s);
		int m = strlen(s);
		int db = 0, it = 0, lo = 0;
		for (int i = 0; i < m; ++i) {
			if (s[i] == '.') db = 1;
		}
		if (db) {
			puts("double");
			continue;
		}
		if (m < 10 || (m == 10 && strcmp(s, Std) < 0)) puts("int");
		else puts("long long");
	}
	return 0;
}