#include <stdio.h>
int main()
{
    int n,m;
    scanf("%d%d",&n,&m);
    int beans[n+1];
    for(int i=0;i<n;i++)
    {
        scanf("%d",&beans[i]);
    }
    beans[n]=0;
    int ipos;
    scanf("%d",&ipos);
    while(m-1>0)
    {
        int pos;
        pos=ipos-1;
        int temp=beans[pos];
        for(int i=pos;beans[i]!=0;i++)
        {
            beans[i]=beans[i+1];
        }
        printf("%d\n",temp);
        scanf("%d",&ipos);
      	m--;
    }
    return 0;
}