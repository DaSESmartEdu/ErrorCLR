#include <stdio.h>
int main()
{
    int m,n,i,j,a,b;
    scanf("%d %d",&m,&n);
    if (m>=n)
        a=n;
    else    
        a=m;
    for (i=a;i>=2;i--){
        if (m%i==0&&n%i==0){
            printf("%d ",i);
            break;
        }
    }
    for (i=1;i<=m*n;i++){
        if (i%m==0&&i%n==0){
            printf("%d",i);
            break;
        }
    }
    return 0;
}