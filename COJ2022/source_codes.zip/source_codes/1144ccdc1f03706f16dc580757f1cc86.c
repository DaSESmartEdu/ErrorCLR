#include <stdio.h>
int main(void) {
  int a,b;
  scanf("%d", &a);
  scanf("%d", &b);
  printf("%d", a+b);
}