#include<stdio.h>
int main()
{
	int a,b,c,n;
	scanf("%d:%d:%d",&a,&b,&c);
	scanf("%d",&n);
	int x,y,z;
	int A,B,C;
	x=n/60;
	y=n%60;
	if((y+c)<60)
	{
		C=y+c;
		B=b+x;
	}else if((y+c)>=60)
	{
		C=y+c-60;
		B=b+x+1;
		}
	int BB;
	BB=B%60;
	z=B/60;
	if(BB>=60)
	{
		BB=BB-60;
		A=z+a+1;
		}
		else if(BB<60)
		{
			A=z+a;
			}
	if(A>=24)
	A=A-24;
	printf("%02d:%02d:%02d",A,BB,C);
	return 0;
}