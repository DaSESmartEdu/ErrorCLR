#include <bits/stdc++.h>
using namespace std;
int dx[4] = {0, -1, 1, 0};
int dy[4] = {1, 0, 0, -1};
int M, N;
bool inboundary(int x, int y) {
    return (x >= 0) && (y >= 0) && (x < M) && (y < N);
}
bool dfs(vector<vector<int>> &Matrix, int x, int y, int L, int fromdir) {
    if (L == -1) return false;
    if (x == Matrix.size() - 1 && y == Matrix[0].size() - 1) return true;
    for (int i = 0; i < 4; i++) {
        if (inboundary(x, y) && fromdir + i != 3 &&
            Matrix[x][y] != Matrix[x + dx[i]][y + dy[i]] &&
            dfs(Matrix, x + dx[i], y + dy[i], L - 1, i))
            return true;
    }
    return false;
}
int main() {
    int n, m;
    cin >> m >> n;
    M = m, n = n;
    vector<vector<int>> Matrix(m, vector<int>(n));
    for (auto &row : Matrix)
        for (auto &elem : row) cin >> elem;
    cout << dfs(Matrix, 0, 0, m * n, -1) << endl;
}