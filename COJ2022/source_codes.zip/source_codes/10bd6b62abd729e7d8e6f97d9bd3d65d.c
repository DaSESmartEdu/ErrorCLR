#include<stdio.h>
#include<math.h>
int main(){
  int i,j,n,l,k=1;
  scanf("%d%d",&n,&l);
  getchar();
  char a[n];
  for(i=0;i<n;i++){
    scanf("%c",&a[i]);
  }
  for(i=0;i<l-1;i++)
    k*=10;
  if(k==1){
    for(i=0;i<n;i++){
      if(a[i]=='2'){
        printf("2");
        break;
      }
      if(a[i]=='3'){
        printf("3");
        break;
      }
      if(a[i]=='5'){
        printf("5");
        break;
      }
      if(a[i]=='7'){
        printf("7");
        break;
      }
    }
    if(i==n)
      printf("404");
  }else{
    int b[3000],cont=0,judge=0;
  	for(i=k+1;i<(k*10-1);i+=2){
      for(j=3;j<(sqrt(i)+1);j+=2){
        if(!(i%j)){
          j=-1;
          break;
        }
      }
      if(j!=-1)
        b[cont++]=i;
    }
    int sum;
    for(i=0;i<n-l+1;i++){
      sum=0;
      for(j=0;j<l;j++){
        sum*=10;
        sum+=a[i+j]-'0';
      }
      for(j=0;j<cont;j++){
        if(b[j]==sum){
          printf("%d",sum);
          judge=1;
          break;
        }
      }
      if(judge)
        break;
    }
    if(!judge)
      printf("404");
  }
  return 0;
}