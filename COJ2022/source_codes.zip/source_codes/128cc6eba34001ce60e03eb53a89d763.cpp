#include<cmath>
#include<iostream>
using namespace std;
const int maxn=8;
int n;
int queen[maxn][maxn];
int posb[maxn]={0};
int posw[maxn]={0};
int ans;
bool checkw(int cur)
{
    for(int i=1;i<cur;i++)
        if(posw[i]==posw[cur]||abs(i-cur)==abs(posw[i]-posw[cur]))
            return false;
    return true;
}
bool checkb(int cur)
{
    for(int i=1;i<cur;i++)
        if(posb[i]==posb[cur]||abs(i-cur)==abs(posb[i]-posb[cur]))
            return false;
    return true;
}
void dfs_white( int cur)
{
    if( cur == n+1)  
    {
        ans++;
    }
    for(int i=1;i<=n;i++)
    {
        if(posb[cur]==i)
            continue;
        if(queen[cur][i]==0)
            continue;
        posw[cur]=i;
        if(checkw(cur))
            dfs_white(cur+1);
    }
}
void dfs_black(int cur)
{
    if( cur == n+1)  
    {
        dfs_white(1);
    }
    for(int i=1;i<=n;i++)
    {
        if(queen[cur][i]==0)
            continue;
        posb[cur]=i;
        if(checkb(cur))
            dfs_black(cur+1);
    }
}
int main()
{
    cin>>n;
    for(int i=1;i<=n;i++)
        for(int j=1;j<=n;j++)
            cin>>queen[i][j];
    ans=0;
    dfs_black(1);
    cout<<ans<<endl;
    return 0;
}