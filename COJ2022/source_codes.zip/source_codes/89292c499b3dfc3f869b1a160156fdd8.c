#include<stdio.h>
int main()
{
    int m;
    int n;
    scanf("%d" , &m);
    scanf("%d" , &n );
    double result;
    result=0;
    int i;
    for(i=m;i<=n;i++)
{
    result=result+(i*i+1.0/i); 
}
    printf ("%.6if\n",result);
    return 0;
}