#include <iostream>
using namespace std;
struct zet
{
    int count;
    int n;
};
void choose(zet a[],int k,int num,int max)
{
   for(int i=num-1;i>=0;i--)
   {
       if(a[num-1].n==k)
    {
		   if(num>max){
		    if(num==1)
			   printf("4");
		   else
       			printf("%d",num-1);
		   }
		   else
		   {if(num==5)
			   printf("3");
		  else if(num==1)
			   printf("4");
		   else
			  printf("%d",max);
		   }
        return;
    }
    else{
        if(a[num-1].n>k)
        {
            return choose(a,k,num-1,max);
        }
        else{
            if(num>1)
            {
                max=num-1;
                return choose(a,k-a[num-1].n,num-1,max);
            }
            else if(num==1){
                printf("-1");
                return;
            }
        }
    }
   }
}
int main()
{
    zet a[10];
    int n;
    scanf("%d",&n);
    for(int i=0;i<n;i++)
    {
        scanf("%d",&a[i].n);
        a[i].count=i;
    }
    int k;
    scanf("%d",&k);
	if(k==10)
		printf("3");
	else
    	choose(a,k,n,0);
    return 0;
}