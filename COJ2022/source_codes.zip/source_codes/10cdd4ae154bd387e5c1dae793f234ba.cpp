#include<iostream>
#include<vector>
using namespace std;
class midFind
{
public:
    midFind(int &n)
    {
        int i,t;
        for(i=0;i<n;i++)
        {
            cin>>a[i];
        }
        cin>>t;
        this->target=t;
    }
    int find(int start,int end)
    {
        if(start>end) return -1;
        int step=(start+end)/2;
        if(a[step]==target) return step;
        else if(a[step]<target) find(step+1,end);
        else if(a[step]>target) find(start,step);
    }
private:
    int a[30];
    int target;
};
int main()
{
    int n;
    cin>>n;
    midFind p1(n);
    cout<<p1.find(0,n-1)<<endl;
}