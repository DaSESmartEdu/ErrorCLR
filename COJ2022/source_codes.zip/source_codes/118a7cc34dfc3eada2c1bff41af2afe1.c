#include<stdio.h>
main(){
	int i,j,n,k;
	scanf("%d",&n);
	k=n/2+1;
	for(i=1;i<=k;i++){
		for(j=k-i;j>0;j--){
			printf("  ");
		}
		for(j=0;j<2*i-1;j++){
			printf("* ");
		}
		printf("\n");
	}
	for(i=1;i<k;i++){
		for(j=0;j<=i-1;j++){
			printf("  ");
		}
		for(j=2*(k-i)-1;j>0;j--){
			printf("* ");
		}
		printf("\n");
	}
	return 0;
}