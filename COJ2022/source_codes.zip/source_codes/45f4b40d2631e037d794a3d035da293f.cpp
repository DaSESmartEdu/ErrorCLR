#include<iostream>
#include<vector>
using namespace std;
class Solution {
public:
    void dfs(vector<int>& candidates, int target, vector<vector<int>>& ans, vector<int>& combine, int idx) {
        if (idx == candidates.size()) {
            return;
        }
        if (target == 0) {
            ans.emplace_back(combine);
            return;
        }
        dfs(candidates, target, ans, combine, idx + 1);
        if (target - candidates[idx] >= 0) {
            combine.emplace_back(candidates[idx]);
            dfs(candidates, target - candidates[idx], ans, combine, idx+1);
            combine.pop_back();
        }
    }
    vector<vector<int>> combinationSum(vector<int>& candidates, int target) {
        vector<vector<int>> ans;
        vector<int> combine;
        dfs(candidates, target, ans, combine, 0);
        return ans;
    }
};
int main()
{
    int n;
    cin>>n;
    vector<int> candidates;
    for(int i=0;i<n;i++)
    {
        int temp;
        cin>>temp;
        candidates.push_back(temp);
    }
    vector<vector<int>> ans;
    int target;
    cin>>target;
    Solution P;
    ans=P.combinationSum(candidates,target);
    vector<int> xiabiao_shu;
    for(int i=0;i<ans.size();i++)
    {
        int j=ans[i].size();
        int number=ans[i][j-1];
        xiabiao_shu.push_back(number);
    }
    int ret=-1;
    for(int i=0;i<xiabiao_shu.size();i++)
    {
        for(int j=candidates.size()-1;j>=0;j--)
        {
            if(candidates[j]==xiabiao_shu[i])
            {
                ret=max(ret,j);
            }
        }
    }
    cout<<ret;
    return 0;
}