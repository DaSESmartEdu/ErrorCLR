#include<stdio.h>
int main(){
    int n,i=0;
    int x,y,z;
    scanf("%d",&n);
    for(x=1;x<=19;x++){
    for(y=1;y<=47;y++){
      if((n-5*x-2*y)%1==0) i++;
        }
    }
    printf("%d",i);
    return 0;
}