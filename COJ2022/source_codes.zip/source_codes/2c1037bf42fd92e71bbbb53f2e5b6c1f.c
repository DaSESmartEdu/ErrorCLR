#include<stdio.h>
int main()
{
int a,b,c,d;
scanf("%d %d %d %d",&a,&b,&c,&d);
float average=(a+b+c+d)/4.0;
int sum=a+b+c+d;
printf("d %.1f",sum,average);
return 0;
}