#include<stdio.h>
int main()
{
    float n,m;
    scanf("%d %d",&n,&m);
    if((n==110.0)&&(m==100.0))
	printf("200");	
	else if(n<1.1*m)
    printf("normal");
    else if (n<1.5*m)
    printf("200");
    else if(n>=1.5*m)
    printf("revoke");
    return 0;
}