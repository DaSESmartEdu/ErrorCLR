#include<stdio.h>
int fib(int);
void PrintFN(int, int);
int main(){
    int m, n, t;
    scanf("%d %d %d", &m, &n, &t);
    printf("%d\n", fib(t));
    PrintFN(m,n);
    return 0;
}
int fib(int x){
    if (x==1 || x==2) return 1;
    else return fib(x-1) + fib(x-2);
}
void PrintFN(int m, int n){
    int i=1;
    while (fib(i)<m) i++;
    int flag=0;
    while (fib(i)<=n){
        flag=1;
        printf("%d ", fib(i));
        i++;
    }
    if(flag==0) printf("No Fibonacci Number");
}