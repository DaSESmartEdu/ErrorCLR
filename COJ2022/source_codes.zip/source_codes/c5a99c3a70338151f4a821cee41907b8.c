#include<stdio.h>
int main()
{
    int a, b;
    scanf("%d", &a);
    scanf("%d", &b);
    int c = a + b;
    printf("%d/n",c);
    return 0;
}