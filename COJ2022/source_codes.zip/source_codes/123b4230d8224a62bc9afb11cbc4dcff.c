#include<stdio.h>
int set_grade(int number){
   char grade;
if(number>=85)
{grade='A';}
else if(number<85&&number>=70)
{grade='B';}
else if(number<70&&number>=60)
{grade='C';}
else
{grade='D';}
return grade;
}
struct x{
   int number;
   char name[20];
   int fen;
   char grade;
}x[19],*p;
int main(){
int n,i=0,f=0;
scanf("%d",&n);
for(i=0;i<n;i++){
scanf("%d %s %d",&x[i].number,x[i].name,&x[i].fen);
x[i].grade=set_grade(x[i].fen);
if(x[i].fen<60){
	f++;
}
}
printf("The count for failed (<60): %d\n",f);
printf("The grades:\n");
for(i=0;i<n;i++){
printf("%d %s %c\n",x[i].number,x[i].name,x[i].grade);
}
return 0;
}