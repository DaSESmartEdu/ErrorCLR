#include<stdio.h>
double fact (int n)
{
     int i=1;
     double t=1;
     for(i=1;i<=n;i++)
      t*=i;
     return t;
}
 int main()   
 {
   int x=1,n=1;
   double result;
   scanf("%d",&n);
   for(x=1;x<=n;x++){
     result+=fact(x);
    }
    printf("%.0f\n",result);
    return 0;
}