#include<stdio.h>
int main(void)
{
	int n;
	double ans, height;
	scanf("%lf%d", &height,&n);
	ans = height;
	for(int i=1;i<=n;i++)
		ans /= 2.0;
	printf("%.2f", ans);
}