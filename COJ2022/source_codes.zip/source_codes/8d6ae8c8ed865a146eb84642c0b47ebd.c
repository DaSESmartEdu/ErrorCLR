#include<stdio.h>
#include<math.h>
int prime(int p){
    int i,result;
    if (p==1) result=0;
    for(i=2;i<=sqrt(p);i++){
            if (p%i==0) result=0;
          }
        result=1;
       return result;
    }
int PrimeSum( int m, int n ){
    int i;
    int result=0;
    for (i=m;i<=n;i++){
        if (prime(i)==1){
           result=result+i;
        }
    }
    return result;
}
int main(){
    int m,n;
    scanf("%d %d",&m,&n);
    printf("%d",PrimeSum(m,n));
    return 0;
}