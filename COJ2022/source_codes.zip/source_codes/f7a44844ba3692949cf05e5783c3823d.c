#include <stdio.h>
int main()
{
    int n;
    double denominator,flag;
    double numerator;
    double item,sum;
    scanf("%d",&n);
    flag=1.0;
    denominator=1.0;
    numerator=1.0;
        do
        {
		item=numerator/denominator*flag;
        sum=sum+item;
        flag=-flag;
        numerator=numerator+1.0;
        denominator=denominator+2.0;
    }
    while(numerator<=n);
    printf("%lf\n",sum);
    return 0;
}