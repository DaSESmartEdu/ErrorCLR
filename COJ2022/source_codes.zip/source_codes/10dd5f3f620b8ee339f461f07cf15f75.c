#include <stdio.h>
struct time{
    int h;
    int m;
    int s;
};
int main()
{
    struct time a;
    scanf("%d:%d:%d",&a.h,&a.m,&a.s);
    int n;
    scanf("%d",&n);
    int x,y;
    x=a.s+n;
    y=a.m+x/60;
    if(x>=60){
        a.m+=x/60;
        a.s=x%60;
    }else{
        a.s+=n;
    }
    if(y>=60){
        a.h+=y/60;
        a.m=y%60;
    }
    if(a.h>=24){
        a.h-=24;
    }
    printf("%02d:%02d:%02d",a.h,a.m,a.s);
    return 0;
}