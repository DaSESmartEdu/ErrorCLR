#include <iostream>
#include <vector>
#define LEFT(i)	 (2 * i + 1)
#define RIGHT(i) (2 * i + 2)
using namespace std;
class heap
{
public:
	void input();
	void min_heapify(const int& i);
	void build_min_heap();
	void heap_sort();
	void output();
private:
	vector<vector<int>> data;
	int size;
};
void heap::input()
{
	vector<int> temp(2);
	cin >> size;
	for (int i = 0; i < size; i++)
	{
		cin >> temp[0] >> temp[1];
		data.push_back(temp);
	}
}
void heap::min_heapify(const int& i)
{
	int smallest = 0;
	if (LEFT(i) <= size - 1 &&
		(data[LEFT(i)][0] < data[i][0] || (data[LEFT(i)][0] == data[i][0] && data[LEFT(i)][1] < data[i][1])))
	{
		smallest = LEFT(i);
	}
	else
	{
		smallest = i;
	}
	if (RIGHT(i) <= size - 1 &&
		(data[RIGHT(i)][0] < data[i][0] || (data[RIGHT(i)][0] == data[i][0] && data[RIGHT(i)][1] < data[i][1])))
	{
		smallest = RIGHT(i);
	}
	if (smallest != i)
	{
		swap(data[i], data[smallest]);
		min_heapify(smallest);
	}
}
void heap::build_min_heap()
{
	for (int i = (size - 1) / 2; i >= 0; i--)
	{
		min_heapify(i);
	}
}
void heap::heap_sort()
{
	build_min_heap();
	for (int i = size - 1; i >= 1; i--)
	{
		swap(data[0], data[i]);
		size--;
		min_heapify(0);
	}
}
void heap::output()
{
	for (int i = data.size() - 1; i >= 0; i--)
	{
		cout << "(" << data[i][0] << "," << data[i][1] << ")" << endl;
	}
}
int main(void)
{
	heap MyHeap;
	MyHeap.input();
	MyHeap.heap_sort();
	MyHeap.output();
	return 0;
}