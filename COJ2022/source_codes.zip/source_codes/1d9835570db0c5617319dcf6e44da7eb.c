#include <stdio.h>
int main ()
{
    int odd,sum,a;
    scanf("%d",&odd);
    sum =0;
    while (odd>0)
    {   scanf("%d",&odd);
        a =odd%2;
        if(a !=0) 
        {
         sum=sum+odd;
        }
    }
    printf ("%d",sum);
    return 0;
}