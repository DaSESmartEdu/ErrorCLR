#include<stdio.h>
int main()
{
    int k;
    scanf("%d",&k);
    if(k>26){
        k=k%26;
    }
    char a[100];
    scanf("%s",a);
    int i;
    int len=0;
    for(i=0;a[i]!='\0';i++){
        len++;
    }
    for(i=0;i<len;i++){
        if(a[i]+k>'z'){
            a[i]='a'+k-('z'-a[i])-1;
        }else{
            a[i]=a[i]+k;
        }
    }
    printf("%s",a);
    return 0;
}