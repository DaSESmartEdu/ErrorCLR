#include<stdio.h>
#include<math.h>
double fact(int n);
double fact(int n)
{
    double i, sum;
    sum=1;
    for(i=1; i<=n; i++){
        sum=sum*i;
    }
    return sum;
}
int main()
{
    int n;
    double i, m;
    scanf("%d", &n);
    double total;
    for(i=1; i<=n; i++){
        total=total+fact(i);
    }
    printf("%.0lf", total);
    return 0;
}