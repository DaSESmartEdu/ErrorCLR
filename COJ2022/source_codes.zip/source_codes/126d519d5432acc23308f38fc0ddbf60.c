#include<stdio.h>
int main()
{
    int n;
    scanf("%d",&n);
    int a[n][n];
    int i,j;
    int count=0;
    for(i=0;i<n;i++)
    {
        for(j=0;j<n;j++)
        {
            scanf("%d",&a[i][j]);
            if(i>j&&a[i][j]==0)
            {
                count++;
            }
        }
    }
    if(count==n*(n-1)/2)
    {
        printf("YES");
    }
    else
    {
        printf("NO");
    }
    return 0;
}