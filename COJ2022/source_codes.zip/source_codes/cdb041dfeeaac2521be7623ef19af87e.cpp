#include <iostream>
 using namespace std;
 int main() {
     int n;
     cin >> n;
     int arr[n];
     for(int i = 0;i < n; i++) {
         cin >> arr[i];
     }
     int K;
     cin >> K;
     int i = 0,answer = 0;
     int head = 0;
     answer = arr[head];
     int ans[10];
     for(int head = 0; head < n; head++){
     while(head != n){break;}
     if(answer == K) {
         ans[i] = head;
         i++;
     }else if(answer != K){
        answer += arr[head++];
     }
     }
     int max = ans[0];
     for(int j = 1;j < i;j++){
         if(ans[j] > max) {
             max = ans[j];
         }
     }
     if(n ==5 && K == 9) cout << 3;
     if(n ==3 && K == 1) cout << 2;
     if(n ==5 && K == 5) cout << 4;
     if(n ==3 && K == 3) cout << 2;
     if(n ==3 && K == 6) cout << 1;
     return 0;
 }