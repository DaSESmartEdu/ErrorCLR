#include<iostream>
int Max;
int a[4]={1,0,-1,0};
int b[4]={0,1,0,-1};
int maze[100][100]={0};
int visited[10000][10000]={0};
int visited2[10000][10000]={0};
using namespace std;
int col,row;
void DFS(int x,int y,int count){
    int m,n,i,j;
    if (Max<count)
    {
        Max=count;
    }
    for ( i = 0; i < 4; i++)
    {
        m=x+a[i];
        n=y+b[i];
        if (m>=0&&n>=0&&m<row&&n<col&&maze[m][n]!=maze[x][y]&&visited[m][n]==0)
        {
            visited[m][n]=1;
            visited2[m][n]=1;
            DFS(m,n,count+1);
            visited[m][n]=0;
        }
    }
}
int main(void){
    int count=1;
    cin >>row >>col;
    int i=0,j=0;
    for ( i = 0; i < row; i++)
    {
        for ( j = 0; j < col; j++)
        {
            cin>>maze[i][j];
        }
    }
    for ( i = 0; i < row; i++)
    {
        for ( j = 0; j <col; j++)
        {
            DFS(i,j,1);
        }
    }
    if (visited2[row-1][col-1]==1)
    {
        cout << 1;
    }
    else{
        cout << 0;
    }
    cout << endl;
    return 0;
}