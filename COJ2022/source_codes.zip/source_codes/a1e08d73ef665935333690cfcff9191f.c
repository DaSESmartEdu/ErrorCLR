#include<stdio.h>
int main()
{
	int n1, n2, o, sum, time, p;
	n1 = 1;
	n2 = 0;
	time = 1;
	o = 0;
	scanf("%d", &p);
	if (p>10000) {
		printf("wrong.");
	} 
	else {
		while (sum<p) {
			time += 1;
			o += n2;
			n2 = n1;
			n1 = o;
			sum = n1+n2+o;
		}
		printf("%d", time);
	}
}