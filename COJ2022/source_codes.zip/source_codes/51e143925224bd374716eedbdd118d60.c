#include <stdio.h>
int main()
{
    int i,n,sum;
    sum=0;
    while(n>0)
    {
       scanf("%d",&n);
       if(n%2!=0) 
       {
         sum=sum+n;
       }
    }
    printf("%d",sum);
    return 0;
}