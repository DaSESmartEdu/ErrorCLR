#include<stdio.h>
int main()
{
	double x1=1,x2=2,cup1=1,cup2=2,sum=2,t;
	int i,n;
	scanf("%d",&n);
	for(i=1;i<n;i++){
		t=cup1;cup1=cup2;cup2=t+cup2;
		sum=sum+cup2/cup1;	
	}
	printf("%.2f",sum);
	return 0;
}