#include <stdio.h>
int sign(int x);
int main()
{
    int x;
    scanf("%d",&x);
    printf ("%d",sign(x));
    return 0;
}
int sign(int x)
{
    if (x>0)
    {
        printf("1\n");
    }
    else if (x==0)
    {
        printf("0\n");
    }
    else 
    {
        printf("-1");
    }
    return x;
}