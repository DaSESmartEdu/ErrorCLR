#include <stdio.h>
int main(void)
{
    int input;
    int i;
    int number = 0;
    int result;
    int fact = 0;
    char nums[7];
    scanf("%d", &input);
    switch (input)
    {
    case 3:
        for(result = 100; result <= 1000; result++)
        {
            sprintf(nums, "%d", result);
            fact = 0;
            for(i = 0; i < 3; i++)
            {
                fact = fact + (nums[i]-48)*(nums[i]-48)*(nums[i]-48);
            }
            if(fact == result)
            {
                number++;
            }
        }
        break;
    case 4:
        for(result = 1000; result <= 10000; result++)
        {
            sprintf(nums, "%d", result);
            fact = 0;
            for(i = 0; i < 4; i++)
            {
                fact = fact + (nums[i]-48)*(nums[i]-48)*(nums[i]-48)*(nums[i]-48);
            }
            if(fact == result)
            {
                number++;
            }
        }
        break;
    case 5:
        for(result = 10000; result <= 100000; result++)
        {
            sprintf(nums, "%d", result);
            fact = 0;
            for(i = 0; i < 5; i++)
            {
                fact = fact + (nums[i]-48)*(nums[i]-48)*(nums[i]-48)*(nums[i]-48)*(nums[i]-48);
            }
            if(fact == result)
            {
                number++;
            }
        }
        break;
    case 6:
        for(result = 100000; result <= 1000000; result++)
        {
            sprintf(nums, "%d", result);
            fact = 0;
            for(i = 0; i < 6; i++)
            {
                fact = fact + (nums[i]-48)*(nums[i]-48)*(nums[i]-48)*(nums[i]-48)*(nums[i]-48)*(nums[i]-48);
            }
            if(fact == result)
            {
                number++;
            }
        }
        break;
    case 7:
        for(result = 1000000; result <= 10000000; result++)
        {
            sprintf(nums, "%d", result);
            fact = 0;
            for(i = 0; i < 7; i++)
            {
                fact = fact + (nums[i]-48)*(nums[i]-48)*(nums[i]-48)*(nums[i]-48)*(nums[i]-48)*(nums[i]-48)*(nums[i]-48);
            }
            if(fact == result)
            {
                number++;
            }
        }
        break;
    default:
        break;
    }
    printf("%d", number);
    return 0;
}