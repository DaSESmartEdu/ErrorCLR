#include<iostream>
#include<vector>
using namespace std;
typedef struct 
{
    int x,y;
}point;
class Min_Heap
{
    public:
        vector<point> ans;
        void Heap_sort(int n)
        {
            Creat_List(n);
            for(int i=n/2;i>=0;i--)
            {
                Heap_Build(i,n,list);
            }
            for(int j=n-1;j>=0;j--)
            {
                ans.push_back(list[0]);
                swap(list[0],list[j]);
                Heap_Build(0,j,list);
            }
        }
    private:
        vector<point> list;
        void Creat_List(int n)
        {
            for(int i=0;i<n;i++)
            {
                point temp;
                cin>>temp.x>>temp.y;
                cout<<temp.x<<" "<<temp.y<<endl;
                list.push_back(temp);
            }
        }
        void Heap_Build(int root,int len,vector<point>& list)
        {
            int lchild = root*2+1;
            if(lchild<len)
            {
                int flag=lchild;
                int rchild=lchild+1;
                if(rchild<len && compare(list[rchild],list[lchild]))
                {
                    flag=rchild;
                }
                if(compare(list[flag],list[root]))
                {
                    swap(list[root],list[flag]);
                    Heap_Build(flag,len,list);
                }
            }
        }
        bool compare(point& p1,point& p2)
        {
            if(p1.x==p2.x)
                return p1.y<p2.y;
            return p1.x<p2.x;
        }
};
void Print_point(vector<point>& list,int n)
{
    int i=0;
    for(;i<n-1;i++)
    {
        cout<<"("<<list[i].x<<","<<list[i].y<<")"<<endl;
    }
    cout<<"("<<list[i].x<<","<<list[i].y<<")";
}
int main()
{
    int n;
    cin>>n;
    Min_Heap P;
    P.Heap_sort(n);
    Print_point(P.ans,n);
    return 0;
}