#include <stdio.h>
int main()
{
	int n,i,k,max;
    int a[10];
    scanf("%d",&n);
    for (i=0;i<n;i++)
    scanf("%d",&a[i]);
    for (k=0;k<=n-1;k++)
    {
    	max=k;
    	for(i=k+1;i<n;i++)
    	{
    	if(a[i]>a[k])
    	{
    	max=a[k];
    	a[k]=a[i];
    	a[i]=max;
    }
}
	}
	for(i=0;i<n;i++)
	printf("%d ",a[i]); 
	  }