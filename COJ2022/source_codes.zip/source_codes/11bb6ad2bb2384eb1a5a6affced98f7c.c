#include<stdio.h>
#include<math.h>
int main()
{
    int n;
    double a,i,c;
    scanf("%d",&n);
   for ( i = 1; i <=n; i++)
   {
      c=pow(-1,i+1);
      a+=c*(i/(2*i-1));
   }
    printf("%f",a);
}