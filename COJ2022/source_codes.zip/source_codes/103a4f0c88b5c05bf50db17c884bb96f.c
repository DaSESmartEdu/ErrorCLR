#include<stdio.h>
int main()
{
    char letter[26] = {'A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z'};
    char b;
    char ans[80];
    int count = 0;
    char m;
    b = getchar();
    while (b != '\n' && b != EOF){
        if (b>='A' && b<='Z'){
            for (int i=0;i<=25;i++){
                if (b == letter[i]){
                    m = letter[25-i];
                }
            }
        }
        else{
            m = b;
        }
        ans[count] = m;
        count++;
        b = getchar();
    }
    for(int j=0;j<=count-1;j++){
        printf("%c",ans[j]);
    }
}