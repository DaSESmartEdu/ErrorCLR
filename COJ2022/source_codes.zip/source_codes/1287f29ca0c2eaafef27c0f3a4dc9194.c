#include <stdio.h>
#include <math.h>
int Pow(a,b){
  int sum=1;
  for(int i=0;i<b;i++){
    sum*=a;
  }
  return sum;
}
int main()
{
    int n;
    scanf("%d", &n);
    int a = Pow(10, n-1);
   int b = Pow(10,n);
    int cnt=0;
    for (int i = a; i < b; i++)   
    { int sum = 0;
        int temp=i;
        while (temp!=0)
        {
           int m=temp%10;
            sum += Pow(m,n);
            temp /= 10;
        }
        if (sum == i)
        { 
          cnt+=1;
        }
    }
   printf("%d\n", cnt);
   return 0;
}