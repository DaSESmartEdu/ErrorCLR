#include<stdio.h>
int main()
{
    char s[80];
    char hexad[80];
    int i=0;
    while ((s[i]=getchar())!='#')
    {
        i++;
    }
    s[i]='\0';int j=0;
    for ( i = 0; s[i]!='\0';i++)
    {
        if ((s[i]>='0'&&s[i]<='9')||(s[i]>='A'&&s[i]<='F')||(s[i]>='a'&&s[i]<='f')||s[i]=='-')
        {
            hexad[j]=s[i];
            j++;
        }
    }
    hexad[j]='\0';
    long number=0;
    for ( i = 0; hexad[i]!='\0'; i++)
    {
        if (hexad[i]>='0'&&hexad[i]<='9')number=number*16+hexad[i]-'0';
        else if(hexad[i]>='A'&&hexad[i]<='F')number=number*16+hexad[i]-'A'+10;
        else if(hexad[i]>='a'&&hexad[i]<='f')number=number*16+hexad[i]-'a'+10;
    }
    if (hexad[0]=='-')
    {
        printf("%ld\n",-number);
    }else
    {
        printf("%ld\n",number);
    }
    return 0;
}