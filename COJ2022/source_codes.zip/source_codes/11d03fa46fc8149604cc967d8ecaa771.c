#include<stdio.h>
int main(){
    int j,k,i=0,n;
    scanf("%d",&n);
    int a[n+1];
    while(i<n){
        a[i++]=0;
    }
    i=0;
    while(i<n){
        scanf("%d",&a[n]);
        j=0;
        while(1){
            if(a[n]>=a[j]){
                for(k=n-1;k>j;k--){
                    a[k]=a[k-1];
                }
                a[j]=a[n];
                break;
            }
            j++;
        }
        i++;
    }
    i=0;
    while(i<n){
        printf("%d ",a[i++]);
    }
    return 0;
}