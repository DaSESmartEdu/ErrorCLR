#include <stdio.h>
int main(){
    int sum=0;
    int shuru;
    int i=1;
    while(i=1){
        scanf("%d",&shuru);
        if(shuru>0){
            if(shuru%2==1){
                sum+=shuru;
            }
            else;
        }
        else {
            i=0;
        }
    }
    printf("%d",sum);
    return 0;
}