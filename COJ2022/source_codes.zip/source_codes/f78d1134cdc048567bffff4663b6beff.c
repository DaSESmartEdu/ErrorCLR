#include<stdio.h>
int main()
{
	int n, a[3000], imax=0;
	scanf("%d", &n);
	for (int i=0; i<3000; i++) a[i]=1;
	for (int num=2; num<=n; num++){
		for (int i=0; i<=imax; i++){
			a[i] *= num;
		}
		for (int i=0; i<=imax; i++){
			if (a[i]>1000){
				a[i+3]+=a[i]/1000;
				a[i]%=1000;
				a[i+2]+=a[i]/100;
				a[i]%=100;
				a[i+1]+=a[i]/10;
				a[i]%=10;
				if(i==imax){
					imax+=3;
					a[i+1]--;
					a[i+2]--;
					a[i+3]--;
				}
			}
			if (a[i]>100){
				a[i+2]+=a[i]/100;
				a[i]%=100;
				a[i+1]+=a[i]/10;
				a[i]%=10;
				if(i==imax){
					imax+=2;
					a[i+1]--;
					a[i+2]--;
				}
			}
			if (a[i]>10){
				a[i+1]+=a[i] / 10;
				a[i] %= 10;
				if(i==imax){
					imax+=1;
					a[i+1]--;
				}
			}
		}
	}
	for(int i=imax; i>=0; i--) printf("%d", a[i]);
	return 0;
}