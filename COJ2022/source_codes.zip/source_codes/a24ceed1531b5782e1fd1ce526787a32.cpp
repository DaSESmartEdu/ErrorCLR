#include<iostream>
using namespace std;
int a[201][201];
void out(int up,int below,int first,int last)
{
    if(first>last||up>below)return;
    for(int i=up;i<=below;i++)
    {
        if(i!=0)cout<<" ";
        cout<<a[i][first];
    }
    for(int i=first+1;i<=last;i++)
    {
        cout<<" "<<a[below][i];
    }
    for(int i=below-1;i>=up;i--)
    {
        cout<<" "<<a[i][last];
    }
    for(int i=last-1;i>=first+1;i--)
    {
        cout<<" "<<a[up][i];
    }
    out(up+1,below-1,first+1,last-1);
}
int main()
{
    int m,n;
    cin>>m>>n;
    for(int i=0;i<m;i++)
    for(int j=0;j<n;j++)
    cin>>a[i][j];
    out(0,m-1,0,n-1);
    return 0;
}