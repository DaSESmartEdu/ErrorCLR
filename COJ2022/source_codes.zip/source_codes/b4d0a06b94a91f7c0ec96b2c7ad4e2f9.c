#include <stdio.h>
int main()
{
    int x=0;
    float y=0;
    scanf("%d",&x);
    if(x<=50){
        y=0.53*x;
    }else{
        y=26.5+0.57*(x-50);
    }
    printf("%.6f",y);
    return 0;
}