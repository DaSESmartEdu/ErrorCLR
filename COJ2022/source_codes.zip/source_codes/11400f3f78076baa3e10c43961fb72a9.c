#include <stdio.h>
int prime(int p);
int PrimeSum(int m, int n);
int main()
{
	int m, n;
	scanf("%d%d", &m, &n);
	printf("%d\n", PrimeSum(m, n));
	return 0;
}
int prime(int p) {
	int a = 1;
	for(int i = 2; i < p; i++) {
		if(p % i == 0) {
			a = 0;
			break;
		}
	}
	if(p <= 1) a = 0;
	return a;
}
int PrimeSum(int m, int n) {
	int sum = 0;
	for(int i = m; i <= n; i++) {
		if(prime(i) == 1)
		sum += i;
	}
	return sum;
}