#include<bits/stdc++.h>
using namespace std;
template <class entry1, class entry2>
class myHeap
{
    public:
        vector<pair<entry1, entry2>> aryOfHeap;
        int sizeOfHeap;
        void buildHeap(int size, int k);
        void mySwap(pair<entry1, entry2> &a, pair<entry1, entry2> &b);
        char compare(pair<entry1, entry2> a, pair<entry1, entry2> b) const;  
        void heapSort(int posi);
        void myPrint() const;
    private:
};
template <class entry1, class entry2>
void myHeap<entry1, entry2>::buildHeap(int size, int k)
{
    sizeOfHeap = 0;
    int i = size;
    while(i--)
    {
        entry1 ele1;
        entry2 ele2;
        cin>>ele1>>ele2;
        aryOfHeap.push_back(pair<entry1, entry2> (ele1, ele2));
        sizeOfHeap = aryOfHeap.size();
        if(size-i >= k)
        {
            for(int m = 0; m < k; m++)
            {
                for(int j = sizeOfHeap / 2 - 1; j >= 0; j--)
                    heapSort(j);
                cout<<'('<<aryOfHeap[0].first<<','<<aryOfHeap[0].second<<(m<k-1?")\n":")");
                mySwap(aryOfHeap[0], aryOfHeap[sizeOfHeap-1]);
                sizeOfHeap--;
            }
        }
    }
    sizeOfHeap = size;
}
template <class entry1, class entry2>
void myHeap<entry1, entry2>::mySwap(pair<entry1, entry2> &a, pair<entry1, entry2> &b)
{
    pair<entry1, entry2> temp(a.first, a.second);
    a.first = b.first; a.second = b.second;
    b.first = temp.first; b.second = temp.second;
}
template <class entry1, class entry2>
char myHeap<entry1, entry2>::compare(pair<entry1, entry2> a, pair<entry1, entry2> b) const
{
    if(a.first > b.first) return 1;
    if(a.first < b.first) return -1;
    if(a.second > b.second) return 1;
    if(a.second < b.second) return -1;
    return 0;
}
template <class entry1, class entry2>
void myHeap<entry1, entry2>::heapSort(int i)
{
    if(2*i+1 >= sizeOfHeap) return ;
    if(compare(aryOfHeap[i], aryOfHeap[2*i+1]) == 1)
    {
        if(2*i+2 < sizeOfHeap && compare(aryOfHeap[2*i+1], aryOfHeap[2*i+2]) == 1)
        {
            mySwap(aryOfHeap[i], aryOfHeap[2*i+2]);
            heapSort(2*i+2);
        }
        else
        {
            mySwap(aryOfHeap[i], aryOfHeap[2*i+1]);
            heapSort(2*i+1);
        }
    }
    else if(2*i+2 < sizeOfHeap && compare(aryOfHeap[i], aryOfHeap[2*i+2]) == 1)
    {
        mySwap(aryOfHeap[i], aryOfHeap[2*i+2]);
        heapSort(2*i+2);
    }
}
template <class entry1, class entry2>
void myHeap<entry1, entry2>::myPrint()const
{
    for(int i = 0; i < sizeOfHeap; i++) cout<<'('<<aryOfHeap[i].first<<','<<aryOfHeap[i].second<<(i == sizeOfHeap-1?")":")\n");
}
int main()
{
    myHeap<int, int> hp;
    int size, k;
    cin>>size>>k;
    hp.buildHeap(size, k);
    return 0;
}