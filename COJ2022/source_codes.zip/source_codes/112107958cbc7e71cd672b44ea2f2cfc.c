#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<math.h>
long long fac (int x);
int main()
{
    int n;
    scanf("%d", &n);
    printf("%lld", fac(n));
    return 0;
}
long long fac (int x)
{
    long long res;
    switch (x)
    {
        case 1: res=1;break;
        case 2: res=2;break;
        default : res=x*fac(x-2);
    }
    return res;
}