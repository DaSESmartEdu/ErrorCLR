#include <stdio.h>
int main()
{
    int n, m;
    scanf("%d", &m);
    scanf("%d", &n);
    float sum = 0;
    for(int i = m; i <= n; i++)
    {
        sum += i * i + 1.0/i;
    }
    printf("%f", sum);
    return 0;
}