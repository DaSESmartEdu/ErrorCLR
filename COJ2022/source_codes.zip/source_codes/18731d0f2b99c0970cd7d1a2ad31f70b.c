#include <stdio.h>;
double fact(int n);
int main()
{
    int i,n;
    double result,sum;
    sum=0;
    scanf("%d",&n);
    for(i=0;i<=n;i++)
	{
		result=fact(i);
        sum=sum+result;
	}
	printf("%.0f",sum);
    return 0;
}
    double fact(int n)
    {
        int i;
        double x;
		x=1;
        for(i=1;i<=n;i++)
        {
          x=x*i;
        }
       return x; 
    }