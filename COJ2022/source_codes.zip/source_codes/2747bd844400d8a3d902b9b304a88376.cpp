#include<iostream>
#include<algorithm>
using namespace std;
int main()
{
    int x;
    cin>>x;
    int m[35];
    for (int i=0;i<x;i++)
    {
        cin>>m[i];
    }
    sort(m,m+x);
    while(sizeof(m)>1)
    {
        if(m[x]!=m[x-1])
        {
            m[x] = m[x]-m[x-1];
            x = x-1;
        }
        else if(m[x] == m[x-1])
        {
            m[x] = 0;
            m[x-1] = 0;
            x = x-2;
        }
        sort(m,m+x);
    }
    cout<<m[0];
    return 0;
}