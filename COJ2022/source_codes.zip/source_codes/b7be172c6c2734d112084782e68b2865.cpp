#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <algorithm>
using namespace std;
int judge(pair<int, int> a, pair<int, int> b)
{
    if(a.first > b.first)
        return 1;
    if(a.first == b.first && a.second > b.second)
        return 1;
    return 0;
}
void max_heapify(pair<int, int> arr[], int start, int end)
{
    int dad = start;
    int son = dad * 2 + 1;
    while (son <= end)
    {
        if (son + 1 <= end && judge(arr[son + 1], arr[son]))
            son++;
        if (arr[dad] > arr[son])
            return;
        else {
            swap(arr[dad], arr[son]);
            dad = son;
            son = dad * 2 + 1;
        }
    }
}
void heap_sort(pair<int, int> arr[], int len) {
    for (int i = len / 2 - 1; i >= 0; i--)
        max_heapify(arr, i, len - 1);
    for (int i = len - 1; i > 0; i--)
    {
        swap(arr[0], arr[i]);
        max_heapify(arr, 0, i - 1);
    }
}
int main()
{
    int N, K;
    cin >> N >> K;
    pair<int, int> heap[N];
    for(int i = 0; i < N; i++)
    {
        cin >> heap[i].first >> heap[i].second;
        if(i >= K - 1)
        {
            heap_sort(heap, i + 1);
            for (int j = 0; j < K - 1; j++)
                printf("(%d,%d)\n", heap[j].first, heap[j].second);
            printf("(%d,%d)", heap[K - 1].first, heap[K - 1].second);
        }
    }
    return 0;
}