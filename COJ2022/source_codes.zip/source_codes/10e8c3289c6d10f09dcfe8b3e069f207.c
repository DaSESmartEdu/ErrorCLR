#include<stdio.h>
int even(int n){
	if(n%2==0) return 1;
	else return 0;
}
int main(){
    int m,n,ans;
    scanf("%d",&n);
    for(int i=1;i<=n;i++){
    	scanf("%d",&m);
    	if(even(m)==0) ans+=m;
	}
	printf("%d",ans);
	return 0;
}