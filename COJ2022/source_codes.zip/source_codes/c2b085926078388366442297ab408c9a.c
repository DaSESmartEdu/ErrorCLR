#include <stdio.h>
int main()
{
    int a;
    float b;
    scanf("%d",&a);
    if
		(a<=50)
    {
    b=a*0.53;
    printf("%f",b);
    }
    else;
	{  
        b=(a-50)*0.58+26.5;
        printf("%f",b);
        }
    return 0;
}