#include<stdio.h>
#include<math.h>
int main()
{
    int a,n,i,item=a,sum=0;
    scanf("%d %d",&a,&n);
    for(i=2;i<=n;i++)
    {
      item+=a*pow(10,i-1);
      sum+=item;
    }
    printf("%d",sum);
    return 0;
}