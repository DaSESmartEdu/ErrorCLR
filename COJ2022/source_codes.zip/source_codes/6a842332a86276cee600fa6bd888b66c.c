#include <stdio.h>
int main()
{
    int m,n,sum=0;
    scanf("%d %d",&m,&n);
    if(m>n){
        int x;
        x=m;
        m=n;
        n=m;
    }
	int i;
    for(i=m;i<=n;i++){
        int j=2;
        for(j=2;j<i;j++){
            if(i%j==0){
                break;
            }
        }if(j=i-1){
            sum+=i;
        }  
    }
    printf("%d",sum);
    return 0;
}