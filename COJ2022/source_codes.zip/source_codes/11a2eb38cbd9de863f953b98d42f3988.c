#include<stdio.h>
#include<math.h>
void splitfloat(float x,int *intpart,float *fracpart)
{
    *intpart=round(x);
    if(*intpart>x)(*intpart)--;
    *fracpart=x-*intpart;
}
int main()
{
    float x;
    scanf("%f",&x);
    int xi;
    float xj;
    splitfloat(x,&xi,&xj);
    printf("%d %.3f\n",xi,xj);
    return 0;
}