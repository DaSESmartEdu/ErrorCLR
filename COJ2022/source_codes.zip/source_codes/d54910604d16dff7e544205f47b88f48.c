#include<stdio.h>
#include<math.h>
int main()
{
int n;
int i=1;
scanf("%d",&n);
double m=0;
do 
{
	m=m+pow(-1,i-1)*i/(2i-1);
	i++;
}while(i<=n);
	printf("%.6f",m);
return 0;	
}