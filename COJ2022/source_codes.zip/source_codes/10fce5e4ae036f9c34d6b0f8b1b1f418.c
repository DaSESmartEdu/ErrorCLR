#include <stdio.h>
#include <math.h>
int fact(int);
int main()
{
  int t=2;
  double x=0;
  double sum=1,ind=0;
  scanf("%lf",&x);
  ind=x;
  while(fabs(ind)>=0.00001)
  {
    sum+=ind;
    ind=pow(x,t)/fact(t);
    t++;
  }
  printf("%.4lf",sum);
  return 0;
}
int fact(int n)
{
  int sum=1,t=1;
  for (t=1;t<=n;t++)
  {
    sum*=t;
  }
  return sum;
}