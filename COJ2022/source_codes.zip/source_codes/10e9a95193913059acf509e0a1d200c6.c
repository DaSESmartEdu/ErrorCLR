#include <stdio.h>
double calc_pow(double x,int n);
int main()
{
    double x;
    int n;
    scanf("%lf %d",&x,&n);
    printf("%.0lf",calc_pow(x,n));
}
double calc_pow(double x,int n)
{
    if (n==1)
    return x;
    return calc_pow(x,n-1)*x;
}