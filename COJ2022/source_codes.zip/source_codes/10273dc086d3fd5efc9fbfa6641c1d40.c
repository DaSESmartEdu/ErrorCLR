#include <stdio.h>
void strmcpy(char *t,int m,char *s);
int main()
{
 int m,i=0;
 char t[100],s[100];
 scanf("%d\n",&m);
 gets(t);
 strmcpy(t,m,s);
 printf("%s",s);
 return 0;
}
void strmcpy(char *t,int m,char *s)
{ 
 t=t+m-1;
 while(*t!='\0')
 {
  *s=*t;
  s++;
  t++;
 }
}