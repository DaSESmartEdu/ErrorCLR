#include<stdio.h>
int main()
{
	int a,b,c;
	scanf("%d %d %d",&a,&b,&c);
	int A,B,C;
	if(a>b){
		if(a<c){A=c,B=a,C=c;}
		else{if(b>c){A=a,B=b,C=c;}
			else{A=a,B=c,C=b;};}
	}
	else{if(b<c){A=c,B=b,C=c;}
		else{if(a>c){A=b,B=a,C=c;}
			else{A=b,B=c,C=a;};}
		}
	printf("%d %d %d",C,B,A);
	return 0;
}