#include<stdio.h>
int fib(int n){
    int i=2;
    int a[100]={1,1};
    while(i<n){
        a[i]=a[i-1]+a[i-2];
        i++;
    }
    return a[i-1];
}
void PrintFN(int m,int n){
    int i=1,c=1;
    while (fib(i)<=n){
        if(fib(i)>=m){
            if(c)c--;
            else printf(" ");
            printf("%d",fib(i));
            }
        i++;
    }
}
int main(){
    int m,n,t;
    scanf("%d %d %d",&m,&n,&t);
    printf("%d\n",fib(t));
    PrintFN(m,n);
    return 0;
}