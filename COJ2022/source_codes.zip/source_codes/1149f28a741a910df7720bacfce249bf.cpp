#include <iostream>
#include <math.h>
using namespace std;
void Strassen_Multi(int** arr1,int ** arr2,int x1, int y1, int x2, int y2,int ** arr3,int M){
    if(M==1){
        arr3[0][0]=arr1[x1][y1]*arr2[x2][y2];
    }
	else if(M<=32){
		int i,j,k;
		for(i=0;i<M;i++){
           for(j=0;j<M;j++){
               arr3[i][j]=0;
               for(k=0;k<M;k++){
                   arr3[i][j]+=arr1[x1+i][y1+k]*arr2[x2+k][y2+j];
               }
           }
       }
	}
    else{
        int half = M/2;
        int i,j,k;
        int **S1 = new int* [half];
        int **S2 = new int* [half];
        int **S3 = new int* [half];
        int **S4 = new int* [half];
        int **S5 = new int* [half];
        int **S6 = new int* [half];
        int **S7 = new int* [half];
        int **S8 = new int* [half];
        int **S9 = new int* [half];
        int **S10 = new int*[half];
        for(i=0;i<half;i++){
            S1[i] = new int[half];
            S2[i] = new int[half];
            S3[i] = new int[half];
            S4[i] = new int[half];
            S5[i] = new int[half];
            S6[i] = new int[half];
            S7[i] = new int[half];
            S8[i] = new int[half];
            S9[i] = new int[half];
            S10[i] = new int[half];
        }
       for(i=0;i<half;i++){
           for(j=0;j<half;j++){
               S1[i][j]=arr2[i+x2][j+y2+half]-arr2[i+x2+half][j+y2+half];
               S2[i][j]=arr1[i+x1][j+y1]+arr1[i+x1][j+y1+half];
               S3[i][j]=arr1[i+x1+half][y1+j]+arr1[i+x1+half][j+y1+half];
               S4[i][j]=arr2[i+x2+half][j+y2]-arr2[i+x2][j+y2];
               S5[i][j]=arr1[i+x1][j+y1]+arr1[i+x1+half][j+y1+half];
               S6[i][j]=arr2[i+x2][j+y2]+arr2[i+x2+half][j+y2+half];
               S7[i][j]=arr1[i+x1][j+y1+half]-arr1[i+x1+half][j+y1+half];
               S8[i][j]=arr2[i+x2+half][y2+j]+arr2[i+x2+half][j+y2+half];
               S9[i][j]=arr1[i+x1][j+y1]-arr1[i+x1+half][j+y1];
               S10[i][j]=arr2[i+x2][j+y2]+arr2[i+x2][j+half+y2];
           }
       }
      int **P1 = new int* [half];
      int **P2 = new int* [half];
      int **P3 = new int* [half];
      int **P4 = new int* [half];
      int **P5 = new int* [half];
      int **P6 = new int* [half];
      int **P7 = new int* [half];
    for(i=0;i<half;i++){
        P1[i] = new int[half];
        P2[i] = new int[half];
        P3[i] = new int[half];
        P4[i] = new int[half];
        P5[i] = new int[half];
        P6[i] = new int[half];
        P7[i] = new int[half];
    }
       Strassen_Multi(arr1,S1,x1,y1,0,0,P1,half);
       Strassen_Multi(S2,arr2,0,0,x2+half,y2+half,P2,half);
       Strassen_Multi(S3,arr2,0,0,x2,y2,P3,half);
       Strassen_Multi(arr1,S4,x1+half,y1+half,0,0,P4,half);
       Strassen_Multi(S5,S6,0,0,0,0,P5,half);
       Strassen_Multi(S7,S8,0,0,0,0,P6,half);
       Strassen_Multi(S9,S10,0,0,0,0,P7,half);
       for(i=0;i<half;i++){
           for(j=0;j<half;j++)
           arr3[i][j]=P5[i][j]+P4[i][j]-P2[i][j]+P6[i][j];
       }
       for(i=0;i<half;i++){
           for(j=half;j<M;j++)
           arr3[i][j]=P1[i][j-half]+P2[i][j-half];
       }
       for(i=half;i<M;i++){
           for(j=0;j<half;j++)
           arr3[i][j]=P3[i-half][j]+P4[i-half][j];
       }
       for(i=half;i<M;i++){
           for(j=half;j<M;j++)
           arr3[i][j]=P5[i-half][j-half]+P1[i-half][j-half]-P3[i-half][j-half]-P7[i-half][j-half];
       }  
       delete S1;
       delete S2;
       delete S3;
       delete S4;
       delete S5;
       delete S6;
       delete S7;      
       delete S8;
       delete S9;
       delete S10;
       delete P1;   
       delete P2;
       delete P3;   
       delete P4;
       delete P5;   
       delete P6;
       delete P7;   
    }
}
int main(){
    ios::sync_with_stdio(false); 
    cin.tie(nullptr);
    int N,M;
    int i,j,k;
    cin>>N>>M;
    int tmpM=M,yu=0,init_M=M;
    while(yu==0){
        if(tmpM==2) break;
        yu = tmpM%2;
        tmpM/=2;
    }
    if(yu==1){
        int pow2;
        for(i=1;i<=9;i++){
            pow2=pow(2,i);
            if(pow2>M){
                init_M=M;
                M = pow2;
                break;
            }
        }
    }
   int **arr1 = new int* [M];
   int **arr2 = new int* [M];
   int **arr3 = new int* [M];
   for(i=0;i<M;i++){
       arr1[i] = new int[M];
       arr2[i] = new int[M];
       arr3[i] = new int[M];
   }
   while(N--){
       for(i=0;i<M;i++){
           for(j=0;j<M;j++){
               if(i<init_M && j<init_M) cin>>arr1[i][j];
               else arr1[i][j] = 0;
           }
       }
       for(i=0;i<M;i++){
           for(j=0;j<M;j++){
               if(i<init_M && j<init_M) cin>>arr2[i][j];
               else arr2[i][j] = 0;
           }
       }
       Strassen_Multi(arr1,arr2,0,0,0,0,arr3,M);
          for(i=0;i<init_M;i++){
           for(j=0;j<init_M;j++){
               cout<<arr3[i][j];
               if(j<init_M-1) cout<<" ";
               else cout<<endl;
           }
       }
   }
}