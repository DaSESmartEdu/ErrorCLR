#include <stdio.h>
int main()
{
    int n,i;
    double grade;
    scanf("%d\n", &n);
    for (i=1;i<=n;i++)
    {
        scanf("%lf", &grade);
        if(grade>=90)
        {
            printf("A");
        }
        if(grade<90&&grade>=80)
        {
            printf("B");
        }
        if(grade<80&&grade>=70)
        {
            printf("C");
        }
        if(grade<70&&grade>=60)
        {
            printf("D");
        }
        if(grade<60)
        {
            printf("E");
        }
    }
    return 0;
}