#include<stdio.h>
int main()
{
    int a;
    scanf("%d",&a);
    float m;
    if (a<=50){
        m=a*0.53;
    } else{
    m=26.5+0.58*(m-50);
    }
    printf("%f\n",m);
    return 0;
}