#include<stdio.h>
#include<math.h>
double fact(int a)
{
    int ans=1,i;
    if(a<=1)return 1;
    for(i=1;i<=a;i++){
    ans*=i;
	}return ans;
}
int main()
{
    int j;
	double n;
    float x,s;
    unsigned long long sum;
    scanf("%lf",&n);
for(j=1;fabs(pow(n,j)/fact(j))>=0.00001;j++){
	s=s+pow(n,j)/fact(j);
}
x=s+1;
printf("%.4f",x);
    return 0;
}