#include <stdio.h>
int main()
{
    int n,m;
    double a,b;
    scanf("%d %d",&n,&m);
    a=1.1*m;
    b=1.5*m;
    if (n<=m)
        {
        printf("normal");
        }
    else if (n>=a&&n<b)
        {
        printf("200");
        }
    else
        {
        printf("revoke");
        }
    return 0;
}