#include<stdio.h>
#include<stdlib.h>
#include<string.h>
int main()
{
int i,j=0;
int count=0;
char a[10000];
gets(a);
if(a[0]!=' ')
{
count=1;
}
for(i=0;i<strlen(a)-1;i++)
{
if(a[i]==' '&&a[i+1]!=' ')
{
count++;
}
}
printf("%d",count);
return 0;
}