#include<stdio.h>
int fc(int a,int b);
int main()
{
    int n,N,a=1,b,i,sum=0;
    scanf("%d",&N);
    for(i=fc(10,N-1);i<fc(10,N);i++) {
        n=1;
        a=i/fc(10,N-n);
        sum=fc(a,N);
        b=i-a*fc(10,N-n);
        while(N-n>0) {
            a=b/fc(10,N-n-1);
            b=b-a*fc(10,N-n-1);
            sum=sum+fc(a,N);
            n++;
        }
    if(sum==i) {
        printf("%d\n",i);}
    }
    return 0;
}
int fc(int a,int b) {
    int pow=1,j;
    for(j=1;j<=b;j++) {
        pow=pow*a;
    }
    return pow;
}