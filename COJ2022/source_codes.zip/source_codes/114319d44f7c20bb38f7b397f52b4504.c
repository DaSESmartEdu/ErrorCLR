#include <stdio.h>
void StringCount(char s[])
{
    int i=0,a=0,b=0,c=0,d=0;
    while((s[i]=getchar())!=EOF)
    {
        if(s[i]>='a'&&s[i]<='z')
        a++;
        else
        {
            if(s[i]>='A'&&s[i]<='Z')
            a++;
            else
            {
                if(s[i]==' '||s[i]=='\n')
                b++;
                else
                {
                    if(s[i]>='0'&&s[i]<='9')
                    c++;
                    else
                    d++;
                }
            }
        }
        i++;
    }  
    printf("%d ",a);
    printf("%d ",b);
    printf("%d ",c);
    printf("%d ",d);
}
int main()
{
    int n,i=0;
    char s[100000];
    StringCount(s);
    return 0;
}