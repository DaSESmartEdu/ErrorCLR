#include<stdio.h>
int main()
{
	int a,b,c,d;
	scanf("%d %d %d %d",&a,&b,&c,&d);
	int e = a+b+c+d;
	float f = e/4.0;
	printf("%d %.1f",&e,&f);	
	return 0;
}