#include <stdio.h>
void count(int n, int sum[])
{
    while(n>0)
    {
        sum[n%10]++;
        n/=10;
    }
}
int main(void)
{
    int n, imax, max=0, flag=1;
    scanf("%d", &n);
    int numbers[n];
    int sum[10]={0};
    for(int i=0;i<n;i++)
    {
        scanf("%d", &numbers[i]);
        count(numbers[i], sum);
    }
    while(flag)
    {
        max = 0;
        for(int i=0;i<10;i++)
        {
            if(sum[i]>max)
            {
                max = sum[i];
                imax = i;
                flag = 0;
                sum[i] = 0;
            }
        }
        for(int i=0;i<10;i++)
        {
            if(sum[i]==max)
                flag = 1;
        }
        printf("%d", imax);
    }
}