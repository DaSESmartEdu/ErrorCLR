#include <iostream>
#include <stdlib.h>
#include <cmath>
#include <vector>
#include <map>
using namespace std;
int K=3628800;
int N;
int main()
{
    int n;
    while(cin>>n)
    {
        N=n;
        int m;
        cin>>m;
        vector<int> jc={1,1,2,6,24,120,720,5040,40320,362880,3628800};
        int *ans=new int [n];
        int *ans2=new int [n];
        for(int i=0;i<n;i++)
        {
            ans2[i]=0;
        }
        for(int i=0;i<n;i++)
        {
            int t2=m%jc[n-i-1];
            int t=m/jc[n-i-1];
            if(t2!=0)
            {
                t++;
            }
            if(m==0)
            {
                for(int j=n-1;j>=0;j--)
                {
                    if(ans2[j]==0)
                    {
                        cout<<j;
                    }
                }
                break;
            }
            else{
                int cnt=0;
                for(int j=0;j<n;j++)
                {
                    if(ans2[j]==0)
                    {
                        cnt++;
                    }
                    if(cnt==t)
                    {
                        cout<<j;
                        ans2[j]=1;
                        break;
                    }
                }
            }
            m=m%jc[n-i-1];
        }
        delete [] ans;
    }
}