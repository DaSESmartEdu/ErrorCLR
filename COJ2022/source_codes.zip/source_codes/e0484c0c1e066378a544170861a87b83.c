#include <stdio.h>
int main()
{
    float n,m;
    scanf("%f %f",&n,&m);
    if(n<m){
        printf("normal\n");
    }
    else if(n<m*1.5){
        printf("200\n");
    }
    else{
            printf("revoke\n");
        }
        return 0;
}