#include<stdio.h>
int dp[2][500000];
#define MOD 100000007
int main()
{
	int n,s,a,b;
	scanf("%d%d%d%d",&n,&s,&a,&b);
	int e=0;
	dp[0][0]=1;
	for (int i=1;i<=499999;i++)
	{
		dp[0][i]=0;
		dp[1][i]=0;
	}
	for (int i=2;i<=n;i++)
	{
		e=1-e;
		for (int j=0;j<=i*(i-1)/2;j++)
		{
			dp[e][j]=dp[1-e][j];
			if (j>=(i-1))
			{
				dp[e][j]=(dp[e][j]+dp[1-e][j-(i-1)])%100000007;
			}
		}
	}
	int ans=0;
	long long sumup;
	for (int i=0;i<=n*(n-1)/2;i++)
	{
		sumup=(s%n)-(a%n*i%n)%n+(b%n*(n*(n-1)/2-i)%n)%n;
		if (sumup%n==0)
			ans=(ans+dp[e][i])%100000007;
	}
	printf("%d",ans);
	return 0;
}