#include<iostream>
using namespace std;
typedef struct TNode* BST;
struct TNode{
    int key;
    char color;
    BST Left;
    BST Right;
    BST Par;
};
void midtraversal(BST BT,BST T);
void insert(BST &BT,BST T,int key);
void RBINSERTFIXUP(BST &BT,BST T,BST z);
void RightROTATE(BST &BT,BST T,BST x);
void LeftROTATE(BST &BT,BST T,BST x);
int main()
{
    BST T=new struct TNode;
    T->color='B';
    BST BT=new struct TNode;
    BT=T;
    int N,a;
    cin>>N;
    for(int i=0;i<N;i++)
    {
        cin>>a;
        insert(BT,T,a);
    }
    midtraversal(BT,T);
    return 0;
}
void midtraversal(BST BT,BST T)
{
    if(BT==T) return;
    midtraversal(BT->Left,T);
    cout<<BT->color;
    midtraversal(BT->Right,T);
}
void insert(BST &BT,BST T,int key)
{
    BST y=T;
    BST x=BT;
    while (x!=T)
    {
        y=x;
        if(key<x->key) x=x->Left;
        else x=x->Right;
    }
    BST z=new struct TNode;
    z->Par=y;
    z->key=key;
    if(y==T) BT=z;
    else if (z->key<y->key)
    {
        y->Left=z;
    }
    else y->Right=z;
    z->Left=T;
    z->Right=T;
    z->color='R';
    RBINSERTFIXUP(BT,T,z);
}
void RBINSERTFIXUP(BST &BT,BST T,BST z)
{
    BST y=NULL;
    while(z->Par->color=='R')
    {
        if(z->Par==z->Par->Par->Left)
        {
            y=z->Par->Par->Right;
            if(y->color=='R')  
            {
                z->Par->color='B';    
                y->color='B';
                z->Par->Par->color='R';
                z=z->Par->Par;
                continue;  
            }
            else if(z==z->Par->Right)
            {
                z=z->Par;
                LeftROTATE(BT,T,z);
            }
            z->Par->color='B';
            z->Par->Par->color='R';
            RightROTATE(BT,T,z->Par->Par);
        }
        else     
        {
            y=z->Par->Par->Left;
            if(y->color=='R')  
            {
                z->Par->color='B';    
                y->color='B';
                z->Par->Par->color='R';
                z=z->Par->Par;
                continue;   
            }
            else if(z==z->Par->Left)
            {
                z=z->Par;
                RightROTATE(BT,T,z);
            }
            z->Par->color='B';
            z->Par->Par->color='R';
            LeftROTATE(BT,T,z->Par->Par);
        }
    }
    BT->color='B';  
}
void RightROTATE(BST &BT,BST T,BST x)
{
    BST y=NULL;
    y=x->Left;
    x->Left=y->Right;
    if(y->Right!=T)  y->Right->Par=x;
    y->Par=x->Par;
    if(x->Par==T)   BT=y;
    else if(x==x->Par->Right) x->Par->Right=y;
    else x->Par->Left=y;
    y->Right=x;
    x->Par=y;
}
void LeftROTATE(BST &BT,BST T,BST x)
{
    BST y=NULL;
    y=x->Right;
    x->Right=y->Left;
    if(y->Left!=T)  y->Left->Par=x;
    y->Par=x->Par;
    if(x->Par==T)   BT=y;
    else if(x==x->Par->Left) x->Par->Left=y;
    else x->Par->Right=y;
    y->Left=x;
    x->Par=y;
}