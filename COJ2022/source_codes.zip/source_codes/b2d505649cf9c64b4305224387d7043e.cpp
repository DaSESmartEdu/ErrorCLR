#include <iostream>
#include <queue>
typedef int Max;
template <class Entry>
class Binary_node {
public:
	Entry data;
	Binary_node<Entry>* parent;		
	Binary_node<Entry>* left;		
	Binary_node<Entry>* right;		
	Binary_node();
	Binary_node(const Entry data);
};
template <class Entry>
Binary_node<Entry>::Binary_node()
{
    this->parent = this->left = this->right = NULL;
}
template <class Entry>
Binary_node<Entry>::Binary_node(const Entry data)
{
    this->data = data;
    this->parent = this->left = this->right = NULL;
}
template <class Entry>
class Binary_search_tree {
private:
	Binary_node<Entry>* root;
	Max count;
	void height(Binary_node<Entry>* root, Max &h, Max d);
	Binary_node<Entry>* build_from_pre_order(Binary_node<Entry>* parent, Entry *array, Max &index, Max num, Entry flag);
	Binary_node<Entry>* build_from_post_order(Binary_node<Entry>* parent, Entry *array, Max &index, Entry flag);
	bool insert(Binary_node<Entry>* &root, Binary_node<Entry>* new_node);
	Binary_node<Entry>* find(Binary_node<Entry>* root, Entry key);
	void pre_order_print(Binary_node<Entry>* root);
	void in_order_print(Binary_node<Entry>* root);
	void post_order_print(Binary_node<Entry>* root);
	void level_order_print(Binary_node<Entry>* root);
	void clear(Binary_node<Entry>* root);
	void remove_node(Binary_node<Entry>* node);
	void solsl(Binary_node<Entry>* node, Max &sum);
	void sorsl(Binary_node<Entry>* node, Max &sum);
public:	
	Binary_search_tree();
	~Binary_search_tree();
	Binary_node<Entry>* get_root();
	bool empty();
	Max size();
	Max height();
	void build_from_pre_order(Entry *array, Max num, Entry flag);
	void build_from_post_order(Entry *array, Max num, Entry flag);
	void insert(Entry key);
	void remove(Entry key);
	bool find(Entry key);
	void clear();
	void pre_order_print();
	void in_order_print();
	void post_order_print();
	void level_order_print();
	Max sum_of_left_sub_leaves();
	Max sum_of_right_sub_leaves();
};
template <class Entry>
Binary_search_tree<Entry>::Binary_search_tree()
{
	this->root = NULL;
	this->count = 0;
}
template <class Entry>
Binary_search_tree<Entry>::~Binary_search_tree()
{
	clear();
}
template <class Entry>
Binary_node<Entry>* Binary_search_tree<Entry>::get_root()
{
	return root;
}
template <class Entry>
bool Binary_search_tree<Entry>::empty()
{
	return root == NULL;
}
template <class Entry>
Max Binary_search_tree<Entry>::size()
{
	return this->count;
}
template <class Entry>
void Binary_search_tree<Entry>::height(Binary_node<Entry>* node, Max &h, Max d)
{
	if (h < d) h = d; 
	if (!node) return;	
	height(node->left, h, d+1);
	height(node->right, h, d+1);
}
template <class Entry>
Max Binary_search_tree<Entry>::height()
{
	int h = 0;
	height(root, h, 0);
	return h;
}
template <class Entry>
Binary_node<Entry>* Binary_search_tree<Entry>::build_from_pre_order(Binary_node<Entry>* parent, Entry* array, Max &index, Max num, Entry flag)
{
	if (index > num || array[index] == flag) return NULL;
	Binary_node<Entry> *new_node = new Binary_node<Entry>(array[index]);
	new_node->parent = parent;
	new_node->left = build_from_pre_order(new_node, array, ++index, num, flag);
	new_node->right = build_from_pre_order(new_node, array, ++index, num, flag);
	this->count++;
	return new_node;
}
template <class Entry>
void Binary_search_tree<Entry>::build_from_pre_order(Entry *array, Max num, Entry flag)
{
	int index = 0;
	this->root = build_from_pre_order(this->root, array, index, num-1, flag);
}
template <class Entry>
Binary_node<Entry>* Binary_search_tree<Entry>::build_from_post_order(Binary_node<Entry>* parent, Entry* array, Max &index, Entry flag)
{
	if (index < 0 || array[index] == flag) return NULL;
	Binary_node<Entry> *new_node = new Binary_node<Entry>(array[index]);
	new_node->parent = parent;
	new_node->right = build_from_post_order(new_node, array, --index, flag);
	new_node->left = build_from_post_order(new_node, array, --index, flag);
	this->count++;
	return new_node;
}
template <class Entry>
void Binary_search_tree<Entry>::build_from_post_order(Entry *array, Max num, Entry flag)
{
	int index = num-1;
	this->root = build_from_post_order(this->root, array, index, flag);
}
template <class Entry>
Binary_node<Entry>* Binary_search_tree<Entry>::find(Binary_node<Entry>* node, Entry key)
{
	while (node && node->data != key) {
		if (key < node->data) {
			node = node->left;
		}
		else {
			node = node->right;
		}
	}
	return node;
}
template <class Entry>
bool Binary_search_tree<Entry>::find(Entry key)
{
	Binary_node<Entry>* node = find(root, key);
	return node != NULL;
}
template <class Entry>
bool Binary_search_tree<Entry>::insert(Binary_node<Entry>* &root, Binary_node<Entry>* new_node)
{
	Binary_node<Entry>* parent = NULL;
	Binary_node<Entry>* node = root;
	while (node) {
		parent = node;
		if 	(new_node->data == node->data) return false;
		else if (new_node->data < node->data) node = node->left;
		else node = node->right;
	}
	if (parent) {
		if (new_node->data < parent->data) parent->left = new_node;
		else parent->right = new_node;
	}
	else {
		root = new_node;
	}
	new_node->parent = parent;
	return true;
}
template <class Entry>
void Binary_search_tree<Entry>::insert(Entry key)
{
	Binary_node<Entry>* new_node = new Binary_node<Entry>(key);
	if (insert(this->root, new_node)) this->count++;
}
template<class Entry>
void Binary_search_tree<Entry>::remove_node(Binary_node<Entry>* node)
{
	Binary_node<Entry>* to_delete = node;
	Entry key = node->data;
	Binary_node<Entry>* parent = node->parent;
	if (!parent) {
		if (node->left && node->right) {
			Binary_node<Entry>* pred = node->left;
			Binary_node<Entry>* pred_parent = node;
			while (pred->right) {
				pred_parent = pred;
				pred = pred->right;
			}
			if (pred_parent == node) node->left = NULL;
			else {
				pred_parent->right = pred->left;
				if (pred->left) pred->left->parent = pred_parent;
			}
			root->data = pred->data;
			to_delete = pred;
		}
		else if (node->left) {
			root = root->left;
			root->parent = NULL;
		}
		else if (node->right) {
			root = root->right;
			root->parent = NULL;
		}
		else {
			root = NULL;
		}
	}
    else {
		bool left = false;
		if (node == parent->left) left = true;
		if (node->left && node->right) {
			Binary_node<Entry>* pred = node->left;
			Binary_node<Entry>* pred_parent = node;
			while (pred->right) {
				pred_parent = pred;
				pred = pred->right;
			}
			if (pred_parent == node) node->left = NULL;
			else {
				pred_parent->right = pred->left;
				if (pred->left) pred->left->parent = pred_parent;
			}
			node->data = pred->data;
			to_delete = pred;
		}
		else if (node->left) {
			node->left->parent = parent;
			if (left) parent->left = node->left;
			else parent->right = node->left;
		}
		else if (node->right) {
			node->right->parent = parent;
			if (left) parent->left = node->right;
			else parent->right = node->right;
		}
		else {
			if (left) parent->left = NULL;
			else parent->right = NULL;
		}
	}
	delete to_delete;
}
template <class Entry>
void Binary_search_tree<Entry>::remove(Entry key)
{
	Binary_node<Entry>* node = find(root, key);
	if (node) 
	{
		remove_node(node);
		this->count--;
	}
}
template <class Entry>
void Binary_search_tree<Entry>::pre_order_print()
{
	pre_order_print(this->root);
	std::cout << std::endl;
}
template <class Entry>
void Binary_search_tree<Entry>::pre_order_print(Binary_node<Entry> *node)
{
	if (node != NULL)
	{
		std::cout << node->data << " ";
		pre_order_print(node->left);
		pre_order_print(node->right);
	}
}
template <class Entry>
void Binary_search_tree<Entry>::in_order_print()
{
	in_order_print(this->root);
	std::cout << std::endl;
}
template <class Entry>
void Binary_search_tree<Entry>::in_order_print(Binary_node<Entry>* node)
{
	if (node != NULL)
	{	
		in_order_print(node->left);
		std::cout << node->data << " ";
		in_order_print(node->right);
	}
}
template <class Entry>
void Binary_search_tree<Entry>::post_order_print()
{
	post_order_print(this->root);
	std::cout << std::endl;
}
template <class Entry>
void Binary_search_tree<Entry>::post_order_print(Binary_node<Entry>* node)
{
	if (node != NULL)
	{
		post_order_print(node->left);
		post_order_print(node->right);
		std::cout << node->data << " ";
	}
}
template <class Entry>
void Binary_search_tree<Entry>::level_order_print()
{
	level_order_print(this->root);
	std::cout << std::endl;
}
template <class Entry>
void Binary_search_tree<Entry>::level_order_print(Binary_node<Entry>* node)
{
	if (!node) return;
	std::queue<Binary_node<Entry>*> q;
	q.push(root);
	while (!q.empty()) {
		std::cout << q.front()->data << " ";
		if (q.front()->left) q.push(q.front()->left);
		if (q.front()->right) q.push(q.front()->right);
		q.pop();
	}
}
template <class Entry>
void Binary_search_tree<Entry>::clear()
{
	clear(root);
	this->root = NULL;
	this->count = 0;
}
template <class Entry>
void Binary_search_tree<Entry>::clear(Binary_node<Entry>* node)
{
	if (node != NULL)
	{
		clear(node->left);
		clear(node->right);
		delete node;
	}
}
template <class Entry>
void Binary_search_tree<Entry>::solsl(Binary_node<Entry>* node, Max &sum)
{
	if (node)
	{
		if (node->left || node->right)
		{
			if (node->left) solsl(node->left, sum);
			if (node->right) solsl(node->right, sum);
		}
		else
		{
			if (node->parent) if (node == node->parent->left) sum += node->data;
		}
	}
}
template <class Entry>
Max Binary_search_tree<Entry>::sum_of_left_sub_leaves()
{
	Max sum = 0;
	solsl(root, sum);
	return sum;
}
template <class Entry>
void Binary_search_tree<Entry>::sorsl(Binary_node<Entry>* node, Max &sum)
{
	if (node) 
	{
		if (node->left || node->right)
		{
			if (node->left) sorsl(node->left, sum);
			if (node->right) sorsl(node->right, sum);
		}
		else
		{
			if (node->parent) if (node == node->parent->right) sum += node->data;
		}
	}
}
template <class Entry>
Max Binary_search_tree<Entry>::sum_of_right_sub_leaves()
{
	Max sum = 0;
	sorsl(root, sum);
	return sum;
}
using namespace std;
void height(Binary_node<int>* node, Max &h, Max d)
{
	if (h < d) h = d; 
	if (!node) return;	
	height(node->left, h, d+1);
	height(node->right, h, d+1);
}
void dfs(Binary_node<int> *node, bool &flag)
{
	if (!node) return;
	int lh, rh;
	lh = rh = 0;
	height(node->left, lh, 0);
	height(node->right, rh, 0);
	int bias = rh-lh;
	if (bias<=-1 || bias>=1)
	{
		flag = false;
		return;
	}
	dfs(node->left, flag);
	dfs(node->right, flag);
}
int main() {
	int num = 0;
	int array[1000];
	cin >> num;
	for (int i=0; i<num; i++)
	{
		char temp[100];
		cin >> temp;
		if (temp[0] == '#') array[i] = -1;
		else array[i] = atoi(temp);
	}
	Binary_search_tree<int> bstree;
	bstree.build_from_pre_order(array, num, -1);
	Binary_node<int>* root = bstree.get_root();
	bool flag = true;
	dfs(root, flag);
	if (!flag) cout << "true";
	else cout << "false";
}