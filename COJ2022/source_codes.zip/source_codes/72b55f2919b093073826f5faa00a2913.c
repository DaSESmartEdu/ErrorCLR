#include <stdio.h>
int main()
{
    int a,b,c,d;
    scanf("%d %d %d %d",&a,&b,&c,&d);
    float q=(a+b+c+d)/4.0;
    printf("%d %f",a+b+c+d,q);
    return 0;
}