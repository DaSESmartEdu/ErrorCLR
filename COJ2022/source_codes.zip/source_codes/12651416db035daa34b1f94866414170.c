#include<stdio.h>
char *match(char *s,char ch1,char ch2);
int main(){
	char s[10],ch1,ch2,*p;
	gets(s);
	scanf("%c %c",&ch1,&ch2);
	p=match(s,ch1,ch2);
	printf("%s",p);
	return 0;
}
char *match(char *s,char ch1,char ch2){
	char *p;
	int i;
	for(i=0;*(s+i)!=0;i++){
		if(*(s+i)==ch1){
			p=s+i;
			break;
		}
	}
	for(i=0;*(p+i)!=0;i++){
		printf("%c",*(p+i));
		if(*(p+i)==ch2) break;
	}
	printf("\n");
	return p;
}