#include<stdio.h>
int main(){
	char source[21]; 
	char sub[21]; 
	int len_source = 0;
	int len_sub = 0;
	while((source[len_source++] = getchar()) != '\n');
	source[--len_source] = '\0';
	while((sub[len_sub++] = getchar()) != '\n');
	sub[--len_sub] = '\0';
	int is_ok;
	for(int i=0; i<len_source; ++i) {
		is_ok = 0;
		for(int j=0;j<len_sub;++j){
			if(source[(i+j)%len_source] != sub[j]) {
				break;
			}else {
				is_ok++;
			}
		}
		if(is_ok==len_sub) break;
	}
	printf("%d\n",is_ok==len_sub);
	return 0;
}