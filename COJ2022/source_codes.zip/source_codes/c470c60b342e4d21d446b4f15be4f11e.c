#include <stdio.h>
int main(){
    int x=1,y=1,z=0;
    int m=2,n;
    scanf("%d",&n);
    if (n==1){
        z=1;
        m=1;
    }
    while(z<=n){
        z=x+y;
        x=y;
        y=z;
        m++;
    }
    m--;
    printf("%d",m);
    return 0;
}