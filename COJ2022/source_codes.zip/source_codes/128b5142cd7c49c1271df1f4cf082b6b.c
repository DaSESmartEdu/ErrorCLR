#include<stdio.h>
int main()
{
    double m,t;
    int t1;
    double pm,pt,p;
    scanf("%lf %lf",&m,&t);
    if(m<=3){
        pm=10;
    }else if(m>3&&m<=10){
        pm=4+2*m;
    }else{
        pm=3*m-6;
    }
    t1=t/5;
    pt=2*t1;
    p=(int)(pm+pt+0.5);
    printf("%.0f",p);
    return 0;
}