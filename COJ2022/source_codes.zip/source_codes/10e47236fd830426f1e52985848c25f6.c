#include <stdio.h>
#include <math.h>
int main()
{
	int a;
	int b;
	int n;
	int sum;
	scanf("%d %d",&a,&n);
	int i;
	b=a;
	sum=a;
	for(i=1;i<n;i++){
		b=b+(a*pow(10,i));
		sum=sum+b;
	}
	printf("%d",sum); 
	return 0;
 }