#include<iostream>
#include<math.h>
#include<stdlib.h>
using namespace std;
void insertion_sort(double *a,int n)
{
	int i=0,j=0;
	double temp=0;
	for(i=1;i<n;i++)
	{
		temp=a[i];
		j=i-1;
		while(j>=0&&temp<a[j])
		{
			a[j+1]=a[j];
			j--;
		}
		a[j+1]=temp;
	}
}
int main(){
	int n,k;
	cin>>n;
	int points[n][2];
	for(int i=0;i<n;i++)
	{
		for(int j=0;j<2;j++)
		{
			cin>>points[i][j];
		}
	}
	cin>>k;
	double distance[n];
	double distance1[n];
	for(int i=0;i<n;i++)
	{
		distance[i]=sqrt(pow(points[i][0],2)+pow(points[i][1],2));
		distance1[i]=sqrt(pow(points[i][0],2)+pow(points[i][1],2));
	}
	insertion_sort(distance,n);
	int key;
	for(int i=0;i<n;i++)
	{
		if(distance1[i]==distance[k-1])
		{
			key=i;
		}
	}
	cout<<points[k][0]<<' '<<points[k][1];
	return 0;
}