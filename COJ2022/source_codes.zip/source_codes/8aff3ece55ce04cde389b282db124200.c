#include <stdio.h>
int main()
{
	int n,x,y,i;
	x = y = 1;
	i = 3;
	int number = 0;
	scanf("%d",&n);
	if (n!=1){
	while (number<n)
	{
		i++;
		number = x+y;
		x = y;
		y = number;
	}
	printf("%d",i);
	}
	else{
		printf("1");
	}
	return 0;
}