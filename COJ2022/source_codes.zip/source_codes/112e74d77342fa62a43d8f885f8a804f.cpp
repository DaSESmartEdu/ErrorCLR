#include<iostream>
#include<string>
using namespace std;
int main(){
   int n;
   cin>>n;
   double a[n];
   char p[n];
   for(int i=0;i<n;i++){
      cin>>a[i];
   }
   for(int i=0;i<n;i++){
      if(a[i]>=90){
        p[i]='A';
      }else if(a[i]>=80&&a[i]<90){
        p[i]='B';
      }else if(a[i]>=70&&a[i]<80){
        p[i]='C';
      }else if(a[i]>=60&&a[i]<70){
        p[i]='D';
      }else{
        p[i]='E';
      }
   }
  for(int i=0;i<n;i++){
     cout<<p[i]<<" ";
  }
  return 0;
}