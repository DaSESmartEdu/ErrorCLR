#include <stdio.h>
int pow1(d,n);
int pow1(d,n){
	int product=1;
	int i=1;
	while(i<=n){
		product=product*d;
		i++;
	}
	return product;
}
int main(){
	int n;
	int max,i;
	int x=0;
	int count=0;
	int a,b;
	scanf("%d",&n);
	max=pow1(10,n)-1;
	i=pow1(10,n-1);
	while(i<=max){
		b=i;
		while(b>0){
			a=b%10;
			b=b/10;
			x=x+pow1(a,n);
		}
		if(i==x){
			count ++;
		}
		i++;
		x=0;
	}
	printf("%d",count);
}