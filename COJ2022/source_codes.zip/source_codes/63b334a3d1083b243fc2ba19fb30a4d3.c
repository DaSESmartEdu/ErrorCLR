#include <stdio.h>
int main()
{
    int n;
    scanf("%d",&n);
    int i=1;
    while(i<=n){
        double a;
        scanf("%lf",&a);
        if(a>=90){
            printf("A");
        }else if(a>=80){
            printf("B");
        }else if(a>=70){
            printf("C");
        }else if(a>=60){
            printf("D");
        }else{
            printf("E");
        }
		i+=1;
	}
    return 0;
}