#include<stdio.h>
#include<math.h>
double fact(int n)
{double result;
int i;
result=1;
for (i=1;i<=n;i++)
result=result*i;
return result;
}
int main()
{
int i ,n;
double x;
scanf("%lf",&x);
double s=1;
for (i=1;i<=n;i++)
{double h=pow(x,i)/fact(i);
if (h>=0.000001) 
{s=s+h;}
else
break;
}
printf("%.4lf",s);
return 0;    
}