#include <stdio.h>
int main()
{
    int n,i,flag;
    double x,sum;
    flag=1;
    scanf("%d",&n);
    for(i=1;i<=n;i++)
    {
        x=flag*1.0*i/(2*i-1);
        sum=sum+x;
        flag=-flag;
    }
  printf("%.6lf",sum);
return 0;
}