#include <stdio.h>
void printdigits( int n );
int main()
{
    int n;
    scanf("%d",&n);
    printdigits(n);
    return 0;
}
void printdigits( int n )
{
    static int i=0,j=0,a[100];
    if(n>0)
    {
        a[i]=n%10;
        i++;
        j++;
        return printdigits(n/10);
    }
    else if(j==0 && n==0)
    {
        printf("%d",n);
    }
    else
    {
        for(i-=1;i>=0;i--)
        {
            printf("%d\n",a[i]);
        }
    }
}