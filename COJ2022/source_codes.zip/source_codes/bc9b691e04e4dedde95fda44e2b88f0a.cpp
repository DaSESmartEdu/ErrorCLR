#include<stdio.h>
int main()
{
	int n, i;
	double sum, x, y, flag;
	x = 2;
	y = 1;
	scanf ("%d", &n);
	for (i = 1; i <=n; i++) {
		sum += x/y;
		flag = x;
		x = x+y;
		y = flag;
	}
	printf("%.2f", sum);
	return 0;
}