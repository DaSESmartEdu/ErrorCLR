#include <stdio.h>
int main(){
    int n,i,count=1;
    double sum;
    scanf("%d",&n);
    int a=0,b=1;
    if(n=1)
    {  
        count=1;
    }
    else {do{
        sum=a+b;
        a=b;
        b=sum;
        count++;
    }while(sum<n);}
    printf("%d",count);
    return 0;
}