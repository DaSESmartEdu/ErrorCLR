#include <stdio.h>
#include <math.h>
char *s[11]={"ling","yi","er","san","si","wu","liu","qi","ba","jiu","shi"};
void base(int n)
{
    int digit=0;
    for (int i=n;i>0;i/=10)
    {
        digit++;
    }
    if (n/1000!=0&&n/100%10!=0)
    {
        if (digit==4)
        {
            if (n/1000!=2)
            {
                printf("%s qian ",s[n/1000]);
            }
            else
            {
                printf("er qian ");
            }
            digit--;
        }
        if (digit==3)
        {
            if ((n/100)%10!=2)
            {
                printf("%s bai ",s[(n/100)%10]);
            }
            else
            {
                printf("er bai ");
            }
            digit--;
        }
        if (digit==2)
        {
            if (n/10%10!=0)
            {
                printf("%s shi ",s[(n%100)/10]);
            }
            else if (n/10%10==0&&n%10!=0)
            {
                printf("ling ");
            }
            digit--;
        }
        if (digit==1)
        {
            if (n%10!=0)
            printf("%s ",s[n%10]);
        }
    }
    if (n/1000!=0&&n/100%10==0)
    {
        if (digit==4)
        {
            if (n/1000!=2)
            {
                printf("%s qian ",s[n/1000]);
            }
            else
            {
                printf("er qian ");
            }
            digit-=2;
        }
        if (digit==2)
        {
            if (n/10%10!=0)
            {
                printf("%s shi ",s[(n%100)/10]);
            }
            else if (n/10%10==0&&n%10!=0)
            {
                printf("ling ");
            }
            digit--;
        }
        if (digit==1)
        {
            if (n%10!=0)
            printf("%s ",s[n%10]);
        }
    }
    if ((n/1000==0&&n/100%10!=0))
    {
        printf("ling ");
        if (digit==3)
        {
            if ((n/100)%10!=2)
            {
                printf("%s bai ",s[(n/100)%10]);
            }
            else
            {
                printf("er bai ");
            }
            digit--;
        }
        if (digit==2)
        {
            if (n/10%10!=0)
            {
                printf("%s shi ",s[(n%100)/10]);
            }
            else if (n/10%10==0&&n%10!=0)
            {
                printf("ling ");
            }
            digit--;
        }
        if (digit==1)
        {
            if (n%10!=0)
            printf("%s ",s[n%10]);
        }
    }
    if ((n/1000==0&&n/100%10==0))
    {
        if (n/10%10!=0)
        {if (digit==2)
        {
            if (n/10%10!=0)
            {
                printf("ling ");
                printf("%s shi ",s[(n%100)/10]);
            }
            else if (n/10%10==0&&n%10!=0)
            {
                printf("ling ");
            }
            digit--;
        }
        if (digit==1)
        {
            if (n%10!=0)
            printf("%s ",s[n%10]);
        }}
        else if (n/10%10==0&&n%10!=0)
        {
            printf("ling ");
            printf("%s",s[n]);
        }
    }
}
int main()
{
    int n;
    scanf("%d",&n);
    int digit=0;
    for (int i=n;i>0;i/=10)
    {
        digit++;
    }
    int yi;
    int wan;
    int ge;
    yi=n/pow(10,8);
    wan=(n/10000)%10000;
    ge=n%10000;
    if (digit>=9)
    {
            if (yi>0)
            {
                if (yi>=20)
                {
                    printf("%s shi ",s[yi/10]);
                    if (yi%10!=0)
                    {
                        printf("%s ",s[yi%10]);
                    }
                }
                else if (yi>=10&&yi<20)
                {
                    printf("shi ",s[yi/10]);
                    if (yi%10!=0)
                    {
                        printf("%s ",s[yi%10]);
                    }
                }
                else 
                {
                    printf("%s ",s[yi]);
                }
            }
        if(yi>0)
        {
            printf("yi ");
        }
        if (wan>0)
        {
            base(wan);
        }
        if (wan>0)
        {
            printf("wan ");
        }
        if (ge>0)
        {
            base(ge);
        }
    }
    else if(digit==8)
    {
        base(wan);
        printf("wan ");
        base(ge);
    }
    else if(digit==7)
    {
        if (wan>=100)
        {
            if ((wan/100)%10!=2)
            {
                printf("%s bai ",s[(n/100)%10]);
            }
            else
            {
                printf("er bai ");
            }
            wan/=10;
        }
        if (wan>=10)
        {
            if (wan/10%10!=0)
            {
                printf("%s shi ",s[(wan%100)/10]);
            }
            else if (wan/10%10==0&&wan%10!=0)
            {
                printf("ling ");
            }
            wan/=10;
        }
        if (wan<10)
        {
            if (wan%10!=0)
            printf("%s ",s[wan%10]);
        }
        printf("wan ");
        base(ge);
    }
    else if (digit==6)
    {
        if (wan>=10)
        {
            if (wan/10%10!=1)
            {
                printf("%s shi ",s[wan/10]);
            }
            else
            {
                printf("shi ");
            }
            wan%=10;
        }
       if (wan<10)
        {
            if (wan%10!=0)
            printf("%s ",s[wan]);
        }
        printf("wan ");
        base(ge);
    }
    else if(digit==5)
    {
        printf("%s ",s[wan]);
        printf("wan ");
        base(ge);
    }
    else if(digit==4)
    {
        base(ge);
    }
    else if (digit==3)
    {
        {
            if ((n/100)%10!=2)
            {
                printf("%s bai ",s[(n/100)%10]);
            }
            else
            {
                printf("er bai ");
            }
            digit--;
        }
        if (digit==2)
        {
            if (n/10%10!=0)
            {
                printf("%s shi ",s[(n%100)/10]);
            }
            else if (n/10%10==0&&n%10!=0)
            {
                printf("ling ");
            }
            digit--;
        }
        if (digit==1)
        {
            if (n%10!=0)
            printf("%s ",s[n%10]);
        }
    }
    else if (digit==2)
    {
        printf("%s ",s[ge/10]);
        printf("shi ");
        if (ge%10!=0)
        {
            printf("%s",s[ge%10]);
        }
    }
    else if(digit==1)
    {
        printf("%s",s[ge]);
    }
    return 0;
}