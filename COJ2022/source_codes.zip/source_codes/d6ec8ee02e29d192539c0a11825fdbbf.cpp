#include<iostream>
using namespace std;
typedef struct num{
    int number;
    struct num *next;
}num;
num *create(int n){
    num *p,*head,*p1;
    int anum;
    cin>>anum;
    head=new num;
    p=new num;
    head->number=anum;
    head->next=NULL;
    p=head;
    while(n!=1){
        p1 =new num;
        cin>>anum;
        p1->number = anum;
        p1->next=NULL;
        p->next=p1;
        p=p->next;
        n--;
    }
    p->next=NULL;
    return head;
}
void *out(num *head1,num *head2){
    while(head1!=NULL && head2!=NULL){
        if(head1->number<head2->number){
            cout<<head1->number<<' ';
            head1 = head1->next;
        }
        else {
            cout<<head2->number<<' ';
            head2 = head2->next;
        }    
    }
    while(head1!=NULL){
        cout<<head1->number<<' ';
        head1 = head1->next;
    }
     while(head2!=NULL){
        cout<<head2->number<<' ';
        head1 = head2->next;
    }
}
int main(){
    int N,M;
    num *list1,*list2;
    cin>>N;
    list1 = create(N);
    cin>>M;
    list2 = create(M);
    out(list1,list2);
    return 0;
}