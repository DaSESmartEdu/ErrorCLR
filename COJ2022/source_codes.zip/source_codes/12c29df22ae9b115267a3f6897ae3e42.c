#include <stdio.h>
double fact( int n ) {
    if (n <= 1) return 1;
    return n*fact(n-1);
}
double factsum( int n ) {
    double ret = .0;
    for (int i=1; i<=n; ++i) ret += fact(i);
    return ret;
}
int main() {
    int n;
    scanf("%d", &n);
    printf("%.0lf\n", fact(n));
    printf("%.0lf\n", factsum(n));
    return 0;
}