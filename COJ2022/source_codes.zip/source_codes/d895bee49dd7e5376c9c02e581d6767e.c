#include<stdio.h>
int main()
{
	int x;
	int count=0;
	int a,b,c;
	scanf("%d",&x);
	for(a=x/5;a>0;a--){
		for(b=x/2;b>0;b--){
			for(c=x;c>0;c--){
				if(5*a+2*b+c==x){count++;
				}
			}
		}
	}printf("count=%d",count);
	return 0;
}