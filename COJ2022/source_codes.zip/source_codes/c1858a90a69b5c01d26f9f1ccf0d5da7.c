#include<stdio.h>
int main(){
    int a,b,panduan=1;
	double sum=0;
    char ch;
    scanf("%d",&a);
    while((ch=getchar())!='='){
        scanf("%d",&b);
        if(ch=='+'){
            sum=a+b;
        }
        else if(ch=='-'){
            sum=a-b;
        }
        else if(ch=='*'){
            sum=a*b;
        }
        else if(ch=='/'){
            if(b==0){
                panduan=0;
                break;
            }
            else{
                sum=a/b;
            }
        }
        a=sum;
    }
    if(panduan=1){
        printf("%.2f",sum);
    }
    else{
        printf("ERROR");
    }
    return 0;
}