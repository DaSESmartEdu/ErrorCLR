#include <stdio.h>
void turn(int n,int x);
int main()
{
	int n,x;
	scanf("%d %d",&n,&x);
	if(x==0)
	{
		printf("0");
	}
	else
	{
	turn(n,x);
	}
	return 0;
}
void turn(int n,int x)
{
	if(x==0)
	{
		return;
	}
	else
	{
		if(n<10)
		{
			if(x>=0&&x<n)
			{
				printf("%d",x);
			}
			else
			{
				turn(n,x/n);
				printf("%d",x%n);
			}
		}
		else
		{
			turn(x,x/n);
			if(x%n>=0&&x%n<10)
		    {
			    printf("%d",x%n);
		    }
		    else
		    {
			    int m=x%n-10;
			    char ch='A';
			    printf("%c",ch+m);
		    }
		}
	}
}