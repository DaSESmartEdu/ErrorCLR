#include<stdio.h>
#include<math.h>
int n(int m)
{
	int res;
	int t=m;int w=m;
	int wei=0;
	while (m>0) {m=m/10;wei++;}
	int a[wei-1];
	for (int i=0;i<=wei-1;i++) {a[i]=t%10;t=t/10;}
	int sum=0;
	for (int j=0;j<=wei-1;j++) {sum+=pow(a[j],3);}
	if (sum==w) res=1;
	else res=0;
	return res;
}
int main()
{
	int x,y;
	scanf("%d %d",&x,&y);
	for (int g=x;g<=y;g++) {if (n(g)==1) printf("%d\n",g);}
	return 0;
}