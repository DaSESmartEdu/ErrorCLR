#include <stdio.h>
#include <math.h>
int main()
{
    int n;
    scanf("%d",&n);
        int i=1;
    int x=(double)(1/(sqrt(5)))*((pow((double)((1+sqrt(5))/2),i))-(pow((double)((1-sqrt(5))/2),i)));
if(n==1){
    printf("%d",i);
}
   else{
    while(x<n){
        x=(double)(1/(sqrt(5)))*((pow((double)((1+sqrt(5))/2),i))-(pow((double)((1-sqrt(5))/2),i)));
        i=i+1;
    }
    printf("%d",i-1);
   }
    return 0;
}