#include<stdio.h>
int main()
{
    int i,n;
    scanf("%d", &n);
    double a[i];
    for(i=0;i<n;i++){
        scanf("%lf",&a[i]);
    if(a[i]>=90){
        printf("A ");
    }
    else if(a[i]<90&&a[i]>=80){
        printf("B ");
    }
    else if(a[i]>=70&&a[i]<80){
        printf("C ");
    }
    else if(a[i]<70&&a[i]>=60){
        printf("D ");
    }
    else if(a[i]<60){
        printf("E ");
    }
    }
    return 0;
}