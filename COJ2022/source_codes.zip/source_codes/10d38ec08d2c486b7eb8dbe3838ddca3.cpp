#include <cstdio>
#include <string>
#include <cstring>
#include <iostream>
#include <algorithm>
using namespace std;
const int N = 20000;
int Set[N];
int Rank[N];
int findx(int x)
{
    int r = x;
    while (r != Set[r])
    {
        r = Set[r];
    }
    return r;
}
void merge(int i,int j)
{
    i=findx(i);
    j=findx(j);
    if(i==j) return ;
    if(Rank[i] > Rank[j]) Set[j] = i;
    else
    {
        if(Rank[i]==Rank[j]) Rank[j]++;  
        Set[i] = j;
    }
}
int main()
{
    int N,M;
    while (cin >> N >> M && N)
    {
        for (int i = 1;i <= N;i++) 
        {
            Set[i] = i;
            Rank[i] = 0;
        }
        for (int i = 0; i < M;i++)
        {
            int a,b;
            cin >> a >> b;
            merge(a,b);
        }
        int cnt = 0;
        for (int i = 1;i <= N;i++)
        {
            if (Set[i] == i) cnt++;
        }
        cout << cnt - 1 << endl;
    }
    return 0;
}