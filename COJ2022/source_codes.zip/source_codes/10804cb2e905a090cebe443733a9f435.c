#include <stdio.h>
int main()
{
	int low,up;
	scanf("%d %d",&low,&up);
	if(low>up||low>100||up>100)
	{
		printf("Invalid.");
	}	
	else
	{
		int i;
		double c;
		printf("fahr celsius\n");
		for(i=low;i<=up;i+=2)
		{
			c=5*(i-32)/9.0;
			printf("%d   %.1lf\n",i,c);
		}
	}
	return 0;
}