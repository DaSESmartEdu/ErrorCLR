#include<stdio.h>
int main()
{ int n,m;
 scanf("%d%d",&n,&m);
 if (n*10<=11*m)
 {
   printf("normal");
 }
 else if (n*10<=15*m)
 {
   printf("200");
 }
 else printf("revoke");
 return 0;
}