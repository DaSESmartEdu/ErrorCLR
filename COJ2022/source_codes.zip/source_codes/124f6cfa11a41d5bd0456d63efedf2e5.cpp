#include<iostream>
using namespace std;
typedef struct HeapStruct
{
	int size;
	int* x;
	int* y;
} MaxHeap;
typedef struct Heap
{
	int m;
	int n;
} IntHeap;
void PercDown(MaxHeap* H,int p)
{
	int Parent,Child,X,Y;
	X=H->x[p];
	Y=H->y[p];
	for (Parent=p;Parent*2<=H->size;Parent=Child)
	{
		Child=Parent*2;
		if (Child!=H->size && H->x[Child]<H->x[Child+1])
		{
			Child++;
		}
		if (Child!=H->size && H->x[Child]==H->x[Child+1] && H->y[Child]<H->y[Child+1])
		{
			Child++;
		}
		if (X>H->x[Child] || (X==H->x[Child]&&Y>=H->y[Child]))
		{
			break;
		}
		else
		{
			H->x[Parent]=H->x[Child];
			H->y[Parent]=H->y[Child];
		}
	}
	H->x[Parent]=X;
	H->y[Parent]=Y; 
}
void BuildHeap(MaxHeap* H)
{
	int i;
	for (i=H->size/2;i>0;i--)
	{
		PercDown(H,i);
	}
}
IntHeap* DeleteHeap(MaxHeap* H)
{
	int Parent,Child;
	int MaxX,MaxY,X,Y;
	MaxX=H->x[1];
	MaxY=H->y[1];
	X=H->x[H->size];
	Y=H->y[H->size];
	H->size--;
	for (Parent=1;Parent*2<=H->size;Parent=Child)
	{
		Child=Parent*2;
		if (Child!=H->size && H->x[Child]<H->x[Child+1])
		{
			Child++;
		}
		if (Child!=H->size && H->x[Child]==H->x[Child+1] && H->y[Child]<H->y[Child+1])
		{
			Child++;
		}
		if (X>H->x[Child] || (X==H->x[Child]&&Y>=H->y[Child]))
		{
			break;
		}
		else
		{
			H->x[Parent]=H->x[Child];
			H->y[Parent]=H->y[Child];
		}
	}
	H->x[Parent]=X;
	H->y[Parent]=Y; 
	IntHeap* S=new IntHeap;
	S->m=MaxX;
	S->n=MaxY;
	return S;
}
void SortHeap(MaxHeap* H,MaxHeap* Q)
{
	int i;
	for (i=H->size;i>0;i--)
	{
		IntHeap* T=DeleteHeap(H);
		Q->x[i]=T->m;
		Q->y[i]=T->n; 
	}
}
void TopKHeap(MaxHeap* H,MaxHeap* Q,int i)
{
	int j;
	for (j=1;j<=i;j++)
	{
		Q->x[j]=H->x[j];
		Q->y[j]=H->y[j];
	}
}
void PrintHeap(MaxHeap* Tem,int K)
{
	int i;
	for (i=1;i<=K;i++)
	{
		cout<<"("<<Tem->x[i]<<","<<Tem->y[i]<<")"<<endl;
	}
}
int main()
{
	MaxHeap* H=new MaxHeap;
	MaxHeap* Q=new MaxHeap;
	H->x=new int[100];
	H->y=new int[100];
	Q->x=new int[100];
	Q->y=new int[100];
	int size=0;
	int K=0;
	int i;
	cin>>size>>K;
	H->size=size;
	Q->size=size;
	H->x[0]=H->y[0]=1000;
	for (i=0;i<=K;i++)
	{
		Q->x[i]=Q->y[i]=1000;
	}
	for (i=1;i<=size;i++)
	{
		int x,y;
		cin>>x>>y;
		H->x[i]=x;
		H->y[i]=y;
		if (i>=K)
		{
			MaxHeap* Tem=new MaxHeap;
			Tem->x=new int[100];
			Tem->y=new int[100];
			Tem->size=i;
			Q->size=i;
			TopKHeap(H,Q,i);
			BuildHeap(Q);
			SortHeap(Q,Tem); 
			PrintHeap(Tem,K);
		}
	}
	return 0;
}