#include<stdio.h>
int main(){
    int n;
    scanf("%d",&n);
    for (int i = 1; i <= (n+1)/2; i++)
    {
        for (int j = (n+1)/2-i; j>=0 ; j--)
        {
            printf(" ");
        }
        for (int m = 1;m <= 2*i-1; m++)
        {
            printf("*");
        }
        printf("\n");
    }
    for(int i=1; i<=n/2;i++)
    {
        for (int j = 0; j<=i; j++)
        {
            printf(" ");
        }
        for (int m = 1;m<=2*(n/2-i)+1; m++)
        {
            printf("*");
        }
    if(i<n/2)printf("\n");
    }
    return 0;
}