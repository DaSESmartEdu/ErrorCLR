#include <stdio.h>
#include <string.h>
#pragma warning(disable:4996)
struct th
{
	char w[20];
	int t;
};
int cmp(struct th a, struct th b)
{
	if (a.t <= b.t)return 1;
	else return 0;
}
void sort(struct th* a, struct th* b, int cmp())
{
	for (struct th* i = b - 1; i >= a + 1; i--)
	{
		for (struct th* j = a; j < b - 1; j++)
		{
			if (cmp(*j, *(j + 1)) == 0)
			{
				struct th temp;
				temp = *j;
				*j = *(j + 1);
				*(j + 1) = temp;
			}
		}
	}
}
int main()
{
	int sum = 0;
	struct th dict[1000];
	memset(dict, 0, sizeof(dict));
	char ch;
	char word[20] = { 0 };
	int point = 0, now = 0;
	do
	{
		ch = getchar();
		if (ch == ' ' || ch == '\n' || ch == EOF || ch == '\0' || ch == '\r')
		{
			if (point == 0)continue;
			else
			{
				point = 0;
				word[now] = '\0';
				for (int i = 0; i < sum; i++)
				{
					if (i == sum - 1)
					{
						strcpy(dict[i].w, word);
						dict[i].t++;
						break;
					}
					if (strcmp(dict[i].w, word) == 0)
					{
						dict[i].t++;
						sum--;
						break;
					}
				}
				memset(word, 0, sizeof(word));
			}
		}
		else
		{
			if (point == 0)
			{
				sum++;
				now = 0;
				point = 1;
				word[now] = ch;
				now++;
			}
			else
			{
				word[now] = ch;
				now++;
			}
		}
	} while (ch != '\n' && ch != EOF && ch != '\0' && ch != '\r');
	sort(dict, dict + sum, cmp);
	printf("%s", dict[0].w);
	for (int i = 1; i < sum; i++)
	{
		printf(" %s", dict[i].w);
	}
}