# include<stdio.h>
# include<math.h>
double fact(int n);
int main()
{
   double x,S,n;
   int item,a; 
   scanf("%lf",&x);
   a=0;
   item=1;
   S=1;
   do
   {
       n=pow(x,a)/fact(item);
       S=S+n;
       a++;
       item++;
   }while (fabs(n)>=0.00001);
  printf("%.4lf\n",S);
   return 0;
}
 double fact(int n)
{
    int i;
    double product;
    product =1;
    for(i=1;i<=n;i++)
    {
      product =product*i;
    }
    return product;
}