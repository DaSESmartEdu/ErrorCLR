#include<iostream>
#include<string>
using namespace std;
string takechar(string a,string b)
{
    string c;
    c=a+b+a;
    a=c;
    return a;
}
int main(int argc,char* argv[])
{
    int num;
    string strs1;
    string strs2;
    string s[26]={"A","B","C","D","E","F","J","H","I","J","K","L","M","N","O","P","Q","R","S","T","U","V","W","X","Y","Z"};
    cin>>num;
    strs1="A";
    if(num==1)
    {
        cout<<strs1<<endl;
    }
    else
    {
        for(int i=1;i<num;i++)
        {
            strs2=s[i];
            strs1=takechar(strs1,strs2);
        }
    }
    cout<<strs1<<endl;
}