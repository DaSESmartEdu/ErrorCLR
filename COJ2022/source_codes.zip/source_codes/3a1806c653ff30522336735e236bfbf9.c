#include<stdio.h>
int main()
{
    int n;
    float i,hight;
    scanf("%f %d",&hight,&n);
    for(i=hight;n>1;n--) {
        hight=hight/2;
        i=i+2*hight;
    }
    if(n==0) i=hight=0;
    printf("%.1f",hight/2);
    return 0;
}