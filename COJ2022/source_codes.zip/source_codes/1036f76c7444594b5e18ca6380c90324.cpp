#include<iostream>
#include<vector>
#include<math.h>
using namespace std;
void Print(vector <vector<int>> & matrix_c,int M)
{
    for (int i = 0; i < M; i++)
    {
        for (int j = 0; j < M; j++)
        {
            cout << matrix_c[i][j];
        if (j == M-1)
            {
                cout << endl;
                break;
            }
            cout << " ";
        }
    }
}
void pusu_caculate(vector <vector<int>> & matrix_a,vector <vector<int>> & matrix_b,vector <vector<int>> & matrix_c,int M)
{
    for (int i = 0; i < M; i++)
    {
        for (int j = 0; j < M; j++)
        {   
            matrix_c[i][j] = 0;
            for (int k = 0; k < M; k++)
            {
                matrix_c[i][j] += matrix_a[i][k]*matrix_b[k][j];
            }
        }
    }
}
void pusu(int N,int M)
{
    vector <vector<int>> matrix_a(M,vector<int>(M));
    vector <vector<int>> matrix_b(M,vector<int>(M));
    vector <vector<int>> matrix_c(M,vector<int>(M));
    for (int k = 0; k < N; k++)
    {
        for (int i = 0; i < M; i++)
        {
            for (int j = 0; j < M; j++)
            {
                cin >> matrix_a[i][j];
            }
        }
        for (int i = 0; i < M; i++)
        {
            for (int j = 0; j < M; j++)
            {
                cin >> matrix_b[i][j];
            }
        }
        pusu_caculate(matrix_a,matrix_b,matrix_c,M);
        Print(matrix_c,M);
    }
}
void m_Add(vector <vector<int>> & matrix_a,vector <vector<int>> & matrix_b,vector <vector<int>> & matrix_c,int M)
{
    for (int i = 0; i < M; i++)
    {
        for (int j = 0; j < M; j++)
        {
            matrix_c[i][j] = matrix_a[i][j] + matrix_b[i][j];
        }
    }
}
void m_Sub(vector <vector<int>> & matrix_a,vector <vector<int>> & matrix_b,vector <vector<int>> & matrix_c,int M)
{
    for (int i = 0; i < M; i++)
    {
        for (int j = 0; j < M; j++)
        {
            matrix_c[i][j] = matrix_a[i][j] - matrix_b[i][j];
        }
    }
}
void Strassen_caculate(vector <vector<int>> & matrix_a,vector <vector<int>> & matrix_b,vector <vector<int>> & matrix_c,int M)
{
    if (M <= 16)
    {
        pusu_caculate(matrix_a,matrix_b,matrix_c,M);
        return;
    }
    vector <vector<int>> A11(M/2,vector<int>(M/2));
    vector <vector<int>> A12(M/2,vector<int>(M/2));
    vector <vector<int>> A21(M/2,vector<int>(M/2));
    vector <vector<int>> A22(M/2,vector<int>(M/2));
    vector <vector<int>> B11(M/2,vector<int>(M/2));
    vector <vector<int>> B12(M/2,vector<int>(M/2));
    vector <vector<int>> B21(M/2,vector<int>(M/2));
    vector <vector<int>> B22(M/2,vector<int>(M/2));
    vector <vector<int>> C11(M/2,vector<int>(M/2));
    vector <vector<int>> C12(M/2,vector<int>(M/2));
    vector <vector<int>> C21(M/2,vector<int>(M/2));
    vector <vector<int>> C22(M/2,vector<int>(M/2));
    vector <vector<int>> tmp1(M/2,vector<int>(M/2));
    vector <vector<int>> tmp2(M/2,vector<int>(M/2));
    vector <vector<int>> P1(M/2,vector<int>(M/2));
    vector <vector<int>> P2(M/2,vector<int>(M/2));
    vector <vector<int>> P3(M/2,vector<int>(M/2));
    vector <vector<int>> P4(M/2,vector<int>(M/2));
    vector <vector<int>> P5(M/2,vector<int>(M/2));
    vector <vector<int>> P6(M/2,vector<int>(M/2));
    vector <vector<int>> P7(M/2,vector<int>(M/2));
    for (int i = 0; i < M/2; i++)
    {
        for (int j = 0; j < M/2; j++)
        {
            A11[i][j] = matrix_a[i][j];
            B11[i][j] = matrix_b[i][j];
            A12[i][j] = matrix_a[i][j+M/2];
            B12[i][j] = matrix_b[i][j+M/2];
            A21[i][j] = matrix_a[i+M/2][j];
            B21[i][j] = matrix_b[i+M/2][j];
            A22[i][j] = matrix_a[i+M/2][j+M/2];
            B22[i][j] = matrix_b[i+M/2][j+M/2];
        }
    }
    m_Sub(B12,B22,tmp1,M/2);
    Strassen_caculate(A11,tmp1,P1,M/2);
    m_Add(A11,A12,tmp1,M/2);
    Strassen_caculate(tmp1,B22,P2,M/2);
    m_Add(A21,A22,tmp1,M/2);
    Strassen_caculate(tmp1,B11,P3,M/2);
    m_Sub(B21,B11,tmp1,M/2);
    Strassen_caculate(A22,tmp1,P4,M/2);
    m_Add(A11,A22,tmp1,M/2);
    m_Add(B11,B22,tmp2,M/2);
    Strassen_caculate(tmp1,tmp2,P5,M/2);
    m_Sub(A12,A22,tmp1,M/2);
    m_Add(B21,B22,tmp2,M/2);
    Strassen_caculate(tmp1,tmp2,P6,M/2);
    m_Sub(A11,A21,tmp1,M/2);
    m_Add(B11,B12,tmp2,M/2);
    Strassen_caculate(tmp1,tmp2,P7,M/2);
    m_Add(P5,P4,tmp1,M/2);
    m_Sub(P2,P6,tmp2,M/2);
    m_Sub(tmp1,tmp2,C11,M/2);
    m_Add(P1,P2,C12,M/2);
    m_Add(P3,P4,C21,M/2);
    m_Add(P5,P1,tmp1,M/2);
    m_Add(P3,P7,tmp2,M/2);
    m_Sub(tmp1,tmp2,C22,M/2);
    for (int i = 0; i < M/2; i++)
    {
        for (int j = 0; j < M/2; j++)
        {
            matrix_c[i][j] = C11[i][j];
            matrix_c[i][j+M/2] = C12[i][j];
            matrix_c[i+M/2][j] = C21[i][j];
            matrix_c[i+M/2][j+M/2] = C22[i][j];
        }
    }
}
void Strassen(int N,int M)
{
    vector <vector<int>> matrix_a(M,vector<int>(M));
    vector <vector<int>> matrix_b(M,vector<int>(M));
    vector <vector<int>> matrix_c(M,vector<int>(M));
    for (int k = 0; k < N; k++)
    {
        for (int i = 0; i < M; i++)
        {
            for (int j = 0; j < M; j++)
            {
                cin >> matrix_a[i][j];
            }
        }
        for (int i = 0; i < M; i++)
        {
            for (int j = 0; j < M; j++)
            {
                cin >> matrix_b[i][j];
            }
        }
        Strassen_caculate(matrix_a,matrix_b,matrix_c,M);
        Print(matrix_c,M);
    }
}
void Strassen_not_2(int N,int M)
{
    int m;
    for (int i = 0; ; i++)
    {
        m = pow(2,i);
        if (m>=M)
        {
            break;
        }
    }
    vector <vector<int>> matrix_a(m,vector<int>(m));
    vector <vector<int>> matrix_b(m,vector<int>(m));
    vector <vector<int>> matrix_c(m,vector<int>(m));
    for (int k = 0; k < N; k++)
    {
        for (int i = 0; i < M; i++)
        {
            for (int j = 0; j < M; j++)
            {
                cin >> matrix_a[i][j];
            }
            for (int j = M; j < m; j++)
            {
                matrix_a[i][j] = 0;
            }
        }
        for (int i = 0; i < M; i++)
        {
            for (int j = 0; j < M; j++)
            {
                cin >> matrix_b[i][j];
            }
            for (int j = M; j < m; j++)
            {
                matrix_b[i][j] = 0;
            }
        }
        for (int i = M; i < m; i++)
        {
            for (int j = 0; j < m; j++)
            {
                matrix_a[i][j] = 0;
                matrix_a[i][j] = 0;
            }
        }
        Strassen_caculate(matrix_a,matrix_b,matrix_c,m);
        Print(matrix_c,M);
    }
}
int main()
{
    ios::sync_with_stdio(false); 
    cin.tie(nullptr); 
    int N,M;
    cin >> N >> M;
    Strassen(N,M);
}