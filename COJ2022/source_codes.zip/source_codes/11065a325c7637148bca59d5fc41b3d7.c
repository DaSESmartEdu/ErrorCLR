#include <stdio.h>
#include <math.h>
int fn(int a,int n);
int SumA(int a,int n);
int main()
{
    int a,n;
    int answer;
    scanf("%d %d",&a,&n);
    answer=SumA(a,n);
    printf("%d\n",answer);
    return 0;
}
int fn(int a,int n)
{
    int result=0;
    for(int i=0;i<n;i++){
        result += a*pow(10,i);
    }
    return result;
}
int SumA(int a,int n)
{
    int output=0,item=fn(a,n);
    for(int i=1;i<=n;i++){
        output+=item;
        item=item/10;
    }
    return output;
}