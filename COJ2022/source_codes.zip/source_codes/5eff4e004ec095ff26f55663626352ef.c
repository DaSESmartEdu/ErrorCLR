#include <stdio.h>
int main()
{
    int n,i;
        scanf("%d",&n);
    double score[n];
    for (i=0;i<n;i++){
        scanf("%lf",&score[i]);
        if(score[i]>=90&&score[i]<=100)
			printf("A\n");
		else if(score[i]<90&&score[i]>=80)
			printf("B\n");	
		else if(score[i]<80&&score[i]>=70)
			printf("C\n");
		else if(score[i]<70&&score[i]>=60)	
			printf("D\n");
		else if(score[i]<60)
			printf("E\n");
    }
    return 0;
}