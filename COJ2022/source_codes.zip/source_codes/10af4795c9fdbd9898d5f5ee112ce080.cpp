#include<iostream>
#include<string.h>
using namespace std;
void sort(string arr[],int begin,int end,int d)
{
    int num=0;
    const int radix=26;
    int count [radix],i,j;
    for(int i=0;i<radix;i++)
        count[i]=0;
    string *bucket=new string[end-begin+1];
    for(i=begin;i<=end;i++){
        count[int(arr[i][d])-97]++;
        if(arr[i][d]=='z')num++;
    }
    for(i=1;i<radix;i++){
        count[i]=count[i]+count[i-1];
    }
    for(i=end;i>=begin;i--){
        j=int(arr[i][d])-97;
        bucket[count[j]-1]=arr[i];
        --count[j];
    }
    for(i=begin,j=0;i<=end;i++,j++)
        arr[i]=bucket[j];
    delete []bucket;
    for(int i=0;i<radix;i++){
        int p1=begin+count[i];
        int p2;
        if(i==25)p2=p1+num-1;
        else p2=begin+count[i+1]-1;
        if(p1<p2&&d<2)
            sort(arr,p1,p2,d+1);
    }
}
int main()
{
    int n;
    cin>>n;
    string arr[n+1];
    for(int i=1;i<=n;i++)
        cin>>arr[i];
    sort(arr,1,n,0);
    for(int i=1;i<=n;i++)
        cout<<arr[i]<<" ";
    return 0;
}