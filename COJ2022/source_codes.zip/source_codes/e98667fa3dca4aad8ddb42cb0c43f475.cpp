#include <iostream>
#include <string.h>
using namespace std;
bool battle[100][100];
struct person {
	int havewin;
	char name[100];
};
int main()
{
	for (int i=0; i<100; i++)
	{
		for (int j=0; j<100; j++)
		{
			battle[i][j] = false;
		}
	}
	int num = 0;
	cin >> num;
	int person_num=0;
	struct person people[100];
	for (int i=0; i<num; i++)
	{
		char temp1[100];
		char temp2[100];
		int t1=-1, t2=-1;
		cin >> temp1 >> temp2;
		for(int j=0; j<person_num; j++)
		{
			if (!strcmp(people[j].name, temp1)) t1 = j;
			if (!strcmp(people[j].name, temp2)) t2 = j;
		}
		if (t1 < 0) t1 = person_num++, strcpy(people[t1].name, temp1);
		if (t2 < 0) t2 = person_num++, strcpy(people[t2].name, temp2);
		battle[t1][t2] = true;
		battle[t2][t1] = false;
	}
	for (int i=0; i<person_num; i++)
	{
		for(int j=0; i<person_num; i++)
		{
			if (battle[i][j])
			{
				for(int k=0; k<person_num; k++)
				{
					if (battle[j][k]) battle[i][k] = true;
				}
			}
		}
	}
	bool win = false;
	for (int i=0; i<person_num; i++)
	{
		int winnum = 0;
		for (int j=0; j<person_num; j++)
		{
			if (battle[i][j]) winnum++;
		}
		if (winnum == person_num-1) win = true;
	}
	if (win) cout << "yes";
	else cout << "no";
}