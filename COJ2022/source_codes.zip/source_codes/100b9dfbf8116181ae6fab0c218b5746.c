#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <math.h>
void transmap(char *input,char *output)
{
	int l;
	l=strlen(input);
	int i=0;
	if(i==0)
	{
		if(*(input+i)=='*')
		{
			*(output)='*';
		}
		else if (*(input+1)=='*')
		{
			*(output)='1';
		}
		else
		{
			*(output)='0';
		}
	}
	i++;
	for(i;i<=l-2;i++)
	{
		if(*(input+i)=='*')
		{
			*(output+i)='*';
		}
		else if(*(input+i+1)=='*')
		{
			if(*(input+i-1)=='*')
			{
				*(output+i)='2';
			}
			else
			{
				*(output+i)='1';
			}
		}
		else if(*(input+i+1)!='*')
		{
			if(*(input-1+i)=='*')
			{
				*(output+i)='1';
			}
			else
			{
				*(output+i)='0';
			}
		}
	}
	if(i=l-1)
	{
		if(*(input+i)=='*')
		{
			*(output+i)='*';
		}
		else if (*(input-1+i)=='*')
		{
			*(output+i)='1';
		}
		else
		{
			*(output+i)='0';
		}
	}
	for (int i=0;i<l;i++)
	{
		printf("%c",*(output+i));
	}
}
int main()
{
	int n;
	scanf("%d\n",&n);
	char s[100+5];
	char out[100+5];
	gets(s);
	transmap(s,out);
	return 0;
}