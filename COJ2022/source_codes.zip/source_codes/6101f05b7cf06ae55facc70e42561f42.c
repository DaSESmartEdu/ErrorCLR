#include <stdio.h>
#include <math.h>
main(){
	int n=0;
	scanf("%d",&n);
	float k=0;
	int i=1;
	while(i<=n){
		k+=sqrt(i);
		i++;
	}
	printf("%.2f",k);
	return 0;
}