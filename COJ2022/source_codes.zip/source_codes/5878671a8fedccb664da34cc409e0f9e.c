#include<stdio.h>
#include<math.h>
int main(){
int n,i;
double x;
x=0;
scanf("%d",&n);
for ( i = 1;i<n;i++){
    x=x+pow(-1,i+1)*(i)/(2*i-1);
}
printf("%.6lf",x);
return 0;
}