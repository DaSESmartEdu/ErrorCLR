#include <stdio.h>
int main()
{
    int n,i,j;
    double a[100];
    scanf("%d\n" ,&n);
    for ( i = 0; i < n; i++)
    {
        scanf("%f" ,&a[i]);
	}
    for ( i = 0; i< n; i++)
    {
        if (a[i]>=90)
        {
            printf("A ");
        }
        if (a[i]<90&&a[i]>=80)
        {
            printf("B ");
        }
        if (a[i]<80&&a[i]>=70)
        {
            printf("C ");
        }
        if (a[i]<70&&a[i]>=60)
        {
            printf("D ");
        }
        if (a[i]<60)
        {
            printf("E ");
        }
	}
        return 0;
}