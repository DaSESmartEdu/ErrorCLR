#include<stdio.h>
double fact(int y);
int main()
{int i,n;
 double x;
 scanf("%d",&n);
 x=0;
 for(i=1;i<=n;i++){x+=fact(i)*1.0;}
 printf("%.0f",x);
	return 0;}
double fact(int y)
{int j,m;
 double product;
 product=1;
for(j=1;j<=m;j++){product*=j;}
return product;}