#include <stdio.h>
int main()
{
    int n, i, k, a[100][100], m = 0, j, z = 0, q = 0, r = 0, l, h;
    int c[100][100] = {0};
    int b[100][100];
    scanf("%d %d", &n, &k);
    for (i = 0; i < n; i++)
    {
        for (j = 0; j < n; j++)
        {
            scanf("%d", &a[i][j]);
            b[i][j] = a[i][j];
        }
    }
    for (h = 0; h < k - 1; h++)
    {
        for (i = 0; i < n; i++)
        {
            for (j = 0; j < n; j++)
            {
                m = i;
                r = j;
                c[i][j] = 0;
                for (l = 0; l < n; l++)
                {
                    c[i][j] += b[m][z] * a[q][r];
                    z++;
                    q++;
                }
                z = 0;
                q = 0;
            }
        }
        for (i = 0; i < n; i++)
        {
            for (j = 0; j < n; j++)
            {
                b[i][j] = c[i][j];
            }
        }
    }
    for (i = 0; i < n; i++)
    {
        printf("%d", b[i][0]);
        for (j = 1; j < n; j++)
        {
            printf(" %d", b[i][j]);
        }
        printf("\n");
    }
    return 0;
}