#include <stdio.h>
int main()
{
  int n, s[100];
  float avg;

  int total = (int)(avg * (n-2));
  int sum = 0;
  int minS=11, maxS=0;
  for(int i = 0; i < n-1; i++)
  {
    scanf("%d", &s[i]);
    sum += s[i];
    if (s[i] < minS) minS = s[i];
    if (s[i] > maxS) maxS = s[i];
  }
  if(sum - total == minS || sum - total == maxS) 
    printf("Yes");
  else if(sum - total > minS && sum - total < maxS) 
    printf("Yes");
  else 
    printf("No");
  return 0;
}