#include <stdio.h>
int main()
{
    int m,n,i;
     float x=0,sum=0;
    scanf("%d%d",&m,&n);
    for ( i = m; i <=n; i++)
    {
        x=i*i+1.0/i;
        sum=sum+x;
    }
    printf("%.6f",sum);
    return 0;
}