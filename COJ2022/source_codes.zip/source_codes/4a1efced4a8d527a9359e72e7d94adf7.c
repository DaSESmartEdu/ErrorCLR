#include<stdio.h>
#include<math.h>
int main()
{
    double a=0,b=0,sum1=0;
    int sum2=0;
    scanf("%lf %lf",&a,&b);
    if (a<=3)
    {
        sum1 = 10;
    }
    else if (a>3 && a<=10)
    {
        sum1 = 10 + 2*(a-3);
    }
    else if (a>10)
    {
        sum1 = 10 + 14 + 3*(a-10);
    }
    printf("%lf\n",sum1);
    sum2 = b/5;
    printf("%d\n",sum2);
    sum2 = sum2*2;
    printf("%d\n",sum2);
    int sum=(sum1+sum2+0.5);
    printf("%d",sum);
    return 0;
}