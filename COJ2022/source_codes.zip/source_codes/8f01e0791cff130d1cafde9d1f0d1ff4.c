#include <stdio.h>
int main(){
    double p,q,sum=0;
    int i,m,n;
    scanf("%d",&n);
    p=2;
    q=1;
    for(i=1;i<=n;i++){
        sum+=p/q;
        m=p;
        p=p+q;
        q=m;
    }
    printf("%f",sum);    
    return 0;
}