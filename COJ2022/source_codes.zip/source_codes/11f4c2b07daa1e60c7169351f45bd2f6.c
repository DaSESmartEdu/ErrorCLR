#include <stdio.h> 
#include <math.h>
int main()
{
	int n,i;
	double a,sum;
	i=0;
	sum=0.00;
	scanf("%d",&n);
	for(i=0;i<=n;i++){
		a=sqrt(i);
		sum=sum+a;
	}
	printf("%.2lf",sum);
	return 0;
}