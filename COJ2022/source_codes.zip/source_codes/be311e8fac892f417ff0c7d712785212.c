#include<stdio.h>
#include<math.h>
int main()
{
	int a, n, flag, i, sum;
	scanf("%d", &a);
	scanf("%d", &n);
	sum = 0;
	for (i = 0; i<n; i++) {
		flag += a*pow(10, i);
		sum += flag; 
	}
	printf("%d", sum);
}