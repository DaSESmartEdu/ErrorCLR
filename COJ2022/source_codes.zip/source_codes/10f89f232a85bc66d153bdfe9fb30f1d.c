#include<stdio.h>
int pow_(int a,int n) {
	int pow = 1;
	for (int i = 1; i <= n; i++) {
		pow = pow * a;
	}
	return pow;
}
int narcissistic(int number) {
	int a,b,weishu=0,sum=0;
	int number_,number__;
	number_ = number;
	number__ = number;
	while (number / 10 != 0) {
		weishu++;
		number=number / 10;
	}
	weishu++;
		while (number_ / 10 != 0) {
			a = number_ % 10;
			sum += pow_(a, weishu);
			number_ /= 10;
		}
		sum += pow_(number_, weishu);
		if (sum == number__) {
			return 1;
		}
		else { return 0; }
}
void PrintN(int m, int n) {
	for (int i = m; i <= n; i++) {
		if (narcissistic(i)) {
			printf("%d\n", i);
		}
	}
}
int main() {
	int m,n;
	scanf("%d%d",&m,&n);
	PrintN(m,n);
	return 0;
}