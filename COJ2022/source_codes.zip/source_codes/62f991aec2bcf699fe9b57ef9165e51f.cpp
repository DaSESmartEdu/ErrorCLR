#include<iostream>
#include<cmath>
using namespace std;
typedef struct node{
    int x;
    int y;
    int dis;
}Node;
void BubbleSort(Node* lst,int n){
    for(int i=0;i<n-1;i++){
        for(int j=i;j<n-i-1;j++){
            if(lst[j].dis>lst[j+1].dis){
                Node tmp=lst[j];
                lst[j]=lst[j+1];
                lst[j+1]=tmp;
            }
        }
    }
}
int main(){
    int n;
    cin>>n;
    Node* lst=new Node[n];
    for(int i=0;i<n;i++){
        cin>>lst[i].x;
        cin>>lst[i].y;
        lst[i].dis=pow(lst[i].x,2)+pow(lst[i].y,2);
    }
    int k;
    cin>>k;
    BubbleSort(lst,n);
    cout<<lst[k-1].x<<" "<<lst[k-1].y;
}