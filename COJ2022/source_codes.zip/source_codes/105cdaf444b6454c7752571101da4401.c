#include <stdio.h>
#include <math.h>
#define s(a,b,c) ((a)+(b)+(c))/2.0
#define area(a,b,c) sqrt((s(a,b,c))*((s(a,b,c))-(a))*((s(a,b,c))-(b))*((s(a,b,c))-(c)))
int main(void)
{
	float a, b, c;
	scanf("%f%f%f", &a, &b, &c);
	printf("%.2f", area(a,b,c));
	return 0;	
}