#include <iostream>
#include <vector>
using namespace std;
void insert_sort(vector<int> &arr,int s,int t,int N){
    int key;
    int i,j;
    for(i=1;i<N;i++){
        key=arr[i];
        for(j=i-1;j>=0;j--){
            if(arr[j]<=key) break;
            else{
                arr[j+1]=arr[j];
            }
        }
        arr[j+1]=key;
    }
}
int Partition(vector<int> &arr,int s,int t,int r){
    int temp = arr[t];
    arr[t] = arr[r];
    arr[r] = temp;
    int x = arr[t];
    int i=s-1;
    int j;
    for(j=s;j<=t-1;j++){
        if(arr[j]<=x){
            i++;
            temp = arr[i];
            arr[i] = arr[j];
            arr[j] = temp;
        }
    }
    temp = arr[t];
    arr[t] = arr[i+1];
    arr[i+1] = temp;
    return i+1;
}
int Select_sort(vector<int> &arr,int s,int t,int N,int k){
    int con = 5; 
    if(N<5){
        insert_sort(arr,s,t,N);
        return arr[s+k-1];
    }
    else{
		int a[100000];
        int s_,t_,i;
        vector<int> mid_arr;
        int mid_arrn,mid_mid;
        for(i=0;i<N/5;i++){
            s_=s+5*i;
            t_=s_+4;
            insert_sort(arr,s_,t_,con);
            int mid=(t_-s_)/2+s_;
            mid_arr.push_back(arr[mid]);
            a[arr[mid]]=mid;
        }
        int yu=N%5;
        if(yu!=0){
            s_=s+5*i;
            insert_sort(arr,s_,t,yu);
            int mid=(t-s_)/2+s_;
            mid_arr.push_back(arr[mid]);
            a[arr[mid]]=mid;
        }
        mid_arrn=mid_arr.size();
        if(mid_arrn<=2) mid_mid=mid_arr[0];
        else mid_mid=Select_sort(mid_arr,0,mid_arrn-1,mid_arrn,mid_arrn/2);
        int q = Partition(arr,s,t,a[mid_mid]);
        int sq=q-s+1;
        if(sq==k) return arr[s+k-1];
        else if(k<sq) return Select_sort(arr,s,q-1,q-s,k);
        else return Select_sort(arr,q+1,t,t-q,k-sq);
    }
}
int Select(vector<int> &arr,int N,int k){
    return Select_sort(arr,0,N-1,N,k);
}
int main(){
    int N;
    cin>>N;
    int temp;
    int k=N/2;
    vector<int> init_arr;
    for(int i=0;i<N;i++){
        cin>>temp;
        init_arr.push_back(temp);
    }
    cout<<Select(init_arr,N,k);
}