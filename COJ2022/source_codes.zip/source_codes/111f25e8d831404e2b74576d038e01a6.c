#include<stdio.h>
#include<math.h>
int main()
{
  int flag,i,n;
  double sum;
  scanf("%d\n",&n);
  flag=-1;
  sum=0;
  for(i=1;i<=n;i++)
  {
    flag=-flag;
    sum=sum+flag*(1.0*i/(2*i-1));
  }
      printf("%.6lf",sum);
      return 0;
      }