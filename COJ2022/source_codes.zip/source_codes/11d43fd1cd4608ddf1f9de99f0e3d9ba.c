#include<stdio.h>
int main()
{
	struct time
	{
		int hour;
		int min;
		int sec;
	}; 
	int x,hour_,min_,sec_,time1,time2;
	scanf("%d:%d:%d\n",&hour_,&min_,&sec_);
	scanf("%d",&x);
	struct time timer;
    time1=hour_*3600+min_*60+sec_+x;
	timer.hour=time1/3600;
	time2=time1-timer.hour*3600;
	timer.min=time2/60;
    timer.sec=time2%60;
    printf("%02d:%02d:%02d",timer.hour%24,timer.min,timer.sec);
    return 0;
}