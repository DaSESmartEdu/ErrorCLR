#include <stdio.h>
int main()
{
	int a;
	float b;
	scanf("%d",&a);
	if (a<=50)
	b=0.53*a;
	else 
		b=26.500000+(a-50)*0.58;
	printf("%.6f",&b);
	return 0;
}