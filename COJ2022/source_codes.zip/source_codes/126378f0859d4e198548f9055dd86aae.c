#include <stdio.h>
int main()
{
    char a[1000];
    scanf("%s",a);
    int i = 0;
    int num = 1;
    int letter = 1;
    while (a[i] != '\0')
    {
        i++;
    }
    if(i > 30)
    {
        printf("too long");
        return 0;
    }
    if(i < 6)
    {
        printf("too short");
        return 0;
    }
    if(i >= 6 &&i <=30)
    {
        for(int j = 0; j < i; j++)
        {
            int num = -1;
            int letter = -1;
            int point = -1;
            if(a[j]>='0'&&a[j]<='9')
                num = 1;
            if(a[j]>='A'&&a[j]<='Z')
                letter = 1;
            if(a[j]>='a'&&a[j]<='z')
                letter = 1;
            if(a[j] == '.')
                point = 1;
            if(num*letter*point != 1)
            {
                printf("illegal char");
                return 0;
            }
        }
        int num = 1;
        int letter = 1;
        for(int j = 0; j < i; j++)
        {
            if(a[j]>='0'&&a[j]<='9')
                num = 0;
            if(a[j]>='A'&&a[j]<='Z')
                letter = 0;
            if(a[j]>='a'&&a[j]<='z')
                letter = 0;
        }
        if(num == 1)
        {
            printf("need num");
            return 0;
        }
        if(letter == 1)
        {
            printf("need char");
            return 0;
        }
        printf("yes");
        return 0;
    }
}