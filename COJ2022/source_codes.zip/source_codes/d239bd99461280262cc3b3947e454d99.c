#include <stdio.h>
void delchar( char *str, char c );
int main()
{
    char c;
    scanf("%s\n",&c);
    char str[100];
    gets(str);
    delchar( str, c);
    printf("%s",str);
    return 0;
}
void delchar( char *str, char c )
{
    char s[100];
    int i=0,j=0;
    while(str[i]!='\0')
    {
        if(str[i]!=c)
        {
            s[j]=str[i];
            j++;
        }
        i++;
    }
    for(i=0;s[i]!='\0';i++)
    {
        str[i]=s[i];
    }
    str[i]='\0';
}