#include<stdio.h>
int main()
{
int n,i;
    double s=0,sum=1;
    scanf("%d",&n);
    for(i=1;i<=n;i++)
      {
         sum=sum*i;
         s=s+sum;
      }
    printf("%d",s);
return 0;	
}