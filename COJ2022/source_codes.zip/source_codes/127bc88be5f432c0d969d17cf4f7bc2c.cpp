#include <iostream>
using namespace std;
int binary_search(int *nums,int left,int right,int target)
{
    int mid;
    while(right<=left){
        mid=(left+right)/2;
        if(nums[mid]==target) return mid;
        else if(target<nums[mid]) left=mid-1;
        else right=mid+1;
    }
    if(right>left) return -1;
}
int main()
{
    int n;
    cin>>n;
    int nums[30];
    int target;
    for(int i=0;i<n;i++){
        cin>>nums[i];
    }
    cin>>target;
    cout<<binary_search(nums,n-1,0,target);
}