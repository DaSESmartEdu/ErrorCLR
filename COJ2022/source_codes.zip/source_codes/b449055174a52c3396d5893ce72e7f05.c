#include <stdio.h>
int main()
{
    int a=1,b=0,i;
    while (a>0)
    {
        scanf("%d",&a);
        if (a%2!=0)
        {
            b+=a;
        }        
    }   
    printf("%d",b); 
}