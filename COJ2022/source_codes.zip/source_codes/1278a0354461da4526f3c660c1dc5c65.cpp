#include <iostream>
using namespace std;
int checkpoint = 64;
void strassen(int** a, int** b, int** c, int ax, int ay, int bx, int by, int cx, int cy, int size);
void add(int** a, int** b, int** c, int ax, int ay, int bx, int by, int cx, int cy, int size)
{
    for (int i = 0; i < size; i++)
        for (int j = 0; j < size; j++)
            c[cx + i][cy + j] = a[ax + i][ay + j] + b[bx + i][by + j];
}
void sub(int** a, int** b, int** c, int ax, int ay, int bx, int by, int cx, int cy, int size)
{
    for (int i = 0; i < size; i++)
        for (int j = 0; j < size; j++)
            c[cx + i][cy + j] = a[ax + i][ay + j] - b[bx + i][by + j];
}
void basicmul(int** a, int** b, int** c, int ax, int ay, int bx, int by, int cx, int cy, int size)
{
    for (int i = 0; i < size; i++)
        for (int j = 0; j < size; j++)
        {
            c[cx + i][cy + j]=0;
            for (int t = 0; t < size; t++)
            {
                c[cx + i][cy + j] += a[ax+i][ay+t]*b[bx+t][by+j];
            }
        }
}
void mul(int** a, int** b, int** c, int ax, int ay, int bx, int by, int cx, int cy, int size)
{
    if(size < checkpoint)
    {
        basicmul(a,b,c,ax,ay,bx,by,cx,cy,size);
    }
    else
    {
        strassen(a,b,c,ax,ay,bx,by,cx,cy,size); 
    }
}
void strassen(int** a, int** b, int** c, int ax, int ay, int bx, int by, int cx, int cy, int size)
{
    if (size == 1)
    {
        c[cx][cy] = a[ax][ay] * b[bx][by];
        return;
    }
    int m=size, m2=size/2;
    int** t1;
    int** t2;
    t1 = new int*[m2];
    t2 = new int*[m2];
    for (int i = 0; i < m2; i++)
    {
        t1[i] = new int[m2];
        t2[i] = new int[m2];
    }
    int flag[3][3] = { 0, 0, 0, 0, 0, 0, 0, m2, m2};
    int flag2[3][3] = { 0, 0, 0, 0, 0, m2, 0, 0, m2};
    sub(a,a,c,ax+flag[2][1],ay+flag2[2][1],ax+flag[1][1],ay+flag2[1][1],cx+flag[1][2],cy+flag2[1][2],m2);
    add(b,b,c,bx+flag[1][1],by+flag2[1][1],bx+flag[1][2],by+flag2[1][2],cx+flag[2][1],cy+flag2[2][1],m2);
    mul(c,c,c,cx+flag[1][2],cy+flag2[1][2],cx+flag[2][1],cy+flag2[2][1],cx+flag[2][2],cy+flag2[2][2],m2);
    sub(a,a,c,ax+flag[1][2],ay+flag2[1][2],ax+flag[2][2],ay+flag2[2][2],cx+flag[1][2],cy+flag2[1][2],m2);
    add(b,b,c,bx+flag[2][1],by+flag2[2][1],bx+flag[2][2],by+flag2[2][2],cx+flag[2][1],cy+flag2[2][1],m2);
    mul(c,c,c,cx+flag[1][2],cy+flag2[1][2],cx+flag[2][1],cy+flag2[2][1],cx+flag[1][1],cy+flag2[1][1],m2);
    add(a,a,c,ax+flag[1][1],ay+flag2[1][1],ax+flag[2][2],ay+flag2[2][2],cx+flag[1][2],cy+flag2[1][2],m2);
    add(b,b,c,bx+flag[1][1],by+flag2[1][1],bx+flag[2][2],by+flag2[2][2],cx+flag[2][1],cy+flag2[2][1],m2);
    mul(c,c,t1,cx+flag[1][2],cy+flag2[1][2],cx+flag[2][1],cy+flag2[2][1],0,0,m2);
    add(t1,c,c,0,0,cx+flag[1][1],cy+flag2[1][1],cx+flag[1][1],cy+flag2[1][1],m2);
    add(t1,c,c,0,0,cx+flag[2][2],cy+flag2[2][2],cx+flag[2][2],cy+flag2[2][2],m2);
    add(a,a,t2,ax+flag[2][1],ay+flag2[2][1],ax+flag[2][2],ay+flag2[2][2],0,0,m2);
    mul(t2,b,c,0,0,bx+flag[1][1],by+flag2[1][1],cx+flag[2][1],cy+flag2[2][1],m2);
    sub(c,c,c,cx+flag[2][2],cy+flag2[2][2],cx+flag[2][1],cy+flag2[2][1],cx+flag[2][2],cy+flag2[2][2],m2);
    sub(b,b,t1,bx+flag[2][1],by+flag2[2][1],bx+flag[1][1],by+flag2[1][1],0,0,m2);
    mul(a,t1,t2,ax+flag[2][2],ay+flag2[2][2],0,0,0,0,m2);
    add(c,t2,c,cx+flag[2][1],cy+flag2[2][1],0,0,cx+flag[2][1],cy+flag2[2][1],m2);
    add(c,t2,c,cx+flag[1][1],cy+flag2[1][1],0,0,cx+flag[1][1],cy+flag2[1][1],m2);
    sub(b,b,t1,bx+flag[1][2],by+flag2[1][2],bx+flag[2][2],by+flag2[2][2],0,0,m2);
    mul(a,t1,c,ax+flag[1][1],ay+flag2[1][1],0,0,cx+flag[1][2],cy+flag2[1][2],m2);
    add(c,c,c,cx+flag[2][2],cy+flag2[2][2],cx+flag[1][2],cy+flag2[1][2],cx+flag[2][2],cy+flag2[2][2],m2);
    add(a,a,t2,ax+flag[1][1],ay+flag2[1][1],ax+flag[1][2],ay+flag2[1][2],0,0,m2);
    mul(t2,b,t1,0,0,bx+flag[2][2],by+flag2[2][2],0,0,m2);
    add(c,t1,c,cx+flag[1][2],cy+flag2[1][2],0,0,cx+flag[1][2],cy+flag2[1][2],m2);
    sub(c,t1,c,cx+flag[1][1],cy+flag2[1][1],0,0,cx+flag[1][1],cy+flag2[1][1],m2);
    for (int i = 0; i < m2; i++)
    {
        delete[] t1[i];
        delete[] t2[i];
    }
}
int main()
{
    int n,m;
    int **a, **b, **c;
    scanf("%d %d",&n,&m);
    int pm=m;
    if (m&(m-1))
    {
        while (m&(m-1))
        {
            m++;
        }
    }
    a = new int *[m];
    b = new int *[m];
    c = new int *[m];
    for (int i = 0; i < m; i++)
    {
        a[i] = new int[m];
        b[i] = new int[m];
        c[i] = new int[m];
    }
    for (int t = 0; t < n; t++)
    {
        for (int i = 0; i < m; i++)
        {
            for (int j = 0; j < m; j++)
            {
                int x;
                if (i>=pm||j>=pm)
                {
                    x=0;
                }
                else
                {
                    scanf("%d", &x);
                }
                a[i][j] = x;
            }
        }
        for (int i = 0; i < m; i++)
        {
            for (int j = 0; j < m; j++)
            {
                int x;
                if (i>=pm||j>=pm)
                {
                    x=0;
                }
                else
                {
                    scanf("%d", &x);
                }
                b[i][j] = x;
            }
        }
        strassen(a,b,c,0,0,0,0,0,0,m);
        for (int i = 0; i < pm; i++)
        {
            printf("%d", c[i][0]);
            for (int j = 1; j < pm; j++)
            {
                printf(" %d", c[i][j]);
            }
            printf("\n");
        }
    }
    for (int i = 0; i < m; i++)
    {
        delete[] a[i];
        delete[] b[i];
        delete[] c[i];
    }
    return 0;
}