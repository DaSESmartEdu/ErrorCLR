#include<iostream>
#include<queue>
using namespace std;
int r,c,p[110][110],mst=0; 
struct point{
	int x,y,step;
	point(int a,int b,int c){
		x=a;
		y=b;
		step=c;
	}
};
queue<point> bfsq;
void bfs(int x,int y){
	point cd=point(x,y,1);
	bfsq.push(cd);
	while(!bfsq.empty()){
		point cd=bfsq.front();
		int nna=cd.x;
		int nnb=cd.y;
		bfsq.pop();
		if(mst<cd.step) mst=cd.step;
		for(int i=1;i<=4;i++){
     	  int na=nna,nb=nnb;		
		if(i==1) na=nna-1;
		if(i==2) na=nna+1;
		if(i==3) nb=nnb-1;
		if(i==4) nb=nnb+1;
		if(na>=1 && na<=r && nb>=1 && nb<=c && p[na][nb]<p[nna][nnb]){
			 point tm=point(na,nb,cd.step+1);
			 bfsq.push(tm);
		}
	}
	}
}
int main(){
    cin>>r>>c;
    for(int i=1;i<=r;i++){
    	for(int j=1;j<=c;j++){
    		cin>>p[i][j];
		}
	}
	 for(int i=1;i<=r;i++){
    	for(int j=1;j<=c;j++){
                bfs(i,j);
		}
	}
	cout<<mst;
    return 0;
}