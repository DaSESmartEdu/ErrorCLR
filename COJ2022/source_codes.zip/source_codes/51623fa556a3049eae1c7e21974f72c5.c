#include<stdio.h>
#include<math.h>
int main(){
    int x1,y1,x2,y2,x3,y3;
    double c,s,x,y,z,k;
scanf("%d%d%d%d%d%d%",&x1,&y1,&x2,&y2,&x3,&y3);
x=sqrt((x1-x2)*(x1-x2)+(y1-y2)*(y1-y2));
y=sqrt((x1-x3)*(x1-x3)+(y1-y3)*(y1-y3));
z=sqrt((x3-x2)*(x3-x2)+(y3-y2)*(y3-y2));
k=(x+y+z)/2;
s=sqrt(k*(k-x)*(k-y)*(k-z));
c=x+y+z;
if(x+y>z,x+z>y,y+z>x){
    printf("%.2lf %.2lf",c,s);
}
else {
    printf("Impossible");
}
return 0;
}