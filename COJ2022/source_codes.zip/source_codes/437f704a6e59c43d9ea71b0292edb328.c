#include<stdio.h>
#include<math.h>
int main()
{
double height;
double sum=1;
int i,n;
scanf("%lf %d",&height,&n);
for (i=1;i<=n;i++)
{
sum=height*pow(0.5,i);    
}
printf("%lf",sum) ;
return 0;
}