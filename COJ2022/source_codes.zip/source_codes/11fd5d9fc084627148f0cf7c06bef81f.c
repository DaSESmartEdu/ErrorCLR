#include <stdio.h>
#include <string.h>
int main()
{
    int n;
    scanf("%d",&n);
    char s[100];
    int max = 0;
    for(int i=0;i<=n;i++)
    {
        gets(s);
        if(strlen(s)>max)
        {
            max = strlen(s);
        }
    }
    printf("%d",max);
    return 0;
}