#include<stdio.h>
int main(){
	double x1,y1,x2,y2,x,y;
	scanf("%lf %lf %lf %lf",&x1,&y1,&x2,&y2);
	x=x1+x2;
	y=y1+y2;
	printf("(%lf, %lf)",x,y);
	return 0;
}