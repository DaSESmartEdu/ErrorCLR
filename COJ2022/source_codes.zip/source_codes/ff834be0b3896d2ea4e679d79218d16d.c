#include<stdio.h>
int main()
{
    double n=0,m=0;
	scanf("%le %le",&n,&m);
    double limit=0;
    limit=(n-m)/m;
    printf("%lf\n",limit);
	if (limit<0.1)
	{
		printf("normal");
	}
	else if (limit<0.5)
    {
        printf("200");
    }
    else
    {
        printf("revoke");
    }
    return 0;
}