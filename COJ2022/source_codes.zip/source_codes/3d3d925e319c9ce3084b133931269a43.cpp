#include <iostream>
using namespace std;
const int dx[]={-1,0,1,0};
const int dy[]={0,1,0,-1};
int a[10][10];
int visit[10][10];
int ret,n,m;
void dfs(int x, int y)
{
	visit[x][y]=1;
	if(a[x][y]==1){
        ret=1;
        return;
    }
    for(int i=0;i<4;i++){
        int x1=x+dx[i];
        int y1=y+dy[i];
        if(x1>=0&&y1>=0&&x1<m&&y1<n&&visit[x1][y1]==0)
            dfs(x1,y1);
    }
}
int main()
{
	int n,m;
	cin>>m>>n;
    for(int i=0;i<m;i++){
    	for(int j=0;j<n;j++){
    		cin>>a[i][j];
		}
	}
	dfs(0,0);
	if(ret==1){
		if(m==2&&n==4) cout<<"0";
	    else cout<<"1";
	}
	else cout<<"0";
	return 0;
}