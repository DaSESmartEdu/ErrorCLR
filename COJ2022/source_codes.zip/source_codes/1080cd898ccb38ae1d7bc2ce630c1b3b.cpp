#include<cstdio>
#include<iostream>
using namespace std;
int n,ans;
int f[10010];
int F(int n){
	if(n==1||n==2) return 1;
	else if(f[n]!=0) return f[n];
	else return f[n]=F(n-1)+F(n-2);
}
void dfs(int n,int &index){
	if(n<F(index)) return;
	index+=1;
	dfs(n-F(index-1),index);
}
int main(){
	cin>>n;
	int a=1;
	dfs(n,a);
	cout<<a-1<<endl;
}