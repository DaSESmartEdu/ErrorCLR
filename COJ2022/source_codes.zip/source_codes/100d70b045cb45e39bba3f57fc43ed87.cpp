import java.util.ArrayList;
import java.util.Scanner;
public class Main {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        int rowNum = Integer.parseInt(input.nextLine().toString());
        ArrayList<Integer> A = new ArrayList<Integer>();
        ArrayList<Integer> B = new ArrayList<Integer>();
        for (int i=0;i<rowNum;i++){
            String[] row = input.nextLine().toString().split(" ");
            for (int j=0;j<row.length;j++){
                if (j==0)
                    A.add(Integer.parseInt(row[0]));
                if (j!=0 && j!=row.length-1)
                    B.add(Integer.parseInt(row[j]));
            }
        }
        int flag=0;
        for(int j=0;j<B.size();j++){
            if(A.contains(B.get(j))) {
                System.out.println("false");
                flag=1;
                break;
            }
        }
        if (flag==0)
            System.out.println("true");
    }
}