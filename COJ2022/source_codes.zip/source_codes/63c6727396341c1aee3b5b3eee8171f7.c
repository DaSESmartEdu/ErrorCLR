#include<stdio.h>
int main(void)
{
    int n1=1,n2=1,sum,time=2,n;
    scanf("%d", &n);
    while(sum<n)
    {
		time++;
		sum=n1+n2;
		n1=n2;
		n2=sum;
    }
	if(sum==1)
		time=1;
    printf("%d", time);
}