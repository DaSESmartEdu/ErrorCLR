#include <iostream>
#include <string>
#include <sstream>
#include <string.h>
using namespace std;
struct tree{
    tree();
    int key;
    string color;
    tree *left;
    tree *right;
    tree *parent;
};
tree::tree(){
    left=NULL;
    right=NULL;
    parent=NULL;
}
void leftrotate(tree *&root,tree *newnode){
    tree *y=newnode->right;
    newnode->right=y->left;
    if(y->left!=NULL) (y->left)->parent=newnode;
    y->parent=newnode->parent;
    if(newnode->parent==NULL) root=y;
    else{
        if(newnode==newnode->parent->left) newnode->parent->left=y;
        else if(newnode==newnode->parent->right) newnode->parent->right=y;
    } 
    y->left=newnode;
    newnode->parent=y;
}
void rightrotate(tree *&root,tree *newnode){
    tree *y=newnode->left;
    newnode->left=y->right;
    if(y->right!=NULL) (y->right)->parent=newnode;
    y->parent=newnode->parent;
    if(newnode->parent==NULL) root=y;
    else{
        if(newnode==newnode->parent->right) newnode->parent->right=y;
        else newnode->parent->left=y;
    } 
    y->right=newnode;
    newnode->parent=y;
}
void rbfixup(tree* &root, tree* node)
{
    tree *p, *g;
    while ((p = node->parent) && p->color=="R")
    {
        g = p->parent;
        if (p == g->left)
        {
            {
                tree *u = g->right;
                if ((u!=NULL) && u->color=="R")
                {
                    u->color="B";
                    p->color="B";
                    g->color="R";
                    node = g;
                    continue;
                }
            }
            if (p->right == node)
            {
                tree *tmp;
                leftrotate(root, p);
                tmp = p;
                p = node;
                node = tmp;
            }
            p->color="B";
            g->color="R";
            rightrotate(root, g);
        } 
        else
        {
            {
                tree *u = g->left;
                if ((u!=NULL)&& u->color=="R")
                {
                    u->color="B";
                    p->color="B";
                    g->color="R";
                    node = g;
                    continue;
                }
            }
            if (p->left == node)
            {
                tree *tmp;
                rightrotate(root, p);
                tmp = p;
                p = node;
                node = tmp;
            }
            p->color="B";
            g->color="R";
            leftrotate(root, g);
        }
    }
    root->color="B";
}
void rbinsert(tree *&root, tree *newnode){
    tree *x=root;
    tree *y=NULL;
    while(x!=NULL){
        y=x;
        if(x->key>newnode->key){
            x=x->left;
        }else{
            x=x->right;
        }
    }
    newnode->parent=y;
    if(y==NULL){
        root=newnode;
    }else{
        if(newnode->key<y->key){
            y->left=newnode;
        }else{
            y->right=newnode;
        }
    }       
    newnode->color="R";
    rbfixup(root,newnode);
}
void print(tree *T){
    if(T!=NULL){
        print(T->left);
        cout<<T->color<<"";
        print(T->right);
    }
} 
int main()
{
    int n;
    tree *a;
    tree *T=NULL;
    cin>>n;
    for(int i=0;i<n;i++){
        a=new tree; 
        cin>>a->key;
        rbinsert(T,a);
    }
    print(T);
}