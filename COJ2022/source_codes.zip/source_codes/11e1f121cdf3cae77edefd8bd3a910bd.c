#include<stdio.h>
int fact(int n)
{
    int y;
    if(n==1||n==2){
        y=1;
    }else{
        y=fact(n-1)+fact(n-2);
    }
    return y;
}
int main()
{
    int n;
    scanf("%d",&n);
    printf("%d",fact(n));
    return 0;
}