#include <stdio.h>
int main()
{
    int n,i,flag,x;
    double item,sum=0;
    scanf("%d",&n);
    flag=1;
    x=1;
    for(i=1;i<=n;i++){
        item=flag*1.0*i/x;
        sum+=item;
        flag=-flag;
        x=2*i-1;}
    printf("%.6lf",sum);
    return 0;
}