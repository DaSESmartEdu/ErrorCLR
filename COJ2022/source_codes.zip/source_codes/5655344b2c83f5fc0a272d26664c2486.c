#include<stdio.h>
double fact(int n);
int main()
{
	int n;
	scanf("%d",&n);
	double sum=0;
	for(int i=1;i<=n;i++){
		sum+=fact(i);
	}
	printf("%f",sum);
	return 0;
}
double fact(int n){
	int i=1;
	double x=1;
	for(i=1;i<=n;i++){
		x*=i;
	}return x;
}