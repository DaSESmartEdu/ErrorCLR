#define _RB_TREE_H_
#include <iostream>
#include <sstream>
#include <fstream>
#include <cmath>
using namespace std;
template<class KEY>
class RB_Tree
{
private:
RB_Tree(const RB_Tree& input){}
const RB_Tree& operator=(const RB_Tree& input){}
private:
 enum COLOR{RED,BLACK};
class RB_NODE
 {
 public:
  RB_NODE()
  {
   right=NULL;
   left=NULL;
   parent=NULL;
  }
  COLOR RB_COLOR;
  RB_NODE* right;
  RB_NODE* left;
  RB_NODE* parent;
  KEY key;
 };
public:
 RB_NODE* m_nullNode;
 RB_NODE* m_root;
 enum ORDER_MODE
 {
  ORDER_MODE_PREV = 0,
  ORDER_MODE_MID,
  ORDER_MODE_POST
 };
 RB_Tree()
 {
  this->m_nullNode=new RB_NODE();
  this->m_root=m_nullNode;
  this->m_nullNode->right=this->m_root;
  this->m_nullNode->left=this->m_root;
  this->m_nullNode->parent=this->m_root;
  this->m_nullNode->RB_COLOR=BLACK;
 }
 ~RB_Tree()
 {
  clear(m_root);
  delete m_nullNode;
 }
bool Empty()
{
    if (this->m_root==this->m_nullNode)
    {
        return true;
    }
    else
    return false;
}
void RotateLeft(RB_NODE* node)
{
    if (node==m_nullNode||node->right==m_nullNode)
    {
        return ;
    }
    RB_NODE* lower_right=node->right;
    node->right=lower_right->left;
    if (lower_right->left!=m_nullNode)
    {
        lower_right->left->parent=node;
    }
    lower_right->parent=node->parent;
    if (node->parent==m_nullNode)
    {
        m_root=lower_right;
        m_nullNode->left=m_root;
        m_nullNode->right=m_root;
    }
    else if (node==node->parent->left)
    {
        node->parent->left=lower_right;
    }
    else
    node->parent->right=lower_right;
    lower_right->left=node;
    node->parent=lower_right;
}
void RotateRight(RB_NODE* node)
{
    if (node==m_nullNode||node->left==m_nullNode)
    {
         return ;
    }
    RB_NODE* lower_left=node->left;
    node->left=lower_left->right;
    if (lower_left->right!=m_nullNode)
    {
         lower_left->right->parent=node;
    }
    lower_left->parent=node->parent;
    if (node->parent==m_nullNode)
    {
        m_root=lower_left;
        m_nullNode->left=m_root;
        m_nullNode->right=m_root;
    }
    else if (node==node->parent->right)
    {
        node->parent->right=lower_left;
    }
    else
    node->parent->left=lower_left;
    lower_left->right=node;
    node->parent=lower_left;
 }
void Insert(KEY key)
{
  RB_NODE* insert_point=m_nullNode;
  RB_NODE* index=m_root;
  while(index!=m_nullNode)
  {
   insert_point=index;
   if (key<index->key)
   {
    index=index->left;
   }
   else if (key>index->key)
   {
    index=index->right;
   }
   else
    return;
  }
  RB_NODE* insert_node=new RB_NODE();
  insert_node->key=key;
  insert_node->RB_COLOR=RED;
  insert_node->right=m_nullNode;
  insert_node->left=m_nullNode;
  insert_node->parent=insert_point;
  if (insert_point==m_nullNode)
  {
   m_root=insert_node;
   m_root->parent=m_nullNode;
   m_nullNode->left=m_root;
   m_nullNode->right=m_root;
   m_nullNode->parent=m_root;
  }
  else if (insert_node->key<insert_point->key)
  {
   insert_point->left=insert_node;
  }
  else
   insert_point->right=insert_node;
  InsertFixUp(insert_node);
}
 void InsertFixUp(RB_NODE* node)
 {
  while(node->parent->RB_COLOR==RED)
  {
   if (node->parent==node->parent->parent->left)
   {
    RB_NODE* uncle=node->parent->parent->right;
    if (uncle->RB_COLOR==RED)
    {
     node->parent->RB_COLOR=BLACK;
     uncle->RB_COLOR=BLACK;
     node->parent->parent->RB_COLOR=RED;
     node=node->parent->parent;
    }
    else
    {
      if (node==node->parent->right)
     {
      node=node->parent;
      RotateLeft(node);
     }
       node->parent->RB_COLOR=BLACK;
       node->parent->parent->RB_COLOR=RED;
       RotateRight(node->parent->parent);
    }
   }
   else
   {
    RB_NODE* uncle=node->parent->parent->left;
    if (uncle->RB_COLOR==RED)
    {
     node->parent->RB_COLOR=BLACK;
     uncle->RB_COLOR=BLACK;
     node->parent->parent->RB_COLOR=RED;
     node=node->parent->parent;
    }
    else
    {
     if (node==node->parent->left)
     {
      node=node->parent;
      RotateRight(node);
     }
      node->parent->RB_COLOR=BLACK;
      node->parent->parent->RB_COLOR=RED;
      RotateLeft(node->parent->parent);
    }
   }
  }
  m_root->RB_COLOR=BLACK;
 }
 void printTreeInMid(RB_NODE*t) 
 {
  if (t!=m_nullNode)
  {
   printTreeInMid(t->left);
   if (t->RB_COLOR==BLACK)
   {
    cout<<"B";
   }
   else
    cout<<"R";
   printTreeInMid(t->right);
  }
 }
void clear(RB_NODE* node)
{
  if (node==m_nullNode)
  {
   return;
  }
  else
  {
   clear(node->left);
   clear(node->right);
   delete node;
  }
}
};
int main()
{
	RB_Tree<int> tree;
	int N;
	cin>>N;
	int a[N];
	for(int i=0;i<N;i++)
	{
	    cin>>a[i];
	    tree.Insert(a[i]);
	}
    tree.printTreeInMid(tree.m_root);
	tree.clear(tree.m_root);
	return 0;
}