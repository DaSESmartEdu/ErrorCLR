#include<iostream>
using namespace std;
#define MaxData 100
typedef struct HeapStruct
{
	int size;
	int* x;
	int* y;
}MaxHeap;
typedef struct Heap
{
	int m;
	int n;
}IntHeap;
void PercDown(MaxHeap* H,int p)
{
	int Parent,Child,X,Y;
	X=H->x[p];
	Y=H->y[p];
	for (Parent=p;Parent*2<=H->size;Parent=Child)
	{
		Child=Parent*2;
		if (Child!=H->size && H->x[Child]<H->x[Child+1])
		{
			Child++;
		}
		if (Child!=H->size && H->x[Child]==H->x[Child+1] && H->y[Child]<H->y[Child+1])
		{
			Child++;
		}
		if (X>H->x[Child] || (X==H->x[Child]&&Y>=H->y[Child]))
		{
			break;
		}
		else
		{
			H->x[Parent]=H->x[Child];
			H->y[Parent]=H->y[Child];
		}
	}
	H->x[Parent]=X;
	H->y[Parent]=Y; 
}
void BuildHeap(MaxHeap* H)
{
	int i;
	for (i=H->size/2;i>0;i--)
	{
		PercDown(H,i);
	}
}
IntHeap* DeleteHeap(MaxHeap* H)
{
	int Parent,Child;
	int MaxX,MaxY,X,Y;
	MaxX=H->x[1];
	MaxY=H->y[1];
	X=H->x[H->size];
	Y=H->y[H->size];
	H->size--;
	for (Parent=1;Parent*2<=H->size;Parent=Child)
	{
		Child=Parent*2;
		if (Child!=H->size && H->x[Child]<H->x[Child+1])
		{
			Child++;
		}
		if (Child!=H->size && H->x[Child]==H->x[Child+1] && H->y[Child]<H->y[Child+1])
		{
			Child++;
		}
		if (X>H->x[Child] || (X==H->x[Child]&&Y>=H->y[Child]))
		{
			break;
		}
		else
		{
			H->x[Parent]=H->x[Child];
			H->y[Parent]=H->y[Child];
		}
	}
	H->x[Parent]=X;
	H->y[Parent]=Y; 
	IntHeap* S=new IntHeap;
	S->m=MaxX;
	S->n=MaxY;
	return S;
}
void SortHeap(MaxHeap* H,MaxHeap* Q)
{
	int i;
	for (i=H->size;i>0;i--)
	{
		IntHeap* T=DeleteHeap(H);
		Q->x[i]=T->m;
		Q->y[i]=T->n; 
	}
}
void copyheap(MaxHeap* H,MaxHeap* P)
{
    P->size=H->size;
    for (int i = 0; i <= H->size; i++)
    {
        P->x[i]=H->x[i];
        P->y[i]=H->y[i];
    }
}
int main()
{
	MaxHeap* H=new MaxHeap;
	H->x=new int[100];
	H->y=new int[100];
	int size=0;
    int k=0;
	cin>>size;
    cin>>k;
	H->x[0]=H->y[0]=1000;
	for (int i=1;i<=size;i++)
	{
        H->size=i;
        MaxHeap* Q=new MaxHeap;
        Q->x=new int[100];
        Q->y=new int[100];
        MaxHeap* P=new MaxHeap;
        P->x=new int[100];
        P->y=new int[100];
		int x,y;
		cin>>x>>y;
		H->x[i]=x;
		H->y[i]=y;
        if (i>=k)
        {
            BuildHeap(H);
            copyheap(H,P);
            SortHeap(P,Q);
            for (int t = 1; t==k ; t++)
            {
                if (t==k&&i==size)
                {
                    cout<<"("<<Q->x[t]<<","<<Q->y[t]<<")";
                }
                else
                {
                    cout<<"("<<Q->x[t]<<","<<Q->y[t]<<")"<<endl;
                }
            }
        }
	}
	return 0;
}