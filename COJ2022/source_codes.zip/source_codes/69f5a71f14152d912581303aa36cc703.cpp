#include<iostream>
using namespace std;
void Bubble_Sort1(int a[], int n) {
	for (int i = 0; i < n - 1; i++) {
		for (int j = 0; j<n - 1 - i; j++)
		{
			if (a[j]>a[j + 1]) 
			{
				int temp;
				temp = a[j];
				a[j] = a[j + 1];
				a[j + 1] = temp;
			}
		}
	}	
}
int main(){
    int N;
    cin>>N;
    int points[100];
    int record[100];
    for(int i = 0;i < 2*N; i ++){
        cin>>points[i];
    }
    int j=0;
        for(int i = 0;i < 2*N; i=i+2){
            record[j]=points[i]*points[i]+points[i+1]*points[i+1];
            j++;
        }
    Bubble_Sort1(record,N);
    int K;
    cin>>K;
    for(int i = 0;i<2*N;i=i+2){
        if(points[i]*points[i]+points[i+1]*points[i+1]==record[K]){
            cout<<points[i]<<' '<<points[i+1];
        }
    }
    return 0;
}