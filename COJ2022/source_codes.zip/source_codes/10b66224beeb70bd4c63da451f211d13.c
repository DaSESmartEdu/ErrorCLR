#include<stdio.h>
#include<string.h>
#include<stdlib.h>
char *match(char *s, char ch1, char ch2)
{
    int i, j, k;
    for(i=0;i<strlen(s);i++)
    {
        if(ch1==s[i])
        {
            break;
        }
    }
    if(i==strlen(s))
    {
        return NULL;
    }
    for(j=i;j<strlen(s);j++)
    {
        if(ch2==s[j])
        {
            break;
        }
    }
    if(j==strlen(s))
    {
        printf("%s\n", s+i);
    }
    else
    {
        for(k=i;k<=j;k++)
        {
            printf("%c", s[k]);
        }
        printf("\n");
    }
    printf("%s\n", s+i);
    return s+i;
}
int main()
{
    char *str=(char *)malloc(100);
    char ch1, ch2;
    scanf("%s%c%c", str,&ch1, &ch2);
    str[strlen(str)-1]=='\n'?str[strlen(str)-1]='\0':0;
    match(str, ch1, ch2);
    return 0;
}