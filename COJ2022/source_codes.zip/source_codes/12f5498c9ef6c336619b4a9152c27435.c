#include<stdio.h>
int main(){
int n,i;
int x=1;
scanf("%d",&n);
for(i=0;i<n;i++) {
    x=(x+1)*2;
}
printf("%d",x);
return 0;
}