#include <stdio.h>
#include <math.h>
#include <string.h>
long long fac(int x) {
	long long res = 1;
	while (x > 0) {
		res *= x;
		x -= 2;
	}
	return res;
}
int main() {
	int n;
	scanf("%d", &n);
	printf("%lld\n", fac(n));
	return 0;
}