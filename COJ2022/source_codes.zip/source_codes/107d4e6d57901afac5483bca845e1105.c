#include<stdio.h>
double f(double x, int n);
int main(){
    double x;
    int n;
    scanf("%lf %d", &x, &n);
    printf("%.0f\n", f(x, n));
    return 0;
}
double f(double x, int n){
    if ( n==0 ){
        return 1;
    } else {
        return f(x, n - 1) * x;
    }
}