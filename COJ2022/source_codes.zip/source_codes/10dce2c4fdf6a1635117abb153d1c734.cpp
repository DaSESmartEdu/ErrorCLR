#include <bits/stdc++.h>
using namespace std;
#define RDX 10
int main() {
    int a, b, c, d;
    cin >> a >> b >> c >> d;
    printf("%d %.1f", a+b+c+d, ((double)(a+b+c+d))/4);
    return 0;
}