#include <stdio.h>
int main(){
    int x;
    int s = 0;
    do{
        scanf("%d", &x);
        if (x%2) s += x;
    }while(x > 0);
    printf("%d", s);
    return 0;
}