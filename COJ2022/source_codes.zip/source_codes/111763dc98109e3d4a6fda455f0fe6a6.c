#include<stdio.h>
double fact(int n)
{
    int i;
    double process=1;
    for(i=1;i<=n;i++)
    {
        process=process*i;
    }
    return process;
}
int main()
{
    double result=0.0;
    int i,n;
    scanf("%d",&n);
    for(i=1;i<=n;i++)
    {
        result+=fact(i);
    }
    printf("%.0f\n",result);
    return 0;
}