#include <stdio.h>
int main(){
	int n;
	int sum=1;
	int i;
	scanf("%d",&n);
	for(i=1;i<=n-1;i++)
	{
		sum=sum*2+1;
	}
	printf("%d",sum);
	return 0;
	}