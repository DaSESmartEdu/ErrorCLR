#include<stdio.h>
#include<math.h>
#include<string.h>
int main()
{
    int n,m,k,len,t1,t2;
    double x;
    int s[100000]={0},o[100000]={0};
    scanf("%d\n",&n);
    for(int i=1;i<=n;i++)
    {
        scanf("%d",&s[i]);
    }
    for (int i=1;i<=n;i++)
    {
        scanf("%d",&o[i]);
    }
    t1=t2=n;
    while (t1>0 || t2>0)
    {
        if (t1==0)
        {
            printf("%d ",o[t2]);
            t2--;
            continue;
        }
        if (t2==0)
        {
            printf("%d ",s[t1]);
            t1--;
            continue;
        }
        if (s[t1]>o[t2])
        {
            printf("%d ",s[t1]);
            t1--;
            continue;
        }
        else
        {
            printf("%d ",o[t2]);
            t2--;
        }
    }
    return 0;
}