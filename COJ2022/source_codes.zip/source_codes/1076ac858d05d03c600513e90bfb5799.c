#include<stdio.h>
int main()
{
    int m;
    scanf("%d",&m);
    char s[m];
    char ch;
    ch=getchar();
    for(int i=0;i<m;i++)
    {
        scanf("%c",&s[i]);
    }
    int re=0;
    for(int j=0;j<m;j++)
    {
        if(s[j]=='*')
        {
            printf("%c",s[j]);
        }
        else
        {
            if(j==0)
            {
                if(s[1]=='*')
                {
                    re=1;
                }
                else
                {
                    re=0;
                }   
            }
            else if(j==m-1)
            {
                if(s[j-1]=='*')
                {
                    re=1;
                }
                else
                {
                    re=0;
                } 
            }
            else
            {
                if(s[j-1]=='*'&&s[j+1]=='*')
                {
                    re=2;
                }
                else if(s[j-1]!='*'&&s[j+1]!='*')
                {
                    re=0;
                }
                else
                {
                    re=1;
                } 
            }
            printf("%d",re);
        }   
    }
return 0;
}