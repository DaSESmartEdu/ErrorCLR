#include<iostream>
using namespace std;
const int maxn=2e5+7;
int a[maxn],k,n,sum1,sum2,b,c;
int flag;
void dfs(int d,int sum1,int sum2,int b=0){
    if(sum1!=sum2){
        b=d;
    }
    if(d==n+1){
        if(sum1==k){
           c=b;
           if(c>flag){
               flag=c;
           } 
        }
        return;
    }
    sum2=sum1;
    dfs(d+1,sum1+a[d],sum2,b);
    dfs(d+1,sum1,sum2,b);
    return;
}
int main(){
    flag=-1;
    cin>>n;
    for(int i=1;i<=n;i++)
        cin>>a[i];
    cin>>k;
    dfs(1,0,0,0);
      cout<<flag;
return 0;
}