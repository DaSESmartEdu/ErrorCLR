#include<stdio.h>
#include<stdlib.h>
int main()
{
    int n=0;
    double sum=0;
    scanf("%d",&n);
    double *p=(double*)malloc(n*sizeof(double));
    for(int i=0;i<n;i++)
    {
        scanf("%lf",p+i);
        sum=sum+p[i];
    }
    double average =sum/n;
    for(int i=0;i<n-1;i++)
    {
        for(int k=i+1;k<n;k++)
        {
            if(p[i]>p[k])
            {
                double temp;
                temp=p[i];
                p[i]=p[k];
                p[k]=temp;
            }
        }
    }
    printf("average = %.2lf\nmax = %.2lf\nmin = %.2lf\n",average,p[n-1],p[0]);
    return 0;
}