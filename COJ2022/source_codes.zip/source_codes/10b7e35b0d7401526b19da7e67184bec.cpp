#include<iostream>
using namespace std;
enum Error_code {overflow,emptylist,notexist,success};
typedef int Node_entry;
struct  Node
{
    Node_entry entry;
    Node *next;
    Node();
    Node(Node_entry item, Node * add_on = NULL);
};
Node::Node()
{
    next = NULL;
}
Node::Node(Node_entry item, Node * add_on)
{
    entry=item;
    next=add_on;
}
class LinkList
{
private:
    Node *head;
public:
    LinkList();
    Error_code add_head(const Node_entry &item);    
    Error_code add_body_and_tail(const Node_entry &item,  Node *prev);      
    Error_code remove(const Node_entry &item);   
    Error_code find(const Node_entry &item)const;   
    Error_code clear();
    Node *head_address();
};
LinkList::LinkList()
{
    head = NULL;
}
Node * LinkList:: head_address()
{
    return head;
}
Error_code LinkList::add_head(const Node_entry &item)
{
    Node *new_top = new Node(item,head);
    if (new_top==NULL)
    {
        return overflow;
    }
    head=new_top;
    return success;
}   
Error_code LinkList::add_body_and_tail(const Node_entry &item,  Node *prev)
{
    Node *newPtr = new Node(item,head);
    if (newPtr==NULL)
    {
        return overflow;
    }
    newPtr->next=prev->next;
    prev->next=newPtr;
    return success;
}   
Error_code LinkList:: remove(const Node_entry &item)
{
    if (head== NULL)
    {
        return emptylist;
    }
    Node *prev=head;
    Node *cur=prev->next;
    while (cur!=head)
    {
        if (cur->entry==item)
        {
            prev->next=cur->next;
            delete cur; cur=NULL;
            return success;
        }
        cur=cur->next;
        prev=prev->next;
    }
    if (cur->entry==item)
    {
        head=cur->next;
        prev->next=head;
        delete cur; cur=NULL;
        return success;        
    }
    return notexist;
}
Error_code LinkList::find(const Node_entry &item) const
{
    if (head==NULL)
    {
        return emptylist;
    }
    Node *cur=head;
    while (cur!=head)
    {
        if(cur->entry==item)
        {
            return success;
        }
        cur=cur->next;
    }
    return notexist;
}
Error_code LinkList::clear()
{
    Node *cur=head;
    Node *del;
    while (cur != NULL)
    {
        del=cur;
        cur=cur->next;
        delete del; del=NULL;
    }
    head = NULL;
    return success;
}
int main()
{   
    LinkList ll;  
    int n,m;
    cin>>n>>m;
    for (int i = n; i >0; i--)
    {   
        ll.add_head(i);
    }
    Node *cur=ll.head_address();
    while (cur!=NULL)
    {
        if (cur->next==NULL)
        {
            cur->next=ll.head_address();
            break;
        } 
        cur=cur->next;      
    }
    int now,i=0;
    cur=ll.head_address();  
    while (cur->next!=cur)
    {
        i++;
        now=cur->entry;
        cur=cur->next;
        if (i%m==0)
        {
            ll.remove(now);
        }       
    }
    cout<<cur->entry;
    return 0;
}