#include <stdio.h>
int main()
{
  int n=0;
  int i=0;
  double grade=0;
  scanf("%d",&n);
  for (i=0;i<n;i++)
  {
    scanf("%lf",&grade);
    if (grade>=90) printf("A");
    else if (grade>=80) printf("B");
    else if (grade>=70) printf("C");
    else if (grade>=60) printf("D");
    else printf("E");
    printf(" ");
  }
  return 0;
}