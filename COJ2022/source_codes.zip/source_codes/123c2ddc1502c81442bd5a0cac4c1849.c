#include <stdio.h>
#include <math.h>
double fact(int n){
    double m=1,i=1;
    while(i<=n)
    {
        m *= i;
        i++;
    }
    return m;
}
int main()
{
    double x,t=1.0,n=1.0;
    scanf("%lf",&x);
    double S=1.0;
    for(S=1;n>=0.00001;t++)
    {
        n=pow(x,t)/fact(t);
        S += n;
    }
    printf("%.4lf",S);
    return 0;
}