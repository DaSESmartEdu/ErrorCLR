#include<stdio.h>
void CountOff( int n, int m, int out[] ){
  int b[n];
  for(int i=0;i<n;i++){
    b[i]=1;              
  }
  int i=0,j=0;
  int count=0;           
  while(1){
    if(b[i]!=0)   j++;
    if(j==m)  {
      count++;
      out[i]=count;
      b[i]=0;
      j=0;
    }
    i++;
    if(i>n)  i=0;
    if(count==n)  break;
  }
}
int main()
{
  int n,m;
  scanf("%d %d",&n,&m);
  int out[n];
  CountOff(n,m,out);
  for(int i=0;i<n;i++){
    printf("%d",out[i]);
    if(i<n-1)  printf(" ");
  }
  return 0;
}