#include<stdio.h>
#include<math.h>
int main() {
	int x1, y1, x2, y2, x3, y3;
	double a, b, c,pot;
	double Area, s,s1;
	scanf ("%d %d %d %d %d %d", &x1,&y1,&x2,&y2,&x3,&y3);
	pot = ((double)x2 - (double)x1)*((double)x2 - (double)x1) + ((double)y1 - (double)y2)*((double)y1 - (double)y2);
	a = sqrt(pot);
	b = sqrt(pow(((double)x2 - (double)x3),2)+ pow(((double)y2 - (double)y3),2));
	c = sqrt(pow(((double)x3 - (double)x1),2) + pow(((double)y1 - (double)y3),2));
	s = (a + b + c);
	s1 = s / 2;
	if ((a + b) > c && (a + c) > b && (b + c) > a) {
		Area = sqrt(s * (s - a) * (s - b) * (s - c));
		printf("%.2lf %.2lf", s, Area);
	}
	else {
		printf("Impossible");
	}
	return 0;
}