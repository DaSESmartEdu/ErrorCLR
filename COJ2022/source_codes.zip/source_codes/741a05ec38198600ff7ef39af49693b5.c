#include<stdio.h>
int main()
{
    int i,n,rest=1,peach=0;
    scanf("%d",&n);
    for(i=1;i<n;i++)
    {
    peach=(rest+1)*2;
    rest=peach;
    }
    printf("%d",peach);
    return 0;
}