#include <stdio.h>
int main()
{
	int sum = 0;
	int x = 2;
	for(;x>0;){
		scanf("%d",&x);
		if(x%2!=0)
			sum += x;
	}
	printf("%d",sum);
	return 0;
}