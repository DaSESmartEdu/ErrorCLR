#include <stdio.h>
int main()
{
    double s,t;
    scanf("%lf %lf",&s,&t);
    float sum=0;
    if(s<=3.0)
    {
        sum=10+((int)(t/5))*2.0;
    }
    else if(s>3.0&&s<=10.0)
    {
        sum=10+(s-3)*2.0+((int)(t/5))*2.0;
    }
    else{
        sum=24+(s-10)*3.0+((int)(t/5))*2.0;
    }
    printf("%d",sum+0.5);
    return 0;
}