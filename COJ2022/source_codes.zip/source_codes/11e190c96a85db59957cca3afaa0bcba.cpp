#include<bits/stdc++.h>
using namespace std;
const int MAXN = 20000;
int parent[MAXN];
int Rank[MAXN];
int N, M;
void make_Set()
{
    for(int i=1;i<=N;i++)
    {
        parent[i]=i;
        Rank[i]=0;
    }
}
int find_Set(int x)
{
    if(parent[x]!=x)
    {
        parent[x]=find_Set(parent[x]);
    }
    return parent[x];
}
int link(int x,int y)
{
    if(Rank[x]>Rank[y]) 
    {
        parent[y]=x; 
    }
    else
    {
        parent[x]=y; 
        if(Rank[x]==Rank[y]) 
        {
            Rank[y]++;
        }
    }
}
void Union(int x,int y)
{
    link(find_Set(x),find_Set(y));
}
int main()
{
    while(scanf("%d %d",&N,&M))
    {
        if(N==0)
        {
            break;
        }
        make_Set();
        for(int i=0;i<M;i++)
        {
            int a,b;
            cin>>a>>b;
            Union(a,b);
        }
        int road=-1;
        for(int i=1;i<=N;i++)
        {
            if(parent[i]==i)
            {
                road++;
            }
        }
        cout<<road<<endl;
    }
    return 0;
}