#include <stdio.h>
#include <string.h>
int main()
{
    char b[27]={0},a[1000];
    int count=0;
    gets(a);
    for(int i=0;i<strlen(a);i++){
        b[a[i]-'a']++;
    }
    for(int i=0;i<strlen(a);i++){
    if(b[1]%2==1)
    count++;
    }
    if(count<=1) printf("1");
    else printf("0");   
	return 0;
}