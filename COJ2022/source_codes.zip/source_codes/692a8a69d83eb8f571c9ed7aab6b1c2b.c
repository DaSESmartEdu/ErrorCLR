#include <stdio.h>
#include <string.h>
int zimu = 0;
int space = 0;
int digit = 0;
int other = 0;
int main()
{
    char c;
    while((c == getchar()) != EOF)
    {
        if('A'<=c && c<='Z' || 'a' <= c && c <= 'z')
            zimu++;
        else if('0'<=c && c <='9')
            digit++;
        else if (c == ' ' || c == '\n')
            space++;
        else
            other++;
    }
    printf("%d %d %d %d\n", zimu, space, digit, other);
    return 0;
}