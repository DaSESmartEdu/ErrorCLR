#include<stdio.h>
#include<math.h>
int main()
{
	double x;
	scanf("%lf",&x);
	double m;
	if(x>=0)
	{
		m=sqrt(x);
		printf("f(%.2lf) = %.2lf",x,m);
	}else{
		m=pow(x+1,2)+2*x+1/x;
		printf("f(%.2lf) = %.2lf",x,m);
	}
	return 0;
}