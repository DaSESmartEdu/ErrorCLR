#include <stdio.h>
int main()
{
    int n;
    int t=0;
    int k=0;
    double a[n];
    char K;
    scanf("%d",&n);
    while(t<=n-1){
        scanf("%lf",&a[t]);
        t++;
    }
    while(k<=n-1){
        if(a[k]>=90){
            K='A';
            printf("%c",K );
        }
        else if(a[k]>=80){
        K='B';
        printf("%c",K );
        }
        else if(a[k]>=70){
        K='C';
        printf("%c",K );
        }
        else if(a[k]>=60){
        K='D';
        printf("%c",K);
        }
        else{ 
        K='E';
        printf("%c",K);
        }
        if(k<4){
            K=' ';
            printf("%c",K);
        }
        k++;
    }
    return 0;
    }