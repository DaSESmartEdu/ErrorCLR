#include<stdio.h>
void time(int a,int b,int c,int d){
    c+=d;
    if(c>=60){
		int c1=c;
        c=c%60;
        b=b+(c1-c)/60;
    }if(b>=60){
		int b1=b;
        b=b%60;
        a=a+(b1-b)/60;
    }if(a>=24){
        a-=24;}
        printf("%.2d:%.2d:%.2d",a,b,c);
}
int main(){    
	int a,b,c,d;
    scanf("%d:%d:%d",&a,&b,&c);
	getchar();
    scanf("%d",&d);
    time(a,b,c,d);
    return 0;
}