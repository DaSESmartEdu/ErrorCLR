#include <stdio.h>
int main ()
{
    int N,i;
    double max,min;
    int a[N];
    int sum;
    sum = 0;
    max = 0;
    min = 100;
    scanf("%d\n",&N);
    for (i=1;i<=N;i++)
    {
        scanf("%d",&a[i]);
        sum=sum+a[i];
        if (a[i]>=max)
        {
            max=a[i];
        }
        if (a[i]<=min)
        {
            min=a[i];
        }
    }
    double average;
    average=(double) sum / N;
    printf("average = %.2lf\nmax = %.2lf\nmin=%.2lf",average,max,min);
    return 0;
}