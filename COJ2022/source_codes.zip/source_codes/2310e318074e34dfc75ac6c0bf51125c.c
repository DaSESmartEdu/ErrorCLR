#include <stdio.h>
int main(void)
{	
    int a, b, c, d, e;
    float f;
    scanf("%d%d%d%d", &a, &b, &c, &d);
    e = a + b + c + d;
    f = e/4.0;
    printf("%d, %.1f\n", e, f);
    return 0;
}