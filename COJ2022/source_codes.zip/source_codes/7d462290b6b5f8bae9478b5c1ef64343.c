#include<stdio.h>
#include<math.h>
int main()
{int n,i;
 double x;
 scanf("%d",n);
 for(i=1;i<=n;i++){x+=sqrt(i);}
 printf("%.2f",x);
	return 0;}