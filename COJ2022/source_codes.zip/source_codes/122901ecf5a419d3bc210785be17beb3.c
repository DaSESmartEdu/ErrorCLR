#include <stdio.h>
int main()
{
    int n=0;
    scanf("%d\n",&n);
    struct phone
    {
        char name[10];
        int b;
        char p[17];
    }man[n];
    int i=0;
    for(i=0;i<n;i++)
    {
        man[i].b=0;
    }
    for(i=0;i<n;i++)
    {
        scanf("%s %d %s\n",man[i].name,&man[i].b,man[i].p);
    };
    struct phone temp;
    for(i=0;i<(n-1);i++)
    {
        for(int k=(i+1);k<n;k++)
        {
            if(man[i].b>man[k].b)
            {
                temp=man[i];
                man[i]=man[k];
                man[k]=temp;
            }
        }
    }
     for(i=0;i<n;i++)
    {
        printf("%s %d %s\n",man[i].name,man[i].b,man[i].p);
    };
}