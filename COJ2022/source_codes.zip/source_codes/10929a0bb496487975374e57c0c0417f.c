#include<stdio.h>
int main()
{ int a[10000];
  int k=0;
 for(int i=0;i<10000;i++)
 {
	 scanf("%d",&a[i]);
	 if(a[i]<=0)
	 { 
	  k=i;
	  break;
	 }
 }
 int sum=0;
 for(int i=0;i<k;i++)
 {
	 if(a[i]%2==1)
	 {sum+=a[i];}
 }
 printf("%d",sum);
 return 0;	
}