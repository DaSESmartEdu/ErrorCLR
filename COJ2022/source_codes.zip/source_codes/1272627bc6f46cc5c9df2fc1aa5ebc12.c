#include <string.h>
#include <stdio.h>
#include <math.h>
int main()
{
    int n,m;
    scanf("%d %d", &n,&m);
    int t[n], c[n];
    for (int i = 0; i < n; i++){
        scanf("%d %d", &t[i],&c[i]);
    }
    int a[m];
    for (int i = 0; i < m;i++){
        scanf("%d", &a[i]);
    }
    int flag = 1;
    for (int i = 0; i < m;i++){
        flag = 1;
        for (int j = 0; j < n;j++){
            if(i == t[j]-1){
                for (int k = 0; k < c[j];k++){
                    printf("%d ", a[i]);
                    flag = 0;
                }
            }
        }
        if(flag){
            printf("%d ", a[i]);
        }
    }
    return 0;
}