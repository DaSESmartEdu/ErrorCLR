#include<stdio.h>
int main()
{
	int n,m;
	scanf("%d %d",&n,&m);
	double a=(double)n/m;
	if(a<1.1*m){
		printf("normal");
	}
	else if(a>=1.5*m){
		printf("revoke");
	}
	else{
		printf("200");
	}
	return 0;
}