#include<stdio.h>
#include<math.h>
#include<string.h>
struct xigua{
    char s[20];
    double jiage;
    double zhiliang;
};
int main(){
    int n,i;
    scanf("%d\n",&n);
    struct xigua gua[n];
    for(i=0;i<n;i++){
        scanf("%s %lf %lf\n",gua[i].s,&gua[i].jiage,&gua[i].zhiliang);
    }
    double a[n];
    for(i=0;i<n;i++){
        a[i]=1.0*gua[i].jiage/gua[i].zhiliang;
    }
    double max=0;
    int count=0;
    for(i=0;i<n;i++){
        if(a[i]-max>1e-4){
            max=a[i];
        }
    }
    for(i=0;i<n;i++){
        if(fabs(a[i]-max)<=1e-4){
            count++;
        }
    }
    struct xigua b[count];
    if(count==1){
        for(i=0;i<n;i++){
            if(fabs(a[i]-max)<=1e-4){
                printf("%s",gua[i].s);
            }
        }
    }
    else{
        int m=0;
        struct xigua zhongjian;
        for(i=0;i<n;i++){
            if(fabs(a[i]-max)<=1e-4){
                b[m]=gua[i];
                m++;
            }
        }
        for(i=0;i<count-1;i++){
            for(int j=0;j<count-1-i;j++){
                if(strcmp(b[j].s,b[j+1].s)>0){
                    zhongjian=b[j];
                    b[j]=b[j+1];
                    b[j+1]=zhongjian;
                }
            }
        }
        for(i=0;i<count;i++){
            printf("%s",b[i].s);
            if(i!=count-1){
                printf(" ");
            }
        }
    }
}