#include <stdio.h>
int wanshu(int p);
int main(void)
{
	int m, n;
	scanf("%d%d", &m, &n);
	int cnt = 0;
	for (int i = m; i <= n ; i++)
	{
		if (wanshu(i)) 
		{
			cnt++;
		}
		else continue;
	}
	if (cnt != 0) printf("%d", cnt);
	else if (cnt == 0) printf("No perfect number");
	return 0;
}
int wanshu(int p)
{
	int item = 0;
	int sum = 0;
	int out = 0;
	for (int i = 1; i < p; i++)
	{
		if (p % i == 0) item = i;
		else item = 0;
		sum += item;
	}
	if (sum == p || p == 1) out = 1;
    if (out == 1) printf("%d\n", p);
	return out;
}