#include <stdio.h>
int main()
{
    int year,mon,day,count=0;
    scanf("%d %d %d",&year,&mon,&day);
    int q1=year%4,q2=year%400;
    int Feb,MON=31;
    if(q1==0 && q2!=0){
        Feb=29;
    }else{
        Feb=28;
    }
    int i=1,a=1;
    if(mon==1){
        count=day;
    }else if(mon<=7){
        while(i<mon){
            if(i==2){
                count+=Feb;
            }else{
                count+=MON;
            }
            i++;
            a*=-1;
            MON+=a;
        }
        count+=day;
    }else{
        count=4*31+2*30+Feb;
        i=8;
        while(i<mon){
            count+=MON;
            i++;
            a*=-1;
            MON+=a;
        }
        count+=day;
    }
    printf("%d",count);
    return 0;
}