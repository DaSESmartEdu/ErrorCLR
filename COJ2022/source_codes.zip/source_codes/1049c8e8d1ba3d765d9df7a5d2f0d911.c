#include <stdio.h>
#include <math.h>
int reverse(int n)
{   int t=n,sum=0;
    n=fabs(n);
    int i=0,a[100];
    while(n>0)
    {    
        a[i]=n%10;
        n=n/10;
        i++;
    }
         for (int j=0;j<i;j++)  
         sum+=a[j]*pow(10,i-j-1);
    if (t>0)
    printf("%d\n",sum);
    else
    printf("%d\n",-sum);    
}
int main()
 {  
    int n;
    scanf("%d",&n);
    reverse(n);
    return 0;
 }