#include <stdio.h>
int main ()
{
	int m,n,j,i;
	int y;
	scanf("%d %d",&m,&n);
	for (j=1;j<=n;j=j+1)
	{
	if((m%j==0)&&(n%j==0))
	y=j;
	}
	printf("%d",y);
	for(i=2;i<=m;i=i+1)
	{
	int a=i*n;
	if(a%m==0)
	{printf("%d",a);
	break;}
	}
	return 0;
}