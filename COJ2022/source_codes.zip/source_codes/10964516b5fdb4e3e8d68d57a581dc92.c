#include <stdio.h>
int main()
{
float Ave,e;
int a,b,c,d;
scanf("%d %d %d %d",&a,&b,&c,&d);
e=a+b+c+d;
Ave=e/4.0;
printf("%f %.1f",e,Ave);
return 0;
}