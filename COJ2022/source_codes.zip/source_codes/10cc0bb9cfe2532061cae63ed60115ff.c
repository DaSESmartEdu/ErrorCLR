#include <stdio.h>
int main()
{
    int a,b,c,i,j,k;
    scanf("%d %d %d",&a,&b,&c);
    if(a>b)
    {
        i=b;
        b=a;
        a=i;
    }
    if(a>c)
    {
        j=c;
        c=a;
        a=j;
    }
    if(b>c){
        k=c;
        c=b;
        b=k;
    }
    printf("%d %d %d",a,b,c);
    return 0;
}