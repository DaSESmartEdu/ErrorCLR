#include<stdio.h>
char setgrade(int i)
{
    if(i>=85){
        return'A';
    }else if(i>=70&&i<=84){
        return'B';
    }else if(i>=60&&i<=69){
        return'C';
    }else{
        return 'D';
    }
}
int main()
{
    int n;
    scanf("%d",&n);
    typedef struct{
        int number[10];
        char name[20];
        int score;
        char grade;
    }information;
    information a[n];
    char ch;
    scanf("%c",&ch);
    int e=0;
    for(int j=0;j<n;j++){
        scanf("%s %s %d",&a[j].number,&a[j].name,&a[j].score);
        a[j].grade=setgrade(a[j].score);
        if(a[j].grade=='D'){
            e++;
        }
    }
    printf("The count for failed (<60): %d\n",e);
    printf("The grades:\n");
    for(int w=0;w<n;w++){
        printf("%s %s %c\n",a[w].number,a[w].name,a[w].grade);
    }
    return 0;
}