#include <stdio.h>
int main(){
	int m,n;
	scanf("%d %d",&m,&n);
	int a[m][n],sum[m];
	int i,j;
	for(i=0;i<m;i++){
		for(j=0;j<n;j++){
			scanf("%d",&a[i][j]);
		}
	}
	for(i=0;i<m;i++){
		sum[i]=0;
		for(j=0;j<n;j++){
			sum[i]=sum[i]+a[i][j];
		}
 }
	for(i=0;i<m;i++){
		if(i==0){
			printf("%d",sum[i]);
		}else{
			printf(" %d",sum[i]);
		}
	}
	return 0;
}