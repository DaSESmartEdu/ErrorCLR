#include <stdio.h>
int main()
{
    int input = 0;
    int num;
    num = 0;
    scanf("%d", &input);
    while(input / 5 > 0)
    {
        input = input - 5;
        if (input%2 == 0)
        {
            num = num + (input / 2) - 1;
        }
        else
        {
            num = num + input / 2;
        }
    }
    printf("%d", num);
    return 0;
}