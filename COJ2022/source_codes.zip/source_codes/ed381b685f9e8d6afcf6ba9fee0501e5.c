#include <stdio.h>
int main()
{
    int a,i,n;
	a=1;
    scanf("%d",&n);
    while(i<n)
    {
      a=2*(a+1);
      i=i+1;
    }
    printf("%d",a);
	return 0;
}