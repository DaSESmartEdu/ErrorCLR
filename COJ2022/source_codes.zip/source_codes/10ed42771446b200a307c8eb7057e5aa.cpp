#include<bits/stdc++.h>
using namespace std;
int n,k;
int ju(int x,int y){
    return x * x + y * y;
}
int main(){
    cin >> n;
    pair<int, int> p[n];
    for (int i = 0; i < n;i++){
        cin >> p[i].first >> p[i].second;
    }
    for (int i = 0; i < n;i++){
        for (int j = 0; j < n;j++){
            if(ju(p[j].first,p[j].second) > ju(p[i].first,p[i].second)){
                swap(p[i], p[j]);
            }
        }
    }
    cin >> k;
    cout << p[k-1].first << " " << p[k-1].second << endl;
}