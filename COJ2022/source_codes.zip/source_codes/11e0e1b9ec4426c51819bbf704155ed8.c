#include <stdio.h>
int main()
{
    int n;
    scanf("%d",&n);
    int s[n][n];
    int i=0,j=0;
    while(i<n)
    {
        j=0;
        while(j<n)
        {
            scanf("%d",&s[i][j]);
            j++;
        }
        i++;
    }
    i=1,j=0;
    if(n==1)
    printf("NO");
    else
    {
        int x=0;
        while(i<n)
        {
            j=0;
            while(j<i)
            {
                if(s[i][j]!=0)
                {x=1;}
                j++;
            }
            i++;
        }
        if(x)
        {
            printf("NO");
        }
        else
        {
            printf("YES");
        }
    }
    return 0;
}