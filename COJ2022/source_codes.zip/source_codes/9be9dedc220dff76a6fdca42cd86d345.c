#include <stdio.h>
#include <math.h>
double fact(int n)
{
    int i=1,d=1;
    while(i<=n)
    {
        d=d*i;
        i++;
    }
    return d;
}
int main()
{
    double x,S=1.0,t=1.0;
    int n=1;
    scanf("%lf",&x);
    while(fabs(t)>=0.00001)
      {
        S+=pow(x,n)/fact(n);
        n++;
        t=pow(x,n)/fact(n);
      }
    printf("%.4f",S);
    return 0;
}