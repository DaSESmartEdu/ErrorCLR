#include <stdio.h>
#include <math.h>
int main()
{
    int n;
    int x, y;
    scanf("%d", &n);
    for(x = 1; x <= n; x++)
    {
        for(y = 1; y<= n; y++)
        {
            if(fabs(x - (n+1)/2) + fabs(y - (n+1)/2) < (n+1)/2)
            {   
                if (y == n)
                {
                    printf("*\n");
                }
                else
                {
                    printf("*");
                }
            }
            else
            {
                if (y == n)
                {
                    printf(" \n");
                }
                else
                {
                    printf(" ");
                }
            }
        }
    }
    return 0;
}