#include<stdio.h>
int A(int n){
    for(int i=1;i<n;i++){
        printf("sin(%d",i);
        if(i%2) printf("-");
        else printf("+");
    }
    printf("sin(%d",n);
    for(int i=0;i<n;i++){
        printf(")");
    }
    return 0;
}
int S(int n){
    for(int i=0;i<n;i++){
        printf("(");
    }
    for(int i=1;i<n;i++){
        A(i);
        printf("+%d)",n+1-i);
    }
    A(n);
    printf("+%d",1);
    return 0;
}
int main(){
  int n;scanf("%d",&n);
  S(n);
  return 0;
}