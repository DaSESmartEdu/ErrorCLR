#include<stdio.h>
int main()
{
    int n,s[10],a,p,max=0;
    scanf("%d",&n);
    int num[1000];
    for(int i=0;i<n;i++)
    {
        num[i]=0;
        scanf("%d",&num[i]);
    }
    for(int i=0;i<10;i++)
    {
        s[i]=0;
    }
    for(int i=0;i<=n;i++)
    {
        a=num[i];
        while(a!=0)
        {
            p=a%10;
            s[p]=s[p]+1;
            a=a/10;
        }
    }
    for(int i=0;i<10;i++)
    {
        if(max<s[i]) max=s[i];
    }
    int count=0;
    for(int i=0;i<10;i++)
    {
        if(s[i]==max) count=count+1;
    }
    int j=1;
    for(int i=0;i<10;i++)
    {
        if(s[i]==max) 
        {
            printf("%d",i);
            while(j<count)
            {
                printf(" ");
                break;
            }
            j++;
        }
    }
    return 0;
}