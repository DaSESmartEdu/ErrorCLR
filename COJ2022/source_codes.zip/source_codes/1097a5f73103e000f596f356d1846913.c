#include <stdio.h>
int main(){
    int a[200];
    int jishu[100];
    int oushu[100];
    int i;
    for(i=0;i<200;i++){
        scanf("%d",&a[i]);
        if(a[i]<0) break;
    }
    int j,t;
    j=t=0;
    for(i=0;a[i]>=0;i++){
        if(a[i]%2==0) {oushu[j]=a[i];j++;}
        if(a[i]%2==1) {jishu[t]=a[i];t++;}
    }
    oushu[j]=0;
    jishu[t]=0;
    for(i=0;jishu[i]>0;i++){
        printf("%d ",jishu[i]);
    }
    printf("\n");
    for(i=0;oushu[i]>0;i++){
        printf("%d ",oushu[i]);
    }return 0;}