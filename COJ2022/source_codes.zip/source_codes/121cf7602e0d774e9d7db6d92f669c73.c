#include <stdio.h>
#include <math.h>
int main()
{
   int n;
   int q=-1;
   double p,a,sum;
   scanf("%d",&n);
   sum=0;
   p=0;
   while (p<n)
   {
      p++;
      q+=2;
      a=pow(-1,p+1);
      sum+=a*p*1.0/q;
   }
   printf("%lf",sum);
}