#include <iostream>
using namespace std; 
class lifegame{
	public:
		int initx,inity;
		int life[8][8];
		int change[8][8];
		void initialize(void)
		{
			initx=6;
			inity=6;
					for (int i=0;i<=initx+1;i++)
				{
					for(int  j=0;j<=inity+1;j++)
					{
						life[i][j]=0;
						change[i][j]=0;
					}
				}
		}
		void print(void)
		{
			int i=1,j=1;
				for (i=1;i<=initx;i++)
				{
					for(j=1;j<=inity;j++)
					{
						if (i==initx&&j==inity)
						{
							cout<<change[i][j];
						}
						else
						{
							if(j==inity)
							{
								cout<<change[i][j]<<endl;
							}
							else
							{
								cout<<change[i][j]<<" ";
							}
						}
					}
				}
		}
		void update(void)
		{
				for (int i=1;i<=initx;i++)
			{
				for(int j=1;j<=inity;j++)
				{
					int sum=neighbourcount(i,j);
					switch (sum)
					{
						case 0:
							change[i][j]=0;
							break;
						case 2:
							if (life[i][j]==1)
                            {change[i][j]=1;}
							break;
						case 3:
							change[i][j]=1;
							break;
						case 4:
							change[i][j]=0;
							break;
						case 1:
							change[i][j]=0;
							break;
						case 5:
							change[i][j]=0;
							break;
						case 6:
							change[i][j]=0;
							break;
						case 7:
							change[i][j]=0;
							break;
						case 8:
							change[i][j]=0;
							break;
					}
				}
			}
		}
	private:
		int neighbourcount (int row,int col)
		{
			int sum=0;
			sum=sum-life[row][col];
			for (int i=row-1;i<=row+1;i++)
				{
					for (int j=col-1;j<=col+1;j++)
					{
						sum+=life[i][j];
					}
				}
				return sum;
		}
};
int main()
{
	lifegame G1;
	G1.initialize();
	int chgx=0,chgy=0;
	cin>>chgx>>chgy;
		while (chgx!=-1&&chgy!=-1)
			{
				G1.life[chgx][chgy]=1;
				cin>>chgx>>chgy;
			}
		G1.update();
		G1.print();
		return 0;
}