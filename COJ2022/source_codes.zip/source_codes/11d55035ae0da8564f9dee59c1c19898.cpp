#include<stdio.h>
#include<string.h>
int getN(char s)
{
     return s-48;
}
char a[101];
char b[101];
int c[101];
int main()
{
     memset(c,0,sizeof(c));
     scanf("%s",a);
     scanf("%s",b);
     int i,j,k=0,s=0;
     for(i=strlen(a)-1,j=strlen(b)-1;i>=0||j>=0;i--,j--)
     {
         if(i>=0&&j>=0)
         {
             c[k++]=(getN(a[i])+getN(b[j])+s)%10;
             s=(getN(a[i])+getN(b[j])+s)/10;
             if(i==0&&j==0&s>0)
             {
                 c[k++]=s;
             }
         }else if(i>=0){
             c[k++]=(getN(a[i])+s)%10;
             s=(getN(a[i])+s)/10;
             if(i==0&&s>0)
             {
                 c[k++]=s;
             }
         }else if(j>=0){
             c[k++]=(getN(b[j])+s)%10;
             s=(getN(b[j])+s)/10;
             if(j==0&s>0)
             {
                 c[k++]=s;
             }
         }
     }
     for(i=k-1;i>=0;i--)
     {
         printf("%d",c[i]);
     }
     printf("\n");
     return 0;
}