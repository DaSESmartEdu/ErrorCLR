#include <stdio.h>
int main()
{
    char a[1000];
    int i;
    int x=0;
    int y=0;
    for(i=0;i<100;i++){
        a[i]=getchar();
    }
    for(i=0;a[i]!=EOF;i++){
        if(a[i]>='A'&&a[i]<='Z'){
            x++;
        }
    }
    for(i=0;a[i]!=EOF;i++){
        if(a[i]=='A'||a[i]=='E'||a[i]=='U'||a[i]=='I'||a[i]=='O'){
            y++;
        }
    }
    printf("%d",x-y);
    return 0;
}