#include <iostream>
using namespace std;
struct point{
    int key;
    int x;
    int y;
};
void qksort(point r[],int h,int t){
    int i,j,k;
    point x;
    if(h>=t){
        return;
    }
    i=h;
    j=t;
    x=r[i];
    while(i<j){
        while((i<j)&&(r[j].key>=x.key)){
            j--;
        }
        if(i<j){
            r[i]=r[j];
            i++;
        }
        while((i<j)&&(r[i].key<=x.key)){
            i++;
        }
        if(i<j){
            r[j]=r[i];
            j--;
        }
    }
    r[i]=x;
    qksort(r,h,j-1);
    qksort(r,j+1,t);
}
int main(){
    int n;
    cin>>n;    
    point r[100]={0};
    for(int i=0;i<n;i++){
        cin>>r[i].x>>r[i].y;
    }
    int k;
    cin>>k;
    for(int i=0;i<n;i++){
        r[i].key=(r[i].x)*(r[i].x)+(r[i].x)*(r[i].y);
    }
    qksort(r,0,n-1);
    for(int i=0;i<n;i++){
        if(i==k-1){
            cout<<r[i].x<<' '<<r[i].y;
        }
    }
}