#include <stdio.h>
#include <math.h>
int fact(int x);
int main()
{
    int m,n;
	scanf("%d %d",&m,&n);
	int min=m,max=n;
	int a=0;
	for(int k=min;k<=max;k++)
	{
		if(fact(k)==k)
		{
			printf("%d ",k);
		}
	}
    return 0;
}
int fact(int x)  
{
    int y;
    y=x;
    int n=1;
    while(x/10>=1)
    {
        x=x/10;
        n=n+1;
    }
    int i;
    int k;
    int shuixian=0 ;
    for (i=n;i>=1;i--)
    {
        k=pow(10,i-1);
        shuixian = shuixian + pow(y/k,n);
        y=y%k;
    }
    return shuixian;
}