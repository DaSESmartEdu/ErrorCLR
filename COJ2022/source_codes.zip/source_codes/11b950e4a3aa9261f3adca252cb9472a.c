#include <stdio.h>
#include <math.h>
double pow(double x,double y);
int main()
{
    int n,s,a,b;
    scanf("%d",&n);
    a=pow(2,n);
    b=pow(2,n+1);
    s=(a+b-2)/2-2;
    printf("%d",s);
    return 0;
}