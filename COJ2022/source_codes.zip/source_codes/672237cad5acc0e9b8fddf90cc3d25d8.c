#include<stdio.h>
int main()
{int a,b;
int c=200;
scanf("%d %d",&a,&b);
if(a<1.1*b){
printf("normal");}
else if(a>=1.1*b&&a<1.5*b){
    printf("%d",c);
}
else if(a>=1.5*b){
    printf("revoke");
}
return 0;
}