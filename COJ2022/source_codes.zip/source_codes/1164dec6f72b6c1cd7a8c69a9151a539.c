#include<stdio.h>
#include<math.h>
int search(int n);
int main(){
	int n,i,res;
	scanf("%d",&n);
	printf("%d",search(n));
	return 0;
}
int search(int n){
	int i,j,count=0;
	int k,p,l;
	for(i=101;i<=n;i++){
		k=i%10;
		p=i/10%10;
		l=i/100;
		if(k==p||k==l||p==l){
			int t=sqrt(i);
			if(t*t==i){
				count++;
			}
		}
	}
	return count;
}