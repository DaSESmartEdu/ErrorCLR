#include <stdio.h>
int main(void)
{
    int n, max=0, min=0, imax, jmax, flag = 0;
    scanf("%d", &n);
    int numbers[n][n];
    for(int i=0;i<n;i++)
    {
        for(int j=0;j<n;j++)
        {
            scanf("%d",&numbers[i][j]);
        }
    }
    for(int i=0;i<n;i++)
    {
        for(int j=0;j<n;j++)
        {
			max=0;
            if(numbers[i][j]>max)
            {
                max = numbers[i][j];
                imax = i;
                jmax = j;
            }
        }
        flag = 1;
        for(int k=0;k<n;k++)
        {
            if(numbers[k][jmax]<max)
            {
                flag = 0;
                break;
            }
        }
        if(flag)
            break;
    }
    if(flag)
        printf("%d %d", imax, jmax);
    else
        printf("NO");
}