#include <stdio.h>
double fact(int n){
    if(n==0||n==1){
        return 1;
    }
    return n*fact(n-1);
}
double factsum(int n){
    if(n==0){
        return 1;
    }
    else{
    int i=0;
    int sum=0;
    for(i=n;i>0;i--){
        sum+=fact(i);
    }
    return sum;
    }
}
int main(){
    int n;
    scanf("%d",&n);
    double x=0;
    double y=0;
    y=fact(n);
    x=factsum(n);
    printf("%.0f\n%.0f",y,x);
}