#include<stdio.h>
#include<math.h>
int fn(int a,int n);
int SumA(int a,int n);
int main(void)
{
    int a,n;
    scanf("%d %d",&a,&n);
    int i;
    i=1;
    printf("%d",SumA(a,n));
}
int fn(a,n)
{
    int y;
    y=a;
    int k;
    for(k=0;k<n;k++){
        y=pow(10,k+1)*a+y;
    }
    return y;
}
int SumA(a,n)
{
    int y2=0;
    int k2;
    for(k2=0;k2<n;k2++){
        y2=y2+fn(a,k2);
    }
    return y2;
}