#include<stdio.h>
int main()
{
    int n,i;
    double a=2,b=1,c,d;
    scanf("%d",&n);
    for ( i = 0; i < n; i++)
    {
        c+=a/b;
        d=a+b;
        b=a;
        a=d;
    }
    printf("%.2f",c);
    return 0;
}