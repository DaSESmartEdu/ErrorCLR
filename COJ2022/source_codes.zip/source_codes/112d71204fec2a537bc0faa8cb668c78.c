#include <stdio.h> 
#include <string.h>
#include <stdlib.h>
#include <stdbool.h>
#include <math.h>
int new(int n)
{
	if(n==1) return 1;
	if(n==2)return 0;
	if(n<10)
	{
		return new(n-1)+new(n-2);
	}
	return new(n-1)+new(n-2)-new(n-9);
}
int rab(int n)
{
	if(n<=2) return 1;
	if(n<10)
	{
		return (rab(n-1)-new(n-1))*2+new(n-1);
	}
	return (rab(n-1)-new(n-1)-new(n-9))*2+new(n-1);
}
int main()
{
	int n;
	scanf("%d",&n);
	printf("%d",rab(n));
}