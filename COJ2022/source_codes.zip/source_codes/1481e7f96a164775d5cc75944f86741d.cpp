#include <iostream>
#include <vector>
#include <algorithm> 
using namespace std;
int main()
{
    int num, temp, sum = 0;
    cin >> num;
    vector<int> data;
    for (int i = 0; i < num; i++)
    {
        cin >> temp;
        data.push_back(temp);
    }
    sort(data.begin(), data.end());
    while (data.size() >= 2)
    {
        sum = sum + data[0] + data[1];
        data.push_back(data[0] + data[1]);
        data.erase(data.begin());
        data.erase(data.begin());
    }
    cout << sum;
}