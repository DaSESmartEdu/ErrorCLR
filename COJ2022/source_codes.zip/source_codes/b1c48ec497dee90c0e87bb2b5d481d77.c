#include <stdio.h>
int main()
{
    int n, m, i;
    scanf("%d\n", &n);
    int a[n];
    for(i=0;i<n;i++)
    {
        {scanf("%d\n", &a[i]);}
    }
    scanf("%d\n", &m);
    int x[m], y[m];
    for(i=0;i<m;i++)
    {scanf("%d %d", &x[i], &y[i]);}
    for(i=0;i<m;i++)
    {
        if(x[i]==0&&a[y[i]-1]>0) {printf("There are %d books of kind %d,success!\n", a[y[i]-1], y[i]);a[y[i]-1]--;}
        else if(x[i]==0&&a[y[i]-1]==0) {printf("There is no book of kind %d,sorry!\n", y[i]);}
        else if(x[i]==1){printf("Success!There are %d books of kind %d now.\n", a[y[i]-1], y[i]);a[y[i]-1]++;}
    }
    return 0;
}