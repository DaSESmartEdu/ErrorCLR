#include<stdio.h>
#include<math.h>
int main()
{
    int n,a,sum=0,c,b,i;
    scanf("%d",&n);
    int m=n;
    for(i=pow(10,n-1);i<pow(10,n);i++)
    {
        sum=0;
        c=i;
        while(c)
        {
            m=n;
            b=a=c%10;
            c/=10;
            while(--m)
            {
                a*=b;
            }
            sum+=a;
        }
        if(sum==i)
            printf("%d ",sum);
    }
    return 0;
}