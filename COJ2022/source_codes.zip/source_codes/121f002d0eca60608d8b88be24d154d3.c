#include<stdio.h>
#include<string.h>
int main(void)
{
    char *str[101], str1[101], *t;
    int i=0, j=0, min;
    gets(str1);
    str[0]=strtok(str1, " ");
    while(str[i])
    {
        i++;
        str[i]=strtok(NULL, " ");
    }
    printf("After sorted:\n");
    for(int m=0; m<i-1; m++)
    {
        min = m;
        for(int n=m+1; n<i; n++)
        {
            if(strcmp(str[min], str[n])>0)
            {
                min = n;
            }
        }
        if(min!=m)
        {
            t=str[m];
            str[m]=str[min];
            str[min]=t;
        }
    }
    for(int m=0; m<i; m++)
    {
        printf("%s\n", str[m]);
    }
}