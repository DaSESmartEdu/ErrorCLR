#include<iostream>
using namespace std;
int main(){
	int can_b = 0;
	int b_c = 0;
	int baby = 1;
	int a;
	cin>>a;
	int month = 0;
	int sum = 1;
	int bab=0,b_=0,can_=0;
	while(sum<a)
	{
		bab = can_b+b_c;
		b_ = baby;
		can_ = can_b +b_c ;
		sum = bab + b_ + can_;
		baby = bab;
		b_c = b_;
		can_b = can_;
		month+=1;
	}
	cout<<month;
}