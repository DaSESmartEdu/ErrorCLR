#include<stdio.h>
int main()
{
    int i,x1,x2,x,n,a,b,c,d;
    scanf("%d",&n);
    x1=1;
    x2=1;
    for(i=2;i<n;i++){
        x=x1+x2;
        x1=x2;
        x2=x;
    }
    a=x1;
    b=x2;
     c=a*b;
    while(d=a%b){
        a=b;
        b=d;
    }
    c=c/b;
    printf("%d %d",b,c);
    return 0;
}