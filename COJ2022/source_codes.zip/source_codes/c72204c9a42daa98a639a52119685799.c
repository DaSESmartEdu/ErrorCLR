#include<stdio.h>
int main()
{
    int n=0,month=3,i=2,t=1,m=2;
     scanf("%d",&n);
     if(n==1) {month=1;}
     else if(n>3)
     {
      for(m=3;m<=n;month++)
      {
       t=i;i=m;m+=t;
      } 
     }
     else  month=n+1;
     printf("%d\n",month);
     return 0;
}