#include <stdio.h>
int main()
{
    int m,n;
    scanf("%d %d",&m,&n);
    int a[m][n];
    int i,j;
    for(i=0;i<m;i++)
    {
        for(j=0;j<n;j++)
        {
            scanf("%d",&a[i][j]);
        }
    }
    int p=0,q=0,c=0,b=0;
    while(c<=m-1||b<=n-1)
    {
        for (p=c;p<m;p++)
        {
            printf("%d ",a[p][q]);
        }
        if(b==n-1)
        {
            break;
        }
        for (q=b+1;q<n;q++)
        {
            printf("%d ",a[p-1][q]);
        }
        if(c==m-1)
        {
            break;
        }
        for (p=m-2;p>=c;p--)
        {
            printf("%d ",a[p][q-1]);
        }
        for (q=n-2;q>=b+1;q--)
        {
            printf("%d ",a[p+1][q]);
        }
        m--;
        n--;
        c++;
        b++;
        q=b;
    }
    return 0;
}