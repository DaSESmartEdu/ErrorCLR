#include <stdio.h>
#include <stdlib.h>
char *match(char *r,char ch1,char ch2);
int main()
{
    char r[10000];
    fgets(r,10000,stdin);
    char c,c0;
    scanf("%c %c",&c,&c0);
    printf("\n%s",match(r,c,c0));
}
char *match(char *r,char c,char c0){
    int t=0;
    while(*(r+t)!=c&&*(r+t)!='\n'){
        t++;
    }
    int k=t;
    while(*(r+k)!=c0&&*(r+k)!='\n'){
        if(*(r+k)!='\n'){
        printf("%c",*(r+k));
        }
        k++;
    }
    if(*(r+k)!='\n'){
        printf("%c",*(r+k));
        }
    return r+t;
}