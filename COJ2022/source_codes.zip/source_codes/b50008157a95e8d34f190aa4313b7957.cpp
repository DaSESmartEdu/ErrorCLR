#include <iostream>
using namespace std;
void heapSort(int arr[], int list[], int n);
void heapify(int arr[], int list[], int index, int size);
void swap(int arr[], int list[], int i, int j);
void heapInsert(int arr[], int list[], int n);
void traverse(int arr[], int list[], int n);
int main()
{
    int n;
    cin>>n;
    int arr[n];
    int list[n];
    for(int i=0; i<n; i++){
        cin>>arr[i]>>list[i];
    }
    heapSort(arr, list, n);
    traverse(arr, list, n);
    return 0;
}
void heapSort(int arr[], int list[], int n)
{
    heapInsert(arr, list, n);
    int size = n;
    while(size > 1){
        swap(arr, list, 0, size-1);
        size--;
        heapify(arr, list, 0, size);
    }
}
void heapInsert(int arr[], int list[], int n)
{
    for(int i=0; i<n; i++){
        int current_index = i;
        int father_index = (current_index - 1) / 2;
        while(arr[current_index] > arr[father_index]){
            swap(arr, list, current_index, father_index);
            current_index = father_index;
            father_index = (current_index - 1) / 2;
        }
        while(arr[current_index]==arr[father_index] && list[current_index]>list[father_index]){
            swap(arr, list, current_index, father_index);
            current_index = father_index;
            father_index = (current_index - 1) / 2;
        }
    }
}
void heapify(int arr[], int list[], int index, int size)
{
    int left = 2*index + 1;
    int right = 2*index + 2;
    while(left < size){
        int largest_index;
        if(((arr[left]<arr[right]) || (arr[left]==arr[right] && list[right]>list[left])) && right<size)
            largest_index = right;
        else 
            largest_index = left;
        if(arr[index] > arr[largest_index])
            break;
        swap(arr, list, index, largest_index);
        index = largest_index;
        left = 2*index + 1;
        right = 2*index + 2;
    }
}
void swap(int arr[], int list[], int i, int j)
{
    int temp1, temp2;
    temp1 = arr[i];
    arr[i] = arr[j];
    arr[j] = temp1;
    temp2 = list[i];
    list[i] = list[j];
    list[j] = temp2;
}
void traverse(int arr[], int list[], int n)
{
    for(int i=0; i<n-1; i++){
        cout<<'('<<arr[i]<<','<<list[i]<<')'<<endl;
    }
    cout<<'('<<arr[n-1]<<','<<list[n-1]<<')';
}