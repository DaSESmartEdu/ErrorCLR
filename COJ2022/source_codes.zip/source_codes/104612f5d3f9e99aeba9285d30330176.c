#include<stdio.h>
#include<stdlib.h>
#include<string.h>
int main()
{
int i,j=0,sign=0;
char str[10000];
gets(str);
if(str[0]!=' ')
{
sign=1;
}
for(i=0;i<strlen(str)-1;i++)
{
if(str[i]==' '&&str[i+1]!=' ')
{
sign++;
}
}
printf("%d\n",sign);
return 0;
}