#include <stdio.h>
#include <math.h>
int fact(int n)
{
    int a,fact=1;
    for(a=1;a<=n;a++)
    {
        fact*=a;
    }
    return fact;
}
int main()
{
    double x,sum=1.0;
    scanf("%lf",&x);
    int n;
    for (n=1;pow(x,n)/fact(n)>=0.00001;n++)
    {
        sum+=pow(x,n)/fact(n);
    }
    printf("%.4lf",sum);
    return 0;
}