#include <stdio.h>
int pow(int a,int b){
 int pow_res=1;
 for(int i=1;i<=b;i++){
  pow_res*=a;
 } 
 return pow_res;
} 
int main(){
 int n,cnt=0; 
 scanf("%d",&n);
 for(int i= pow(10,n-1);i<pow(10,n);i++){    
  int tmp=i;
  int num=0;
  while(tmp>0){
  num+=(pow(tmp%10,n));
  tmp/=10;
  } 
  if (num==i){
  cnt++;
  }
 }
 printf("%d",cnt);
 return 0;
}