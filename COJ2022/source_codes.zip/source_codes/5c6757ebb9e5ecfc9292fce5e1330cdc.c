#include <stdio.h>
#include <math.h>
int main()
{
    double height;
    int n;
    double result;
    scanf("%d %d",&height,&n);
    result=height/pow(2,n);
    printf("%.2lf",result);
    return 0;
}