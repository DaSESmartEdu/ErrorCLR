#include <stdlib.h>
#include <stdio.h>
struct ListNode{
    int data;
    struct ListNode *next;
};
struct ListNode *readlist(){
    struct ListNode *head,*tail,*p;
    head=tail=NULL;
    p=(struct ListNode*)malloc(sizeof(struct ListNode));
    scanf("%d",&p->data);
    while(p->data!=-1){
    p->next=NULL;
    if(head==NULL){
        head=p;
    }
    else{
        tail->next=p;
    }
    tail=p;
    p=(struct ListNode*)malloc(sizeof(struct ListNode));
    scanf("%d",&p->data);
    }
    return head;
}
struct ListNode *getodd(struct ListNode *L){
    struct ListNode *posNode,*posNodeFront,*p;
    posNode=(struct ListNode*)malloc(sizeof(struct ListNode));
    p=(struct ListNode*)malloc(sizeof(struct ListNode));
    posNode=posNodeFront=NULL;
    while(L!=NULL){
        if(L->data%2!=0){
            p->data=L->data;
            p->next=NULL;
            if(posNodeFront==NULL){
                posNodeFront=p;
            }
            else{
                posNode->next=p;
            }
            posNode=p;
            L=L->next;
            p=(struct ListNode*)malloc(sizeof(struct ListNode));
        }
        else{
            L=L->next;
        }
    }
    return posNodeFront;
}
struct ListNode *geteven(struct ListNode *L){
    struct ListNode *posNode,*posNodeFront,*p;
    posNode=(struct ListNode*)malloc(sizeof(struct ListNode));
    p=(struct ListNode*)malloc(sizeof(struct ListNode));
    posNode=posNodeFront=NULL;
    while(L!=NULL){
        if(L->data%2==0){
            p->data=L->data;
            p->next=NULL;
            if(posNodeFront==NULL){
                posNodeFront=p;
            }
            else{
                posNode->next=p;
            }
            posNode=p;
            L=L->next;
            p=(struct ListNode*)malloc(sizeof(struct ListNode));
        }
        else{
            L=L->next;
        }
    }
    return posNodeFront;
}
void printlist(struct ListNode* headNode){
    struct ListNode* pMove=headNode;
    while(pMove){
        printf("%d ",pMove->data);
        pMove=pMove->next;
    }
}
int main(){
    struct ListNode *list=readlist();
    struct ListNode *list1=getodd(list);
    printlist(list1);
    printf("\n");
    struct ListNode *list2=geteven(list);
    printlist(list2);
}