#include<bits/stdc++.h>
using namespace std;
int INF=0x7fffffff;
int Binary_Search(int *low,int r,int x){        
    int l=1,mid;
    while(l<=r){
        mid=(l+r)/2;
        if(low[mid]<x)
            l=mid+1;
        else
            r=mid-1;
    }
    return l;
}
int main(){
    int K,N,output;
    cin>>K;
    while(K--){
        cin>>N;
        int a[N+1],low[N+1];
        output=1;
        for(int i=1;i<=N;i++){
            cin>>a[i];
            low[i]=INF;
        }
        low[1]=a[1];
        for(int i=2;i<=N;i++)
            if(a[i]>low[output])         
                low[++output]=a[i];
            else                        
                low[Binary_Search(low,output,a[i])]=a[i];
        cout<<output<<" ";
    }
    return 0;
}