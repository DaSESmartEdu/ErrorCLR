#include <stdio.h>
#include <string.h>
int main()
{
    char a[100];
    int sum=1,i=0,j=0,len=0,count=0;
    scanf("%s",&a);
    len=strlen(a);
    for(i=0;i<len;i++){
        sum=1;
        if(a[i]!=0){
            for(j=i+1;j<len;j++){
                if(a[i]==a[j]){
                    a[j]=0;
                    sum++;
                }
            }
            if(sum%2==1) count++;
        }
    }
    if(count>1) printf("0");
    else printf("1");
    return 0;
}