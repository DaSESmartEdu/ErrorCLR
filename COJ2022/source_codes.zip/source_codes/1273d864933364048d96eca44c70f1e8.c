#include<stdio.h>
#include<stdbool.h>
bool palindrome( char *s )
{
    int index;
    for(index=0; s[index]!='\0' ; index++)
        continue;
    for(int i=0,j=index-1; i<j;i++, j--)
    {
        if(s[i]!=s[j])
        {
            return false;
        }
    }
    return true;
}
int main(void)
{
    char str[101];
    gets(str);
    if(palindrome(str))
        printf("Yes");
    else
        printf("No");
}