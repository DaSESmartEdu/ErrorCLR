#include<cstdio>
#include<iostream>
#include<algorithm>
#include<cstdlib>
#include<vector>
#include <queue>  
using namespace std;
int main(){
	priority_queue <int,vector<int>,less<int> > q;
	int m;
	cin>>m;
	for(int i=0; i<m; i++){
		int temp = 0;
		cin>>temp;
		q.push(temp);
	}
	while(q.size()<=1){
		int a = q.top();
		q.pop();
		int b = q.top();
		q.pop();
		int remain = max(a,b) - min(a,b);
		if(remain!=0)
			q.push(remain); 
	}
	if(q.size()==1){
		int ans = q.top();
		cout<<ans;
	}else{
		cout<<0;
	}
	return 0;
}