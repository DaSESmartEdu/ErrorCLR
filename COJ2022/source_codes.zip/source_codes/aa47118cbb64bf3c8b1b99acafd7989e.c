#include <stdio.h>
#include <string.h>
void strmcpy( char *t, int m, char *s );
int main()
{
    int m,i;
    scanf("%d\n",&m);
    char t[100],s[100];
    gets(t);
    strmcpy( t, m, s); 
    printf("%s",s);
    return 0;
}
void strmcpy( char *t, int m, char *s)
{
    int j=0;
    if(strlen(t)<m)
    {
        s='\0';
    }
    else
    {
        while(t[m+j-1]!='\0')
        {
            s[j]=t[m+j-1];
            j++;
        }
        s[j]='\0';
    }
}