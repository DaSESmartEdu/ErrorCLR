#include<stdio.h>
int main()
{
    double m,n,t;
    scanf("%lf%lf",&m,&n);
    t=m/n;
    if(t>=1.5)
    {
        printf('revoke');
    }
    else if(t>=1.1)
    {
        printf('200');
    }
    else
    {
        printf('normal');
    }
    return 0;
}