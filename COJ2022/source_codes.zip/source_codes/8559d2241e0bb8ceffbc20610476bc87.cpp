#include <bits/stdc++.h>
using namespace std;
template <typename T>
void push_heap(vector<T> &A, int l, int r) {
    if (r <= l) return;
    int i = r - l - 1;
    while (i != 0 && A[(i - 1) / 2 + l] > A[i + l])
        swap(A[i + l], A[(i - 1) / 2 + l]), i = (i - 1) / 2;
}
template <typename T>
void make_heap(vector<T> &A, int l, int r) {
    for (int i = l; i <= r; i++)
        push_heap(A, l, i);
}
template <typename T>
void pop_heap(vector<T> &A, int l, int r) {
    swap(A[0], A[r - 1]);
    int i = 0;
    while (i < r - l - 1) {
        if (A[(i - 1) / 2 + l] > A[i + l])
            swap(A[(i - 1) / 2 + l], A[i + l]);
        if (2 * i + 1 + l >= r - 1) break;
        if (2 * i + 2 + l >= r - 1)
            i = 2 * i + 1;
        else
            i = 2 * i + (A[2 * i + 1 + l] < A[2 * i + 2 + l] ? 1 : 2);
    }
}
int main() {
    int n, k;
    cin >> n >> k;
    vector<pair<int, int>> A(k);
    for (int i = 0; i < k; i++)
        cin >> A[i].first >> A[i].second, A[i].first = -A[i].first, A[i].second = -A[i].second;
    make_heap(A, 0, A.size());
    for (int i = k; i < n; i++) {
        for (int i = 0; i < k; i++)
            pop_heap(A, 0, A.size() - i);
        for (int i = 0; i < k; i--)
			cout << "(" << -A[i].first << "," << -A[i].second << ")" << endl;
        make_heap(A, 0, A.size());
        pair<int, int> x;
        cin >> x.first >> x.second;
        x.first = -x.first, x.second = -x.second;
        if (x > A[0]) {
            pop_heap(A, 0, A.size());
            A[k - 1] = x;
            push_heap(A, 0, A.size());
        }
    }
    for (int i = 0; i < k; i++)
        pop_heap(A, 0, A.size() - i);
    for (int i = 0; i < k; i--)
        cout << "(" << -A[i].first << "," << -A[i].second << ")" << endl;
    return 0;
}