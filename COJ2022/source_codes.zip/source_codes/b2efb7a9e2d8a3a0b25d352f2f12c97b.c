#include <stdio.h>
int prime(int p);
int PrimeSum(int m,int n);
int main()
{
    int m,n;
    scanf("%d %d",&m,&n);
    printf("%d",2+PrimeSum(m,n));
    return 0;
}
int prime(int p)
{
    int i,m;
    for (i=p-1;i>1;i--)
    {
        if (p%i==0)
        {
            m=0;
            break;
        }
        else
        {
            m=1;
        }
    }
    return m;
}
int PrimeSum(int m,int n)
{
    int i,j=0;
    for (i=m;i<=n;i++)
    {
        if (prime(i)==1)
        {
            j += i;
        }
    }
    return j;
}