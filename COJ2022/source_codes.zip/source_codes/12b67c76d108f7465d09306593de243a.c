#include <stdio.h>
int min=0;
void jian(int a[11][11],int sum,int he,int x,int y,int n,int m,int time)
{
    if(a[x][y]<0)return;
    if(he==sum){
        if(time<min){
            min=time;
        }
        return ;
    }else if(he>sum){
        return ;
    }
    if(x+1<m){
        he+=a[x][y];
        a[x][y]*=-1;
        jian(a,sum,he,x+1,y,n,m,time+1);
        a[x][y]*=-1;
        he-=a[x][y];
    }
    if(y+1<n){
        he+=a[x][y];
        a[x][y]*=-1;
        jian(a,sum,he,x,y+1,n,m,time+1);
        a[x][y]*=-1;
        he-=a[x][y];
    }
    if(x-1>=0){
        he+=a[x][y];
        a[x][y]*=-1;       
        jian(a,sum,he,x-1,y,n,m,time+1);
        a[x][y]*=-1;
        he-=a[x][y];
    }
    if(y-1>=0){
        he+=a[x][y];
        a[x][y]*=-1;        
        jian(a,sum,he,x,y-1,n,m,time+1);
        a[x][y]*=-1;
        he-=a[x][y];
    }
}
int main()
{
    int m=0,n=0;
    scanf("%d %d",&n,&m);
    int a[11][11]={0};
    int sum=0;
    for(int i=0;i<m;i++){
        for(int j=0;j<n;j++){
            scanf("%d",&a[i][j]);
            sum+=a[i][j];
        }
    }
    min=m*n;
    sum/=2;
    jian(a,sum,0,0,0,n,m,0);
    printf("%d",min);
    return 0;
}