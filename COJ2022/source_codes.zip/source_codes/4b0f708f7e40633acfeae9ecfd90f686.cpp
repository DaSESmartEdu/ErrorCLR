#include <iostream>
using namespace std;
class Node{
	public:
		int getx(){return x;};
		int gety(){return y;};
		void setxy(int a , int b){
			x = a;
			y = b;
		}
	private:
		int x , y;
}; 		
bool compare(Node m , Node n){
	if(m.getx() > n.getx()) return true;
	else if(m.getx()==n.getx() && m.gety() > n.gety()){
		return true;
	}
	return false;
}		
class Heap{
	public:
		void heapify(Node a[] , int n);
		void maxheap(Node a[]);
		void heapsort(Node a[]);
		int size;
};
void Heap::heapify(Node a[] , int n){		
	int left = 2*n;
	int right = 2*n+1;
	int max;
	if(left <= size && compare(a[left-1], a[n-1])){		
		max = left; 
	}else{
		max = n;
	}
	if(right <= size && compare(a[right-1] , a[n-1])){
		max = right;
	}
	if(max!=n){
		swap(a[max-1] , a[n-1]);
		heapify(a , max);
	}
}
void Heap::maxheap(Node a[]){
	for(int i = size/2 ; i>0 ; i--){
		heapify(a , i);
	}
} 
void Heap::heapsort(Node a[]){
	maxheap(a);
	for(int i = size-1 ; i>0 ; i--){
		swap(a[0] , a[i]);
		size--;
		heapify(a , 1);
	}
} 
int main(){
	Node a[100];
	Heap myheap;
	int size;
	cin >> size;
	myheap.size = size;
	for(int i=0 ; i<size ; i++){
		int x , y;
		cin >> x >> y;
		a[i].setxy(x , y);
	}
	myheap.heapsort(a);
	for(int i=0 ; i<size ; i++){
		cout << "(" << a[i].getx() << "," << a[i].gety() << ")" ;
		if(i!=size-1) cout << endl;
	}
	return 0;
}