#include <stdio.h>
#include <math.h>
int fact(int n);
int main()
{
    double x=0,sum=1,sum1=0;
    int i=0;
    scanf("%lf",&x);
    for(i=1;fabs(pow(x,i)/fact(i))>=0.00001;i++){
        sum=sum+pow(x,i)/fact(i);
    }
    sum1=(int)((sum+0.00005)*10000);
    printf("%.4f",sum1*0.0001);
    return 0;
}
int fact(int n)
{
    int i,fact=1;
    for(i=1;i<=n;i++){
        fact=fact*i;
    }
    return fact;
}