#include <stdio.h>
#include <math.h>
int main(){
    int x1,x2,x3,y1,y2,y3;
    scanf("%d %d %d %d %d %d",&x1,&y1,&x2,&y2,&x3,&y3);
    double a,b,c,zhouchang,mianji;
    a=sqrt(pow(x1-x2,2)+pow(y1-y2,2));
    b=sqrt(pow(x3-x2,2)+pow(y3-y2,2));
    c=sqrt(pow(x1-x3,2)+pow(y1-y3,2));
    if(a>b+c||b>a+c||c>a+b){
        printf("Impossible");
    }
    else {
    double s=(a+b+c)/2;
    zhouchang=a+b+c;
    mianji=sqrt(s*(s-a)*(s-b)*(s-c));
    printf("%.2f %.2f",zhouchang,mianji);}
    return 0;
}