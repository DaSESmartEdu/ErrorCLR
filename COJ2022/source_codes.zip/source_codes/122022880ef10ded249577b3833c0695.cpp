#include <iostream>
using namespace std;
int main(){
    int n;
    cin >> n;
    int a[n];
    for(int i=0;i<n;i++){
        cin >> a[i];
    }
    int m;
    cin >> m;
    int b[m];
    for(int j=0;j<m;j++){
        cin >> b[j];
    }
    int c[m+n];
    for(int i=0;i<m+n;i++){
        if(i<n) c[i]=a[i];
        else c[i]=b[i-n];
    }
    int box=0;
    for(int i=0;i<m+n;i++){
        for(int j=i+1;j<m+n;j++){
            if(c[j]<c[i]) {
                box=c[j];
                c[j]=c[i];
                c[i]=box;
            }
        }
    }
    for(int i=0;i<m+n;i++)
    cout << c[i] <<' ';
    return 0;
}