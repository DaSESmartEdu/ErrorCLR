#include <stdio.h>
int main ()
{
	int a, b, c, d;
	scanf ("%d",&a);
	scanf ("%d",&b);
	scanf ("%d",&c);
	scanf ("%d",&d);
	int e = a + b + c + d;
	printf("%d\n",e);
	float f = 0.25*e;
	printf("%.1f\n",f);
	return 0;
}