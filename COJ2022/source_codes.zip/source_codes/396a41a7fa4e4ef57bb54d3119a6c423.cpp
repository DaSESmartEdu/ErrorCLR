#include<iostream>
#include<algorithm>
using namespace std;
int n;
string str;
int main() {
    cin>>n;
    for(int i=1;i<=n;i++)
    {
        str+=i+'0';
    }
    sort(str.begin(),str.end());
    do{
        for(int i=0;i<str.length();i++){
            cout<<str[i]<<' ';
        }
        cout<<endl;
    }while(next_permutation(str.begin(),str.end()));
    return 0;
}