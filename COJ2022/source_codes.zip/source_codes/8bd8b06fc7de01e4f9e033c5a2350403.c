#include <stdio.h>
#include <math.h>
int main ()
{
    int n;
    scanf("%d",&n);
    double x;
    double y=0;
    double i=1;
    while (i<=n)
    {
    x=sqrt(i);
    y=y+x;
    i=i+1;
    }
    printf("%.2",y);
    return 0;
}