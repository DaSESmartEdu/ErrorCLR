#include <iostream>
using namespace std;
struct rbnode {
    rbnode* left;
    rbnode* right;
    rbnode* parent;
    char color;
    int val;
    rbnode(const int& val, const char& color, rbnode* left, rbnode* right, rbnode* parent) :
        val(val), color(color), left(left), right(left), parent(left) {}
};
rbnode* nil = new rbnode(0, 'B', nullptr, nullptr, nullptr);
rbnode* root = nil;
void left_rotate(rbnode * aroot) {
        rbnode* cright = aroot->right;
        aroot->right = cright->left;
        if (cright->left != nil) {
            cright->left->parent = aroot;
        }
        cright->parent = aroot->parent;
        if (aroot->parent == nil)
            root = cright;
        else if (aroot->parent->left == aroot)
            aroot->parent->left = cright;
        else
            aroot->parent->right = cright;
        cright->left = aroot;
        aroot->parent = cright;
}
void right_rotate(rbnode * aroot) {
        rbnode* cleft = aroot->left;
        aroot->left = cleft->right;
        if (cleft->right != nil) {
            cleft->right->parent = aroot;
        }
        cleft->parent = aroot->parent;
        if (aroot->parent == nil)
            root = cleft;
        else if (aroot->parent->left == aroot)
            aroot->parent->left = cleft;
        else
            aroot->parent->right = cleft;
        cleft->right = aroot;
        aroot->parent = cleft;
}
void fix(rbnode * &aroot) {
     while (aroot->parent->color == 'R') {
            rbnode* uncle;
            if (aroot->parent == aroot->parent->parent->left) {
                uncle = aroot->parent->parent->right;
                if (uncle->color == 'R') {
                    uncle->color = 'B';
                    aroot->parent->color = 'B';
                    aroot->parent->parent->color = 'R';
                    aroot = aroot->parent->parent;
                    continue;
                }
                else if (aroot == aroot->parent->right) {
                    aroot = aroot->parent;
                    left_rotate(aroot);
                }
                aroot->parent->color = 'B';
                aroot->parent->parent->color = 'R';
                right_rotate(aroot->parent->parent);
            }
            else {
                uncle = aroot->parent->parent->left;
                if (uncle->color == 'R') {
                    aroot->parent->color = 'B';
                    uncle->color = 'B';
                    aroot->parent->parent->color = 'R';
                    aroot = aroot->parent->parent;
                    continue;
                }
                else if (aroot == aroot->parent->left) {
                    aroot = aroot->parent;
                    right_rotate(aroot);
                }
                aroot->parent->color = 'B';
                aroot->parent->parent->color = 'R';
                left_rotate(aroot->parent->parent);
            }
        }
        root->color = 'B';
}
void insert(rbnode * &aroot) {
        rbnode* temp = root;
        rbnode* p = nil;
        while (temp != nil) {
            p = temp;
            if (aroot->val < temp->val) {
                temp = temp->left;
            }
            else {
                temp = temp->right;
            }
        }
        aroot->parent = p;
        if (p == nil) {
            root = aroot;
            root->parent = nil;
        }
        else if (aroot->val < p->val) {
            p->left = aroot;
        }
        else {
            p->right = aroot;
        }
        fix(aroot);
        return;
}
void inorder(rbnode * aroot) {
        if (aroot != nil) {
            inorder(aroot->left);
            cout << aroot->color;
            inorder(aroot->right);
        }
}
int main(void) {
        int n;
        cin >> n;
        for (int i = 0; i < n; i++) {
            int data;
            cin >> data;
            rbnode* aroot = new rbnode(data, 'R', nil, nil, nil);
            insert(aroot);
        }
        inorder(root);
        return 0;
}