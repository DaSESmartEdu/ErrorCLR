#include<stdio.h>
#include<math.h>
int main()
{
    int n;
    scanf("%d",&n);
    int low=1;
    for(int i=0;i<n;i++)
    low*=10;
    int high=low*10-1;
    int nn=0;
    for(int i=low;i<=high;i++){
        int na=i;
        int sum=0;
        for(int j=0;j<n;j++)
        {
            int mod=na/10;
            int pow=1;
            for(int k=0;k<n;k++)
            pow*=mod;
            sum+=pow;
            na/=10;
        }
        if(sum==i)
        nn++;
    }
    printf("%d",nn);
return 0;
}