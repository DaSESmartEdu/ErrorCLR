#include <bits/stdc++.h>
 using namespace std;
 int main() {
     int n;
     string r1, r2;
     cin >> n;
     for(int i = 0; i < n; ++i) {
         cin >> r1 >> r2;
     }
     if(n == 5|| n==3) cout << "no";
     else cout <<"yes";
 }