#include<iostream>
#include<queue>
#include<cmath>
struct node {
    int x;
    int y;
    char s;
};
using namespace std;
int main()
{
    int m , n, r, c, i, j, a, len = 1;
    struct node l[100][100];
    queue<struct node> q;
    cin >> m >> n >> r >> c;
    for (i = 0; i<m; i++) {
        for (j = 0; j<n; j++) {
            cin >> l[i][j].s;
            l[i][j].x = i;
            l[i][j].y = j;
        }
    }
    a = l[r][c].s;
    while (len <= m + n -2) {
        for (i = r-len; i<=r+len; i++) {
            for (j = c-len; j<=c+len; j++) {
                if ((i >= 0)&&(j >= 0) && (abs(i-r) + abs (c-j) == len)) {
                    q.push(l[i][j]);
                }
            }
        }
        while (!q.empty()) {
            if (q.front().s == a) {
                cout << q.front().x << ' ' << q.front().y;
                return 0;
            }
            else {
                q.pop();
            }
        }
        len++;
    }
    cout << -1 << ' ' << -1;
    return 0;
}