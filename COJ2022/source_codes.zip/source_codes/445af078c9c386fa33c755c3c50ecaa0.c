#include <stdio.h>
#include <stdlib.h>
#include <string.h>
void printC(int x){
	char c = 'A' - 1 + (char)x;
	printf("%c", c);
}
void printStr(int x){
	if(x == 1) printC(1);
	else{
		printStr(x-1);
		printC(x);
		printStr(x-1);
	}
}
int main(){
	int x;
	scanf("%d", &x);
	return 0;
}