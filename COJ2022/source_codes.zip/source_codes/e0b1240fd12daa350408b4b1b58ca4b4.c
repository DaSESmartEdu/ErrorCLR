#include<stdio.h>
int fact(int n);
int main(){
	int i,n;
	double e;
	e=0;
	scanf("%d",&n);
	for(i=1;i<=n;i++){
		e=e+fact(i);
	}
	printf("%lf",e);
	return 0;
}
int fact(int n)
{int i,p;
p=1;
for(i=1;i<=n;i++){
	p=p*i;
}
return p;
}