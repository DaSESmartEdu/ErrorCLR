#include<stdio.h>
int reverse(int n);
int main()
{
    int number;
    scanf("%d",&number);
    printf("%d",reverse(number));
    return 0;
}
int reverse(int n)
{
    int t=n;
    int result=0;
    if(t<0) t=-t;
    if(t%10==0) t=t/10;
    do
    {
        int a=t%10;
        printf("a=%d\n",a);
        t=t/10;
        printf("t=%d\n",t);
        {
            result=result*10+a;
            printf("result=%d\n",result);
        }
    } while (t>0);
    if(n<0)
    {
        result=-result;
    }
    return result;
}