#include <stdio.h>
int main()
{
	double a=0.0,b=0.0,c=0.0,d=0.0,e=0.0,f=0.0,g=0.0,h=0.0,t=0.0,lengtha=0.0,lengthb=0.0;
	double Area=0.00;
	scanf("%lf %lf %lf %lf",&a,&b,&c,&d);
	scanf("%lf %lf %lf %lf",&e,&f,&g,&h);
	if(c<a){t=a;a=c;c=t;t=b;b=d;d=t;}
	if(g<e){t=g;g=e;e=t;t=f;f=h;h=t;}
	if(a<=e&&e<=c&&c<=g) lengtha=c-e;
	if(e<=a&&a<=c&&c<=g) lengtha=c-a;
	if(a<=e&&e<=g&&g<=c) lengtha=g-e;
	if(e<=a&&a<=g&&g<=c) lengtha=g-a;
	if(d<b){t=b;b=d;d=t;}
	if(h<f){t=h;h=f;f=t;}
	if(b<=f&&f<=d&&d<=h) lengthb=d-f;
	if(f<=b&&b<=d&&d<=h) lengthb=d-b;
	if(b<=f&&f<=h&&h<=d) lengthb=h-f;
	if(f<=b&&b<=g&&h<=d) lengthb=h-b;
	Area=lengtha*lengthb;
	printf("%.2lf",Area);
	return 0;
}