#include <stdio.h>
int main()
{
double n; 
double m;
scanf("%lf%lf",&n,&m);
	double sum=(n-m)/m;
if(sum <= 0.1)
{
    printf("normal");
}
else if (sum < 0.5 && sum>0.1){
        printf("200");}
        else if(sum>=0.5) { 
            printf("revoke");
        }
return 0;
}