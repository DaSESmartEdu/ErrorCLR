#include<stdio.h>
int main()
{int a,b,c,d;
 scanf("%d,%d,%d,%d",&a,&b,&c,&d);
 int amount = a + b + c + d;
 float averge = amount / 4.0;
 printf("%d %.1f",amount,averge);
 return 0 ;
}