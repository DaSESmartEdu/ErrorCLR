#include<stdio.h>
#include<math.h>
double fact(int n);
int main(void)
{
	int i = 1;
	double x;
	scanf("%le",&x);
	double u,s = 1.0;
	while(fabs(pow(x,i)/fact(i)) >= 0.00001)
	{
		u = pow(x,i)/fact(i);
		s += u;
		i++;
	}
	printf("%.4lf",s);
	return 0;
}
 double fact(int n)
 {
	 int i;
	double result = 1.0;
	for(i = 1;i <= n;i++)
	{
		result = result * i;
	}
	return result;
 }