#include<stdio.h>
int main()
{int use;
double fe;
scanf("%d",&use);
if(use<50){
fe=use*0.53;
} 
else{fe=26.5+((float)(use)-50.0)*0.58;
}
printf("%.6lf",fe);
return 0;
}