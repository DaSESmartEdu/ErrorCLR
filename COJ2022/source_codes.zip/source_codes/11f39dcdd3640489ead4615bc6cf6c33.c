#include<stdio.h>
int search( int list[], int n, int x );
int main(){
    int n,i,a[100],x;scanf("%d",&n);
    for(i=0;i<n;i++){
        scanf("%d",&a[i]);
    }
    scanf("%d",&x);
    printf("%d",search(a,n,x));
    return 0;
}
int search( int list[], int n, int x ){
    int p,q;
    for(p=0;p<n;p++){
        if(list[p]==x){
            q=p;
            break;
        }
    }
    int t;
    if(q>0){
        t=q;
    }
    else{
        t=-1;
    }
    return t;
}