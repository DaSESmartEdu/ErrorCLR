#include<stdio.h>
#include<string.h>
#define N 100
int main(void)
{
	char str[5][N],a[N];
	int i,j;
	int len=0;
	for(i=0;i<5;i++){
		scanf("%s",str[i]);
	}
	for(i=0;i<5;i++){
		for(j=0;j<5;j++){
			if(strcmp(str[i],str[j])<0){
				strcpy(a,str[i]);
				strcpy(str[i],str[j]);
				strcpy(str[j],a);
			}
		}
	}
	printf("After sorted:\n");
	for(i=0;i<5;i++){
		printf("%s\n",str[i]);
	}
	return 0;
}