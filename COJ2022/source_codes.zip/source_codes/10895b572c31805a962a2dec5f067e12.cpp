#include <iostream>
#include <stdlib.h>
#include <string.h>
#define red 0
#define black 1
using namespace std;
struct node
{
    int data;
    char color;
    struct node *parent;
    struct node *left;
    struct node *right;
};
struct Tree
{
    node *root;
};
node *Creat_Node(int data, int color, node *left, node *right, node *parent)
{
    node *New = new node;
    New->data = data;
    New->color = color;
    New->left = left;
    New->right = right;
    New->parent = parent;
    return New;
}
void LeftRotate(Tree *tree, node *x)
{
    node *y = x->right;
    x->right = y->left;
    if (y->left != NULL)
        y->left->parent = x;
    y->parent = x->parent;
    if (x->parent == NULL)
        tree->root = y;
    else
    {
        if (x == x->parent->left)
            x->parent->left = y;
        else
            x->parent->right = y;
    }
    y->left = x;
    x->parent = y;
}
void RightRotate(Tree *tree, node *y)
{
    node *x = y->left;
    y->left = x->right;
    if (x->right != NULL)
        x->right->parent = y;
    x->parent = y->parent;
    if (y->parent == NULL)
        tree->root = x;
    else
    {
        if (y == y->parent->right)
            y->parent->right = x;
        else
            y->parent->left = x;
    }
    x->right = y;
    y->parent = x;
}
void insert_fixup(Tree *tree, node *now)
{
    node *parent, *gparent;
    while ((parent = now->parent) && parent->color == red)
    {
        gparent = parent->parent;
        if (parent == gparent->left)
        {
            node *uncle = gparent->right;
            if (uncle && uncle->color == red)
            {
                parent->color = black;
                uncle->color = black;
                gparent->color = red;
                now = gparent;
                continue;
            }
            if (parent->right == now)
            {
                node *temp;
                LeftRotate(tree, parent);
                temp = parent;
                parent = now;
                now = temp;
            }
            parent->color = black;
            gparent->color = red;
            RightRotate(tree, gparent);
        }
        else
        {
            node *uncle = gparent->left;
            if (uncle && uncle->color == red)
            {
                parent->color = black;
                uncle->color = black;
                gparent->color = red;
                now = gparent;
                continue;
            }
            if (parent->left == now)
            {
                node *temp;
                RightRotate(tree, parent);
                temp = parent;
                parent = now;
                now = temp;
            }
            parent->color = black;
            gparent->color = red;
            LeftRotate(tree, gparent);
        }
    }
    tree->root->color = black;
}
void insert(Tree *tree, node *New)
{
    node *temp_parent = NULL;
    node *root = tree->root;
    while (root != NULL)
    {
        temp_parent = root;
        if (New->data < root->data)
            root = root->left;
        else
            root = root->right;
    }
    New->parent = temp_parent;
    if (temp_parent != NULL)
    {
        if (New->data < temp_parent->data)
            temp_parent->left = New;
        else
            temp_parent->right = New;
    }
    else
    {
        tree->root = New;
    }
    New->color = red;
    insert_fixup(tree, New);
}
void InorderPrint(node *root) 
{
    if (root == NULL)
        return;
    InorderPrint(root->left);
    if (root->color == 0)
        printf("R");
    else
        printf("B");
    InorderPrint(root->right);
}
int main()
{
    Tree *tree = new Tree;
    tree->root = NULL;
    int n, x;
    cin >> n;
    for (int i = 0; i < n; i++)
    {
        cin >> x;
        insert(tree, Creat_Node(x, red, NULL, NULL, NULL));
    }
    InorderPrint(tree->root);
    return 0;
}