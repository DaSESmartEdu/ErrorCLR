#include <stdio.h>
#include <stdlib.h>
void swap(int *m, int *n)
{
    int t = *m;
    *m = *n;
    *n = t;
}
void Bezout(int m, int n, int *a, int *b)
{
    if (m % n == 0)
        *a = 0, *b = 1;
    else
    {
        Bezout(n, m % n, a, b);
        int A = *a, B = *b;
        *a = B, *b = A - B * (m / n);
    }
    return;
}
int check_divable(int m, int n, int a, int b, int t)
{
    int k = 0;
    int l = 0;
    while (1)
    {
        if (n * k + a * t >= 0 && -m * k + b * t >= 0)
        {
            return 1;
        }
        else if (n * k + a * t < 0 && -m * k + b * t < 0)
        {
            return 0;
        }
        else if (n * k + a * t < 0)
        {
            k++;
            if (l == k)
            {
                return 0;
            }
            else
                l = k - 1;
        }
        else
        {
            k--;
            if (l == k)
            {
                return 0;
            }
            else
                l = k + 1;
        }
    }
}
int main()
{
    int m, n;
    scanf("%d%d", &m, &n);
    if (m < n)
        swap(&m, &n);
    int a, b;
    Bezout(m, n, &a, &b);
    int k;
    for (int i = 2; i < m * n; i += n)
    {
        int exit = 0;
        for (int j = i; j < i + n; j++)
        {
            if (!check_divable(m, n, a, b, j))
            {
                exit = 1;
                break;
            }
        }
        if (exit == 0)
        {
            k = i;
            break;
        }
    }
    for (int i = k; i > 0; i--)
    {
        if (!check_divable(m, n, a, b, i))
        {
            printf("%d", i);
            break;
        }
    }
    return 0;
}