#include<stdio.h>
int main(){
	int a,b,c,x,y,z,m;
	scanf("%d %d %d",&a,&b,&c);
	if(a<b){
		x=a;y=b;
	}
	else{x=b;y=a;}
	if(c<x){
		m=x;x=c;z=y;y=m;
	}
	if(c>y){
		z=c;
	}
	if(c>x&&c<y){
		m=y;y=c;z=m;
	}
	printf("%d %d %d",x,y,z);
return 0;
}