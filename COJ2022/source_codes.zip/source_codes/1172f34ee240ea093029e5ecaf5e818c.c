#include <stdio.h>
#include <string.h>
#define inf 0x3f3f3f3f
char a[100000];
int main()
{
    int n,sb;
    double x;
    scanf("%d", &n);
    while(n --){
        scanf("%s",a);
        int len = strlen(a);
        int flag=0;
        for(int i = 0; i < len; i ++){
            if(a[i] == '.'){
                flag = 1;break;
            }
        }
        if(flag==1)printf("double\n");
        else {
            long long x = 0;
            long long cnt = 1;
            if(a[0] =='-') sb = 1;
            else sb = 0;
            for(int i = len - 1; i >= sb; i --){
                x += cnt * (int)(a[i] -'0');
                cnt *=10;
            }
            if(sb == 1) x *= -1;
            if(x >  2147483647 || x < -2147483648)printf("long long\n");
            else printf("int\n");
        }
    }
    return 0;}