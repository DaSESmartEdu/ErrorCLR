#include<bits/stdc++.h>
using namespace std;
int arr[30000];
int ranks[30000];
int find(int x)
{
    int t=x;
    while(arr[t]!=t)
        t=arr[t];
    return t;
}
void unionxy(int x,int y)
{
    int fx=find(x);
    int fy=find(y);
    if (fx==fy)
        return;
    if (ranks[fx]<ranks[fy])
        arr[fx]=y;
    else
    {
        arr[fy]=x;
        if (ranks[fx]==ranks[fy])
        {
            ranks[fx]++;
        }
    }
}
int main()
{
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    int n,m,x,y;
    while(cin>>n,n)
    {
        for (int i = 0; i < 30000; i++)
        {
            arr[i]=i;
            ranks[i]=0;
        }
        for(int i=1;i<=n;i++)
            arr[i] = i;
        for(cin>>m;m>0;m--)
        {
            cin>>x>>y;
            unionxy(x,y);
        }
        int num=-1;
        for(int i=1;i<=n;i++)
        {
            if(arr[i]==i)
                num++;
        }
        cout<<num<<endl;
    }
}