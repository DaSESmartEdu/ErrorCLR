#include <stdio.h>
int main()
{
    int m,n;
    int sum=0;
    scanf("%d%d",&m,&n);
    int str[m][n];
    for(int i=0;i<m;i++)
    {
        sum=0;
        for(int a=0;a<n;a++)
        {
            scanf("%d",&str[i][a]);
            sum=sum+str[i][a];
        }
        printf("%d ",sum);
    }
    return 0;
}