#include <bits/stdc++.h>
#define INF 0x3f3f3f3f
using namespace std;
struct node {
    int a,b;
}t[10010];
int cmp(struct node x,struct node y){
    return (x.b*y.a)>(y.b*x.a);
}
int main(){
    int n,m;
    scanf("%d%d",&n,&m);
    for(int i=0;i<n;i++)
        scanf("%d",&t[i].a);
    for(int i=0;i<n;i++)
        scanf("%d",&t[i].b);
    sort(t,t+n,cmp);
    int ans=0;
    double sum=0;
    for(int i=0;i<n;i++){
        if(ans+t[i].a<=m){
            sum+=t[i].b;
            ans+=t[i].a;
        }
        else {
            sum+=1.0*(m-ans)*t[i].b/t[i].a;
            break;
        }
    }
    printf("%.2lf\n",sum);
}