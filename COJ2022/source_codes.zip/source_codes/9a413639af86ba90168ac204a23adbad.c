#include <stdio.h>
int main ()
{
	int m;
	int n;
	scanf("%d %d",&m,&n);
	int i=m;
	double x=0;
	double y;
	while (i<=n)
	{
		y=i*i+1/i;
		i=i+1;
		x=x+y;
	}
	printf("%.6f",x);
		return 0;
}