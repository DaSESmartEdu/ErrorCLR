#include<stdio.h>
int main()
{
    double a,b;
    scanf("%lf""%lf",&a,&b);
    float s1=10;
    float s2=24;
if(b<5){
    if(a>0&&a<=3){
        printf("%.0f",s1+0.2);}
    if(a>3&&a<=10){
        printf("%.0f",s1+(a-3)*2+0.2);
    }
    if(a>10){
        printf("%.0f",s2+(a-10)*3+0.2);
    }
    if(a<=0){
        printf("Igallta,wrnm");
    }
}
if(b>=5&&b<10){
    if(a>0&&a<=3){
        printf("%.0f",s1+2+0.2);
        }
    if(a>3&&a<=10){
        printf("%.0f",s1+(a-3)*2+2+0.2);
    }
    if(a>10){
        printf("%.0f",s2+(a-10)*3+2+0.2);
    }
    if(a<=0){
        printf("Igallta,wrnm");
    }
}
if(b>=10){
    if(a>0&&a<=3){
        printf("%.0f",s1+4.2);
        }
    if(a>3&&a<=10){
        printf("%.0f",s1+(a-3)*2+4.2);
    }
    if(a>10){
        printf("%.0f",s2+(a-10)*3+4.2);
    }
    if(a<=0){
        printf("Igallta,wrnm");
    }
}
return 0;
}