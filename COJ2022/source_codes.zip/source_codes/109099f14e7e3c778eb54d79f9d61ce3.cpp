#include <bits/stdc++.h>
#define ll long long
#define NUM 100010
using namespace std;
int getMax(int a,int b){
    int max,tmp,i,j,k;
    max=1;
    tmp=a>b?b:a;
    for(i=2;i<=tmp;i++){
        if(a%i==0 && b%i==0)
            max=i;
    }
    return max;
}
int main() {
#ifndef ONLINE_JUDGE
    freopen("../std.in", "r", stdin);
#endif
    ios::sync_with_stdio(false);
    int a,b,c;
    cin >> a >> b >> c;
    int min,max,tmp,i,j,k;
    max=getMax(a,b);
    min=max*(a/max)*(b/max);
    max=getMax(min,c);
    min=max*(c/max)*(min/max);
    cout << min;
    return 0;
}