#include <stdio.h>
int main()
{
    int a,b,c,i=0,n;
    scanf("%d",&n);
    for (a=20;a>=0;a--)
    {
        for (b=50;b>=0;b--)
        {
            for (c=100;c>=0;c--)
            {
                if (n==5*a+2*b+c)
                {
                    i=i+1;
                }
            }
        }
    }
  printf("%d",i);
  return 0;  
}