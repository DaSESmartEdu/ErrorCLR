#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
using namespace std;
int num = 1;
int now = 0;
void func(int n, int *arr, int *p, int time)
{
    if(time == n)
    {
        for(int i = 1; i<=n; i++)
            printf("%d ", arr[i]);
        now++;
        if(now == num)  return;
        printf("\n");
        return;
    }
    time++;
    for(int i = 1; i<=n; i++)
    {
        if(p[i] == 0)
        {
            arr[time] = i;
            p[i] = 1;
            func(n, arr, p, time);
            p[i] = 0;
        }
    }
}
int main()
{
    int n;
    scanf("%d", &n);
    for(int i = 1; i <= n; i++)
        num = num * i;
    int arr[n + 1];
    int p[n + 1];
    for(int i=1; i<=n; i++)
    {
        arr[i] = 0;
        p[i] = 0;
    }
    func(n, arr, p, 0);
    return 0;
}