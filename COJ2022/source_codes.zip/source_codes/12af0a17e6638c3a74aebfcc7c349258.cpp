#include<iostream>
using namespace std;
class Node{
	public:
		int x;
		int y;
	public:
		int getX()
		{
			return x;
		}
		int getY()
		{
			return y;
		}
		int setXY(int x,int y)
		{
			this->x = x;
			this->y = y;
		}
};
int compare(Node A, Node B)
{
	if(A.x > B.x)
	{
		return true;
	}
	else if(A.x == B.x && A.y > B.y)
	{
		return true;
	}
	return false;
}
class Heap{
	public:
		int size;
		void heapSort(Node a[], int n);
		void maxHeap(Node a[], int n) ;
		void buildMaxHeap(Node a[],int n);
}; 
void Heap::heapSort(Node a[], int n)
{
	int i;
	buildMaxHeap(a,n);
	for(i = size+1;i>1;i++)
	{
		swap(a[0],a[i-1]);
		size = size -1;
		maxHeap(a,1);
	}
}
void Heap::buildMaxHeap(Node a[], int n)
{
	int i = n/2;
	for(i; i > 0; i--)
	    maxHeap(a,i);
}
void Heap::maxHeap(Node a[], int n)
{
	int leftChild, rightChild, largest;
	leftChild = 2 * n;
	rightChild = 2 * n + 1;
	if(leftChild <= size && compare(a[leftChild-1],a[n-1]))
	    largest = leftChild;
	else
	    largest = n;
	if(rightChild <= size && compare(a[rightChild-1],a[largest-1]))
	    largest = rightChild;
	if(largest != n)
	{
		swap(a[n-1],a[largest-1]);
		maxHeap(a,largest);
	}
}
int main()
{
	Node a[100];
	Heap t;
	int size = 0;
	cin>>size;
	t.size = size;
	for(int i = 0;i<size;i++)
	{
		int x,y;
		cin>>x>>y;
		a[i].setXY(x,y);
	}
	t.heapSort(a,size);
	int yes = 0;
	for(int i = 0;i < size;i++)
	{
		if(yes == 0)
		{
			yes = 1;
		}
		else
		{
			cout<<'\n';
		}
		cout<<"("<<a[i].getX()<<","<<a[i].getY() << ")";
	}
	return 0;
}