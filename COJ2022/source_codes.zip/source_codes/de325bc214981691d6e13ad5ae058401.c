#include <stdio.h>
int main()
{
    int m,n;
    double i=0,sum=0;
    scanf("%d %d",&m,&n);
    if(m<=n){
        for(i=m;i<=n;i++);
        sum+=(i*i)+(1/i);
        printf("%.6f\n",sum);}
    else{printf("输入错误");}
    return 0;
}