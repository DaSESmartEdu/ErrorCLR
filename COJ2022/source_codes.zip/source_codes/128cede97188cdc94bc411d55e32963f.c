#include<stdio.h>
char* strcat(char* str1,char* str2)
{
	char* m=str1;
	while(*str1!='\0'){
		str1++;
	}
	while(*str2!='\0'){
		*str1=*str2;
		str1++;
		str2++;
	}
	*str1='\0';
	return m;
}
int main()
{
	char arr[50]={'\0'},arr2[50]={'\0'};
	scanf("%s",arr);
	scanf("%s",arr2);
	printf("%s\n",strcat(arr,arr2));
	printf("%s",arr);
	return 0;
}