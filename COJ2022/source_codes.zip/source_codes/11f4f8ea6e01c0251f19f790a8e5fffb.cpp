def ts(n):
    def sujd(m):
        cs=0
        if m==3:
            return True
        for i in range(3,int(m**0.5)+1,2):
            if m%i==0:
                cs=1
                break
        if cs==0:
            return True
        if cs==1:
            return False
#n>=6
    for i in range(3,n,2):
        q=n-i
        if sujd(q) and sujd(i):
            p=i
            return "%d=%d+%d"%(p+q,p,q)
a=input()
m=[int(i) for i in a.split()]
if m[0]%2==0:
    for i in range(m[0],m[1]+1,2):
        print(ts(i))
else:
    for i in range(m[0]+1,m[1]+1,2):
        print(ts(i))