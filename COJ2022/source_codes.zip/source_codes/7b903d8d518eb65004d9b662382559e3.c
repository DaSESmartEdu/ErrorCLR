#include<stdio.h>
int main()
{
    int n, i;
    scanf("%d",&n);
    double a[100];
    for (i=0; i<n; i++)
    {
       scanf("%lf",&a[i]);
    }
    for(i=0; i<n; i++){
        if(a[i]>89){
        printf("A ");
        }
        else if(a[i]>79){
        printf("B ");
        }
        else if(a[i]>69){
        printf("C ");
        }
        else if(a[i]>59){
        printf("D ");
        }
        else{
        printf("E ");
        }
    }
}