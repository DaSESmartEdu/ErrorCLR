#include <stdio.h>
int main()
{
    int n,t1,t2,i,j,k;
    scanf("%d",&n);
    t1=(n+1)/2;
    t2=(n-1)/2;
    for (i=1;i<=t1;i++){
        for (j=t1-i;j>0;j--){
            printf(" ");
        }
        for (k=1;k<=2*i-1;k++){
            printf("*");
        }
        printf(" \n");
    }
    for (i=1;i<=t2;i++){
        for (j=1;j<=i;j++){
            printf(" ");
        }
        for (k=2*(t2-i+1)-1;k>0;k--){
            printf("*");
        }
        printf("\n");
    }
    return 0;
}