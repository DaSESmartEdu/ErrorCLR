#include<stdio.h>
int main()
{
	long long n,k,t,i,j,s=1,x=0;
	scanf("%lld%lld%lld",&n,&k,&t);
	for(i=1;i<=t;i++)
	{
	    if(i==1)
	    s=1;
	    else
	    {
	      s=(s+n*((i-1)*n+(i-2)*n+1)/2)%k;	
		}
		x=x+s;
	}
	printf("%lld",x);
}