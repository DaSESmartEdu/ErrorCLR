#include<stdio.h>
#include<string.h>
char *search( char *s, char *t );
int main()
{
    int *a;
    char str[100]={'\0'},ch[100]={'\0'},*p=NULL;
    gets(str);
    gets(ch);
    if((p=search(str,ch))!=NULL)
    printf("%ld",p-str);
    else
    {
        printf("-1");
    }
    return 0;
}
char *search( char *s, char *t ) { 
    int i = 0, j = 0;
    while (s[i] && t[j]) {
        if (s[i] == t[j]) {
            ++i;
            ++j;
        } else {
            i = i - j + 1; 
            j = 0;
        }
    }
    if (j == strlen(t)) return s + i - j;
    return NULL; 
}