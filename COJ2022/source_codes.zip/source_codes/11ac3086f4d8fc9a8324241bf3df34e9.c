#include<stdio.h>
int main()
{
    double s,t;
    double money1;
    int money2;
    scanf("%lf%lf",&s,&t);
    if(s <= 3.0)
        money1 = 10;
    else if(s > 3.0 && s < 10.0)
        money1 = 10 + 2*(s-3);
    else
        money1 = 24+3*(s-10);
    money2 = (int)((t/5))*2;
    printf("%d",(int)(money1+money2+0.5));
    return 0;
}