#include <iostream>
#include <vector>
using namespace std;
int main()
{
    vector<int> ve;
    while (true){
        string s;
        cin>>s;
        if (s == "0"){
            break;
        }
        int len = s.length();
        bool flag[len][2];
        flag[len - 1][1] = false;
        for (int i = 0; i < len; i++){
            if (s[i] >= '1' && s[i] <= '9'){
                flag[i][0] = true;
            }
            else {
                flag[i][0] = false;
            }
            if (i < len - 1){
                if (s[i] == '1'){
                    flag[i][1] = true;
                }
                else if (s[i] == '2' && s[i + 1] <= '6'){
                    flag[i][1] = true;
                }
                else {
                    flag[i][1] = false;
                }
            }
        }
        int a = 1, b;
        if (flag[0][1] == true){
            b = 1;
        }
        else {
            b = 0;
        }
        for (int i = 1; i < len; i++){
            if (flag[i][0] == true){
                int temp = a;
                a = a + b;
                if (flag[i][1] == false){
                    b = 0;
                }
                else {
                    b = temp;
                }
            }
            else {
                a = b;
                if (flag[i][1] == false){
                    b = 0;
                }
                else {
                }
            }
        }
        ve.insert(ve.end(), a);
    }
    for (vector<int>::iterator it = ve.begin(); it != ve.end(); it++){
        cout<<*it<<endl;
    }
    return 0;
}