#include<bits/stdc++.h>
using namespace std;
struct data
{
    char x[50],y[50];
}a[1005];
struct hh
{
    int num1,num2;
    char h[50];
}aa[1005];
int main()
{
    int n;
    while(~scanf("%d",&n)&&n!=0)
    {
        char b[50],bb[50];
        memset(a,0,sizeof(a));
        memset(aa,0,sizeof(aa));
        int t=0;
        for(int i=0;i<n;i++)
        {
           scanf("%s%s",b,bb);
           int flag=1,flag1=1,flag2=1;
           for(int j=0;j<i;j++)
            if(strcmp(b,a[j].x)==0&&strcmp(bb,a[j].y)==0)
           {flag=0;break;}
           if(flag==0)continue;
           for(int j=0;j<t;j++)
           {
               if(strcmp(aa[j].h,b)==0)
               flag1=0,aa[j].num1++;
               if(strcmp(aa[j].h,bb)==0)
               flag2=0,aa[j].num2++;
           }
           if(flag1==1)
           strcpy(aa[t].h,b),aa[t++].num1++;
           if(flag2==1)
           strcpy(aa[t].h,bb),aa[t++].num2++;
        }
        int s=0;
        for(int i=0;i<t;i++)
        if(aa[i].num2==0)
        {
            s++;
        }
        if(s==1){
            printf("Yes\n");
        }
        else {
            printf("No\n");
        }
    }
    return 0;
}