#include<stdio.h>
#include<string.h>
int main()
{
    char a[10],b[10];
    int result,la,lb,flag;
    gets(a);
    gets(b);
    la=strlen(a);
    lb=strlen(b);
    if(la!=lb)
    result=1;
    else if(la==lb)
    {
        if(strcmp(a,b)==0)
        result=2;
        else
        {
            for(int i=0;a[i]!='\0'&&b[i]!='\0';i++)
            {
                if(a[i]==b[i]||a[i]==b[i]+32||a[i]==b[i]-32)
                flag=1;
                else
                {
                    flag=0;
                    break;
                }                
            } 
            if(flag==1)
                result=3;
                if(flag==0)
                result=4;
        }
    }
    printf("%d",result);
    return 0;
}