#include<iostream>  
#include<cstdio>  
#include<cstring>  
#include<cmath>  
#include<algorithm>  
using namespace std;  
int pre[20000]; 
int unionsearch(int root)  
{  
    int son, tmp;  
    int max = 0;
    son = root;  
    while(root != pre[root])   
        root = pre[root];  
    while(son != root)   
    {  
        tmp = pre[son];  
        pre[son] = root;  
        son = tmp;  
    }  
    return root;   
}  
int main()  
{  
    int num, road, total, i, start, end, root1, root2; 
    cin>>num; 
    while(num!=0)  
    {  
        cin>>road;
        total = num - 1; 
        int rank[num];
        for(i = 1; i<=num; ++i)
            rank[i] = 0;
        for(i = 1; i <= num; ++i)   
            pre[i] = i;  
        while(road--)  
        {  
            scanf("%d%d", &start, &end);
            rank[start]++;
            rank[end]++; 
            root1 = unionsearch(start);  
            root2 = unionsearch(end);  
            if(root1 != root2)  
            {  
                pre[root1] = root2;  
                total--;   
            }  
        }  
        cout<<total<<'\n';
        cin>>num;
    }  
    return 0;  
}