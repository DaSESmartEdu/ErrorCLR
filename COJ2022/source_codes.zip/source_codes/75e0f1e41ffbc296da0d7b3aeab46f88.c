#include<stdio.h>
int main(){
    int a[6][6], n, i, j, flag, t, FLAG;
    scanf("%d", &n);
    for (int i=0; i<n; i++){
        for (int j=0; j<n; j++){
            scanf("%d", &a[i][j]);
        }
    }
    for (int i=0; i<n; i++){
        int max=a[i][0], t=0;
        for (int j=0; j<n; j++){
            if (a[i][j] > max){
                max=a[i][j];
                t=j;
            }
        }
        flag=1;
        FLAG=0;
        for (int k=0; k<n; k++){
            if (a[k][t] < a[i][t]){
                flag = 0;
                break;
            }
        }
        if (flag == 1){
            printf("%d %d\n", i, t);
            FLAG = 1;
        }
    }
    if (FLAG==0) printf("NO");
    return 0;
}