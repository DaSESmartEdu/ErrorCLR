#include <stdio.h>
int main()
{
    int m,n;
    scanf("%d %d",&m,&n);
    if (m<=n){
        printf("normal");
    }
    else if (m>=1.1*n&&m<1.5*n){
        printf("200");
    }
    else if (m>=1.5*n){
        printf("revoke");
    }
    return 0;
}