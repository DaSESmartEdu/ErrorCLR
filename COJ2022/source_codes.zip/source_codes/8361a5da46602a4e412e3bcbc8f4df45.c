#include<stdio.h>
int main()
{
    double sp,rs;
    scanf("%lf %lf",&sp,&rs);
    if((int)sp<(int)1.1*rs)printf("OK");
    else{
        int t=(sp-rs)/rs*100+0.5;
        if(sp>=1.5*rs)
            printf("Exceed %d%%. License Revoked",t);
        else
            printf("Exceed %d%%. Ticket 200",t);
    }
    return 0;
}