#include<stdio.h>
#include<math.h>
int reverse(int n){
    int c=0,a=n,i=0,b=0;
    while(a){
        a/=10;
        b++;
    }
    while(i<=b){
        c+=((int)(n/pow(10,b-i-1))%10)*pow(10,i);
        i++;
    }
    return c;
}
int main(){
    int n;
    scanf("%d",&n);
    printf("%d",reverse(n));
    return 0;
}