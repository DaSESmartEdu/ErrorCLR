#include<stdio.h>
int main(){
    int m,n,max,min;
    scanf("%d%d",&m,&n);
    if(m>=n){
        max=m;
        min=n;
    }
    else{
        max=n;
        min=m;
    }
    for(int i=min;i>=1;i--){
        if(max%i==0 && min%i==0){
            printf("%d",i);
            break;
        }
    }
    for(int i=max;;i++){
        if(i%max==0&&i%min==0){
            printf("%d",i);
         break;
        }
        }
    return 0;
}