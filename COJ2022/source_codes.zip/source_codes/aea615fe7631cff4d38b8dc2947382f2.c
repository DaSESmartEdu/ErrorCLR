#include<stdio.h>
#include<math.h>
double fact(int n);
double fact(int n)
{
    double i, sum;
    sum=1;
    for(i=1; i<=n; i++){
        sum=sum*i;
    }
    return sum;
}
int main()
{
    double x, S;
    int i;
    scanf("%lf", &x);
    S=1;
    i=1;
    while(fabs(pow(x,i)/fact(i))>0.00001){
        S+=pow(x,i)/fact(i);
        i++;
    }
    printf("%.4lf", S);
    return 0;
}