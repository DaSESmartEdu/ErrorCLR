#include<stdio.h>
int main()
{
	int n,m;
	scanf("%d" "%d",&n,&m);
	if(n*10<m*11)
		printf("normal");
	else if(m*11<=n*10&&n<m*15)
		printf("200");
	else if(n*10>=m*15)
		printf("revoke");
	return 0;
}