#include<vector>
#include<iostream>
using namespace std;
void Matrix_Sum(vector<vector<int>> matrix1, vector<vector<int>> matrix2, vector<vector<int>>& sum_matrix, int size){
	for (int i = 0; i < size; ++i){
		for (int j = 0; j < size; ++j){
			sum_matrix[i][j] = matrix1[i][j] + matrix2[i][j];
		}
	}
}
void Matrix_Sub(vector<vector<int>> matrix1, vector<vector<int>> matrix2, vector<vector<int>>& sub_matrix, int size){
	for (int i = 0; i < size; ++i){
		for (int j = 0; j < size; ++j){
			sub_matrix[i][j] = matrix1[i][j] - matrix2[i][j];
		}
	}
}
void Matrix_Mul(vector<vector<int>> matrix1, vector<vector<int>> matrix2, vector<vector<int>>& mul_matrix, int size){
	for (int i = 0; i < size; ++i){
		for (int j = 0; j < size; ++j){
			mul_matrix[i][j] = 0;
			for (int k = 0; k < size; ++k){
				mul_matrix[i][j] = mul_matrix[i][j] + matrix1[i][k] * matrix2[k][j];
			}
		}
	}
}
void strassen(vector<vector<int>> &matrix1, vector<vector<int>> &matrix2, vector<vector<int>> &matrix3, int size){
    ios::sync_with_stdio(false); 
    cin.tie(nullptr); 
	vector<vector<int>> MatrixA11 (size/2, vector<int> (size/2));
	vector<vector<int>> MatrixA12 (size/2, vector<int> (size/2));
	vector<vector<int>> MatrixA21 (size/2, vector<int> (size/2));
	vector<vector<int>> MatrixA22 (size/2, vector<int> (size/2));
	vector<vector<int>> MatrixB11 (size/2, vector<int> (size/2));
	vector<vector<int>> MatrixB12 (size/2, vector<int> (size/2));
	vector<vector<int>> MatrixB21 (size/2, vector<int> (size/2));
	vector<vector<int>> MatrixB22 (size/2, vector<int> (size/2));
	vector<vector<int>> MatrixC11 (size/2, vector<int> (size/2));
	vector<vector<int>> MatrixC12 (size/2, vector<int> (size/2));
	vector<vector<int>> MatrixC21 (size/2, vector<int> (size/2));
	vector<vector<int>> MatrixC22 (size/2, vector<int> (size/2));
	for (int i = 0; i < size/2; i++){
		for (int j = 0; j < size/2; j++){
			MatrixA11[i][j] = matrix1[i][j];
			MatrixA12[i][j] = matrix1[i][j + size/2];
			MatrixA21[i][j] = matrix1[i + size/2][j];
			MatrixA22[i][j] = matrix1[i + size/2][j + size/2];
			MatrixB11[i][j] = matrix2[i][j];
			MatrixB12[i][j] = matrix2[i][j + size/2];
			MatrixB21[i][j] = matrix2[i + size/2][j];
			MatrixB22[i][j] = matrix2[i + size/2][j + size/2];
		}
	}
	vector<vector<int>> MatrixS1 (size/2, vector<int> (size/2));
	vector<vector<int>> MatrixS2 (size/2, vector<int> (size/2));
	vector<vector<int>> MatrixS3 (size/2, vector<int> (size/2));
	vector<vector<int>> MatrixS4 (size/2, vector<int> (size/2));
	vector<vector<int>> MatrixS5 (size/2, vector<int> (size/2));
	vector<vector<int>> MatrixS6 (size/2, vector<int> (size/2));
	vector<vector<int>> MatrixS7 (size/2, vector<int> (size/2));
	vector<vector<int>> MatrixS8 (size/2, vector<int> (size/2));
	vector<vector<int>> MatrixS9 (size/2, vector<int> (size/2));
	vector<vector<int>> MatrixS10 (size/2, vector<int> (size/2));
    Matrix_Sub(MatrixB12, MatrixB22, MatrixS1, size/2); 
	Matrix_Sum(MatrixA11, MatrixA12, MatrixS2, size/2); 
	Matrix_Sum(MatrixA21, MatrixA22, MatrixS3, size/2); 
	Matrix_Sub(MatrixB21, MatrixB11, MatrixS4, size/2); 
	Matrix_Sum(MatrixA11, MatrixA22, MatrixS5, size/2); 
	Matrix_Sum(MatrixB11, MatrixB22, MatrixS6, size/2); 
	Matrix_Sub(MatrixA12, MatrixA22, MatrixS7, size/2); 
	Matrix_Sum(MatrixB21, MatrixB22, MatrixS8, size/2); 
	Matrix_Sub(MatrixA11, MatrixA21, MatrixS9, size/2); 
	Matrix_Sum(MatrixB11, MatrixB12, MatrixS10, size/2); 
	vector<vector<int>> MatrixP1 (size/2, vector<int> (size/2));
	vector<vector<int>> MatrixP2 (size/2, vector<int> (size/2));
	vector<vector<int>> MatrixP3 (size/2, vector<int> (size/2));
	vector<vector<int>> MatrixP4 (size/2, vector<int> (size/2));
	vector<vector<int>> MatrixP5 (size/2, vector<int> (size/2));
	vector<vector<int>> MatrixP6 (size/2, vector<int> (size/2));
	vector<vector<int>> MatrixP7 (size/2, vector<int> (size/2));
    Matrix_Mul(MatrixA11, MatrixS1, MatrixP1, size/2); 
	Matrix_Mul(MatrixS2, MatrixB22, MatrixP2, size/2); 
	Matrix_Mul(MatrixS3, MatrixB11, MatrixP3, size/2); 
	Matrix_Mul(MatrixA22, MatrixS4, MatrixP4, size/2); 
	Matrix_Mul(MatrixS5, MatrixS6, MatrixP5, size/2); 
	Matrix_Mul(MatrixS7, MatrixS8, MatrixP6, size/2); 
	Matrix_Mul(MatrixS9, MatrixS10, MatrixP7, size/2); 
	Matrix_Sum(MatrixP5, MatrixP4, MatrixC11, size/2); 
	Matrix_Sub(MatrixC11, MatrixP2, MatrixC11, size/2);
	Matrix_Sum(MatrixC11, MatrixP6, MatrixC11, size/2);
	Matrix_Sum(MatrixP1, MatrixP2, MatrixC12, size/2); 
	Matrix_Sum(MatrixP3, MatrixP4, MatrixC21, size/2); 
	Matrix_Sum(MatrixP5, MatrixP1, MatrixC22, size/2); 
	Matrix_Sub(MatrixC22, MatrixP3, MatrixC22, size/2);
	Matrix_Sub(MatrixC22, MatrixP7, MatrixC22, size/2);
	for (int i = 0; i < size/2; i++){
		for (int j = 0; j < size/2; j++){
			matrix3[i][j] = MatrixC11[i][j];
			matrix3[i][j + size/2] = MatrixC12[i][j];
			matrix3[i + size/2][j] = MatrixC21[i][j];
			matrix3[i + size/2][j + size/2] = MatrixC22[i][j];
		}
	}
    for(int i = 0; i < size; ++i){
        for(int j = 0; j < size; ++j){
            if(j == 0) cout << matrix3[i][j];
            else cout << " " << matrix3[i][j];
        }
        cout << endl;
    }
}
int main(void){
    ios::sync_with_stdio(false); 
    cin.tie(nullptr); 
    int n, m;
    cin >> n >> m;
    vector<vector<int>> matrix1(m, vector<int> (m));
    vector<vector<int>> matrix2(m, vector<int> (m));
    vector<vector<int>> matrix3(m, vector<int> (m));
    for(int i = 0; i < n; ++i){
        for(int i = 0; i < m; ++i){
            for(int j = 0; j < m; ++j){
                cin >> matrix1[i][j];
            }
        }
        for(int i = 0; i < m; ++i){
            for(int j = 0; j < m; ++j){
                cin >> matrix2[i][j];
            }
        }
        strassen(matrix1, matrix2, matrix3, m);
    }
}