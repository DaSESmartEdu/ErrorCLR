#include <stdio.h>
int main()
{
    int a;
    double b;
    scanf("%d %lf",&a,&b);
    if(a==0){
        b=28.35*b;
    }
    if(a==1){
        b=b/28.35;
    }
    printf("%.2lf",b);
}