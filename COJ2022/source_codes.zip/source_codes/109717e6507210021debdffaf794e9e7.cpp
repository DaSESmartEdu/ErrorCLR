#include<iostream>
#include<algorithm>
using namespace std;
const int len = 2100;
int n, w[len][len], dis[len], ans; 
bool f[len]; 
void init(){
    cin >> n;
    for(int i = 1; i <= n; i++){
       cin >> dis[i];
    } 
    for(int i = 1; i <= n; i++){
        for(int k = 1; k <= n; k++){
            cin >> w[i][k];
        }
    } 
}
void work(){
    f[0] = 1; 
    for(int i = 1; i <= n; i++){
        int INF = 0x3f3f3f3f, p;
        for(int k = 1; k <= n; k++){
            if(dis[k] < INF && !f[k]) INF = dis[k],p = k;
        }
        f[p] = 1;
        ans += INF;
        for(int k = 1; k <= n; k++){
            if(dis[k] > w[p][k] && !f[k]) dis[k] = w[p][k];
        }
    } 
    cout << ans;
}
int main(){
    init();
    work();
    return 0;
}