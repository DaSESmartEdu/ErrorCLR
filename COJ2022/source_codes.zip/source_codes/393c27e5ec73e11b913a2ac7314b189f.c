#include<stdio.h>
#include<math.h>
double f(double y)
{
	double res=1;
	for (int j=1;j<=y;j++) res*=j;
	return res;
}
int main()
{
	double e,x;
	scanf("%lf %lf",&e,&x);
	double product=1;
	int i=2;
	do
	{
		product+=pow(-1,i+1)*pow(x,(i-1)*2)/f((i-1)*2);
		i++;
	}
	while(fabs(pow(-1,i+1)*pow(x,(i-1)*2)/f((i-1)*2))>=e);
	printf("%f",product);
	return 0;
}