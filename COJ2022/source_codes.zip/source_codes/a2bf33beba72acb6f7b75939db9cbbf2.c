#include <stdio.h>
int main(void)
{
    int n, max, k, t;
    scanf("%d", &n);
    int numbers[n];
    for(int i=0; i<n; i++)
    {
        scanf("%d", &numbers[i]);
    }
    for(int i=0; i<n-1; i++)
    {
        max = numbers[i];
        for(int j=i+1; j<n; j++)
        {
            if(numbers[j]>max)
            {
                max = numbers[j];
                k = j;
            }
        }
        if(max!=numbers[i]);
        {
            t=numbers[k];
            numbers[k]=numbers[i];
            numbers[i]=t;
        }
    }
    for(int i=0; i<n; i++)
    {
        printf("%d ", numbers[i]);
    }
}