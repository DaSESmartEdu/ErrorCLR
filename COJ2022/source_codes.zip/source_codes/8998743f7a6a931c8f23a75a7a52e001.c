#include<stdio.h>
int main()
{
    int n;
    int i=1;
    double k=1;
    double q;
    scanf("%d",&n);
    while(i<=n){
     k*=i;
     q+=k;
     i++;
    }
    printf("%0f\n",q);
    return 0;
}