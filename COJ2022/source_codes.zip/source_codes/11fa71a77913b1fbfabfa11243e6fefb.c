#include <stdio.h>
#include <string.h>
int main()
{
  int k;
  scanf("%d",&k);
  getchar();     
  char b[1000];
  scanf("%s",&b);
  while(k>26)
  {
  k-=26;
  }
 int x=strlen(b);
 for(int i=0;i<x;i++)
 {
   if(b[i]>='a'&&b[i]<='z')
  {
   if(b[i]+k>'z') b[i]=b[i]+(k-26);
   else b[i]+=k;
  }
 }
 puts(b);
  return 0;
}