#include <stdio.h>
#include <math.h>
int main()
{
    int n;
    scanf("%d",&n);
    int i;
    i=1;
    float sum;
    sum=0;
    for(i=1;i<=n;i++){
        sum=sum+sqrt(i);
    }
    printf("%.2lf",sum);
    return 0;
}