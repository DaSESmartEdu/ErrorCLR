#include<stdio.h>
int main(){
    int n;
    scanf("%d",&n);
    for(int i=0;i<n;i++){
        double a[n];
        scanf("%lf",&a[i]);
        if(a[i]>=90){
            printf("A ");
        }
        else if(a[i]<90&&a[i]>=80){
            printf("B ");
        }
        else if(a[i]<80&&a[i]>=70){
            printf("C ");
        }
        else if(a[i]<70&&a[i]>=60){
            printf("D ");
        }
        else printf("E");
    }
    return 0;
}