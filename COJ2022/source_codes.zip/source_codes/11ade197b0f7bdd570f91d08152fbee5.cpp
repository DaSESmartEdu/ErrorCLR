#include <iostream>
using namespace std;
class Life{
public:
    void init();
    void update();
    void print();
private:
    int neighbor_count(int xx,int yy);
    int mat[8][8];
    int k;
    int x,y;
};
void Life::init(){
    int i,j;
    for(i=0;i<8;i++){
        for(j=0;j<8;j++){
            mat[i][j]=0;
        }
    }
    cin >> k;
    cin >> x >> y;
    while(x!=-1&&y!=-1){
        mat[x][y]=1;
        cin >> x >> y;
    }
}
int Life::neighbor_count(int xx,int yy){
    int num=0;
    for(int i=xx-1; i<=xx+1;i++){
        for(int j=yy-1;j<=yy+1;j++){
            num+=mat[i][j];
        }
    }
    num-=mat[xx][yy];
    return num;
}
void Life::update(){
    int tem_mat[8][8];
    int i,j,num;
    for(i=0;i<8;i++){
        for(j=0;j<8;j++){
            tem_mat[i][j]=0;
        }
    }
    while(k--){
        for(i=1;i<7;i++){
            for(j=1;j<7;j++){
                num=neighbor_count(i,j);
                if(mat[i][j]==1){
                    if(num==2||num==3){
                        tem_mat[i][j]=1;
                    }
                    else {
                        tem_mat[i][j]=0;
                    }
                }
                else {
                    if(num==3){
                        tem_mat[i][j]=1;
                    }
                    else {
                        tem_mat[i][j]=0;
                    }
                }
            }
        }
        for(i=1;i<7;i++){
            for(j=1;j<7;j++){
                mat[i][j]=tem_mat[i][j];
            }
        }
    }
}
void Life::print(){
    int i,j;
    for(i=1;i<7;i++){
        for(j=1;j<7;j++){
            if(j==6){
                cout << mat[i][j] << endl;
            }
            else {
                cout << mat[i][j] << " ";
            }
        }
    }
}
int main(){
    Life life;
    life.init();
    life.update();
    life.print();
    return 0;
}