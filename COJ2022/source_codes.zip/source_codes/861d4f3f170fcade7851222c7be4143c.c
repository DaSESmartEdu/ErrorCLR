#include <stdio.h>
int main()
{
    int N=0,i;
    int grade;
    scanf("%d/n",&N);
    for(i=0;i<N;i++)
    {
      scanf("%d",&grade);
    if(grade>=90)
    {
       printf("A "); }
    else if(grade>=80) 
    {
        printf("B ");}
    else if(grade>=70)
    {
        printf("C ");}
    else if(grade>=60)
    {
        printf("D ");}  
    else
    {
        printf("E ");}          
    }
    return 0;
}