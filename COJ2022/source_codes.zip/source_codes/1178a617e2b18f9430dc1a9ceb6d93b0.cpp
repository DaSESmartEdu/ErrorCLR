#include <stdio.h>
int main ()
{
	int t;
	scanf("%d",&t);
	int h,m,s;
	if(t==0)
		printf("0:0:0");
	else
	{
		s=t%60;
		m=(t/60)%60;
		h=((t/60)-m)/60;
		printf("%d:%d:%d",h,m,s);
	}
	return 0;
}