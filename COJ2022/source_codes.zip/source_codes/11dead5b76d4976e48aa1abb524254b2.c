#include <stdio.h>
int main()
{
	int n,j,i=0,t;
	scanf("%d",&n);
	int num[n];
	for(i=0;i<n;i++)
	{
		scanf("%d",&num[i]);
	}
	for(i=0;i<n;i++)
	{
		for(j=i+1;j<n;j++)
		{
			if(num[i]<num[j])
			{
				t=num[i];
				num[i]=num[j];
				num[j]=t;
			}
		}
	}
	printf("%d",num[0]);
	for(i=1;i<n;i++)
	{
		printf("% d",num[i]);
	}
	return 0;
}