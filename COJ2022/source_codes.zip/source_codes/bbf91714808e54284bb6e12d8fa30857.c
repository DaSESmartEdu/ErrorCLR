#include <stdio.h>
int prime( int p ){
    if (p<2) return 0;
    int isPrime = 1;
    for (int i=2; i<p; i++){
        if(p%i==0){
            isPrime = 0;
            break;
        }
    }
    return isPrime;
}
int PrimeSum( int m, int n ){
    int s=0;
    for (int i=m; i<=n; i++){
        if(prime(i)) s+=i;
    }
    return s;
}
int main(){
    int m, n;
    scanf("%d %d", m, n);
    printf("%d", PrimeSum(m, n));
    return 0;
}