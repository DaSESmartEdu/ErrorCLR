#include<iostream>
using namespace std;
#include<stdio.h>
void PrintMatrix(int **MatrixA, int N)
{
    for(int i=0;i<N;i++)
        {
            for(int j=0;j<N;j++)
            {
                if(j==N-1)
                {
                    printf("%d",MatrixA[i][j]);
					printf("\n");
                }
                else
                printf("%d ",MatrixA[i][j]);
            }
        }
}
int add(int** MatrixA, int** MatrixB, int** MatrixResult, int MatrixSize )
{   
    for ( int o = 0; o < MatrixSize; o++)
    {
        for ( int p = 0; p < MatrixSize; p++)
        {
            MatrixResult[o][p] =  MatrixA[o][p] + MatrixB[o][p];
        }
    }
    return 0;
}
int sub(int** MatrixA, int** MatrixB, int** MatrixResult, int MatrixSize )
{   
    int q=0,r=0;
    for ( q = 0; q < MatrixSize; q++)
    {
        for (  r = 0; r < MatrixSize; r++)
        {
            MatrixResult[q][r] =  MatrixA[q][r] - MatrixB[q][r];
        }
    }
    return 0;
}
void strassen(int N, int** MatrixA, int** MatrixB, int** MatrixC)
{
    if(N<=0) 
    {
        return;
    }
    else if (N == 1)
    {
        MatrixC[0][0] = MatrixA[0][0]*MatrixB[0][0];
        return;
    }
    else if (N<=128)
    {
        for(int i=0;i<N;i++)
        {
            for(int j=0;j<N;j++)
            {
                for(int k=0;k<N;k++)
                {
                    MatrixC[i][j]+=MatrixA[i][k]*MatrixB[k][j];
                }
            }
        }
        return;
    }
    int** MatrixA11;
	int** MatrixA12;
	int** MatrixA21;
	int** MatrixA22;
	int** MatrixB11;
	int** MatrixB12;
	int** MatrixB21;
	int** MatrixB22;
	int** MatrixC11;
	int** MatrixC12;
	int** MatrixC21;
	int** MatrixC22;
    MatrixA11 = new int*[N/2];
	MatrixA12 = new int*[N/2];
	MatrixA21 = new int*[N/2];
	MatrixA22 = new int*[N/2];
	MatrixB11 = new int*[N/2];
	MatrixB12 = new int*[N/2];
	MatrixB21 = new int*[N/2];
	MatrixB22 = new int*[N/2];
	MatrixC11 = new int*[N/2];
	MatrixC12 = new int*[N/2];
	MatrixC21 = new int*[N/2];
	MatrixC22 = new int*[N/2];
    for (int i = 0; i < N/2; i++)
	{
		MatrixA11[i] = new int[N/2];
		MatrixA12[i] = new int[N / 2];
		MatrixA21[i] = new int[N / 2];
		MatrixA22[i] = new int[N / 2];
		MatrixB11[i] = new int[N / 2];
		MatrixB12[i] = new int[N / 2];
		MatrixB21[i] = new int[N / 2];
		MatrixB22[i] = new int[N / 2];
		MatrixC11[i] = new int[N / 2];
		MatrixC12[i] = new int[N / 2];
		MatrixC21[i] = new int[N / 2];
		MatrixC22[i] = new int[N / 2];
	}
	for (int i = 0; i < N / 2; i++)
    {
		for (int j = 0; j < N / 2; j++)
        {
			MatrixA11[i][j] = MatrixA[i][j];
			MatrixA12[i][j] = MatrixA[i][j + N / 2];
			MatrixA21[i][j] = MatrixA[i + N / 2][j];
			MatrixA22[i][j] = MatrixA[i + N / 2][j + N / 2];
			MatrixB11[i][j] = MatrixB[i][j];
			MatrixB12[i][j] = MatrixB[i][j + N / 2];
			MatrixB21[i][j] = MatrixB[i + N / 2][j];
			MatrixB22[i][j] = MatrixB[i + N / 2][j + N / 2];
		}
	}
	int** MatrixS1 = new int*[N / 2];    
	int** MatrixS2 = new int*[N / 2];
	int** MatrixS3 = new int*[N / 2];
	int** MatrixS4 = new int*[N / 2];
	int** MatrixS5 = new int*[N / 2];
	int** MatrixS6 = new int*[N / 2];
	int** MatrixS7 = new int*[N / 2];
	int** MatrixS8 = new int*[N / 2];
	int** MatrixS9 = new int*[N / 2];
	int** MatrixS10 = new int*[N / 2];
	for (int i = 0; i < N / 2; i++)
	{
		MatrixS1[i] = new int[N / 2];
		MatrixS2[i] = new int[N / 2];
		MatrixS3[i] = new int[N / 2];
		MatrixS4[i] = new int[N / 2];
		MatrixS5[i] = new int[N / 2];
		MatrixS6[i] = new int[N / 2];
		MatrixS7[i] = new int[N / 2];
		MatrixS8[i] = new int[N / 2];
		MatrixS9[i] = new int[N / 2];
		MatrixS10[i] = new int[N / 2];
	}
	int** MatrixP1 = new int*[N / 2];
	int** MatrixP2 = new int*[N / 2];
	int** MatrixP3 = new int*[N / 2];
	int** MatrixP4 = new int*[N / 2];
	int** MatrixP5 = new int*[N / 2];
	int** MatrixP6 = new int*[N / 2];
	int** MatrixP7 = new int*[N / 2];
	for (int i = 0; i < N / 2; i++)
	{
		MatrixP1[i] = new int[N / 2];
		MatrixP2[i] = new int[N / 2];
		MatrixP3[i] = new int[N / 2];
		MatrixP4[i] = new int[N / 2];
		MatrixP5[i] = new int[N / 2];
		MatrixP6[i] = new int[N / 2];
		MatrixP7[i] = new int[N / 2];
	}
    sub(MatrixB12, MatrixB22, MatrixS1,N/2);
    strassen(N/2,MatrixA11, MatrixS1, MatrixP1);
    add(MatrixA11, MatrixA12, MatrixS2,N/2);
    strassen(N/2,MatrixS2, MatrixB22, MatrixP2);
    add(MatrixA21, MatrixA22, MatrixS3,N/2);
    strassen(N/2,MatrixS3, MatrixB11, MatrixP3);
    sub(MatrixB21, MatrixB11, MatrixS4,N/2);
    strassen(N/2,MatrixA22, MatrixS4, MatrixP4);
    add(MatrixA11, MatrixA22, MatrixS5,N/2);
    add(MatrixB11, MatrixB22, MatrixS6,N/2);
    strassen(N/2,MatrixS5, MatrixS6, MatrixP5);
    sub(MatrixA12, MatrixA22, MatrixS7,N/2);
    add(MatrixB21, MatrixB22, MatrixS8,N/2);
    strassen(N/2,MatrixS7, MatrixS8, MatrixP6);
    sub(MatrixA11, MatrixA21, MatrixS9,N/2);
    add(MatrixB11, MatrixB12, MatrixS10,N/2);
    strassen(N/2,MatrixS9, MatrixS10, MatrixP7);
    add(MatrixP5, MatrixP4, MatrixC11,N/2); 
	sub(MatrixC11, MatrixP2, MatrixC11,N/2);
	add(MatrixC11, MatrixP6, MatrixC11,N/2);
	add(MatrixP1, MatrixP2, MatrixC12,N/2);
	add(MatrixP3, MatrixP4, MatrixC21,N/2);	
	add(MatrixP5, MatrixP1, MatrixC22,N/2);	
	sub(MatrixC22, MatrixP3, MatrixC22,N/2);
	sub(MatrixC22, MatrixP7, MatrixC22,N/2);
	for (int i = 0; i < N / 2; i++){
		for (int j = 0; j < N / 2; j++){
			MatrixC[i][j] = MatrixC11[i][j];
			MatrixC[i][j+N/2] = MatrixC12[i][j];
			MatrixC[i+N/2][j] = MatrixC21[i][j];
			MatrixC[i+N/2][j+N/2] = MatrixC22[i][j];
		}
	}
    delete MatrixA11;delete MatrixA12;delete MatrixA21;delete MatrixA22;
    delete MatrixB11;delete MatrixB12;delete MatrixB21;delete MatrixB22;
    delete MatrixC11;delete MatrixC12;delete MatrixC21;delete MatrixC22;
    delete MatrixS1;delete MatrixS2;delete MatrixS3;delete MatrixS4;delete MatrixS5;
    delete MatrixS6;delete MatrixS7;delete MatrixS8;delete MatrixS9;delete MatrixS10;
}
int main()
{
    int i,j,k,t;
    int n,m;
    scanf("%d %d",&n,&m);
    int** MatrixA = new int *[m];
	int** MatrixB = new int *[m];
	int** MatrixC = new int *[m];
    for (int i = 0; i < m; i++)  
	{
		MatrixA[i] = new int[m];
		MatrixB[i] = new int[m];
		MatrixC[i] = new int[m];
	}
    for(k=0;k<n;k++)
    {
        for(i=0;i<m;i++)
        {
            for(j=0;j<m;j++)
            {
                scanf("%d",&MatrixA[i][j]);
            }
        }
        for(i=0;i<m;i++)
        {
            for(j=0;j<m;j++)
            {
                scanf("%d",&MatrixB[i][j]);
                MatrixC[i][j] = 0;
            }
        }
        strassen(m,MatrixA,MatrixB,MatrixC);
        PrintMatrix(MatrixC, m);
    }
    return 0;
}