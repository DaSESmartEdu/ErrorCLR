#include<cstdio>
#include<algorithm>
#include<iostream>
#include<cmath>
#include<string>
#include<cstring>
using namespace std;
typedef long long ll;
const int maxv = 1e5 + 3;
const int maxn = 1e2 + 2;
int n, m;
int a[maxv];
int dp[maxv][maxn],sum[maxv];
int main()
{
	scanf("%d %d", &n, &m);
	for (int i = 1; i <= n; i++)
	{
		scanf("%d", &a[i]);
	}
	dp[0][0] = 0;
	dp[0][1] = 0;
	for (int i = 1; i <= n; i++)
	{
		dp[i][1] = dp[i - 1][1] + a[i];
	}
	sum[0] = 0;
	for (int i = 1; i <= n; i++)
	{
		sum[i] = sum[i - 1] + a[i];
	}
	for (int i = 2; i <= n; i++)
	{
		for (int j = 2; j <= m; j++)
		{
			int maxx = max(dp[1][j - 1], sum[i] - sum[1]);
			for (int k = 2; k < i; k++)
			{
				int tmp = max(dp[k][j - 1], sum[i] - sum[k]);
				maxx = min(maxx, tmp);
			}
			int x2 = max(dp[i - 1][j], a[i]);
			dp[i][j] = max(maxx, x2);
		}
	}
	printf("%d\n", dp[n][m]);
	return 0;
}