#include<stdio.h>
#include<stdlib.h>
struct listnode
{
    int data;
    struct listnode *next;
};
struct listnode* readlist()
{
    struct listnode* head,*end;
    head=end=NULL;
    int tmp;
    while(scanf("%d",&tmp)&&tmp!=-1)
    {
        struct listnode *q=(struct listnode*)malloc(sizeof(struct listnode));
        q->data=tmp;
        q->next=NULL;
        if(head==NULL)
        {
            head=q;
        }
        else
        {
            end->next=q;
        }
        end=q;
        end->next=NULL;
    }
    return head;
}
struct listnode* redelete(struct listnode* head,int m)
{
    struct listnode *head1,*end1;
    head1=end1=NULL;
    int data;
    while(head!=NULL)
    {
        data=head->data;
        if(data!=m)
        {
            struct listnode *q=(struct listnode*)malloc(sizeof(struct listnode));
            q->data=data;
            q->next=NULL;
            if(head1==NULL)
            {
                head1=q;
            }
            else
            {
                end1->next=q;
            }
            end1=q;
            end1->next=NULL;
        }
        head=head->next;
    }
    return head1;
}
void prin(struct listnode*head)
{
    struct listnode*q;
    q=head;
    while(q!=NULL)
    {
        printf("%d ",q->data);
        q=q->next;    
    }
}
int main()
{
    int m;
    struct listnode *head;
    head=readlist();
    scanf("%d",&m);
    head=redelete(head,m);
    prin(head);
}