#include <stdio.h>
#include <stdlib.h>
int* multiply_naive(int* A, int* B, int M){
    int* product = (int*)malloc(sizeof(int)*M*M);
    for (int i=0; i<M; ++i){
        for (int j=0; j<M; ++j){
            product[i*M+j] = 0;
            for (int k=0; k<M; ++k){
                product[M*i+j] += A[M*i+k] * B[M*k+j];
            }
        }
    }
    return product;
}
int main(){
    int N, M;
    scanf("%d %d", &N, &M);
    for (int cnt=0; cnt<N; ++cnt){
        int* matA = (int*)malloc(sizeof(int)*M*M);
        int* matB = (int*)malloc(sizeof(int)*M*M);
        for (int i=0; i<M*M; ++i){
             scanf("%d", &matA[i]);
        }
        for (int i=0; i<M*M; ++i){
             scanf("%d", &matB[i]);
        }
        int* matC = multiply_naive(matA, matB, M);
        free(matA);
        free(matB);
        for (int i=0; i<M; ++i){
            int idx_product=M*i;
            printf("%d", matC[idx_product++]);
            for (int j=1; j<M; ++j){
                printf(" %d", matC[idx_product++]);
            }
            printf("\n");
        }
    }
    return 0;
}