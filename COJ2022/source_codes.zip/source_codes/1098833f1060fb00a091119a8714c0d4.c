#include <stdio.h>
#include <math.h>
int prime( int p );
void Goldbach( int n );
int main(void)
{
    int m,n,i;
    scanf("%d", &m);
    scanf("%d", &n);
    for(i=m;i<=n;i++)
    {   
        if(i % 2 == 0)
            Goldbach(i);
    }
    return 0;
}
int prime(int p)
{
    int isPrime = 1;
    int i;
    if(p == 1)
    {
        isPrime = 0;
    }
    for(i = 2; i <= sqrt(p); i++)
    {
        if(p % i == 0)
        {
            isPrime = 0;
            break;
        }
    }
    return isPrime;
}
void Goldbach(int n)
{
    int i,j;
    for(i = 2; i <= n; i++)
    {
        j = n - i;
        if(prime(i)&&prime(j))
        {
            printf("%d=%d+%d\n", n, i, j);
            break;
        }
    }
}