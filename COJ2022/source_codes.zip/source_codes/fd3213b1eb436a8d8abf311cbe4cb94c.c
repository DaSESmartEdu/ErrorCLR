#include<stdio.h>
int main()
{
    int one,two,three,n,sum,i;
    scanf("%d",&n);
    one=1;
    two=0;
    three=0;
    sum=1;
    i=1;
    while(sum<n)
    { 
      three=three+two;
      two=one;
      one=three;
      sum=one+two+three;
      i++;
      printf("%d %d\n",sum,i);
    }
    printf("%d",i);
    return 0;
}