#include <stdio.h>
int main ()
{
    int n,i;
    scanf("%d",&n);
    double a[n];
    for(i=1;i<=n;i++)
    {
        scanf("%lf",&a[i]);
        if(a[i]>=90 && a[i]<=100)
        {
            printf(" A");
        }
        else if(a[i]>=80 && a[i]<=90)
        {
            printf(" B");
        }
        else if(a[i]>=70)
        {
            printf(" C");
        }
        else if(a[i]>=60)
        {
            printf(" D");
        }
        else
        {
            printf(" E");
        }
    }
    return 0;
}