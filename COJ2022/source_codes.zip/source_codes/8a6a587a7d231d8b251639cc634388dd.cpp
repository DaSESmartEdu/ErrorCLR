#include <iostream>
#include <string>
#include <math.h>
using namespace std;
struct point
{
    int x;
    int y;
    int length;
};
void QuickSort(point arr[], int t, int w)
{
    if (t >= w)
    {
        return;
    }
    int i, j;
    int x;
    i = t, j = w, x = arr[i].length;
    while (i < j)
    {
        while (i < j && x < arr[j].length)
        {
            j--;
        }
        if (i < j)
        {
            arr[i] = arr[j];
            i++;
        }
        while (i < j && x > arr[i].length)
        {
            i++;
        }
        if (i < j)
        {
            arr[j] = arr[i];
            j--;
        }
    }
    arr[i].length = x;
    QuickSort(arr, t, i - 1);
    QuickSort(arr, i + 1, w);
}
int main()
{
    int n;
    cin >> n;
    point list[n];
    for (int i = 0; i < n; i++)
    {
        int a, b;
        cin >> a >> b;
        list[i].x = a;
        list[i].y = b;
        list[i].length=a*a+b*b;
    }
    point list2[n];
    for (int i=0;i<n;i++)
    {
        list2[i].x = list[i].x;
        list2[i].y = list[i].y;
        list2[i].length=list[i].length;
    }
    int k;
    cin >> k;
    QuickSort(list, 0, n - 1);
    int ans=list[k-1].length;
    for (int i = 0; i < n; i++)
    {
        if(list2[i].length == ans)
        {
            k=i;
            break;
        }
    }
    cout << list2[k - 1].x << " " << list2[k - 1].y << endl;
    return 0;
}