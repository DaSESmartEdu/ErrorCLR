#include <stdio.h>
#include <string.h>
struct word
{
    char w;
    int t;
} dict1[128], dict2[128];
int Min(struct word a, struct word b)
{
    if (a.t < b.t)return a.t;
    else return b.t;
}
int Strlen(char a[])
{
    int strlen = 0;
    int i;
    for (i = 0; a[i] != '\0'; i++)strlen++;
    return strlen;
}
void Getline(char* str, int N)
{
    char ch;
    int i;
    for (i = 0, ch = '\0'; ch != '\n'; ++i)
    {
        ch = getchar();
        if (i >= N)
        {
            continue;
        }
        if (ch == '\n' || i == N - 1)
        {
            str[i] = '\0';
            continue;
        }
        str[i] = ch;
    }
}
int main()
{
    int i;
    char a[1001], b[1001];
    for (i = 0; i < 128; i++)
    {
        dict1[i].t = 0;
        dict1[i].w = i;
        dict2[i].t = 0;
        dict2[i].w = i;
    }
    gets(a);
    gets(b);
    for (i = 0; i < Strlen(a); i++) dict1[a[i]].t++;
    for (i = 0; i < Strlen(b); i++) dict2[b[i]].t++;
    int c = 0;
    for (i = 0; i < 128; i++) c += Min(dict1[i], dict2[i]);
    if ((c * 1.0) / Strlen(a) > 0.5) printf("Yes");
    else printf("No");
}