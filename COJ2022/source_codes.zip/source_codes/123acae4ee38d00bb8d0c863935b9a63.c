#include <stdio.h>
#include<malloc.h>
#pragma warning(disable:4996)
struct ListNode {
	int data;
	struct ListNode* next;
};
typedef struct ListNode list;
void push_back(list** p,int data)
{
	if (*p == NULL)
	{
		*p = (list*)malloc(sizeof(list));
		(*p)->data = data;
		(*p)->next = NULL;
		return;
	}
	else
	{
		list* end;
		for (end = *p; end->next != NULL; end = end->next);
		list* temp = (list*)malloc(sizeof(list));
		temp->data = data;
		temp->next = NULL;
		end->next = temp;
	}
}
void empty(list* p)
{
	if (p == NULL)return;
	list* pnext = p->next;
	while (pnext != NULL)
	{
		free(p);
		p = pnext;
		pnext = p->next;
	}
	free(p);
}
struct ListNode* readlist()
{
	list* head = (list*)malloc(sizeof(list));
	list* end = head;
	int data;
	scanf("%d", &data);
	if (data == -1)return NULL;
	head->data = data;
	head->next = NULL;
	while (1)
	{
		scanf("%d", &data);
		if (data == -1)return head;
		else
		{
			list* temp = (list*)malloc(sizeof(list));
			temp->data = data;
			temp->next = NULL;
			end->next = temp;
			end = temp;
		}
	}
}
struct ListNode* getodd(struct ListNode** p)
{
	list* iter = NULL,* odd = NULL,* even =NULL;
	for (iter = *p; iter != NULL; iter = iter->next)
	{
		if (iter->data % 2 == 1)push_back(&odd, iter->data);
		else push_back(&even, iter->data);
	}
	empty(*p);
	*p = even;
	return odd;
}
struct ListNode* deletem(struct ListNode* L, int m)
{
	while (L->data == m)
	{
		list* l = L;
		L = L->next;
		free(l);
		if (L == NULL)return NULL;
	}
	for (list* it = L; it->next != NULL; it = it->next)
	{
		if (it->next->data == m)
		{
			list* l = it->next;
			it->next = it->next->next;
			free(l);
			if (it->next == NULL)break;
		}
	}
	return L;
}
void listprint(list* p)
{
	for (list* i = p; i != NULL; i = i->next)printf("%d ", i->data);
}
int main()
{
	list* p;
	p = readlist();
	int m;
	scanf("%d", &m);
	p = deletem(p, m);
	listprint(p);
	empty(p);
}