#include<stdio.h>
void cao(float x)
{   int a;
float b;
       a=(int)x;
       b=x-(float)a;
       printf("%d %.3f",a,b);
}
int main()
{
	float x;
	scanf("%f",&x);
	cao(x);
	return 0;
}