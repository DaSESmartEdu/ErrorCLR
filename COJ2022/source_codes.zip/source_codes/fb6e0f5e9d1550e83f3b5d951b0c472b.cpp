#include<iostream>
using namespace std;
const int maxheap = 30;
typedef struct pos{
	char x, y;
	bool operator >(const pos& temp) const{
		if ( x > temp.x )   return true;
		if ( x < temp.x )	return false;
		if ( y > temp.y )   return true;
		if ( y <= temp.y )   return false;
	};
}pos;
class Heap{
public:
	Heap();
	~Heap();
	void init();
	void build();
	void insert(int temp_pos);
	void heap_sort();
	void extract_max();
	void heapify(int i);
private:
	int size;
	int count;
	int sort_index;
	pos *entry;
	pos *sorted; 
};
Heap::Heap(){
}
Heap::~Heap(){
}
void Heap::extract_max(){
	sorted[sort_index++] = entry[0];
	entry[0] = entry[--size];
	heapify(0);
}
void Heap::heap_sort(){
	for (int i=0; i<count; i++)
		extract_max();
	for (int i=count-1; i>=0; i--)
	{
		cout << "(" << sorted[i].x << "," << sorted[i].y << ")";
		cout << endl;
	}
}
void Heap::init(){
	int i;
	cin >> size;
	count = size;
	sorted = new pos[size];
	sort_index = 0;
	entry = new pos[size];
	for (i=0; i<size; i++)
		cin >> entry[i].x >> entry[i].y;
}
void Heap::heapify(int i){
	int l = 2*i + 1;
	int r = 2*i + 2;
	int max;
	if ( l < size && entry[l] > entry[i] )
		max = l;
	else max = i;
	if ( r < size && entry[r] > entry[max] )
		max = r;
	if ( max != i )
	{
		pos temp = entry[i];
		entry[i] = entry[max];
		entry[max] = temp;
		heapify(max);
	}
}
void Heap::build(){
	for ( int i=size/2-1; i>=0; i--)
	{
		heapify(i);
	}
}
int main()
{
	Heap myheap;
	myheap.init();
	myheap.build();
	myheap.heap_sort();
	return 0; 
} 