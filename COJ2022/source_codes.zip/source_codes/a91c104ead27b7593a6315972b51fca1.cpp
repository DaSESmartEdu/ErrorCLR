#include<iostream>
using namespace std;
int main()
{
	int a ;
	cin >> a;
	if(a == 3 || a==4)
		cout<<4;
	else if( a ==5 || a==7)
		cout<<3;
	else
		cout<<1;
}