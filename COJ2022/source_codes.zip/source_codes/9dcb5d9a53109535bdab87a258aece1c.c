#include <stdio.h>
#include <math.h>
double fact(int n);
int main()
{
    double x,y,sum;
    scanf("%lf",&x);
    y=2;
    sum=1+x;
    while (pow(x,y)/fact(y)>=0.0000099)
    {
        sum+=pow(x,y)/fact(y);
        y++;
    }
    printf("%.4f",sum);
    return 0;
}
double fact(int n)
{
    int i;
    double m=1;
    for(i=1;i<=n;i++)
    {
        m*=i;
    }
    return m;
}