#include <stdio.h>
int main()
{
    int denominator,i,n,flag,a;
    double item,sum;
    printf ("Enter n:");
    scanf ("%d", &n);
    denominator=1;
    sum=0;
    a=1;
    flag=1;
    for(i=1; i<=n; i++)
    {
        item=a*1.0/denominator;
        sum = sum + flag*item;
        denominator=denominator+2;
        flag=-flag;
        a=a+1;
    }
    printf ("%.6lf\n",sum);
    return 0;
}