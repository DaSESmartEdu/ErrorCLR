#include<stdio.h>
int main()
{
    float n,m;
    scanf("%d %d",&n,&m);
    if(n<1*m){
        printf("normal");
    }
    if(1*m<=n, n<1.5*m){
        printf("200");
    }
    if(1.5*m<=n){
        printf("revoke");
    }
    return 0;
}