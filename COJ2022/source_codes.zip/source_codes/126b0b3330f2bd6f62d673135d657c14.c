#include <stdio.h>
int search( int n )
{
    int s[8]={121,144,225,400,441,484,676,900}; 
    int ret=0;
    for(int j=101;j<=n;j++)
    {
        for(int k=0;k<8;k++)
        {
            if(s[k]==j)ret++;
        }
    }
    return ret;
}
int main()
{
    int i;
    scanf("%d",&i);
    printf("%d",search(i));
    return 0;
}