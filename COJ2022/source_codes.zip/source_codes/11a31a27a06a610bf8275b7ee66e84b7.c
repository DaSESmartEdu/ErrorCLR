#include<stdio.h>
int fact(int n)
{
int product;
 if(n==1||n==2)
 product=1;
 else
 product=fact(n-1)+fact(n-2);
 return product;
}
int main()
{
    int n;
 scanf("%d",&n);
 printf("%d",fact(n));
 return 0;
}