#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
int main()
{
    int n,tmp=1;
    cin>>n;
    int x=n/2;
    for(int i=0;i<=n/2;i++)
    {
        for(int j=0;j<x;j++)
            cout<<' ';
        for(int j=0;j<tmp;j++)
            cout<<'*';
        cout<<endl;
        tmp+=2;
        x--;
    }
    tmp-=4;
    x+=2;
    for(int i=0;i<n/2;i++)
    {
        for(int j=0;j<x;j++)
            cout<<' ';
        for(int j=0;j<tmp;j++)
            cout<<'*';
        cout<<endl;
        tmp-=2;
        x++;
    }
    return 0;
}