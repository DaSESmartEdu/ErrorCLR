#include <stdio.h>
#define N 100
int main()
{
    char a[N];
    int i,k=0;
    int len=0;
    for(i=0;i<N;i++){
        scanf("%c",&a[i]);
        len++;
        if(a[i]=='\n'){
            break;
        }
    }
    for(i=0;i<len-1;i++){
        if(a[i]>65&&a[i]<91){
            if(a[i]!=69&&a[i]!=73&&a[i]!=79&&a[i]!=85){
                k++;
            }
        }
    }
    printf("%d",k);
    return 0;
}