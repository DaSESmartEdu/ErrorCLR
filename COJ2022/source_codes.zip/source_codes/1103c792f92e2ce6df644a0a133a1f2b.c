#include<stdio.h>
#include<string.h>
void strmcpy( char *t, int m, char *s )
{
    int n,i;
    memset(s,0,sizeof(s));
    n=strlen(t);
    if(m>n)
    {
        *s=NULL;
    }
    else
    {
        for(i=m-1;i<n;i++)
        {
            s[i-(m-1)]=t[i];
        }
    }
}
int main()
{
    char t[20], s[20];
    int m;
    scanf("%d\n", &m);
    gets(t);
    strmcpy( t, m, s );
    printf("%s\n", s);
}