#include <stdio.h>
void CountOff(int n, int m, int out[] );
int main()
{
    int out[1000],n,m,i;
    scanf("%d %d",&n,&m);
    for(i=0;i<n;i++){
        out[i]=0;
    }
    CountOff( n, m, out );
    for(i=0;i<n;i++)
        printf("%d ",out[i]);
    return 0;
}
void CountOff( int n, int m, int out[] )
{
int ind=-1,cnt=0,i=0;
for(i=1;i<=n;i++)
{
cnt=0;
while(cnt<m)
        {
            ind++;
            if(ind==n) ind=0;
            if(out[ind]==0)
            {
                cnt++;
            }
        }
        out[ind]=i;
    }
}