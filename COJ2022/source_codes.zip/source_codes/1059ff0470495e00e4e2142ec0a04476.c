#include<stdio.h>
void StringCount(char s[]){
    int i=0,a=0,b=0,c=0,d=0;
    while(s[i]!='\0'){
        if((s[i]>='A'&&s[i]<='Z')||(s[i]>='a'&&s[i]<='z'))a++;
        else if(s[i]=='\n'||s[i]==' ')b++;
        else if(s[i]>='0'&&s[i]<='9')c++;
        else d++;
        i++;
    }
    printf("%d %d %d %d",a,b,c,d);
}
int main(){
    char s[100]={0};
    int i=0;
    do{
        s[i]=getchar();
    }while(s[i++]!=EOF);
    StringCount(s);
    return 0;
}