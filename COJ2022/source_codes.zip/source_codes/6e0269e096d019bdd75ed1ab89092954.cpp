#include<iostream>
using namespace std;
enum Error_code{success,no};
typedef struct Binary_node
{
    char data;
    struct Binary_node *left;
    struct Binary_node *right;
    Binary_node();
    Binary_node(char &x);
}TreeNode;
Binary_node::Binary_node()
{
    left=NULL;
    right=NULL;
}
Binary_node::Binary_node(char &x)
{
    data=x;
    left=NULL;
    right=NULL;
}
class Binary_tree{
    public:    
    TreeNode *root;
    Binary_tree();
    void inorder(void (*visit)(char&));
    void Build_Post(TreeNode* &aroot,string &postorder,int &index );
    protected:
    void recursive_inorder(TreeNode* &subroot,void (*visit)(char&));
    int count;
};
Binary_tree::Binary_tree()
{
    root=NULL;
    count=0;
}
void Binary_tree::Build_Post(TreeNode* &aroot,string &postorder,int &index)
{
    if(index>=0)
    {
        if(postorder[index]=='#')
        aroot=NULL;
        else 
        {
            aroot=new TreeNode;
            aroot->data=postorder[index];  
            Build_Post(aroot->right,postorder,--index);  
            Build_Post(aroot->left,postorder,--index);          
        }
    }
}
void Binary_tree::inorder(void (*visit)(char&))
{
    recursive_inorder(root,visit);
}
void Binary_tree::recursive_inorder(TreeNode* &subroot,void (*visit)(char&))
{
    if(subroot!=NULL)
    {
        recursive_inorder(subroot->left,visit);        
        (*visit)(subroot->data);
        recursive_inorder(subroot->right,visit);
    }
}
class Search_tree:public Binary_tree{
    public:    
    Error_code tree_search(TreeNode* &root,char &target);
    void remove(TreeNode* &root,char &target);
    private:   
    Error_code search_and_destroy(TreeNode* &subroot,char &target);
    TreeNode* search_for_node(TreeNode* &subroot,char &target);
    Error_code remove_root(TreeNode* &subroot);
};
TreeNode* Search_tree::search_for_node(TreeNode* &subroot,char &target){
    if(subroot==NULL||subroot->data==target)
    {
        cout<<subroot->data<<" ";
        return subroot;
    } 
    else if(subroot->data<target){
        cout<<subroot->data<<" ";
        return search_for_node(subroot->right,target);
    }
    else{
        cout<<subroot->data<<" ";
        return search_for_node(subroot->left,target);
    }
}
Error_code Search_tree::tree_search(TreeNode* &root,char &target)
{
    Error_code result=success;
    TreeNode *found=search_for_node(root,target);
    if(found==NULL)
    result=no;
    else 
    target=found->data;
    return result;
}
Error_code Search_tree::remove_root(TreeNode* &subroot)
{
    if(subroot==NULL)
    return no;
    TreeNode *delete_node=subroot;
    if(subroot->right==NULL)
    subroot=subroot->left;
    else if(subroot->left==NULL)
    subroot=subroot->right;
    else 
    {
        delete_node=subroot->left;
        TreeNode *parent=subroot;
        while(delete_node->right!=NULL)
        {
            parent=delete_node;
            delete_node=delete_node->right;
        }
        subroot->data=delete_node->data;
        if(parent==subroot)
        subroot->left=delete_node->left;
        else 
        parent->right=delete_node->left;       
    }
    delete delete_node;
    return success;
}
Error_code Search_tree::search_and_destroy(TreeNode* &subroot,char &target)
{
    if(subroot==NULL||subroot->data==target)
    return remove_root(subroot);
    else if(subroot->data>target)
    {
        return search_and_destroy(subroot->left,target);
    }
    else 
    return search_and_destroy(subroot->right,target);
}
void Search_tree::remove(TreeNode* &root,char &target)
{
    Error_code result=search_and_destroy(root,target);
    if(result==success)
    count--;
    else 
    cout<<"no";
}
void out(char &a)
{
    cout<<a<<" ";
}
int main()
{
    Search_tree t;
    string s;
    cin>>s;
    int length;
    length=s.size()-1;
    t.Build_Post(t.root,s,length);
    char a,b;
    cin>>a>>b;
    t.tree_search(t.root,a);
    cout<<'\b';
    cout<<endl;
    t.remove(t.root,b);
    t.inorder(out);
    cout<<'\b';
    return 0;
}