#include<stdio.h>
int powe(int flag, int n);
int main()
{
    int n, m, count, i, sum, j, flag, k, j1, j2;
    scanf("%d%d", &n, &m);
    count = 0;
    for (j = n; j<=m; j++) {
        sum = k = 0;
        i = 0;
        j1 = j2 = j;
        while (j1!=0) {
            j1 = j1/10;
            k += 1;
        }
        while (j2!=0) {
            flag = j2%10;
            j2 = j2/10;
            sum += powe(flag, k-i);
            i += 1;
        }
        if (sum == j) count += 1;
    }
    printf("%d", count);
}
int powe(int flag, int n){
    int i, an = 1;
    for (i = 0; i<n;i++) {
        an = flag * an;
    }
    return an;
}