#include <stdio.h>
#include <math.h>
int main()
{
    int a,n;
    scanf("%d %d",&a,&n);
    double x=0;
    for (int i=1;i<=n;i++)
    {
        x=(double)x + pow(10,i-1)*a;
    }
    printf("%lf",x);
    return 0;
}