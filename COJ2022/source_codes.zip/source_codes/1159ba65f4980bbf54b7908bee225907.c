#include <stdio.h>
#include <math.h>
int CountDigit( int number, int digit )
{
    int r=0;
    int k;
    while(number>0){
        k=number%10;
        number/=10;
        if(digit==k) r++;    
    }
    return r;
}
int CountDigit( int number, int digit );
int main()
{
    int num;
    int dig;
    int x;
    scanf("%d %d",&num,&dig);
    num=fabs(num);
    x=CountDigit(num,dig);
    printf("%d",x);
    return 0;
}