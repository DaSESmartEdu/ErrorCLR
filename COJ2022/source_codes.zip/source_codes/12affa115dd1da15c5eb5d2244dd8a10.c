#include<stdio.h>
int main()
{int n;
 scanf("%d",&n);
 int a[100];
 int b[100];
 int i;
 int j;
 for(i=1;i<=n;i++)
 {scanf("%d",&a[i]);}
 for(j=1;j<=n;j++)
 {scanf("%d",&b[j]);}
 for(i=1;i<=n;i++)
 {for(j=1;j<=n;j++)
 {if(a[i]==b[j])
 {a[i]=j;break;}
 }
 }
 for(i=1;i<=n;i++)
 {printf("%d ",a[i]);}
 return 0;
}