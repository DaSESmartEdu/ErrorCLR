#include <stdio.h>
#include <math.h>
int main()
{
    int n;
    scanf("%d",&n);
    double x,i;
    x=0;
    for(i=1;i<=n;i++)
    {
        x=x+sqrt(i);
    }
    printf("%.6lf",x);
    return 0;
}