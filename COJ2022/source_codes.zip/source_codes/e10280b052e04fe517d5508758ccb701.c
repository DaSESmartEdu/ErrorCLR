#include <stdio.h>
int even(int n);
int oddsum(int list[],int N);
int main(){
    int i,n,a[n];
    scanf("%d",&n);
    for(i=1;i<=n;i++)
    {scanf("%d",&a[n]);}
    printf("%d",oddsum(a,n));
    return 0;
}
int even(int n)
{
    if(n%2==0)
    return 1;
    else
    return 0;
}
int oddsum(int list[],int N)
{   int sum=0,i1;
    for(i1=1;i1<=N;i1++)
    {
        if(even(list[i1])==0)
        sum+=list[i1];
}       return sum;
}