#include <stdio.h>
int main(){
  int n,i,j,k,u;
  scanf("%d",&n);
  int a[10][10]={0};
  for (i=0;i<=n-1;i++){
    for(j=0;j<=n-1;j++){
      scanf("%d",&a[i][j]);
    }
  }
  int max[10]={0};
  for(i=0;i<n;i++){
    for(j=0;j<n;j++){
      if(max[i]<a[i][j])
        max[i]=a[i][j];
    }
  }
  int shifou=0;
  for(i=0;i<n;i++){
    for(j=0;j<n;j++){
      if(a[i][j]==max[i])
        break;
    }
    int bool=1;
    for(u=0;u<=n-1;u++){
      if(max[i]>a[u][j])
        bool=0;
    }
    if(bool==1) {
      printf("%d %d",i,j);
      shifou=1;
      break;
    }
  }
  if (shifou==0) printf("NO");
  return 0;
}