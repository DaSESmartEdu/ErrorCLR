#include <stdio.h>
int main()
{
    int x;
    float y;
    scanf("%d",&x);
    if (0 <= x <= 50)
    {
        y = 0.53 * (double)x;
    }
    else
    {
        y = 50 * 0.53 + (x - 50) * (0.53+0.05);
    }
    printf("%f", y);
    return 0;
}