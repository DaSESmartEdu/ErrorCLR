#include <stdio.h>
double fact(int n);
int main()
{
    int i,n;
    double e;
    scanf("%d",&n);
	e=1;
    for(i=1;i<=n;i++)
    {
        e=e+fact(i);
    }
    printf("%.lf",e);
    return 0;
}
double fact(int n)
{
    int i;
    double product;
    product =1;
    for(i=1;i<=n;i++)
    {
      product =product*i;
    }
    return product;
}