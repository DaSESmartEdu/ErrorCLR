#include<stdio.h>
#include<math.h>
int CountDigit(int number,int digit);
int main(){
    int number,digit;
    scanf("%d %d",&number,&digit);
    printf("%d",CountDigit(number,digit));
    return 0;
}
int CountDigit(int number,int digit){
    int sum=0,i=0,x;
    double n;
    if(number<0){
        number=-number;
    }
    while(number>0){
        n=number%10;
        if(n==digit){
            sum++;
        }
        number/=10;
        i++;
    }
    return sum;
}