#include<stdio.h>
#include<math.h>
int main()
{int x1,x2,y1,y2,z1,z2;
scanf("%d %d %d %d %d %d",&x1,&x2,&y1,&y2,&z1,&z2);
double a,b,c;
a=sqrt(pow(x1-y1,2)+pow(x2-y2,2));
b=sqrt(pow(y1-z1,2)+pow(y2-z2,2));
c=sqrt(pow(x1-z1,2)+pow(x2-z2,2));
double area,s,length;
if (a+b>c&&a+c>b&&b+c>a)
{
length=a+b+c;    
s=(a+b+c)/2.0;
area=sqrt(s*(s-a)*(s-b)*(s-c)); 
printf("%.2lf %.2lf",length,area);}
else {printf("impossible");}
return 0;
}