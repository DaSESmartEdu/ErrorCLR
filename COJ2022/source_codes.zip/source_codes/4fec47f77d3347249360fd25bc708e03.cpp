#include<iostream>
using namespace std;
int main()
{
    int n;
    cin>>n;
    int a[n][n];
    for(int i=0;i<n;i++)
    for(int j=0;j<n;j++)
    {
        cin>>a[i][j];
    }
    for(int i=0;i<n;i++)
    {
        int flag=0;
        int count=0;
        for(int j=0;j<n;j++)
        {
            if(a[j][0]==0)count++;
            else if(j!=i&&a[j][0]==1)
            {
                for(int t=0;t<n;t++)
                if(a[i][t]!=a[j][t])
                {
                    flag=1;
                    break;
                }
            }
        }
        if(flag==1||count==n-1);
        else
        {
            for(int j=0;j<n;j++)
            if(a[i][j]==1)
            cout<<j+1<<" ";
            break;
        }
    }
    return 0;
}