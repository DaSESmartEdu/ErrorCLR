#include <stdio.h>
int main()
{
    int a5,b2,c1;
    int money;
    int i=0;
    scanf("%d",&money);
    for (a5=1;a5<19;a5++)
    {
        for (b2=1;b2<=46;b2++)
        {
            for (c1=1;c1<=92;c1++)
            {
                if(5*a5+2*b2+c1==money)
                {
                    i=i+1;
                }
            }
        }
    }
    printf("%d",i);
    return 0;
	}