#include <stdio.h>
#include <math.h>
int main()
{
	int x1,y1,x2,y2,x3,y3;
	double p=0 , s=0 , a ,b ,c;
	scanf("%d %d %d %d %d %d",&x1,&y1,&x2,&y2,&x3,&y3);
	a =sqrt(pow(x2 - x1,2)+pow(y2 - y1,2));
	b =sqrt(pow(x3 - x1,2)+pow(y3 - y1,2));
	c =sqrt(pow(x3 - x2,2)+pow(y3 - y2,2));
	p = (a + b + c)/2;
	s =sqrt(p*(p-a)*(p-b)*(p-c));
	if ( (x2 - x1)*(y3 - y1)==(y2 - y1)*(x3 - x1))
	{
		printf("Impossible");
	}
	else if ((x3 - x1)*(y3 - y2)==(y3 - y1)*(x3 - x2))
	{
		printf("Impossible");
	}
	else
	{
		printf("%.2f %.2f",2*p,s);
	}
	return 0 ;
}