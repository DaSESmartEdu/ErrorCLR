#include<iostream>
#include<cstdio>
#include<cstdlib>
using namespace std;
int n, a[105], k, ans;
int read()
{
    char c = getchar();
    int x = 0, f = 1;
    while(!isdigit(c)){
        if(c == '-')
            f=-1;
        c = getchar();
    }
    while(isdigit(c)) x = (x<<3)+(x<<1)+(c^48), c = getchar();
    return x * f;
}
int dfs(int cur, int sum){
    if(cur >= n) return -1;
    if(sum + a[cur] == k && cur >= ans){
        ans = cur;
        return cur;
    }
    int suc1, suc2;
    suc1 = dfs(cur + 1, sum);
    suc2 = dfs(cur + 1, sum + a[cur]);
    if(suc1 > suc2) return suc1;
    else return suc2;
}
int main(){
    n = read();
    for(int i = 0; i < n; i++){
        a[i] = read();
    }
    k = read();
    ans = -1;
    dfs(0, 0);
    cout<<ans;
    return 0;
}