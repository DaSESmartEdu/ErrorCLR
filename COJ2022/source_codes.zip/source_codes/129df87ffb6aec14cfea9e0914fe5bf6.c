#include<stdio.h>
#include<stdlib.h>
struct ListNode{
    int data;
    struct ListNode *next;
};
struct ListNode *readlist();
struct ListNode *getodd(struct ListNode **L);
int main()
{
    struct ListNode *L,*p;
    L=readlist();
    p=getodd(&L);
    while(p)
    {
        printf("%d ",p->data);
        p=p->next;
    }
    printf("\n");
    while(L)
    {
        printf("%d ",L->data);
        L=L->next;
    }
    return 0;
}
struct ListNode *readlist()
{
    struct ListNode *head,*tail,*p;
    int t;
    head=NULL;
    tail=NULL;
    scanf("%d",&t);
    while(t!=-1)
    {
        p=(struct ListNode*)malloc(sizeof(struct ListNode));
        p->data=t;
        p->next=NULL;
        if(head==NULL) 
        head=p;
        else 
        tail->next=p;
        tail=p;
        scanf("%d",&t);   
        }
        return head;
}
struct ListNode *getodd( struct ListNode **L )
{
    struct ListNode * head = NULL,*tail;
    while((*L)&&(*L)->data%2==1)     
    {
        if(head==NULL)         
        {
            head=*L;
            *L = (*L)->next;
            head->next = NULL;
            tail=head;
        }
        else
        {
            tail->next=(*L);
            *L = (*L)->next;
            tail= tail->next;
            tail->next = NULL;
        }
    }
    if(*L)
    {
        struct ListNode * front = *L;
        struct ListNode * back = (*L)->next;
        while(back)
        {
            if(back->data%2==1)
            {
                if(head==NULL)    
                {
                    head = back;
                    back = back->next;
                    head->next = NULL;
                    tail = head;
                }
                else
                {
                    tail->next = back;
                    back = back->next;
                    tail=tail->next;
                    tail->next = NULL;
                    if(back==NULL)      
                        front->next=NULL;
                }
            }
            else
            {
                front->next = back;
                front=front->next;
                back = back->next;
            }               
        }
    } 
    return head;
}