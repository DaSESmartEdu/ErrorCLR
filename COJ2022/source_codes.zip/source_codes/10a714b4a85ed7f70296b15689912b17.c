#include <stdio.h>
#include <string.h>
char *search(char *s,char *t);
int main()
{
    char s[30];
    char t[30];
    gets(s);
    scanf("%s",t);
    char *n=search(s,t);
    if(n!=NULL){
        printf("%d",n-s);
    }else{
        printf("-1");
    }
    return 0;
}
char *search(char *s,char *t)
{
    int lens=strlen(s);
    int lent=strlen(t);
    int i,j,k;
    int x=lens-lent;
    for(i=0;i<=x;i++){
        for(j=0,k=i;j<lent;j++,k++){
            if(s[k]!=t[j]){
                break;
            }
        }
        if(j==lent){
            break;
        }
    }
    if(i<=x){
        return s+i;
    }else{
        return NULL;
    }
}