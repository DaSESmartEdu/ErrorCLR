#include<stdio.h>
int main()
{
    int a[100];
    int N;
    float average,max,min,sum;
    int i=0;
    scanf("%d",&N);
    for (i=0;i<N;i++)
    {
        scanf("%d",&a[i]);
    }
    max=a[0];
    min=a[0];
    sum=a[0];
    for (i=1;i<N;i++)
    {
        if (a[i]>max)
        {
            max=a[i];
        }
        else
        {
            min=a[i];
        }
        sum+=a[i];
    }
    average=sum/N;
    printf("average = %.2f\n",average);
    printf("max = %.2f\n",max);
    printf("min = %.2f\n",min);
}