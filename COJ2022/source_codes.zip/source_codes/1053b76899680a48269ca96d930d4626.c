#include <stdio.h>
int main()
{
	int a,b,c,result,i,sum;
	sum=0;
	scanf("%d %d %d",&a,&i,&c);
	for (b=1;b<=i-1;b++)
	{
		if ((b==1)||(b==3)||(b==5)||(b==7)||(b==8)||(b==10)||(b==12))
		{
			sum=sum+31;
		}
		if (b==2)
		{
		if (((a%4==0)&&(a%100!=0))||(a%400==0))
		{ 
		sum=sum+29; 
		}
		else
		       {
		       	sum=sum+28;
		       } 
         } 
         if ((b==4)||(b==6)||(b==9)||(b==11))
         {
         	sum=sum+30;
		 }
    } 
    result=sum+c;
    printf("%d",result);
}