#include<stdio.h>
#include<math.h>
int main()
{
    int i,j,m,n,k;
	int x[10],y[10];
	float dis[10];
	scanf("%d",&m);
	for(i=0;i<m;i++)
	{scanf("%d %d",&x[i],&y[i]);
	 dis[i]=sqrt(x[i]*x[i]+y[i]*y[i]);}
	scanf("%d",&k);
	int number=0;
	for(i=0;i<m;i++)
	{
		for(j=0;j<m;j++)
		{
			if(dis[i]>dis[j]) number++;
		}
		if(number==k-1) {
			printf("%d %d",x[i],y[i]);
			break;
		}
	}
}