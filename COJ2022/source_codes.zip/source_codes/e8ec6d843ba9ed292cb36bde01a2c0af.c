#include<stdio.h>
int main()
{
    int a, i, n, sum, item;
    scanf("%d %d",&a,&n);
    sum=a;
    item=a;
    for(i=a;i<n;i++){
        item=item*10+a;
        sum=sum+item;
    }
    printf("%d\n",sum);
    return 0;
}