#include <iostream>
#include <vector>
using namespace std;
#define N 10
int a[N];
int isChoose[N];
int sum=0;
vector<int*>results;
void dfs(int i,int n,int K){
    if(i<n) {
        sum += a[i];
        isChoose[i] = 1;
        if(sum==K){
            int* result=new int[N];
            for(int j=0;j<N;j++){
                result[j]=-1;
            }
            for(int j=0;j<n;j++){
                if(isChoose[j]==1){
                    result[j]=j;
                }
            }
            results.push_back(result);
        }
        dfs(i + 1,n,K);
        isChoose[i] = 0;
        sum -= a[i];
        dfs(i + 1,n,K);
    }
}
int main(){
    int n;
    cin>>n;
    for(int i=0;i<n;i++){
        cin>>a[i];
    }
    int K;
    cin>>K;
    dfs(0,n,K);
    int max=0;
    if(results.empty()){
        cout<<-1<<endl;
        return 0;
    }
    for(auto i: results){
        for(int j=0;j<N;j++){
            if(max<i[j]){
                max=i[j];
            }
            cout<<i[j]<<" ";
        }
        cout<<endl;
    }
    cout<<max<<endl;
    return 0;
}