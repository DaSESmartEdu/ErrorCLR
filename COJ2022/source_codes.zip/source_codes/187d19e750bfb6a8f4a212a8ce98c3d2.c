#include <stdio.h>
#include <math.h>
int main()
{
    int n,i;
    double height;
    scanf("%lf",&height);
    scanf("%d",&n);
    for(i=1;i<=n;i++)
    {
        height/=2;
    }
    height=round(height);
    printf("%.2lf",height);
    return 0;
}