#include<stdio.h>
#include<string.h>
int main()
{
	int i;
	char*DAY[7]={"Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"};
	char str[20];
	scanf("%s",str);
	for(i=0;i<7;i++){
		if(strcmp(str,DAY[i])==0){
			break;
		}
	}
	if(i<7){
		printf("%d",i);
	}else{
		printf("wrong input!");
	}
	return 0;
 }