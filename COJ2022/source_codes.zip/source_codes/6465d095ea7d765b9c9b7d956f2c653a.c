#include <stdio.h>
int main()
{
    int a;
    double b;
    scanf("%d",&a);
    if (a<=50)
    {
        b=a*0.53;
        printf("%f",b);
    }
    if (a>50)
    {
        b=26.5+(a-50)*0.58;
        printf("%f",b);
    }
    return 0;   
}