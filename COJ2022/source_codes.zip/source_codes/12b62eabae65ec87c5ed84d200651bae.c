#include <stdio.h>
#include <stdlib.h>
struct book{
char name[32];
double price;
};
int main()
{
    int n;
    scanf("%d",&n);
    getchar();
    int i;
    struct book a[10];
    for(i=0;i<n;i++)
    {
        gets(a[i].name);
        scanf("%lf",&a[i].price);
        getchar();
    }
    double min=10000,max=-1;
    int c,d;
    for(i=0;i<n;i++)
    {
        if(a[i].price>max) {max=a[i].price;c=i;}
        if(a[i].price<min) {min=a[i].price;d=i;}
    }
    printf("%.2lf, %s\n",max,a[c].name);
    printf("%.2lf, %s\n",min,a[d].name);
    return 0;
}