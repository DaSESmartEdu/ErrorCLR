#include<stdio.h>
int main()
{
    int n,i;
    double c;
    scanf("%d",&n);
    for(i=1;i<=n;i++)
   { 
       scanf("%lf",&c);
   if(c>=90){
       printf(" A");
       }
   else if (c<90 && c>=80)
   { 
       printf(" B");
       }
   else if (c<80 && c>=70)
   { 
       printf(" C");
       }
   else if (c<70 && c>=60)
   { 
       printf(" D");
       }
   else if (c<60)
   {
        printf(" E");
        };
   }
   return 0;
}