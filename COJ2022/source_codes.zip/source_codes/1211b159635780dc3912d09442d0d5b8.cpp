#include <bits/stdc++.h>
using namespace std;
int main()
{
    int n, m;
    cin >> n >> m;
    int a[300][300];
    int dir = 0;
    int cnt = n * m;
    for (int i = 1; i <= n; i++)
        for (int j = 1; j <= m; j++)
            cin >> a[i][j];
    int nmin = 1, nmax = n, mmin = 1, mmax = m;
    while (cnt)
    {
        for (int i = nmin; i <= nmax; i++)
        {
            cout << a[i][mmin];
            if (cnt != 1)
                cout << " ";
            cnt--;
        }
        if (!cnt)
            break;
        mmin++;
        for (int i = mmin; i <= mmax; i++)
        {
            cout << a[nmax][i];
            if (cnt != 1)
                cout << " ";
            cnt--;
        }
        if (!cnt)
            break;
        nmax--;
        for (int i = nmax; i >= nmin; i--)
        {
            cout << a[i][mmax];
            if (cnt != 1)
                cout << " ";
            cnt--;
        }
        if (!cnt)
            break;
        mmax--;
        for (int i = mmax; i >= mmin; i--)
        {
            cout << a[nmin][i];
            if (cnt != 1)
                cout << " ";
            cnt--;
        }
        if (!cnt)
            break;
        nmin++;
    }
}