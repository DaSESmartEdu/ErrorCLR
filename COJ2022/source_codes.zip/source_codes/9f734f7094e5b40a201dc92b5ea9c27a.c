#include <stdio.h>
#include <math.h>
int main(){
 int n;
 int i=1;
 float sum=0;
 scanf("%d",&n);
 while(i<=n){
 sum=sum +sqrt(i);
 i++;
 }
printf("%.2f",sum);
	return 0;
}