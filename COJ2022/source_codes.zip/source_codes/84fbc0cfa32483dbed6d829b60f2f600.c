#include<stdio.h>
int main()
{
int n,m;
scanf("%d %d",&n,&m);
if (100*n<110*m) {printf("normal");}
else if (150*m<n<=110*m){printf("200");}
else  {printf("revoke");}
return 0;
}