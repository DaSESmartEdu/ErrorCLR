#include "stack"
#include "iostream"
using namespace std;
int main(){
    int m;
    int n;
    cin>>m;
    cin>>n;
    stack<int>sta;
    int res=0;
    for (int i = m; i <=n ; ++i) {
        if (i==0||i==1){
            res++;
        }
        for (int j = 1; j <i ; ++j) {
            if (i%j==0){
                sta.push(j);
            }
        }
        int q=0;
        int qq=sta.size();
        for (int j = 0; j <qq ; ++j) {
            q=q+sta.top();
            sta.pop();
        }
        if (q==i){
            res++;
        }
    }
        if (res!=0){
        cout<<res;
    } else {
        cout<<"No perfect number";
    }
}