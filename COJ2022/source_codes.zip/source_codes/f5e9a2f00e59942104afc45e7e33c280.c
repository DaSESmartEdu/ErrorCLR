#include <stdio.h>
int main()
{
    int n;
    scanf("%d",&n);
    int booknumber[n+1];
    booknumber[0]=0;
    for (int i=1;i<=n;i++)
        scanf("%d",&booknumber[i]);
    int m;
    scanf("%d",&m);
    int c[2*m];
    for (int i=0;i<2*m;i++)
    {
        scanf("%d",&c[i]); 
    }
    int count = 0;
    for (int l=0;l<m;l++)
    {
        if (c[count]==0)
        {
            if (booknumber[c[count+1]]==0)
            {
                printf("There is no book of kind %d,sorry!\n",c[count+1]);
            }
            if (booknumber[c[count+1]]>0)
            {
                printf("There are %d books of kind %d,success!\n",booknumber[c[count+1]],c[count+1]);
                booknumber[c[count+1]]--;
            }
        }
        if (c[count]==1)
        {
            booknumber[c[count+1]]++;
            printf("Success!There are %d books of kind %d now!\n",booknumber[c[count+1]],c[count+1]);
        }
        count+=2;
    }
    return 0;
}