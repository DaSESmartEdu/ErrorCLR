#include<stdio.h>
int main(){
	int m,n,p[7][7],b[7][7];
	scanf("%d%d",&m,&n);
	for(int i=0;i<n;i++){
		for(int j=0;j<n;j++){
			scanf("%d",&p[i][j]);
			b[i][(j+m)%n]=p[i][j];
		}
	}
	for(int i=0;i<n;i++){
		for(int j=0;j<n;j++){
			printf("%d",b[i][j]);
			if(i!=n-1 || j!=n-1) printf(" ");
		}
		if(i!=n-1) printf("\n");
	}
	return 0;
}