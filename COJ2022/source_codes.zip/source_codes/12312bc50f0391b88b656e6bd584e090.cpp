#include <iostream>
using namespace std;
enum Error_code{underflow,overflow,success};
const int maxqueue=8;
template<class Queue_entry>
class Queue{
public:
    Queue();
    bool empty()const;
    Error_code serve();
    Error_code append(const Queue_entry &item);
    Error_code retrieve(Queue_entry &item)const;
private:
    int count;
    int rear,front;
    Queue_entry entry[maxqueue];
} ;
template<class Queue_entry>
Queue<Queue_entry>::Queue()
{
    count=0;
    front=0;
    rear=maxqueue-1;
}
template<class Queue_entry>
bool Queue<Queue_entry>::empty()const
{
    return count==0;
}
template<class Queue_entry>
Error_code Queue<Queue_entry>::serve()
{
    if(count<=0)return underflow;
    count--;
    front=((front+1)==maxqueue)?0:(front+1);
    return success;
}
template<class Queue_entry>
Error_code Queue<Queue_entry>::append(const Queue_entry &item)
{
    if(count>=maxqueue)return overflow;
    count++;
    rear=((rear+1)==maxqueue)?0:(rear+1);
    entry[rear]=item;
    return success;
}
template<class Queue_entry>
Error_code Queue<Queue_entry>::retrieve(Queue_entry &item)const
{
    if(count<=0)return underflow;
    item=entry[front];
    return success;
}
int main()
{
    int n,item;
    Queue<int>numbers;
    bool overflow=false;
    cin>>n;
    for(int i=0;i<n;i++)
    {
        cin>>item;
        Error_code x=numbers.append(item);
        if(x==1)overflow=true;
    }
    if(overflow) cout<<"This queue is overflow!"<<endl;
    int cnt=0;
    while(!numbers.empty())
    {
        numbers.retrieve(item);
        if(cnt==0) cout<<item;
        else cout<<" "<<item;
        numbers.serve();
        cnt++;
    }
    cout<<endl;
    return 0;
}