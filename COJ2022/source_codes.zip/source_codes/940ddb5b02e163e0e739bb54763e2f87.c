#include <stdio.h>
int main()
{
    double s,time;
    scanf ("%f %f" ,s,time);
    double m;
    if (s<=3.0)
    {
        m=10.0;
    }
    if (s>3.0&&s<=10.0)
    {
        m=10.0+(s-3.0)*2.0;
    }
    if (s>10.0)
    {
        m=10.0+7*2.0+(s-10.0)*3.0;
    }
    int min=time;
    int n=min/5;
    m=m+n*2+0.5;
    int money=(int)m;
    printf("%d" ,money);
    return 0;
}