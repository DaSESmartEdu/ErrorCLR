#include<iostream>
#include<stdio.h>
using namespace std;
int main()
{
  int a,b;
  cin>>a>>b;
  int sum=a+b;
  cout<<sum;
  return 0;
  }