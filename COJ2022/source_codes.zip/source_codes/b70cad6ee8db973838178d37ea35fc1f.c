#include<stdio.h>
int main(){
    int n,i,j,m;
    scanf("%d",&n);
    m=n/2+1;
    for(i=1;i<=m;i++){
        for(j=1;j<=n;j++){
            if(j>=m-i+1 && j<=m+i-1){
                printf("* ");
            }
            else printf(" ");
        }printf("\n");
    }
    for(i=m+1;i<=n;i++){
        for(j=1;j<=n;j++){
            if(j>=m+i-n && j<=m+n-i){
                printf("* ");}
                else printf(" ");
        }printf("\n");
    }
    return 0;
}