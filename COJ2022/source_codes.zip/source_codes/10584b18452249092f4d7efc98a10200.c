#include<stdio.h>
int main()
{
	int v,l;
	scanf("%d %d",&v,&l);
	double item;
	item=100.0*(v-l)/l;
	if(item<10){
		printf("OK");
	}
	else if(item<50){
		printf("Exceed %.0f%%. Ticket 200",item);
	}
	else{
		printf("Exceed %.0f%%. License Revoked",item);
	}
	return 0;
}