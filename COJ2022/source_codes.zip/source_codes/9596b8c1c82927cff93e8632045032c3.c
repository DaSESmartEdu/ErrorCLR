#include<stdio.h>
double fact(int n);
int main()
{
    int i=1,n;
    double e;
    scanf("%d",&n);
    for(i=1;i<=n;i++){
        e=e+fact(i);
    }
    printf("%.0f",e);
    return 0;
}
double fact(int n)
{
    int i;
    double r;
    r=1;
    for(i=1;i<=n;i++){
        r=r*i;
    }
    return r;
}