#include <stdio.h>
int main(){
	double mile, time, mfee;
	int i_mfee, tfee, totalfee;
    scanf("%lf %lf", &mile, &time);
	if((int)mile <= 3){
		mfee = 10;
	}
	else if((int)mile > 3 && (int)mile <= 10 ){
		mfee = 10 + (mile - 3) * 2;
	}
	else{
		mfee = 24 + (mile - 10)*3;
	}
	tfee = ((int)time / 5) * 2;
    if((int)(mfee+0.5)> (int)mfee){
        i_mfee = (int)mfee + 1;
    }
    else{
        i_mfee = (int)mfee;        
    }
	totalfee = tfee + i_mfee;
	printf("%d", totalfee);
	return 0;
}