#include<stdio.h>
int sushu (int n);
int OddSum (int m,int n);
int main()
{
    int m,n;
    scanf("%d %d",&m,&n);
    printf("%d",OddSum(m,n));
    return 0;
}
int sushu (int n)
{
    int i,count=0;
    for(i=1;i<=n;i++)
    {
        if(n%i==0) count++;
    }
    if(count==2) return 1;
    else return 0;
}
int OddSum (int m,int n)
{
    int x;
    int sum = 0;
    for(x=m;x<=n;x++)
    {
        if(sushu(x)==0) sum = sum + x;
    }
    return sum;
}