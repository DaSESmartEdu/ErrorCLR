#include <stdio.h>
int main()
{
    int i,n,j,k;
    scanf("%d",&n);
    for(i=0;i<(n+1)/2;i++)
    {   
        for(j=0;j<(n+1)/2-i;j++)
        printf(" ");
        for(k=0;k<2*i+1;k++)
        printf("*");
        printf("\n");
    }
    for(i=0;i<(n+1)/2-1;i++)
    {   
        for(j=0;j<i+2;j++)
        printf(" ");
        for(k=0;k<n-2*(i+1);k++)
        printf("*");
        printf("\n");
    }
    return 0;
}