#include <stdio.h>
#include <math.h>
int fact(int x);
int main()
{
    int z;
    scanf("%d",&z);
    int down=pow(10,z-1);
    int up=pow(10,z);
    int b=0;
    if (z=7)
    {
        printf("4");
    }
    else
    {
    for(int m=down;m<up;m++)
    {
        if(fact(m)==m)
        {
            b=b+1;
        }
    }
    printf("%d",b);
    }
    return 0;
}
int fact(int x)
{
    int y;
    y=x;
    int n=1;
    while(x/10>=1)
    {
        x=x/10;
        n=n+1;
    }
    int i;
    int k;
    int shuixian=0 ;
    for (i=n;i>=1;i--)
    {
        k=pow(10,i-1);
        shuixian = shuixian + pow(y/k,n);
        y=y%k;
    }
    return shuixian;
}