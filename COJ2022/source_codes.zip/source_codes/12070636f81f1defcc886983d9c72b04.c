#include <stdio.h>
int main()
{
	int m, n;
	scanf("%d%d", &m, &n);
	int flag = 0, cnt = 0;
	for(int i = m; i <= n; i++) {
		int sum = 0;
		for(int j = 1; j < i; j++) {
			if(i % j == 0) sum += j;
		}
		if(sum == i || i == 1) {
			cnt++;
			flag = 1;
		}		
	}
	if(flag == 0) printf("No perfact number\n");
	else printf("%d\n", cnt);
	return 0;
}