#include <stdio.h>
#include <malloc.h>
typedef struct ListNode{
	int data;
	struct ListNode *next;
}ListNode;
ListNode* readlist1() {
	int t;
	ListNode *L = (ListNode*)malloc(sizeof(ListNode)), *s, *r = L;
	scanf("%d", &t);
	while (t != -1) {
		s = (ListNode*)malloc(sizeof(ListNode));
		s->data = t;
		r->next = s;
		r = s;
		scanf("%d", &t);
	}
	r->next = NULL;
	return L;
}
ListNode* readlist2() {
	int t;
	ListNode *L = (ListNode*)malloc(sizeof(ListNode)), *s, *r = L;
	scanf("%d", &t);
	while (t != -1) {
		s = (ListNode*)malloc(sizeof(ListNode));
		s->data = t;
		r->next = s;
		r = s;
		scanf("%d", &t);
	}
	r->next = NULL;
	return L;
}
void writelist(ListNode* L) {
	while (L->next != NULL) {
		L = L->next;
		printf("%d ", L->data);
	}
}
ListNode* getodd(ListNode* L) {
	ListNode* Lres = (ListNode*)malloc(sizeof(ListNode)), *r = Lres;
	while (L->next != NULL) {
		if (L->next->data % 2 == 1) {
			r->next = L->next;
			r = L->next;
			L->next = L->next->next;
		} else {
			L = L->next;
		}
	}
	return Lres;
}
main() {
	ListNode* L = readlist1();
	ListNode* Lres = getodd(L);
	writelist(Lres);
	printf("\n");
	writelist(L);
}