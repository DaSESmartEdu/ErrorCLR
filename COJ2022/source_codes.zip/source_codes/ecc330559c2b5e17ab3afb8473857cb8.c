#include<stdio.h>
int main() {
	int n, i;
	double a = 1, b = 2,d;
	double sum = 0, c = 0;
	scanf("%d", &n);
	for (i = 1; i <= n; i++) {	
		c = b / a;
		printf("%lf",c);
		d = a + b;
		a = b;
		b = d;
		sum += c;
	}
	printf("%.2lf", sum);
	return 0;
}