#include <stdio.h>
#define lowbit(x) (x) & (-(x))
char buff[1 << 26];
char map[1 << 25];
int main() {
	int n;
	scanf("%d", &n);
	for(int i = 0; i < n; ++i) {
		map[1 << i] = 'A' + i;
	}
	for(int i = 1; i < (1 << n); ++i) {
		int r = lowbit(i);
		buff[i] = map[r];
	}
	puts(buff + 1);
	return 0;
}