#include <stdio.h>
int main()
{
        int n;
        scanf("%d",&n);
        int num[n];
        int sum[10]={0,0,0,0,0,0,0,0,0,0};
        for(int i=0;i<n;i++){
            scanf("%d",&num[i]);
            int t, k=num[i];
            while(k!=0){
                t=k%10;
                sum[t]++;
                k/=10;
            }
        }
        int max=0;
        for(int g=0;g<10;g++){
            if(sum[g]>max){
                max=sum[g];
            }
        }
       int num1=0;
        for(int g=0;g<n;g++){
            if(sum[g]==max){
                num1++;
            }
        }
        int num2=0;
        for(int t=0;t<n;t++){
            if(sum[t]==max){
                num2++;
                if(num2<num1){
                    printf("%d ",t);
                }
                else if(num2==num1){
                    printf("%d",t);
                }
            }
        }
        return 0;
}