#include<stdio.h>
double fact(int a)
{
    int ans=1,i;
    if(a<=1)return 1;
    for(i=1;i<=a;i++){
    ans*=i;
    return ans;}
}
int main()
{int n;
scanf("%d",&n);
 double e,j;
    e=0;
    if(j<=n){
    for(j=1;j<=n;j++){
    e=e+fact(j);
}
printf("%.0f",(double)(e));
	}
    return 0;
}