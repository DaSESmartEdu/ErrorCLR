#include<stdio.h>
int main()
{
    int n;
    int m;
    scanf("%d %d",&n,&m);
    if (1.1*m<=n&&n<=1.5*m) printf("200");
    else if(n>=1.5*m) printf("revoke");
    else printf("normal");
    return 0;
}