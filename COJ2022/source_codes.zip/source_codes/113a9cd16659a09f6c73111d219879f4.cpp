#include <bits/stdc++.h>
using namespace std;
const int maxn=1e4+10;
int n,m,k,t;
int main()
{
    int i,j;
    scanf("%d",&n);
    printf("%d:%d:%d\n",n/3600,n/60%60,n%60);
    return 0;
}