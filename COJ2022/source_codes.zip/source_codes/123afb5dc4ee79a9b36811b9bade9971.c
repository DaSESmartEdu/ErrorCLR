#include <stdio.h>
int main(){
	int n;
	scanf("%d",&n);
	int a[n];
	int i,j;
	for(i=0;i<n;i++){
		scanf("%d",&a[i]);
	}
	a[n]=0;
	for(i=0;i<=n-1;i++){
		for(j=0;j<=n-1-i;j++){
			if(a[j]<a[j+1]){
				a[n]=a[j];
				a[j]=a[j+1];
				a[j+1]=a[n];
			}
		}
	}
	for(i=0;i<n;i++){
		if(i==0){
			printf("%d",a[i]);
		}else{
			printf(" %d",a[i]);
		}
	}
	return 0;
}