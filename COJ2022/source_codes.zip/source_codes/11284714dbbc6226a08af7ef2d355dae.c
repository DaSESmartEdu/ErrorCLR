#include <stdio.h>
int prime(int p);
void Goldbach(int n);
int main()
{
    int m,n;
    scanf("%d%d",&m,&n);
    for (int i = m; i <=n; i++)
    {
        if (i%2==0)
        {
            Goldbach(i);
        }
    }
}
int prime(int p)
{
    int sum=0;
    if (p==1)
    {
        return 0;
    }
    else
    {
        for (int i = 1; i < p; i++)
        {
            int a=p%i;
            if (a==0)
            {
                sum=sum+1;
            }
            else
            {
                sum=sum+0;
            }
        }
        if (sum==1)
        {
            return 1;
        }
        else
        {
            return 0;
        }
    }
}
void Goldbach(int n)
{
    int a,i,c=0;
    for ( i = 1; i <= n; i++)
    {
        a=n-i;
        for (;prime(i)==1&&prime(a)==1;)
        {
            printf("%d=%d+%d\n",n,i,a);
            c++;
            break;
        }
        if(c!=0)
        {
            break;
        }
    }
}