#include<stdio.h>
 int main()
 {
    int a[30]={1,1,1};
    int b,i=1;
    scanf("%d",&b);
    while(a[i-1]<b){
        if(i>2){
            a[i]=a[i-1]+a[i-2];
        }
        i++;
    }
    printf("%d",i-1);
    return 0;
 }