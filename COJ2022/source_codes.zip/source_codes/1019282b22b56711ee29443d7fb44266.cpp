#include<iostream>
using namespace std;
bool isPerfect(int n) {
	int half = n/2;
	int sum = 0;
	if(n == 1)
		return true;
	for(int i=1;i<=half;i++)
		if(n % i == 0)
			sum += i;
	if(sum == n)
		return true;
	else
		return false;
}
int main() {
	int a,b;
	int cnt = 0;
	cin >> a >> b;
	for(int i=a;i<b;i++)
		if(isPerfect(i))
			cnt++;	
	if(cnt == 0)
		cout<<"No perfect number"<<endl;
	else
		cout<<cnt<<endl;
	return 0;
}