#include<stdio.h>
int main()
{
    double km,time;
    double m1,m2;
    scanf("%lf %lf",&km,&time);
    if (km<=3)
    {
        m1=10;
    }
    else if (3<km && km<=10)
    {
        m1=10+2*(km-3);
    }
    else 
    {
        m1=10+3*(km-3)+2*7;
    }
    int t;
    t=time/5;
    if (t==0)
    {
        m2=0;
    }
    else
    {
        m2=2*t;
    }
    double M;
    M=m1+m2;
    int q;
    double p;
    q=M;
    p=M-q;
    if (p>=0.5)
    {
        q=q+1;
    }
    printf("%d",q);
}