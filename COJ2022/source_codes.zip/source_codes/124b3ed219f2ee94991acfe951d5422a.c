#include<stdio.h>
#include<math.h>
double fn(double x,int n)
{
    int i,t=1;
    double sum=0,m;
    for(i=1;i<=n;i++)
    {
        m=t*pow(x,i);
        sum+=m;
        t*=-1;
    }
    return sum;
}
int main(void)
{
    int n;
    double x;
    scanf("%lf %d",&x,&n);
    printf("%.2lf",fn(x,n));
    return 0;
}