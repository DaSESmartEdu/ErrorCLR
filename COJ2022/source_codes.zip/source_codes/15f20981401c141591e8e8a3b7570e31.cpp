#include <bits/stdc++.h>
using namespace std;
struct Node {
    int val, h = 0;
    Node *l, *r;
    Node(int val, Node *l, Node *r) : val(val), l(l), r(r) {}
};
Node *build() {
    string str;
    cin >> str;
    if (str == "#") return nullptr;
    int num = 0;
    for (auto x : str) num = num * 10 + x - '0';
    return new Node(num, build(), build());
}
void testprint(Node *root, int h = 0) {
    if (root == nullptr) return;
    for (int i = 0; i < h; i++)
        cout << " ";
    cout << root->val << endl;
    return testprint(root->l, h + 1), testprint(root->r, h + 1);
}
bool is_balanced(Node *root) {
    if (!root) return true;
    if (root->r && root->l) {
        bool res = is_balanced(root->l) && is_balanced(root->r);
        root->h = max(root->l->h, root->r->h);
        return res && (abs(root->l->h - root->r->h) <= 1);
    } else if (root->l) {
        bool res = is_balanced(root->l);
        root->h = max(root->l->h, 0);
        return res && (abs(root->l->h) <= 1);
    } else if (root->r) {
        bool res = is_balanced(root->r);
        root->h = max(root->r->h, 0);
        return res && (abs(root->r->h) <= 1);
    } else {
        root->h = 1;
        return true;
    }
}
int main() {
    int len;
    cin >> len;
    Node *root = build();
    cout << (is_balanced(root) ? "true" : "false") << endl;
}