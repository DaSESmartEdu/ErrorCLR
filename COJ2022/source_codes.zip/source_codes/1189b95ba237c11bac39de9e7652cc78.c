#include<stdio.h>
double fact(int n);
int main()
{
	int n,i;
	double e=0;
	scanf("%d",&n);
	for(i=1;i<=n;i++){
		e=e+fact(i);
	}
	printf("%.0f",e);
	return 0;
}
double fact(int n)
{
	int i;
	double sum=1;
	for(i=1;i<=n;i++){
		sum=sum*i;
	}
	return sum;
}