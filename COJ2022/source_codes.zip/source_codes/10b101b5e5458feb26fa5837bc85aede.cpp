#include <cstdio>
#include <algorithm>
using namespace std;
int m,n,sum_c,ans=100;
int c[10][10],vis[10][10];
int tx[4]={1,0,0,-1};
int ty[4]={0,1,-1,0};
void dfs(int x,int y,int sum,int dep){
if(sum>sum_c/2)return;
 if(sum==sum_c/2){ans=min(ans,dep);return;}
     for(int i=0;i<4;i++){
         int x0=x+tx[i],y0=y+ty[i];
         if(x0>=1&&x0<=n&&y0>=1&&y0<=m&&!vis[x0][y0]){
            vis[x0][y0]=1;
            dfs(x0,y0,sum+c[x0][y0],dep+1);
             vis[x0][y0]=0;
       }
     }
 }
int main(){
    scanf("%d%d",&m,&n);
	for(int i=1;i<=n;i++)for(int j=1;j<=m;j++)scanf("%d",&c[i][j]),sum_c+=c[i][j];
     vis[1][1]=1;
     dfs(1,1,c[1][1],1);
     printf("%d\n",ans==100?0:ans);
   return 0;
 }