#include <stdio.h>
#include <math.h>
double fact(int x); 
int main(void) {
	double x;
	scanf("%lf",&x);
	double s,item = 1.0;
    s=1;
	int i = 1;
	while(fabs(item) >= 1e-5){
		item = pow(x,i)/fact(i);
		s+=item;
		i++;
	}
	printf("%.4lf",s);
	return 0;
}
double fact(int n){
	int i;
	double result = 1;
	for(i = 1; i <= n; i++){
		result=result*i;
	}
	return result;
}