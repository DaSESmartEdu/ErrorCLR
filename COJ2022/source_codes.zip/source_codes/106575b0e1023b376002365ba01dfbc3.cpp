#include <iostream>
#include <string>
#include <vector>
using namespace std;
struct node
{
    node()=default;
    node(int n):value(n){}
    int value;
    node* next=nullptr;
};
class mylist
{
    friend ostream& operator<<(ostream&, mylist&);
public:
    mylist(){ head=new node; }
    void add(int n)
    {
        node* cur=new node(n);
        cur->next=head->next;
        head->next=cur;
    }
    void remove(int n)
    {
        node*cur=head;
        while(cur->next)
        {
            if(cur->next->value==n)
            {
                node*p=cur->next;
                cur->next=cur->next->next;
                delete p;
            }
            else
            {
                cur=cur->next;
            }
        }
    }
    void clear()
    {
        node*cur=head;
        while(cur->next)
        {
            node*p=cur->next;
            cur->next=cur->next->next;
            delete p;
        }
    }
    void find(int n)
    {
        node*cur=head;
        while(cur->next)
        {
            if(cur->next->value==n)
            {
                iffind.push_back(1);
                return;
            }
            cur=cur->next;
        }
        iffind.push_back(0);
    }
    ~mylist()
    {
        clear();
        delete head;
    }
private:
    node* head;
    vector<int> iffind;
};
ostream& operator<<(ostream& os, mylist& rhs)
{
    for(auto v:rhs.iffind)
    {
        os<<v<<endl;
    }
    if(!rhs.head->next)
    {
        os<<"empty linklist";
    }
    else
    {
        node*cur=rhs.head;
        while(cur->next)
        {
            os<<cur->next->value<<" ";
            cur=cur->next;
        }
    }
    return os;
}
int main(void)
{
    int n;
    cin>>n;
    mylist L;
    for(int i=0; i<n; i++)
    {
        string s;
        int v;
        cin>>s;
        if(s=="add")
        {
            cin>>v;
            L.add(v);
        }
        else if(s=="remove")
        {
            cin>>v;
            L.remove(v);
        }
        else if(s=="clear")
        {
            L.clear();
        }
        else if(s=="find")
        {
            cin>>v;
            L.find(v);
        }
    }
    cout<<L;
}