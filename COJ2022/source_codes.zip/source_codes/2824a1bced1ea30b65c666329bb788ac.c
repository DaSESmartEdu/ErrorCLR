#include<stdio.h>
int main() {
	int n,i=1;
	int a=0,b=1;
	int sum =	1;
	scanf("%d", &n);
	while (sum <n) {
		sum= a + b;
		a = b;
		b = sum;
		i++;
		printf("b=%d i=%d \n", sum,i);
	}
	printf("%d",i);
	return 0;
}