#include <stdio.h>
int main()
{
    int n,sum=1,m=1,t,i=2;
    scanf("%d",&n);
    if (n==1)
    {
        printf("%d",i);
    }
    else
    {
        while (sum<n)
        {
            i++;
            t=m;
            m=sum;
            sum+=t;
        }
        printf("%d",i);
    }
    return 0;
}