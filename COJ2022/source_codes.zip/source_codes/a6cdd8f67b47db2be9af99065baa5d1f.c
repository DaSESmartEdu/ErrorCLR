#include <stdio.h>
#include <math.h>
int main()
{
    int a,b;
    double sum=0.0;
    scanf("%d",&a);
    for(b=1;b<=a;b++){
        sum += sqrt(b);
    }
    printf("%f",sum);
    return 0;
}