#include<iostream>
using namespace std;
enum Error_code{underflow,overflow,success};
typedef char T;
const int maxn=100;
class Mystack
{
    public:
    Mystack();
    bool empty();
    Error_code push(T &item);
    Error_code pop();
    Error_code top(T &item);
    int count;
    private:
    T arr[maxn];
};
Mystack::Mystack()
{
    count = 0;
}
bool Mystack::empty()
{
    if(count==0)
    {
        return true;
    }
    return false;
}
Error_code outcome;
Error_code Mystack::push(T &item)
{
    outcome=success;
    if(count>=maxn)
    {
        outcome=overflow;
    }
    else
    {
        arr[count++]=item;
    }
    return outcome;
}
Error_code Mystack::pop()
{
    outcome=success;
    if(count==0)
    {
        outcome=underflow;
    }
    else
    count--;
    return outcome;
}
Error_code Mystack::top(T &item)
{
    outcome=success;
    if(count==0)
    {
        outcome=underflow;
    }
    else
    item=arr[count-1];
    return outcome;
}
int main()
{
	Mystack q;
	string s;
	cin>>s;
	int res=0;
	for(int i=0;i<s.size();i++)
	{
		if(s[i]=='['||s[i]=='(')
		{
			q.push(s[i]);
            continue;
		}
		else if(s[i]==']')
		{
			char item;
			int flag=q.top(item);
			if(flag!=2)
			{
				res=1;
				break;
			}
			else if(item!='[')
			{
                res=1;
                break;
			}
            else
            q.pop();
        }
		else if(s[i]==')')
		{
			char item;
			int flag=q.top(item);
			if(flag!=2)
			{
				res=1;
				break;
			}
			else if(item!='(')
            {
                res=1;
                break;
            }
            else
            q.pop();	
		}
    }
    if(q.count!=0)
    {
        res=1;
    }
    cout<<res;
}