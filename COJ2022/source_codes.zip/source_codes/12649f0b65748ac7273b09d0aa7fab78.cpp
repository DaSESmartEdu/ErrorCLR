#include<iostream>
using namespace std;
const int N = 20005;
int fa[N], sz[N];
void init(int n) {
	for (int i = 0; i <= n; i++)
		fa[i] = i, sz[i] = 1;
}
int find(int x) {
	return (x == fa[x] ? x : (fa[x] = find(fa[x])));
}
void merge(int u, int v) {
	int fu = find(u), fv = find(v);
	if (sz[fu] <= sz[fv]) {
		fa[fu] = fv;
	}
	else
		fa[fv] = fu;
	if (sz[fu] == sz[fv] && fu != fv)
		sz[fv]++;
}
int main(void) {
	int n, m;
	while (cin >> n, n) {
		cin >> m;
		init(n);
		for (int i = 0; i < m; i++) {
			int u, v;
			cin >> u >> v;
			merge(u, v);
		}
		int ans = 0;
		for (int i = 1; i <= n; i++)
			if (find(i) == i)ans++;
		cout << ans - 1 << endl;
	}
	return 0;
}