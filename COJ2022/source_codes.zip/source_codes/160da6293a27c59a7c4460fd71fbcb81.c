#include <stdio.h>
int main(){
    int a=0,b=0,c=0;
    scanf("%d %d %d",&a,&b,&c);
    int d=0,e=0,f=0;
    if(a>b && a>c){
        f=a;
        if(b>c) e=b,d=c;
        else e=c,d=b;
    }
    else if(b>c && b>a){
        f=b;
        if(a>c) e=a,d=c;
        else e=c,d=a;
    }
    else if(c>a && c>b){
        f=c;
        if(a>b) e=a,d=b;
        else e=b,d=a;
    }
    printf("%d %d %d\n",d,e,f);
    return 0;
}