#include<stdio.h>
void ArrayShift( int a[], int n, int m ){
    int b[n];
    for(int i=0;i<n;i++){
        b[i]=a[i];
    }
    m=m%n;
    for(int i=0;i<n;i++){
        int after = i+m;
        if (after >= n) after =  after - n;
        a[after] = b[i];
    }
    for (int i = 0; i < n; i++){
        printf("%d ", a[i]);
    }
}
int main(){
    int n,m;
    scanf("%d %d",&n,&m);
    int a[n];
    for(int i=0;i<n;i++){
        scanf("%d",&a[i]);
    }
    ArrayShift(a,n,m);
    return 0;
}