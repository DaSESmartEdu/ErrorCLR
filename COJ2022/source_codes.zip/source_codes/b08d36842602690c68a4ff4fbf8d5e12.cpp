#include<iostream>
using namespace std;
    int b[8];
    int p[8];
void qpl(int m,int n){
    if(m==n)
    {
        for(int i = 0;i<n;i++)
        {
            cout<<p[i]<<" ";
        }
        cout<<endl;
        return;
    }
    else{
        for(int i = 0;i<n;i++)
        {
            if(b[i]==0){
            p[m]= i+1;
            b[i]= 1;
            qpl(m+1,n);
            b[i]=0;}
        }
    }
}
int main()
{
    int a;
    cin>>a;
    for(int i = 0 ;i<a;i++)
    {
        b[i]=0;
    }
    qpl(0,a);
}