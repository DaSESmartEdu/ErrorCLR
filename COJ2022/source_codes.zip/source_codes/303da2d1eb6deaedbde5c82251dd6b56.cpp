#include<iostream>
#include<algorithm>
using namespace std;
struct point{
    int x;
    int y;
};
void Heapify_max(struct point a[], int i, int n){
    if(2*i<=n && 2*i+1<=n){ 
        if(a[2*i].x<a[2*i+1].x || (a[2*i].x==a[2*i+1].x && a[2*i].y<a[2*i+1].y)){ 
            if(a[i].x<a[2*i].x || (a[i].x==a[2*i].x && a[i].y<a[2*i].y)){ 
                struct point temp=a[i];
                a[i]=a[2*i+1];
                a[2*i+1]=temp;
                Heapify_max(a,2*i+1,n);
            }
        }
        else if(a[2*i].x>a[2*i+1].x || (a[2*i].x==a[2*i+1].x && a[2*i].y>a[2*i+1].y)){ 
            if(a[i].x<a[2*i].x || (a[i].x==a[2*i].x && a[i].y<a[2*i].y)){ 
                struct point temp=a[i];
                a[i]=a[2*i];
                a[2*i]=temp;
                Heapify_max(a,2*i,n);
            }
            else return;
        }
        else return; 
    }
    else if(2*i<=n && 2*i+1>n){ 
        if(a[i].x<a[2*i].x || (a[i].x==a[2*i].x && a[i].y<a[2*i].y)){
            struct point temp=a[i];
            a[i]=a[2*i];
            a[2*i]=temp;
            Heapify_max(a,2*i,n);
        }
    }
    else return; 
}
void Build_heap(struct point a[], int n){
    for(int i=n/2;i>=1;i--){
        Heapify_max(a,i,n);
    }
}
void print_heap(struct point a[], int n){
    for(int i=1;i<=n;i++){
        cout<<"("<<a[i].x<<","<<a[i].y<<")"<<endl;
    }
}
int main(void){
    int n;
    cin>>n;
    struct point a[n+1];
    for(int i=1;i<=n;i++){
        cin>>a[i].x>>a[i].y;
    }
    Build_heap(a,n);
    int length=n;
    for(int j=n;j>1;j--){
        swap(a[1],a[j]);
        n--;
        Build_heap(a,n);
    }
    print_heap(a,length);
}