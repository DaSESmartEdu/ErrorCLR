#include <bits/stdc++.h>
#define ll long long
#define NUM 10
using namespace std;
int n;
string A[NUM];
string dfs(int ind){
    if(ind==1){
        return A[1].append("+").append(to_string(n));
    }
    else{
        string ans="";
        return ans.append("(").append(dfs(ind-1)).append(")").append(A[ind]).append("+").append(to_string(n+1-ind));
    }
}
int main() {
#ifndef ONLINE_JUDGE
    freopen("../std.in", "r", stdin);
#endif
    ios::sync_with_stdio(false);
    int i,j,k;
    cin >> n;
    for(i=1;i<=n;i++){
        int j=i;
        A[i]="sin("+to_string(i)+")";
        string sym="+";
        while (j>1){
            if(j%2==0)
                sym="-";
            string tmp="sin("+to_string(j-1)+sym;
            tmp=tmp.append(A[i]).append(")");
            A[i]=tmp;
            j--;
        }
    }
    cout << dfs(n);
    return 0;
}