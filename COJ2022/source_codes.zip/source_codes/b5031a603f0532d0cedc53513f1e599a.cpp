#include<stdio.h>
int a[256][256],b[256][256],c[256][256],d[256][256],e[256][256],f[256][256],g[256][256],h[256][256];
int p1[256][256],p2[256][256],p3[256][256],p4[256][256],p5[256][256],p6[256][256],p7[256][256];
int r[256][256],s[256][256],T[256][256],u[256][256];
int x[512][512],y[512][512],z[512][512];
void F(int M)
{
	int i,j,k;
	int t=M/2;
	for(i=0;i<M;i++)
	{
		for(j=0;j<M;j++)
		{
			scanf("%d ",&x[i][j]);
		}
	}
	for(i=0;i<M;i++)
	{
		for(j=0;j<M;j++)
		{
			scanf("%d ",&y[i][j]);
		}
	}
	for(i=0;i<t;i++)
	{
		for(j=0;j<t;j++)
		{
			a[i][j]=x[i][j];
			e[i][j]=y[i][j];
		}
	}
	for(i=t;i<M;i++)
	{
		for(j=0;j<t;j++)
		{
			c[i-t][j]=x[i][j];
			g[i-t][j]=y[i][j];
		}
	}
	for(i=0;i<t;i++)
	{
		for(j=t;j<M;j++)
		{
			b[i][j-t]=x[i][j];
			f[i][j-t]=y[i][j];
		}
	}
	for(i=t;i<M;i++)
	{
		for(j=t;j<M;j++)
		{
			d[i-t][j-t]=x[i][j];
			h[i-t][j-t]=y[i][j];
		}
	}
	for(i=0;i<t;i++)
	{
		for(j=0;j<t;j++)
		{
			p1[i][j]=0;
			p2[i][j]=0;
			p3[i][j]=0;
			p4[i][j]=0;
			p5[i][j]=0;
			p6[i][j]=0;
			p7[i][j]=0;
			for(k=0;k<t;k++)
			{
				p1[i][j]+=a[i][k]*(f[k][j]-h[k][j]);
				p2[i][j]+=(a[i][k]+b[i][k])*h[k][j];
				p3[i][j]+=(c[i][k]+d[i][k])*e[k][j];
				p4[i][j]+=d[i][k]*(g[k][j]-e[k][j]);
				p5[i][j]+=(a[i][k]+d[i][k])*(e[k][j]+h[k][j]);
				p6[i][j]+=(b[i][k]-d[i][k])*(g[k][j]+h[k][j]);
				p7[i][j]+=(a[i][k]-c[i][k])*(e[k][j]+f[k][j]);
			}
		}
	}
	for(i=0;i<t;i++)
	{
		for(j=0;j<t;j++)
		{
			r[i][j]=p5[i][j]+p4[i][j]-p2[i][j]+p6[i][j];
			s[i][j]=p1[i][j]+p2[i][j];
			T[i][j]=p3[i][j]+p4[i][j];
			u[i][j]=p5[i][j]+p1[i][j]-p3[i][j]-p7[i][j];
		}
	}
	for(i=0;i<t;i++)
	{
		for(j=0;j<t;j++)
		{
			z[i][j]=r[i][j];
		}
	}
	for(i=t;i<M;i++)
	{
		for(j=0;j<t;j++)
		{
			z[i][j]=s[i-t][j];
		}
	}
	for(i=0;i<t;i++)
	{
		for(j=t;j<M;j++)
		{
			z[i][j]=T[i][j-t];
		}
	}
	for(i=t;i<M;i++)
	{
		for(j=t;j<M;j++)
		{
			z[i][j]=u[i-t][j-t];
		}
	}
	for(i=0;i<M;i++)
	{
		for(j=0;j<M-1;j++)
		{
			printf("%d ",z[i][j]);
		}
		printf("%d\n",z[i][j]);
	}
}
int main()
{
	int N,M;
	scanf("%d %d",&N,&M);
	int i;
	for(i=0;i<N;i++)
	{
		F(M);	
	}
	return 0;
}