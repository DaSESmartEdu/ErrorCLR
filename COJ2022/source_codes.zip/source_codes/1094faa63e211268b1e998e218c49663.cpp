#include<stdio.h>
#include<math.h>
#include<cmath>
int prime(int );
main()
{
	int a,b,n=0,c;
	scanf("%d %d",&a,&b);
	for(c=a;c<=b;c++)
	{
		n+=prime(c);
	}
	if(a<=1)printf("%d",n-1);
	else printf("%d",n);
	return 0;
 } 
 int prime(int n)
{
	int x=2,l=0;
	while(x<=floor(sqrt(n)))
	{
		if(n<=1)l=0;
		else if(n%x==0)
		{
			l=0;
			break;
		}
		else x++;
	}
	if(x>floor(sqrt(n)))l=1;
	return l;
	}