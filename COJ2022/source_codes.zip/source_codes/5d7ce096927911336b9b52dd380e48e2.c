#include<stdio.h>
int main(void)
{
	int n,count = 0;
	while(n > 0)
	{
		scanf("%d",&n);
		if(n == 1)
		{
			count += n;
		}
		else if(n % 2 != 0)
		{
			count += n;
		}
	}
	printf("%d",count);
	return 0;
}