#include <stdio.h>
#include <math.h>
int main()
{
    int n;
    float i, p, sum;
    scanf("%d", &n);
    i = 1;
    sum = 0;
    for ( i = 1; i <= n; i ++){
        p = sqrt(i);
        sum = sum + p;
    }
    printf("%.2f", sum);
    return 0;
}