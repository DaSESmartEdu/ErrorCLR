#include<stdio.h>
struct stu{
    int num;
    char name[20];
    int score;
};
char set_grade(int score){
    if(score>=85){
        return 'A';
    }
    else if(score>=70){
        return 'B';
    }
    else if(score>=60){
        return 'C';
    }
    else{
        return 'D';
    }
}
int main(){
    int n,i,j=0;
    scanf("%d",&n);
    struct stu stus[n];
    for(i=0;i<n;i++){
        scanf("%d %s %d",&stus[i].num,&stus[i].name,&stus[i].score);
        if(stus[i].score<60){
            j++;
        }
    }
    printf("The count for failed (<60): %d\n",j);
    printf("The grades:\n");
    for(i=0;i<n;i++){
        printf("%d %s %d\n",stus[i].num,stus[i].name,stus[i].score);
    }
}