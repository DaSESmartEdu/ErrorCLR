#include<stdio.h>
int main()
{
    int a,b,c,e,i=1;
    scanf("%d %d %d",&a,&b,&c);
    int d=0;
    e=a%4;
    if (e==0)
    {
        while(i<=(b-1))
        {
            switch(i)
            {case 1:
            case 3:
            case 5:
            case 7:
            case 8:
            case 10:
            case 12:
            d=d+31;
            break;
            case 2:
            d=d+29;
            break;
            case 4:
            case 6:
            case 9:
            case 11:
            d=d+30;
            break;
            }
          i++;
        }
    }
    else
    {
        for(i=1;i<=(b-1);i++)
        {
            switch(i)
            {case 1:
            case 3:
            case 5:
            case 7:
            case 8:
            case 10:
            case 12:
            d=d+31;
            break;
            case 2:
            d=d+28;
            break;
            case 4:
            case 6:
            case 9:
            case 11:
            d=d+30;
            break;
            }
        }
    }
    d=d+c;
    printf("%d",d);
    return 0;
}