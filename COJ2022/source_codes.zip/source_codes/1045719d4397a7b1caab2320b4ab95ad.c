#include <stdio.h>
#include <math.h>
int main()
{
    double x,y,z;
    scanf("%lf %lf %lf",&x,&y,&z);
    double s,area;
    s=(x+y+z)/2.0;
    x=s-x;
    y=s-y;
    z=s-z;
    double t;
    t=s*x*y*z;
    area=sqrt(t);
    printf("%.2lf",area);
    return 0;
}