#include<stdio.h>
int main()
{
   double a=0,b=0,c1=0,c2=0,cost=0;
   scanf("%lf %lf",&a,&b);
   if(a>10)
      c1=(24+3*(a-10));
    else {if (a>3)
      c1=(10+2*(a-3));
    else
      c1=10;
		 }
   if (b<=5)
      c2=0;
    else 
    c2=(((int)b/5)*2);
   cost=(int)(c1+c2+0.5);
   printf("%.0f\n",cost);
return 0;
}