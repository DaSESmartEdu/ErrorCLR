#include <stdio.h>
int main()
{
    int m,n,i1=m,i2;
    scanf("%d %d",&m,&n);
    for(i1=1;i1<=1000;i1++)
    {
        if(i1%m==0&&i1%n==0)
        break;
    }
    for(i2=n;i2>=1;i2--)
    {
        if(m%i2==0&&n%i2==0)
        break;
    }
    printf("%d %d",i2,i1);
    return 0;
}