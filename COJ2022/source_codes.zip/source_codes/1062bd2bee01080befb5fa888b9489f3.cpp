#include <iostream>
#include <string>
using namespace std;
int main(void)
{
	string str;
	int count = -1;
	char c;
	int flag = 0;
	while((c = cin.get()) != EOF)
	{
		if(c == '(')
		{
			str[count+1] = c;
			count++;
		}
		else if(c == '[')
		{
			str[count+1] = c;
			count++;
		}
		else if(c == ')')
		{
			if(str[count] != '(')
			{
				flag = 1;
				break;
			}
			else
			{
				count--;
			}
		}
		else if(c == ']')
		{
			if(str[count] != '[')
			{
				flag = 1;
				break;
			}
			else
			{
				count--;
			}
		}
	}
	if(count != -1) flag = 1;
	cout << flag;
}