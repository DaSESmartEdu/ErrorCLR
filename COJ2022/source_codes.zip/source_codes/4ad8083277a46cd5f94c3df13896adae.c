#include<stdio.h>
#include<math.h>
int main()
{int x1,x2,x3,y1,y2,y3;
double area,l;
double a,b,c;
scanf("%d %d %d %d %d %d",&x1,&y1,&x2,&y2,&x3,&y3);
a=sqrt((x1-x2)*(x1-x2)+(y1-y2)*(y1-y2));
b=sqrt((x3-x2)*(x3-x2)+(y3-y2)*(y3-y2));
c=sqrt((x1-x3)*(x1-x3)+(y1-y3)*(y1-y3));
double s=(a+b+c)*0.5;
area=sqrt(s*(s-a)*(s-b)*(s-c));
l=a+b+c;
if ((y1-y2)*(x2-x3)==(y2-y3)*(x1-x2)){printf("impossible");}
else printf("%.2f %.2f",l,area);
return 0;}