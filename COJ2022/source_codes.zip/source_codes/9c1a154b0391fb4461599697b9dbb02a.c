#include <stdio.h>
int main(void)
{
	int m,n,ans1,ans2,m1,n1,mod,m2,n2;
	scanf("%d%d", &m,&n);
	m1=m2=m;
	n1=n2=n;
	while(mod!=0)
	{
		mod=m%n;
		m=n;
		n=mod;
	}
	while(m1!=n1)
	{
		if(m1<n1)
		{
			m1+=m2;
		}
		else
		{
			n1+=n2;
		}
	}
	printf("%d %d", m, m1);
}