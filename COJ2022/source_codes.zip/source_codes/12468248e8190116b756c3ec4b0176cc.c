#include <stdio.h>
int judge(int x)
{
    int i;
    int m=x;
    while(m>0)
    {
        i=m%10;
        if(i==4)
        {
            return 1;
            break;
        }
        m=(m-i)/10;
    }
    m=4;
    while(m<=x)
    {
        if(x%m==0)
        {
            return 1;
            break;
        }
        m=m*10+4;
    }
    return 0;
}
int main()
{
    int L,R;
    scanf("%d %d",&L,&R);
    int x=L;
    int sum=0;
    while(x<=R)
    {
        if(judge(x))
        {
            sum++;
        }
        x++;
    }
    printf("%d",sum);
    return 0;
}