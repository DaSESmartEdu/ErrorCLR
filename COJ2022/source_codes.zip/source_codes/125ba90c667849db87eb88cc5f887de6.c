#include<stdio.h>
#include<string.h>
int main(){
    char *Day[7]={"Sunday","Monday","Tuesday","Wednesdy","Thursday","Friday","Saturday"};
    char *in[10];
    scanf("%s",&in);
    int i=0;
    for(i=0;i<=7;i++){
        if(strcmp(Day[i],in)==0){
            printf("%d",i);
            break;
        }
    }
    if(i==8){
        printf("wrong input!");
    }
    return  0;
}