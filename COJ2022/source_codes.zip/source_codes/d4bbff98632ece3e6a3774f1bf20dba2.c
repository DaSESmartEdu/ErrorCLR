#include<stdio.h>
int main()
{
	int m,n;
	scanf("%d %d",&m,&n);
	double fact = 0;
	int i;
	for(i=m;i<=n;i++){
		fact+=i^2+1/i;
	}	
	printf("%f",fact);	
	return 0;
}