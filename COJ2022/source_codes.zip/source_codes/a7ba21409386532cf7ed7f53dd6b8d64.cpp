#include <stdio.h>
#include<iostream>
using namespace std;
int preOrder[110];
int inOrder[110];
void getPostOrder(int preLeft, int preRight, int inLeft, int inRight) {
         if(preLeft > preRight || inLeft > inRight) {
            return;
         }
      char root = preOrder[preLeft];
         int i = inLeft;
       for( ; i <= inRight; i++) {
          if(inOrder[i] == root)
                 break;
      }
        int leftLen = i - inLeft;
        int rightLen = inRight - i;
         if(leftLen > 0)
            getPostOrder(preLeft+1, preLeft + leftLen, inLeft, i-1);
        if(rightLen > 0)
         getPostOrder(preLeft + leftLen + 1, preRight, i+1, inRight);
          printf("%d ", preOrder[preLeft]);
        return ;
    }
     int main() {
      int m;
    printf("%d",&m);
    for(int i=0; i<m; i++){
     printf("%d",&preOrder[i]);
 }
 for(int i=0; i<m; i++){
     printf("%d",&inOrder[i]);
 }
        getPostOrder(0, m-1, 0, m-1);
   }