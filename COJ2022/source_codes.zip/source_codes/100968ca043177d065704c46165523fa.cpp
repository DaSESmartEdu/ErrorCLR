#include <cstdio>
#include <algorithm>
using namespace std;
const int maxn = 1000;
int n;
int arr[maxn];
bool cmp(int a, int b){
    return a>b;
}
int main(){
    scanf("%d", &n);
    for(int i=0;i<n;i++){
        scanf("%d", &arr[i]);
    }
    sort(arr, arr+n, cmp);
    for(int i=0;i<n;i++){
        printf("%d", arr[i]);
        if (i!=n-1) printf(" ");
    }
    printf("\n");
    return 0;
}