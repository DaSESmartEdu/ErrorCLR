#include <stdio.h>
int main()
{
    double mileage,time,sum;
    mileage=time=sum=0;
    scanf("%lf%lf",&mileage,&time);
    if (mileage<=3) sum=10;
    else if (mileage<=10) sum=10+2*(mileage-3);
    else sum=10+14+3*(mileage-10);
    sum+=(int)(time/5)*2;
    sum=(int)(sum+0.5);
    printf("%0.0lf",sum);
    return 0;
}