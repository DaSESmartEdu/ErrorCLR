#include <stdio.h>
int main()
{
    double a,b,c,d,n,i;
    scanf("%lf",&n);
    c=0;
    for(a=2,b=1,i=1;i<=n;i++){
        c+=(a/b);
        d=b;
        b=a;
        a=a+d;
    }
    printf("%.2f",c);
    return 0;
}