#include <stdio.h>
int main()
{
    int i,n,x,y,z;
    scanf("%d",&n);
	if(n==1){
        printf("1");
    }else{
        x=1;y=1;i=1;
    while(z<n){
        z=x+y;
        x=y;
        y=z;
		i=i+1;
    }
    printf("%d",i);}
    return 0;
}