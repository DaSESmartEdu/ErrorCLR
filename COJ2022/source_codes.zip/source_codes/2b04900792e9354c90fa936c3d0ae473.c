#include <stdio.h>
#include <math.h>
int main()
{
    double h0;
    int times;
    double a;
    scanf("lf %d",&h0,&times);
    printf("%.2lf",a=h0*pow(0.5,times));
    return 0;
}