#include<bits/stdc++.h>
using namespace std;
class Node{
    private:
        int x,y;
    public:
        int getx(){return x;}
        int gety(){return y;}
        void setxy(int a,int b){x = a; y = b;}
};
bool compare(Node A, Node B){
    if (A.getx() > B.getx()) return true;
    else{
	if (A.gety() > B.gety()) return true;
    return false;
    }
}
class Heap{
    public:
        void Heapify(Node a[],int n);
        void Maxheap (Node a[]);
        void HeapSort(Node a[]);
        int size;
};
void Heap::Heapify(Node a[],int n){
    int left = 2*n;
    int right = 2*n+1;
    int largest;
    if (left <= size && compare(a[left],a[n])) largest = left;
    else largest = n;
    if (right <= size && compare(a[right],a[largest])) largest = right;
    if (largest != n){
        swap (a[largest],a[n]);
        Heapify (a,largest);
    }
}
void Heap::Maxheap (Node a[]){
    for (int i = size/2;i>0;i--){
        Heapify(a,i);
    }
}
void Heap::HeapSort (Node a[]){
    Maxheap(a);
    for (int i = size;i>1;i--){
        swap(a[1],a[i]);
        size--;
        Heapify(a,1);
    }
}
int main()
{
    Node a[100];
    Heap myheap;
    int size;
    cin>>size;
    myheap.size = size;
    for (int i = 1;i<=size;i++){
        int x,y;
        cin>>x>>y;
        a[i].setxy(x,y);
    }
    myheap.Maxheap(a);
    myheap.HeapSort(a);
    for (int i = 1;i<=size;i++){
        cout<<"("<<a[i].getx()<<","<<a[i].gety()<<")";
        if (i!= size) cout<<endl;
    }
}