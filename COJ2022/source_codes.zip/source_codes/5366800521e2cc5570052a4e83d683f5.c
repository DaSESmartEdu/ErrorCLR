#include<stdio.h>
#include<math.h>
int main()
{int n;
 scanf("%d",&n);
 float m=0;
 int i=1;
 do
 {
	 m=m+sqrt(i);
	 i++;
 }while(i<=n);
 printf("%.2f",m);
return 0;	
}