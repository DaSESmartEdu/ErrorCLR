#include <stdio.h>
#include <math.h>
int main()
{
int n;
double sum=0;
double p=0;
scanf("%d",&n);
int i=1;
for ( i = 1;i<=n;i++)
{
sum = sum+pow(-1.0,p)*(i/(2*i-1));
p++;
}
printf("%lf",sum);
return 0;
}