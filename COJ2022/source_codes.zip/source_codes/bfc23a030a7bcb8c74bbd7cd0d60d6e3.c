#include <stdio.h>;
int main()
{
    double dis,tim,price1,price2,price;
    int pri;
    scanf("%lf %lf",&dis,&tim);
    if(dis<=3)
    {
     price1=10;
    }
    else if(dis>3&&dis<=10)
    {
        price1=10+(dis-3)*2;
	}
    else
    {
        price1=10+7*2+(dis-10)*3;
    }
       int i;
       i=0;
    if (tim>=5)
    {
       for(i=0;tim>=5;i++)
         {
           tim=tim-5;
           i=i+1;
         }
    }
    price2=i*2;
    price=price1+price2;
   pri=(int)(price+0.5);
   printf("%d",pri);
   return 0;
}