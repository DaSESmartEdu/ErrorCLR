#include <iostream>
using namespace std;
class Bnode{
    public:
    int data;
    char color;
    Bnode *parent,*lChild,*rChild;
};
Bnode *root=new Bnode;
void initial(Bnode *root,int a){
    root->data=a;
    root->color='B';
    root->parent=root->lChild=root->rChild=NULL;
}
void LeftRotate(Bnode *x)
{
	if (NULL == x->rChild) return;
	Bnode *y = x->rChild;
	x->rChild = y->lChild;
	if (NULL != y->lChild)
		y->lChild->parent = x;
	y->parent = x->parent;
	if (NULL == x->parent)
		root = y;
	else if (x == x->parent->lChild)
		x->parent->lChild = y;
	else
		x->parent->rChild = y;
	y->lChild = x;
	x->parent = y;
}
void RightRotate(Bnode *y)
{
	if (NULL == y->lChild) return;
	Bnode *x = y->lChild;
	y->lChild = x->rChild;
	if (NULL != x->rChild)
		x->rChild->parent = y;
	x->parent = y->parent;
	if (NULL == y->parent){
		root = x;
	} else {
		if (y == y->parent->lChild){
			y->parent->lChild = x;
		} else {
			y->parent->rChild = x;
		}
	}
	x->rChild = y;
	y->parent = x;
}
void middle_order(Bnode *Node) {
    if(Node != NULL) {
        middle_order(Node->lChild);
        cout<<Node->color;
        middle_order(Node->rChild);
    }
}
void InsertFix(Bnode *z)
{
	while (z->parent->color == 'R')
	{
		if (z->parent == z->parent->parent->lChild)
		{
			Bnode *y = z->parent->parent->rChild;
			if (y!=NULL&&y->color == 'R'){
				z->parent->color = 'B';
				y->color = 'B';
				z->parent->parent->color = 'R';
				z = z->parent->parent;
			} else {
				if (z == z->parent->rChild){
					z = z->parent;
					LeftRotate(z);
				}
				z->parent->parent->color = 'R';
				z->parent->color = 'B';
				RightRotate(z->parent->parent);
			}
		}
		else
		{
			Bnode *y = z->parent->parent->lChild;
			if (y!=NULL&&y->color == 'R')
			{
				z->parent->color = 'B';
				y->color = 'B';
				z->parent->parent->color = 'R';
				z = z->parent->parent;
			} else {
				if (z == z->parent->lChild)
				{
					z = z->parent;
					RightRotate(z);
				}
				z->parent->color = 'B';
				z->parent->parent->color = 'R';
				LeftRotate(z->parent->parent);
			}
		}
		if(z->parent==NULL){
			break;
		}
	}
	root->color = 'B';
}
void Insert(int a)
{
	Bnode *z = new Bnode;
	z->data = a;
	z->color = 'R';
	z->lChild = z->rChild = NULL;
	Bnode *y = NULL;
	Bnode *x = root;
	while (x){
		y = x;
		if (a < x->data)
			x = x->lChild;
		else
			x = x->rChild;
	}
	z->parent = y;
	if(NULL == y){
		root = z;
	}else if (z->data < y->data){
		y->lChild = z;
	}else{
		y->rChild = z;
	}
	InsertFix(z);
}
int main()
{
    int N;
    cin>>N;
    int a;
    cin>>a;
    initial(root,a);
    for(int i=1;i<N;i++){
        cin>>a;
        Insert(a);
    }
	middle_order(root);
}