#include <bits/stdc++.h>
using namespace std;
int n;
typedef struct{
    int x,y;
} node;
void init();
void percdown(int pos);
vector<node> num;
bool operator>(const node a, const node b){
    if (a.x == b.x) return a.y > b.y;
    else return a.x > b.x;
}
void heapsort(){
    init();
}
void init(){
    for (int i = 1; i < n/2+1; i++)
    {
        percdown(i);
    }
    int len = n;
    for (int i = 0; i < len-1; i++){
        cout << "(" << num[1].x << "," << num[1].y << ")" << endl;
        swap(num[1], num[n]);
        n--;
        percdown(1);
    }
    cout << "(" << num[1].x << "," << num[1].y << ")";
}
void percdown(int pos){
    int parent, child;
    node tmp = num[pos];
    for ( parent = pos; parent*2 <= n; parent = child)
    {
        child = parent<<1;
        if (child != n && num[child] > num[child+1]){
            child++;
        }
        if (tmp > num[child]) swap(num[parent], num[child]);
        else break;
    }
    num[parent] = tmp;
}
int main(){
    cin >> n;
    num = vector<node>(n+1);
    for (int i = 0; i < n; i++){
        cin >> num[i+1].x >> num[i+1].y;
    }
    heapsort();
}