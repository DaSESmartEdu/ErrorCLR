#include<stdio.h>
#include<string.h>
int main()
{
	int n,i,max,min;
	double ave,sum=0;
	int*p,*q;
	p=&max,q=&min;
	double*r;
	r=&ave; 
	scanf("%d",&n);
	int score[n];
	for(i=0;i<n;i++)
	{
		scanf("%d",&score[i]);
	}
	max=score[0];min=score[0];
	for(i=0;i<n;i++)
	{
		if(max<score[i])
		{
			max=score[i];
		}
		if(min>score[i])
		{
			min=score[i];
		}
	}
	for(i=0;i<n;i++)
	{
		sum=sum+score[i];
	}
	ave=(sum-max-min)/(n-2);
	printf("%d %d %.2f\n",*p,*q,*r);
}