#include<stdio.h>
int main()
{   
    int m,n,i;
    i=m;
    scanf("%d%d",&m,&n);
    double x=0;
    for(i=m;i<=n;i++){
        x+=((i*i)+(1.0/i))*1.0;
        printf("%f\n",x);
    }
    printf("%.6f",x);
    return 0;
}