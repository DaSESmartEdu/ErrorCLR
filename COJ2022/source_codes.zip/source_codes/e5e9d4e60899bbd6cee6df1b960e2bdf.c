#include<stdio.h>
int main(){
    int n,yueshu,sum=1;
    int a=1,b=1;
    scanf("%d",&n);
    if(n==1){printf("1");}
    else{
        for(yueshu=3;sum<n;yueshu++){
            sum=a+b;
            a=b;
            b=sum;
        }
        printf("%d",yueshu);
    }
    return 0;
}