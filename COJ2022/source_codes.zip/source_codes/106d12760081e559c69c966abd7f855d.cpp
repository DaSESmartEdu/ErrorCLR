#include<bits/stdc++.h>
using namespace std;
int scoreOfParentheses(string S) {
        stack<int>s;
        for(auto c:S)
        {
            if(c=='(')
                s.push(0);
            else
            {
                if(s.top()==0)
                {
                    s.pop();
                    s.push(1);
                }else{
                    int temp = 0;
                    while(s.top()!=0)
                    {
                        temp+=s.top();
                        s.pop();
                    }
                    s.pop();
                    s.push(temp*2);
                }
            }
        }
        int ans = 0;
        while(!s.empty())
        {
            ans+=s.top();
            s.pop();
        }
        return ans;
    }
int main()
{
    string s;
    cin>>s;
    cout<<scoreOfParentheses(s)<<endl;
    return 0;
}