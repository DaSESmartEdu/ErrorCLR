#include<stdio.h>
#define MAX 1001
int w[MAX];
int main()
{
	int f;
	scanf("%d",&f);
	for(int i=0;i<f;i++)
	scanf("%d",&w[i]);
	int n=f;
	for(n=f;n>0;n--)
	{
	int k=0;
	for(int i=0;i<n-1;i++)
	{
		for(int j=i+1;j<n;j++)
		{
			if(w[i]<w[j])
			{
				k=w[i];
				w[i]=w[j];
				w[j]=k;
			}
		}
	}
	if(w[0]==w[1])
	{
		if(n>2)
		for(int i=0;i<n-2;i++)
		w[i]=w[i+2];
		else
		w[0]=0;
		n--;
	}else{
		if(w[0]>w[1])
		{
			w[0]=w[0]-w[1];
			for(int i=1;i<n-1;i++)
			w[i]=w[i+1];
		}
		else if(w[1]>w[0])
		{
			w[1]=w[1]-w[0];
			for(int i=0;i<n-1;i++)
			w[i]=w[i+1];
		}
	}
	}
	printf("%d",w[0]);
	return 0;
}