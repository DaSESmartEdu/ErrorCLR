#include <stdio.h>
int main(){
    int m,n;
    scanf("%d %d",&m,&n);
    int yve,bei;
    int x,y;
    int min,max;
    if(m<=n){
        min=m;
        max=n;
    }
    else{
        min=n;
        max=m;
    }
    for(x=2;x<=min;x++){
        if(m%x==0&&n%x==0){
            yve=x;
        }
    }
    for(y=max;y<=1000000;y++){
        if(y%m==0&&y%n==0){
            bei=y;
            break;
        }
    }
    printf("%d %d",yve,bei);
    return 0;
}