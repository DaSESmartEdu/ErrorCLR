# include <stdio.h>
int main()
{
    int i,n;
    double m[n];
    scanf("%d\n",&n);
    for(i=0;i<n;i++)
          scanf("%lf",&m[n]);
for(i=0;i<n;i++){
    if(m[n]>=90.0){
    printf("A ");
    }
    else if(m[n]<90.0&&m[n]>=80.0)
    {
    printf("B ");
    }
    else if(m[n]<80.0&&m[n]>=70.0)
    {
     printf("C ");
    }
    else if(m[n]<70.0&&m[n]>=60.0)
    {
     printf("D ");
    }
    else
    {
     printf("E ");
    }
}
    return 0;
}