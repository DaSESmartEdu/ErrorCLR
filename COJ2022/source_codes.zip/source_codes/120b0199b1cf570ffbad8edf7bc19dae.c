#include<stdio.h>
#include<math.h>
int number(char* arr,int k)
{
	int i,num=0;
	char* p=arr;
	int cou[26]={0};
	for(i=0;i<k;i++){
		int t=*p-'a';
		p++;
		cou[t]=cou[t]+1;
	}
	for(i=0;i<26;i++){
		if(cou[i]!=0){
			num++;
		}
	}
	return num;
}
int main( )
{
    int i,m=0,n;
    char arr[100][100]={'\0'};
    scanf("%d",&n);
	int count[100]={0};
    for(i=0;i<n;i++){
        scanf("%s",arr[i]);
		count[i]=number(arr[i],strlen(arr[i]));
    }
	int t=count[0];
    for(i=0;i<n;i++){
        if(count[i]>=t){
			t=count[i];
			m=i;
		}
    }
	i=0;
	while(count[i]!=t){
		i++;
	}
	printf("%s",arr[i]);
    return 0;
}