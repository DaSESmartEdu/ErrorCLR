#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;
int n,fa[10005];
struct Edge{
    int f,t,w;
};
bool cmp(const Edge &a,const Edge &b){
    return a.w<b.w;
}
vector<Edge> E;
int getfa(int x) { return fa[x] == x ? x : fa[x] = getfa(fa[x]); }
int main(){
    int m, res=0, cnt=0; scanf("%d%d",&n,&m);
    for (int i = 0; i < m; ++i) {
        Edge e;
        scanf("%d%d%d", &e.f, &e.t, &e.w);
        E.push_back(e);
    }
    sort(E.begin(), E.end(), cmp);
    for (int i = 1; i <= n; ++i) fa[i] = i;
    for (int i = 0; i < m; ++i) {
        if (cnt == n-1) break;
        int u = getfa(E[i].f), v = getfa(E[i].t);
        if(u == v) continue;
        fa[u] = v; cnt++; res+=E[i].w;
    }
    printf("%d",res);
    return 0;
}