#include <iostream>
using namespace std;
main(){
	int temp, n, flag = 1;
	cin >> n;
	for (int i = 0; i < n; i++) {
		for (int j = 0; j < n; j++) {
			cin >> temp;
			if (i > j && temp != 0) {
				flag = 0;
			}
		} 
	}
	if (!flag) cout << "NO"; 
	else cout << "YES";
}