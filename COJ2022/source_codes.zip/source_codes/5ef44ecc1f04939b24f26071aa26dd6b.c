#include <stdio.h>
int main()
{
    double a,b,c,d=0,e,i,f,sum;
	int n;
    c=10.0;
    i=0;
    scanf("%lf %lf",&a,&b);
    if(a<=3){
        d=c;
    }else if(a<=10){
        d=c+(a-3)*2;
    }else{
        d=c+14.0+(a-10)*3;
    }
    if(f<1){
        e=0;
    }else{
            for(i=0;f>=1;i++){
                b-=5;
				f=b/5;
            }
            e=i*2;
    }
    sum=d+e;
    n=(int)(sum+0.5);
    printf("%d",n);
    return 0;
}