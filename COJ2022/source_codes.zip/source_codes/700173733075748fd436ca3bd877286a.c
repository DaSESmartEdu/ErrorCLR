#include <stdio.h>
int main()
{
    int n,i;
    double height,sum;
    scanf("%lf %d",&height,&n);
    sum=height;
    for(i=1;i<=n;i++)
    {
       height=height/2.0;
    }
    printf("%.1lf",height);
    return 0;
}