#include<stdio.h>
int main ()
{
    int denominator=1, flag=1, i=0, n=0, zi=1 ;
    double item=0, sum=0;
    scanf("%d",&n);
    for(i=1;i<=(n+1);i++){
        sum=sum+item;
		item=flag*zi*1.0/denominator;
        denominator=denominator+2;
        zi=zi+1;
		flag=-flag;
    }
    printf("sum=%f",sum);
    return 0;
}