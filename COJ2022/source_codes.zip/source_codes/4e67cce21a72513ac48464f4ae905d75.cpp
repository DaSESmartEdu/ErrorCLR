#include<iostream>
#include<vector>
using namespace std;
vector<vector<int>> res;
void Subset(vector<int>lst,int k);
void dfs(int k,vector<int>&tmp,int start,vector<int>lst);
void Subset(vector<int>lst,int k){
    vector<int> tmp;
    dfs(k,tmp,0,lst);
}
void dfs(int k,vector<int>&tmp,int start,vector<int>lst){
    if(k<0) return;
    if(k==0){
        res.push_back(tmp);
        return;
    }
    for(int i=start;i<lst.size();i++){
        tmp.push_back(lst[i]);
        dfs(k-lst[i],tmp,i+1,lst);
        tmp.pop_back();
    }
}
int main(){
    int n;
    vector<int> lst;
    cin>>n;
    for(int i=0;i<n;i++){
        int itm;
        cin>>itm;
        lst.push_back(itm);
    }
    int k;
    cin>>k;
    Subset(lst,k);
    if(res.empty()){
        cout<<-1;
    }
    else{
        int max=0;
        int maxindex;
        for(int i=0;i<res.size();i++){
            if(res[i].size()>max){
                max=res[i].size();
                maxindex=i;
            }
        }
        int size=res[maxindex].size();
        for(int i=0;i<n;i++){
            if(lst[i]==res[maxindex][size-1]){
                cout<<i;
                break;
            }
        }
    }
    return 0;
}