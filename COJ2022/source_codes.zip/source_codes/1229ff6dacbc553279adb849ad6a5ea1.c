#include<stdio.h>
char set_grade(int n);
struct student{
    int num;
    char name[100];
    int score;
    char grade;
};
int main()
{
    int n,i,count=0;
    scanf("%d",&n);
    struct student a[100];
    for(i=0;i<n;i++){
        scanf("%d %s %d",&a[i].num,&a[i].name,&a[i].score);}
	for(i=0;i<n;i++){
		a[i].grade=set_grade(a[i].score);
        if(a[i].score<60)
        count++;
	}		
    printf("The count for failed (<60): %d\n",count);
    printf("The grades:\n");
    for(i=0;i<n;i++)
    printf("%d %s %c\n",a[i].num,a[i].name,a[i].grade);
    return 0;
}
char set_grade(int n)
{
    if(n>=85&&n<=100)
    return 'A';
    if(n>=70&&n<=84)
    return 'B';
    if(n>=60&&n<=69)
    return 'C';
    if(n<60)
    return 'D';
}