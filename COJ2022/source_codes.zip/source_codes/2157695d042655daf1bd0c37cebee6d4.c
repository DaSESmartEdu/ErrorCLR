#include<stdio.h>
int main()
{
	double a,b;
	scanf("%d%d",&a,&b);
	double sum = (a-b)/b;
	if(sum < 0.1)
	{
		printf("normal");
	}
	else if(sum >= 0.1 && sum < 0.5)
	{
		printf("200");
	}
	else if(sum >= 0.5)
	{
		printf("revoke");
	}
	return 0;
}