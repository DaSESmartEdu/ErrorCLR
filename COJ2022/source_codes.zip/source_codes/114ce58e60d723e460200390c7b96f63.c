#include<stdio.h>
#include<stdlib.h>
#include<string.h>
struct list
{
    char word[10000];
    int n ;
};
int main()
{
    struct list l[10000],t;
    char temp[10000];
    int i=0;
    while((scanf("%s",temp))!=EOF)
    {
        if(i==0)
        {
            strcpy(l[i].word,temp);
            i++;
        }else
        {
            int k=0;
            while(k<i)
            {
                if((strcmp(l[k].word,temp))==0)
                {
                    l[k].n++;
                    break;
                }
                k++;
            }
            if(k>=i)
            {
                strcpy(l[i].word,temp);
                i++;
            }
        }
    }
    for(int c=0;c<10000;c++)
    {
        for(int d=0;d<i;d++)
        {
            if(l[d].n==c)
            {
                printf("%s ",l[d].word);
            }
        }
    }
    return 0;
}