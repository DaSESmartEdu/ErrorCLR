#include<stdio.h>
#include<math.h>
double calculate(int a,int b,int c,int d){
    double e;
    e=sqrt(1.0*(c-a)*(c-a)+1.0*(d-b)*(d-b));
    return e;
}
int main(){
    int x1,y1,x2,y2,x3,y3;
    double c1,c2,c3,c4,s;
    scanf("%d %d %d %d %d %d",&x1,&y1,&x2,&y2,&x3,&y3);
    if((x1-x2)*(y1-y3)==(x1-x3)*(y1-y2)){
        printf("impossible");
    }else{
    c1=calculate(x2,y2,x3,y3);
    c2=calculate(x1,y1,x3,y3);
    c3=calculate(x1,y1,x2,y2);
    c4=(c1+c2+c3)/2;
    s=sqrt(c4*(c4-c1)*(c4-c2)*(c4-c3));
    printf("%.2lf %.2lf",c4*2,s);
    }
    return 0;
}