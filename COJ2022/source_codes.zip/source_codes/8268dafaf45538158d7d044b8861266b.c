#include<stdio.h>
int sign(int x){
	int result=0;
	if(x>0)
		result=1;
	else if(x=0)
		result=0;
	else if(x<0)
		result=-1;
	return result;
}
int main(){
	int n;
	scanf("%d",&n);
	printf("%d",sign(n));
	return 0;
}