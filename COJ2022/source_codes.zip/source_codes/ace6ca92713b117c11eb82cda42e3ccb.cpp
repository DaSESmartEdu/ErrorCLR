#include <iostream>
#include <vector>
using namespace std;
typedef struct point{
    int x;
    int y;
}point;
class heap
{
    public:
    heap();
    void heapsort(vector<point> &heaps,int i,int l);
    void swap(point &a,point &b);
    int prepare(vector<point> &heaps,int a,int b);
    void print(vector<point> &res);
    void print_and_rebuild();
    int m,n=0,N=0,k;
    private:
    vector<point> heapen;
};
heap::heap()
{
    cin>>m>>k;
    for(int i=0;i<k-1;i++){
        point a;
        cin>>a.x>>a.y;
        heapen.push_back(a);
        n++;
    }
    for(int i=n/2-1;i>=0;i--){
        heapsort(heapen,i,n);
    }
    return;
}
void heap::swap(point &a,point &b)
{
    point temp=a;
    a=b;
    b=temp;
    return;
}
int heap::prepare(vector<point> &heaps,int a,int b)
{
    int less;
    if(heaps[a].x<heaps[b].x){
        less=a;
    }else if(heaps[a].x==heaps[b].x){
        if(heaps[a].y<heaps[b].y){
            less=a;
        }else{
            less=b;
        }
    }else{
        less=b;
    }
    return less;
}
void heap::heapsort(vector<point> &heaps,int i,int l)
{
    int less=i;
    int lson=i*2+1,rson=i*2+2;
    if(lson<n&&prepare(heaps,less,lson)==lson){
        less=lson;
    }
    if(rson<n&&prepare(heaps,less,rson)==rson){
        less=rson;
    }
    if(less!=i){
        swap(heaps[i],heaps[less]);
        heapsort(heaps,less,l);
    }
    return;
}
void heap::print(vector<point> &res)
{
    for(int i=0;i<k;i++){
        cout<<'('<<res[0].x<<','<<res[0].y<<')'<<endl;
        res[0]=res[N-1];
        N--;
        heapsort(res,0,N);
    }
    return;
}
void heap::print_and_rebuild()
{
    point a;int j=n;
    cin>>a.x>>a.y;
    n++;
    heapen.push_back(a);
    while(j>0&&prepare(heapen,j,(j-1)/2)==j){
        swap(heapen[j],heapen[(j-1)/2]);
        j=(j-1)/2;
    }
    vector<point> res=heapen;
    N=n;
    print(res);
    return;
}
int main()
{
    heap sss;
    for(int i=0;i<sss.m-sss.k+1;i++){
        sss.print_and_rebuild();
    }
    return 0;
}