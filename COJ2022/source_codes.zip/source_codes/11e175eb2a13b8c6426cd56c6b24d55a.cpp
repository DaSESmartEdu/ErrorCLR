#include<iostream>
#include<cstdio>
#include<cmath>
using namespace std;
int main() {
	int m, n; float sum; sum = 0;
	cin >> m >> n;
	for (float i = m; i <= n; i++) { 
		sum += pow(i, 2) + (1 / i);
	}
	printf("%.6f", (float)sum);
}