#include <stdio.h>
#include <math.h>
int main()
{
    int x1, x2, x3, y1, y2, y3;
    scanf("%d %d %d %d %d %d", &x1, &y1, &x2, &y2, &x3, &y3);
    double a, b, c, l, s, S, t;
    a = sqrt((x2-x1)*(x2-x1)+(y2-y1)*(y2-y1));
    b = sqrt((x2-x3)*(x2-x3)+(y2-y3)*(y2-y3));
    c = sqrt((x1-x3)*(x1-x3)+(y1-y3)*(y1-y3));
    if(a > b){
        t = a;
        a = b;
        b = t;
    }
    if(a > c){
        t = a;
        a = c;
        c = t;
    }
    if(b > c){
        t = b;
        b = c;
        c = t;
    }
    printf("%lf %lf %lf",a, b, c);
    if(a + b <= c){
        printf("Impossible");
    }
    else{
        l = a + b + c;
        s = l/ 2.0;
        S = sqrt(s*(s-a)*(s-b)*(s-c));
        printf("%.2lf %.2lf", l, S);
    }
    return 0;
}