#include<iostream>
#include<string>
using namespace std;
int main() {
	string a, b;
	cin >> a >> b;
	int len = a.size();
	int num = 0;
	while (len>=2) {
		if (a[len - 1] == b[len - 1])len--;
		else {
			num++;
			if (a[len-1]=='*')
			{
				a[len - 1] = 'o';
				if (a[len - 2] == '*')
				{
					a[len - 2] = 'o';
				}
				else {
					a[len - 2] = '*';
				}
			}
			else {
				a[len - 1] = '*';
				if (a[len - 2] == '*')
				{
					a[len - 2] = 'o';
				}
				else {
					a[len - 2] = '*';
				}
			}
			len--;
		}
	}
	cout << num;
}