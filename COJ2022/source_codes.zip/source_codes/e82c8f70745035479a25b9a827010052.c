#include<stdio.h>
#include<math.h>
double fact(int n)
{
    int i;
	double prod=1;
	for (i=1;i<=n;i++)
	{
		prod=prod*i;
	}
	return prod;
}
int main()
{
    int n=0;
    double x=0, sum=0, c=1;
    scanf("%lf",&x);
    while(fabs(c)>=0.00001)
    {
        printf("%d ",n);
        c=pow(x,n)/fact(n);
        printf("%lf ",c);
        n++;
        sum=sum+c;
        printf("%lf\n", sum);
    }
    printf("%.4lf",sum);
    return 0;
}