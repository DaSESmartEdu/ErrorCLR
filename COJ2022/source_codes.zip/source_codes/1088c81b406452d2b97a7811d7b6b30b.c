#include<stdio.h>
int main()
{
	int num[100000];
	int num1[100000];
	int n;
	int m;
	scanf("%d %d",&m,&n);
for (int i=0;i<=m-1;i++)
{
	scanf("%d",&num[i]);
}
for (int j=n-1;j>=0;j--)
{
	scanf("%d",&num1[j]);
}
int num2[200000];
int i=0;
int j=0;
int t=0;
while (i<=m-1&&j<=n-1)
{
	if (num[i]<=num1[j])
	{
		num2[t]=num[i];
		i=i+1;
	}
	else
	{
		num2[t]=num1[j];
		j=j+1;
	}
	t=t+1;
}
if (i<=m-1)
{
	for (int x=i;x<=m-1;x++)
	{
		num2[t]=num[i];
		t++;
		i++;
	}
}
else
{
	for (int x=j;x<=n-1;x++)
	{
		num2[t]=num1[j];
		t++;
		j++;
	}
}
for (int i=0;i<=m+n-1;i++)
{
	if (i==0)
	printf("%d",num2[i]);
	else
	printf(" %d",num2[i]);
}
return 0;
}