#include <stdio.h>
int f(int n){
    if (n<=0) return 0;
    if (n<=2) return 1;
    return f(n-1) + f(n-2)+f(n-3);
}
int main(){
    int x;
    scanf("%d", &x);
    int n = 1;
    while(f(n) < x){
        n++;
    }
    printf("%d", n);
    return 0;
}