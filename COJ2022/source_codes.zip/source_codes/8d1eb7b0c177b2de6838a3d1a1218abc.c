#include<stdio.h>
int sign(int x){
    if(x>0){
        return 1;
    }
    else if(x=0){
        return 0;
    }
    else if(x<0)
    {
        return -1;
    }
}
int main(){
    int x;
    scanf("%d",&x);
    printf("%d",sign(x));
    return 0;
}