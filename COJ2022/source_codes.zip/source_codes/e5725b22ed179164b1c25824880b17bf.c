#include<stdio.h>
 int main()
 {
    int a,total=0;
    scanf("%d",&a);
    while (a<=0){
        if(a%2==1){
            total+=a;
        }
        scanf("%d",&a);
    } 
    printf("%d",total);
    return 0;
 }