#include <iostream>
#include <cstring>
using namespace std; 
typedef char Stack_entry;
enum Error_code{underflow, overflow, success};
const int maxstack = 100;   
class MyStack {
public:
   MyStack();
   bool empty() {return count==0;}
   int size(){return count;}
   Error_code pop();
   Error_code top(Stack_entry &item) ;
   Error_code push(Stack_entry &item);
private:
   int count;
   Stack_entry entry[maxstack];
};
MyStack::MyStack()
{
    count=0;
    memset(entry,0,sizeof(entry));
}
Error_code MyStack::pop()
{
    if(empty())
    {
        return Error_code::underflow;
    }
    count--;
    return Error_code::success;
}
Error_code MyStack::top(Stack_entry &item)
{
    if(empty())
    {
        return Error_code::underflow;
    }
    item=entry[count-1];
    return Error_code::success;
}
Error_code MyStack::push(Stack_entry &item)
{
    if(count==maxstack)
    {
        return Error_code::overflow;
    }
    entry[count]=item;
    count++;
    return Error_code::success;
}
int main()
{
    MyStack stack;
    string s;
    cin>>s;
    bool match=true;
    for(int i=0;i<s.size();i++)
    {
        if(s[i]=='('||s[i]=='[')
        {
            stack.push(s[i]);
        }
        else if(s[i]==')'||s[i]==']')
        {
            char c;
            stack.top(c);
            stack.pop();
            if((s[i]==')'&&c=='(')||(s[i]==']'&&c=='['))
            {
                continue;
            }
            else
            {
                break;
            }
        }
    }
    if(stack.empty())
    {
        match=false;
    }
    if(match==true)
    {
        cout<<1;
    }
    else
    {
        cout<<0;
    }
    return 0;
}