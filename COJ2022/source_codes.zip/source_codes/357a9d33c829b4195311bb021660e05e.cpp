#include<iostream>
using namespace std;
class Node{
private:
    int x,y;
public:
    int getx(){
        return x;
    };
    int gety(){
        return y;
    };
    void setxy(int a,int b){
        x=a;
        y=b;
    };
};
bool compare(Node a,Node b){
    if(a.getx()>b.getx()){
        return true;
    }else if(a.getx()==b.getx()&&a.gety()>b.gety()){
        return true;
    }else{
        return false;
    }
}
class Heap{
public:
    void Heapify(Node arr[],int n);
    void Maxheap(Node arr[]);
    void Heapsort(Node arr[]);
    int len;
};
void Heap::Heapify(Node arr[],int n){
    int left=2*n;
    int right=2*n+1;
    int maxx;
    if(left<=len&&compare(arr[left-1],arr[n-1])){
        maxx=left;
    }else{
        maxx=right;
    }
    if(right<=len&&compare(arr[right-1],arr[maxx-1])){
        maxx=right;
    }
    if(maxx!=n){
        swap(arr[maxx-1],arr[n-1]);
        Heapify(arr,maxx);
    }
}
void Heap::Maxheap(Node arr[]){
    for(int i=len/2;i>0;i--){
        Heapify(arr,i);
    }
}
void Heap::Heapsort(Node arr[]){
    Maxheap(arr);
    for(int i=len-1;i>0;i--){
        swap(arr[0],arr[i]);
        len--;
        Heapify(arr,1);
    }
}
int main(){
    Node arr[100];
    Heap myheap;
    int len;
    cin>>len;
    myheap.len=len;
    for(int i=0;i<len;i++){
        int x,y;
        cin>>x>>y;
        arr[i].setxy(x,y);
    }
    myheap.Heapsort(arr);
    for(int i=0;i<len;i++){
        cout<<"("<<arr[i].getx()<<","<<arr[i].gety()<<")";
        if(i!=len-1){
            cout<<endl;
        }
    }
}