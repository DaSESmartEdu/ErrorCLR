int main()
{
    int m,n;
    double fact,i;
    scanf("%d %d",&m,&n);
    for(i=m;i<=n;i++)
    {
        fact+=i*i+1/i;
    }
    printf("%.6f\n",fact);
	return 0;
}