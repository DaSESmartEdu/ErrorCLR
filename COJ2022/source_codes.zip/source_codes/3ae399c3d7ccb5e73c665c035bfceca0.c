#include<stdio.h>
#include<math.h>
int main()
{
    int x1,x2,x3,y1,y2,y3;
    double area,s,a,b,c;
    scanf("%d %d %d %d %d %d" , &x1, &y1, &x2, &y2, &x3, &y3);
    a=sqrt(pow((x1-x2),2)+pow((y1-y2),2));
    b=sqrt(pow((x2-x3),2)+pow((y2-y3),2));
    c=sqrt(pow((x3-x1),2)+pow((y3-y1),2));
    if(a+b>c&&a+c>b&&b+c>a){
        s=(a+b+c)/2;
        area=sqrt(s*(s-a)*(s-b)*(s-c));
        printf("%.2lf %.2lf\n",2*s, area );
    }
    else
        printf("impossible");
    return 0;
}