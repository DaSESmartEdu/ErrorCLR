#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
int even(int n)
{
    if(n%2==0)
        return 1;
    else
        return 0;
}
int OddSum(int List[],int N)
{
    int res=0;
    for(int i=0;i<N;i++)
    {
        if(even(List[i])==0)
            res+=List[i];
    }
    return res;
}
int main()
{
    int n;
    cin>>n;
    int a[n];
    for(int i=0;i<n;i++)
        cin>>a[i];
    int res=OddSum(a,n);
    cout<<res<<endl;
    return 0;
}