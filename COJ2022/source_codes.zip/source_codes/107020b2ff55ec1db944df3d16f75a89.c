#include<stdio.h>
int main(){
    char ch[100]={0};
    int i;
    int number=0;
    gets(ch);
        for(i=0;i<100;i++){
            if(ch[i]==' '&&ch[i+1]!=' '&&ch[i+1]!='\0'){
            number++;}
        }     
        if(ch[0]==' ')
          printf("%d",number);
       else{ printf("%d",number+1);} 
    return 0;
}