#include <bits/stdc++.h>
using namespace std;
long long a[1000005];
int main()
{
    int n;
    cin >> n;
    for(int i=0;i<n;i++)
    {
        scanf("%lld",&a[i]);
    }
    int num=0;
    long long maxx=-1e9;
    long long minn = 1e12;
    int ans = 0;
    for(int i=0;i<n;i++)
    {
        if(a[i]>0){
            num++;
            if(a[i]>maxx){
                maxx = a[i];
            }
            if(a[i]<minn){
                minn = a[i];
            }
        }else{
            if(num>=30 && minn*100>=minn){
                ans++;
            }
            num = 0;
            maxx=-1e9;
            minn = 1e12;
        }
        if(i==n-1 && a[i]>0){
            if(num>=30 && minn*100>=minn){
                ans++;
            }
            num = 0;
            maxx=-1e9;
            minn = 1e12;
        }
    }
    cout << ans << endl;
}