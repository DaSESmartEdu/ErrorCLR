#include <stdio.h>
int main()
{
    int i,j,k,n,m=0;
    scanf ("%d",&n);
    for (i=1;i<=9;i++)
    {
        for (j=1;j<=9;j++)
        {
            for (k=1;k<=9;k++)
            {
                if (5*i+2*j+k==n)
                m++;
            }
        }
    }
     printf ("%d",m);
     return 0;
}