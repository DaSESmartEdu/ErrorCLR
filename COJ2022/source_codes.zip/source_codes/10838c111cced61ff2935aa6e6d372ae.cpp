#include<iostream>
using namespace std;
int fx(int x)
{
    if(x==0) return 1;
    else return x*fx(x-1);
}
double funcos( double e, double x )
{
    int k=-1;
    double temp=1, temp1=1,temp2=1,ans=1;
    for(int i= 2;temp>e;i=i+2){ 
            temp1=temp1*x*x;
            temp2=temp2*i*(i-1);
            temp=temp1/temp2;
        ans=ans+k*temp;
        k=-k;
    }
    return ans;
}
int main()
{
    double  e ,x;
    cin>>e>>x;
    double ans=funcos(e,x);
    cout<<ans;
}