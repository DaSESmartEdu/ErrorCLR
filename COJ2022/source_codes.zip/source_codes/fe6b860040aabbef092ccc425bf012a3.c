#include<stdio.h>
#include<math.h>
double funcos( double e, double x );
double fact (int n);
double fact (int n)
{
    int i;
    double hh=1;
    for (i=1 ; i <=n; i++)
    {
        hh*=i;
    }
    return hh;    
}
double funcos( double e, double x )
{
    int i=0,j=0;
    double m,cos=1;
    m=pow(x,0)/fact(0);
    while (fabs(m)>=e)
    {
        i++;
        j+=2;
        m=pow(x,j)/fact(j);
        cos+=pow(-1,i)*m;
    }
	cos-=pow(-1,i-1)*m;
    printf("%.6f",cos);
    return cos;
}
int main()
{
    double e,x;
    scanf("%lf%lf",&e,&x);
    funcos(e,x);
}