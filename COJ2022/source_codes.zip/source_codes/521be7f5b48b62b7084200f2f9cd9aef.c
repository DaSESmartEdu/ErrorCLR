#include <stdio.h>
int main()
{
    float n,m;
    int ticket=200;
    scanf("%d %d",&n,&m);
    if((n-m)<10)
    {
        printf("normal\n");
    }
    else if((n-m)>=10&&(n-m)<50)
    {
        printf("%d\n",ticket);
    }
    else
    {
        printf("revoke\n");
    }
    return 0;
}