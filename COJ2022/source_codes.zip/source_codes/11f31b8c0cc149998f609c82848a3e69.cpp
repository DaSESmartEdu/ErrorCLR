#include<iostream>
#include<cstdio>
#include<cmath>
#include<algorithm>
#include<queue>
#include<string>
using namespace std;
int arr[110];
int fs[110];
int zs[110];
int main() {
	int n; int zsn= 0; int fsn = 0;
	cin >> n;
	for (int i = 0; i < n; i++) {
		cin >> arr[i];
		if (arr[i] < 0) {
			fs[fsn] = arr[i];
			fsn++;
		}
		else if (arr[i] > 0) {
			zs[zsn] = arr[i];
			zsn++;
		}
	}
	for (int i = 0; i < zsn; i++) {
		for (int j = 0; j < zsn - 1 - i; j++) {
			if (zs[j] > zs[j + 1]) {
				int temp = zs[j];
				zs[j] = zs[j + 1];
				zs[j + 1] = temp;
			}
		}
	}
	for (int i = 0; i < fsn; i++) {
		for (int j = 0; j < fsn - 1 - i; j++) {
			if (fs[j] < fs[j + 1]) {
				int temp = fs[j];
				fs[j] = fs[j + 1];
				fs[j + 1] = temp;
			}
		}
	}
	int d1 = 0,  d2 = 0;
	for (int i = 0; i < n; i++) {
		if (arr[i] > 0) {
			printf("%d ", zs[d1++]);
		}
		else if (arr[i] < 0) {
			printf("%d ", fs[d2++]);
		}
		else {
			printf("0 ");
		}
	}
	return 0;
}