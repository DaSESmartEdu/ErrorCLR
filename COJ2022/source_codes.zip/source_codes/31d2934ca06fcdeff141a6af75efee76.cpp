#include<bits/stdc++.h>
using namespace std;
typedef struct Tree_Node{
    char data;
    Tree_Node *l, *r;
}BinTree;
char ans[105];
int ind = 0;
BinTree* buildTree(BinTree* &(root),string nums,int& length){
    if(length >= 0){
        if(nums[length] == '#'){
            root = NULL;
        }
        else{
            root = new BinTree;
            root->data = nums[length];
            buildTree(root->r, nums, --length);
            buildTree(root->l, nums, --length);
        }
    }
    return root;
}
void midOrder(BinTree *root){
    if(root){
        midOrder(root->l);
        ans[ind] = root->data;
        ind++;
        if(root->l == NULL){
        }
        midOrder(root->r);
    }
}
BinTree *searchN(BinTree *root, char target){
    if(root!=NULL){
        if(root->data == target){
            cout << target << " "<<endl;
            return root;
        }
        else{
            cout << root->data<<" ";
            if(root->data > target){
                return searchN(root->l,target);
            }
            if(root->data < target){
                return searchN(root->r,target);
            }
        }
    }
    return NULL;
}
BinTree *findMin(BinTree *root){
    if(!root){
        return NULL;
    }else if (!root->l){
        return root;
    }else{
        return findMin(root->l);
    }
}
BinTree *dele(BinTree *root, char target_2){
    BinTree *tmp;
    if(root){
        if(root->data>target_2){
            root->l = dele(root->l, target_2);
        }
        else if(root->data < target_2){
            root->r = dele(root->r, target_2);
        }
        else{
            if(root->l && root->r){
                tmp=findMin(root->r);
				root->data=tmp->data;
				root->r=dele(root->r,root->data);
            }
            else{
                tmp = root;
                if(!root->l){
                    root = root->r;
                }
                else{
                    root = root->l;
                }
                delete tmp;
            }
        }
    }
    return root;
}
int main()
{
    string nums;
    cin >> nums;
    char target;
    char wdel;
    cin >> target >> wdel;
    int length = nums.length()-1;
    BinTree* root = NULL;
    root = buildTree(root, nums, length);
    searchN(root, target);
    root = dele(root, wdel);
    midOrder(root);
    for (int i = 0; i < ind-1;i++){
        cout << ans[i] << " ";
    }
    cout << ans[ind-1];
    return 0;
}