#include<stdio.h>
int main()
{
    int n, i=0, j=0, p=1, q=0,count=0;
    scanf("%d\n", &n);
    int a[n][n];
    for(;i<n;i++)
    {
        for(;j<n;j++)
        {
            scanf("%d", &a[i][j]);
        }
    }
    for(p=1;p<n;p++)
    {
        for(q=0;q<p;q++)
        {
            if(a[p][q]!=0)
            count++;
        }
    }
    if(count==0)
    printf("YES");
    else
    printf("NO");
    return 0;
}