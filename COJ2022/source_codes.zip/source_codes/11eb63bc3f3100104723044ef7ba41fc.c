#include <stdio.h>
#include <math.h>
int main()
{
    int a=0,n=0,i=0,sum=0,x=0;
    scanf("%d %d",&a,&n);
    for(i=0;i<n;i++){
        x+=pow(10,i)*a;
        sum+=x;
    }
    printf("%d",sum);
    return 0;
}