#include <bits/stdc++.h>
using namespace std;
int N = 0, M = 0;
int f[20010];
int hei[20010];
void init()
{
    for (int i = 0; i < N; i++)
    {
        f[i] = i;
        hei[i] = 1;
    }
}
int findRoot(int x)
{
    return f[x] == x ? x : findRoot(f[x]); 
}
void merge(int x, int y)
{
    int rootx = findRoot(x);
    int rooty = findRoot(y);
    if (rootx != rooty)
    {
        if (hei[rootx] < hei[rooty])
            f[rootx] = rooty;
        else if (hei[rooty] < hei[rootx])
            f[rooty] = rootx;
        else{
            f[rootx] = rooty;
            hei[rooty]++;
        }
    }
}
int main()
{
    int x, y;
    while (cin >> N && N)
    {
        cin >> M;
        int cnt = 0;
        init();
        while (M--)
        {
            cin >> x >> y;
            merge(x, y);
        }
        for (int i = 0; i < N; i++)
            if (findRoot(f[i]) == i)
                cnt++;
        cnt--;
        cout << cnt << endl;
    }
}