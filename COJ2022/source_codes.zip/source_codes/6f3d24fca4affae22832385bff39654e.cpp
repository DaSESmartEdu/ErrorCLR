#include<iostream>
#include<cstring>
using namespace std;
class FindPath{
public:
    int n,m;
    void init();
    int dfs(int rol,int col);
    int matrix[100][100];
    int visited[100][100];
private:
    bool cango(int x1,int y1,int x2,int y2);
};
void FindPath::init() {
    cin>>m;
    cin>>n;
    memset(matrix,-1,sizeof (matrix));
    for(int i=1;i<=m;i++){
        for(int j=1;j<=n;j++){
            cin>>matrix[i][j];
        }
    }
    memset(visited,0,sizeof (visited));
}
bool FindPath::cango(int x1, int y1,int x2,int y2) {
    if((matrix[x1][y1]!=matrix[x2][y2])&&(matrix[x1][y1]!=-1)&&(matrix[x2][y2]!=-1)){
        return true;
    } else{
        return false;
    }
}
int FindPath::dfs(int row,int col){
    int res=0;
    if(row==m&&col==n){
        res=1;
    }
    int dir[4][2]={{-1,0},{1,0},{0,-1},{0,1}};
    for(int z=0;z<4;z++){
        int tmpr=row+dir[z][0];
        int tmpc=col+dir[z][1];
        if(cango(row,col,tmpr,tmpc)&&!visited[tmpr][tmpc]){
            visited[tmpr][tmpc]=1;
            res=dfs(tmpr,tmpc);
        }
    }
    return res;
}
int main(){
    FindPath P;
    P.init();
    int res=P.dfs(1,1);
    cout<<res;
}