#include<stdio.h>
#include<stdlib.h>
#include<string.h>
int main()
{
    char *s[10000];
    char str[200];
    int i=0,n;
    int j,k;        
    while(1)
    {   
        scanf("%s",str);   
        s[i]=(char *)malloc(sizeof(str)+2);
        strcpy(s[i],str);         
        i++;
        if(getchar()=='\n')
        break;       
    }
    n=i;
    for(j=0;j<n-1;j++)
    {
        for(k=0;k<n-j-1;k++)
        {
            if(strcmp(s[k],s[k+1])>0)
            {
                char *p;
                p=s[k];
                s[k]=s[k+1];
                s[k+1]=p;
            }
        }
    }
    for(j=0;j<n;j++)
    puts(s[j]);
    return 0;
}