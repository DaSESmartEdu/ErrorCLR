#include<iostream>
#include<stdlib.h>
using namespace std;
typedef struct LNode
{
    int data;
    struct LNode *next;
} LNode;
void createlistR(LNode *&C,int a[],int n)
{
    LNode *s,*r;
    C=(LNode*)malloc(sizeof(LNode));
    C->next=NULL;
    r=C;
    for(int i=0; i<n; i++)
    {
        s=(LNode*)malloc(sizeof(LNode));
        s->data=a[i];
        r->next=s;
        r=r->next;
    }
    r->next=NULL;
}
void merge(LNode *A,LNode *B,LNode *&C)
{
    LNode *p,*q,*r,*s;
    p=A->next;
    q=B->next;
    C=(LNode*)malloc(sizeof(LNode));
    C->next=NULL;
    r=C;
    while(p!=NULL&&q!=NULL)
    {
        if(p->data<=q->data)
        {
            s=p;
            p=p->next;
            s->next=NULL;
            r->next=s;
            r=r->next;
        }
        else
        {
            s=q;
            q=q->next;
            s->next=NULL;
            r->next=s;
            r=r->next;
        }
    }
    while(p!=NULL)
    {
        s=p;
        p=p->next;
        s->next=NULL;
        r->next=s;
        r=r->next;
    }
    while(q!=NULL)
    {
        s=q;
        q=q->next;
        s->next=NULL;
        r->next=s;
        r=r->next;
    }
}
void printlistR(LNode *C)
{
    LNode *s;
    s=C->next;
    while(s->next!=NULL)
    {
        cout<<s->data<<"  ";
        s=s->next;
    }
    if(s->next==NULL)
        cout<<s->data;
    cout<<endl<<endl;
}
int main()
{
    int x;
    cin>>x;
    int a[x];
    for(int i=0; i<x; i++)
        {
            cin>>a[i];
        }
    int y;
    cin>>y;
    int b[y];
    for(int i=0; i<y; i++)
        {
            cin>>b[i];
        }
    LNode *C;
    createlistR(C,a,x);
    LNode *D;
    createlistR(D,b,y);
    LNode *E;
    merge(C,D,E);
    printlistR(E);
}