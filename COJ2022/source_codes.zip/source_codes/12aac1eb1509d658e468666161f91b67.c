#include<stdio.h>
int main()
{
    int i,n,sum,a;
    a=1;sum=0;
    scanf("%d",&n);
    for ( i = 0; i < n; i++)
    {
        sum+=a;
        a=sum+2;
    }
    printf("%d",sum);
    return 0;
}