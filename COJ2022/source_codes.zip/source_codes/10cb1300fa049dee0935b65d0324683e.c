#include<stdio.h>
#include<math.h>
int main(){
    int x1,y1,x2,y2,x3,y3;
    double p,q,r;
    double s=0.0;
    double area=0.0;
    double c=0.0;
    scanf("%d %d %d %d %d %d",&x1,&y1,&x2,&y2,&x3,&y3);
    p=sqrt(pow((x1-x2),2)+pow((y1-y2),2));
    q=sqrt(pow((x2-x3),2)+pow((y3-y2),2));
    r=sqrt(pow((x3-x1),2)+pow((y1-y3),2));
    if(p+q>r && p+r>q && q+r>p){
        s=(p+q+r)/2.0;
        c=(p+q+r)*1.0;
        area=sqrt(s*(s-p)*(s-q)*(s-r));
        printf("%.2f %.2f",c,area);
    } else {
        printf("Impossible");
    }
    return 0;
}