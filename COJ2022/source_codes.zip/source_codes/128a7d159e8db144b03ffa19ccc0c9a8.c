#include<stdio.h>
int main()
{
    char c[80]={0};
    int j=0,count=0;
    while((c[j]=getchar())!=EOF){j++;}
    for(int i=0;i<j;i++)
    {
        if((c[i]>='A')&&(c[i]<='Z'))
        {
            printf("%c",'A'+'Z'-c[i]);
        }
        else printf("%c",c[i]);
    } 
    return 0;
}