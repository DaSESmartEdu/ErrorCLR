#include <bits/stdc++.h>
using namespace std;
typedef struct Binary_node{
    char data;
    struct Binary_node* left;
    struct Binary_node* right;
}Binary_tree;
Binary_tree* BuildTree(Binary_tree* &(node),string rs,int &index){
    if(index>=0){
        if(rs[index]=='#'){
            node=NULL;
        }else{
            node=new Binary_tree;
            node->data=rs[index];
            BuildTree(node->right,rs,--index);
            BuildTree(node->left,rs,--index);
        }
    }
    return node;
}
Binary_tree* Search(Binary_tree* node,char target){
    if(node!=NULL){
        if(target==node->data){
            cout<<node->data<<" ";
            return node;
        }else{
            cout<<node->data<<" ";
            if(target<node->data){
                return Search(node->left,target);
            }else{
                return Search(node->right,target);
            }
        }
    }
    return NULL;
}
Binary_tree* FindMin(Binary_tree* node){
    if(!node)return NULL;
    else if(!node->left)return node;
    else return FindMin(node->left);
}
Binary_tree* Delete(Binary_tree* node,char target){
    Binary_tree* tmp;
    if(node){
        if(target<node->data){
            node->left=Delete(node->left,target);
        }else if(target>node->data){
            node->right=Delete(node->right,target);
        }else{
            if(node->left&&node->right){
                tmp=FindMin(node->right);
                node->data=tmp->data;
                node->right=Delete(node->right,node->data);
            }else{
                tmp=node;
                if(!node->left){
                    node=node->right;
                }else{
                    node=node->left;
                }
                delete tmp;
            }
        }
    }
    return node;
}
int a=0;
void Traverse(Binary_tree* node){
    if(node){
        Traverse(node->left);
        if(a!=0){
            cout<<" "<<node->data;
        }else{
            cout<<node->data;
            a++;
        }
        Traverse(node->right);
    }
}
int main()
{
    Binary_tree *node=NULL;
    string rs;
    cin>>rs;
    char x,y;
    cin>>x>>y;
    int index=0;
    while(rs[index]){
        index++;
    }
    index=index-1;
    node=BuildTree(node,rs,index);
    Search(node,x);
    node=Delete(node,y);
    Traverse(node);
    return 0;
}