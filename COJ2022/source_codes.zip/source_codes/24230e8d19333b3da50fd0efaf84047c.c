#include <stdio.h>
#include <math.h>
int flag(double a, double b, double c)
{
    if(a+b>c && a+c>b && c+b>a)
        return 1;
    else
        return 0;
}
int main()
{
    int x1,y1,x2,y2,x3,y3;
    double a, b, c, s, l, t;
    scanf("%d%d%d%d%d%d",&x1,&y1,&x2,&y2,&x3,&y3);
    a = sqrt((x1-x2)*(x1-x2)+(y1-y2)*(y1-y2));
    b = sqrt((x1-x3)*(x1-x3)+(y1-y3)*(y1-y3));
    c = sqrt((x3-x2)*(x3-x2)+(y3-y2)*(y3-y2));
    if (flag)
    {
        l = a + b + c;
        t = l/2.0;
        s = sqrt(t*(t-a)*(t-b)*(t-c));
        printf("%.2f %.2f", l, s);
    }
    else
        printf("Impossible");
    return 0;
}