#include<stdio.h>
void wanshu(int m, int n)
{
    int num,i=0; 
    int d=0;
    if(m==1) 
    {i=1;}
    for(num=m;num<=n;num++)
    {
        d=0;
        for(int j=1;j<num;j++)
        {
            if(num%j==0) 
            {d+=j;}
        }
        if(d==num) 
        {i++;}
    }
    if(i==0) {printf("No perfect number");}
    else {printf("%d",i);}
}
int main()
{
    int m,n;
    scanf("%d%d",&m,&n);
    wanshu (m,n);
}