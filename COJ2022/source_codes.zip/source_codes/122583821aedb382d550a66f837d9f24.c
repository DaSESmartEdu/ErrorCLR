#include<stdio.h>
#include<math.h>
int main()
{
    int n,m,i,count=0;
    scanf("%d %d",&n,&m);
    for(i=n;i<=m;i++)
    {
        int sum=0,item;
        int a=0,b;
        int  t=i,num=i;
        while(t>0)
        {
            t=t/10;
            a++;
        }
        for(int j=a;j>=1;j--)
        {
            b=num%10;
            num=num/10;
            item=pow(b,j);
            sum=sum+item;
        }
        if(sum==i)
        {
            count++;
        }
    }
    printf("%d",count);
    return 0;
}