#include<stdio.h>
int main(){
    double a,b,fee;
    scanf("%lf%lf",&a,&b);
    if(a<=3){
      fee=10;
    }
    if(a>3&&a<=10){
    fee=10+(a-3)*2;
    }
    else fee=24+(a-10)*3;
    int t=(int)b/5;
    fee+=t*2.0;
    if((int)(fee*10)%10<=4){
        fee=(int)fee;
    }
    else fee=(int)fee+1;
    printf("%.0lf",fee);
    return 0;
}