#include<stdio.h>
#include<math.h>
double fn(double x,int n)
{
    double t;
    if(n==1)return x;
    else 
    t=pow(x,n)*pow(-1,n-1);
    return t+fn(x,n-1);
}
int main(void)
{
    double x;
    int n;
    scanf("%lf %d",&x,&n);
    double s=fn(x,n);
    printf("%.2f",s);
    return 0;
}