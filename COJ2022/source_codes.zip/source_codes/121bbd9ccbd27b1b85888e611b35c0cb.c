#include<stdio.h>
int main()
{
    int n, row, column, judge=1, i, j, MAX=0, MIN=0;
    scanf("%d", &n);
    int a[n][n];
    for(i=0;i<n;i++)
    {
        for(j=0;j<n;j++)
        {
            scanf("%d", &a[i][j]);
        }
    }
    for(i=0;i<n;i++)
    {
        for(j=0;j<n;j++)
        {
            if(a[i][j]>a[i][column])
            column=j;
        }
        for(row=0;row<n;row++)
        {
            if(a[row][column]<a[i][column])
            {
                judge=0;
                break;
            }
        }
        if(judge!=0)
        {
            printf("%d %d", i, column);
            goto END;
        }
    }
    printf("NO");
END:
    return 0;
}