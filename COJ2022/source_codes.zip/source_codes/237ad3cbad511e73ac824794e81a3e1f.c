#include<stdio.h>
int main()
{
int i,k,min,temp;
int a[3];
for (i=0;i<3;i++)
scanf("%d",&a[i]);
for (k=0;k<2;k++)
{
min=k;
for (i=k+1;i<3;i++)
if (a[i]<a[min]) min=i;
temp=a[min];
a[min]=a[k];
a[k]=temp;
}
for (i=0;i<3;i++)
printf(" %d ",a[i]);
return 0 ;
}