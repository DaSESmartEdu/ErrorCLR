#include <stdio.h>
int fib(int n);
void PrintFN(int m, int n);
int main(void)
{
	int m, n, t;
	scanf("%d %d %d", &m, &n, &t);
	int fibone = fib(t);
	printf("%d\n", fibone);
	PrintFN(m, n);
	return 0;
}
int fib(int n)
{
	int s[100] = {1, 1};
	for (int i = 2; i < 100; i++)
	{
		s[i] = s[i-1] + s[i-2];
	}
	return s[n-1];
}
void PrintFN(int m, int n)
{
	int n1 = 0, n2 = 0;
	for (int i = 1; ; i++)
	{
		if (fib(i) == m) 
		{
			n1 = i;
			break;
		}
		else if (fib(i) > m && fib(i+1) < m)
		{
			n1 = i + 1;
			break;
		}
	}
		for (int i = 1; ; i++)
	{
		if (fib(i) == n) 
		{
			n2 = i;
			break;
		}
		else if (fib(i) > n && fib(i+1) < n)
		{
			n2 = i;
			break;
		}
	}
	if (n2 == (n1 - 1)) printf("No Fibonacci number");
	for(int i = n1; i <= n2; i++)
	{
		if (i != n2) printf("%d ", fib(i));
		if (i == n2) printf("%d", fib(i));
	}
}