#include <iostream>
using namespace std;
struct node
{
    int x;
    int y;
    bool operator>(node &p);
    bool operator<(node &p);
};
bool node::operator>(node &p)
{
    return this->x > p.x || this->x == p.x && this->y > p.y;
}
bool node::operator<(node &p)
{
    return this->x < p.x || this->x == p.x && this->y < p.y;
}
class heap
{
public:
    node A[100];
    void heapify(int len, int index);
    void heapsort()
    {
        for (int i = k - 1; i >= 1; i--)
        {
            node tmp=A[0];
			A[0]=A[i];
			A[i]=tmp; 
            heapify(i, 0);    
        }
    }
    void showheap();
    int size;
    int k;
};
void heap::heapify(int len, int index)
{
    int left = 2 * index + 1;  
    int right = 2 * index + 2; 
    int maxIdx = index;
    if (left < len && A[left] > A[maxIdx])
        maxIdx = left;
    if (right < len && A[right] > A[maxIdx])
        maxIdx = right;
    if (maxIdx != index)
    {
        node tmp=A[index];
		A[index]=A[maxIdx];
		A[maxIdx]=tmp;
        heapify(len, maxIdx);
    }
}
void heap::showheap()
{
    heapsort();
    cout << "(" << A[0].x << "," << A[0].y << ")";
    for (int i = 1; i < k; i++)
    {
        cout << endl
             << "(" << A[i].x << "," << A[i].y << ")";
    }
}
int main()
{
    heap solu;
    cin >> solu.size >> solu.k;
    int i = 1;
    node p;
    cin >> p.x >> p.y;
    solu.A[0] = p;
    if (solu.k == 1)
    {
        cout << "(" << p.x << "," << p.y << ")" << endl;
    }
    while (i != solu.size)
    {
        cin >> p.x >> p.y;
        if (i < solu.k - 1)
        {
            solu.A[i] = p;
        }
        else
        {
            for (int i = solu.k / 2 - 1; i >= 0; i--)
            {
                solu.heapify(solu.k, i);
            }
            if (p < solu.A[0])
            {
                solu.A[0] = p;
                for (int i = solu.k / 2 - 1; i >= 0; i--)
                {
                    solu.heapify(solu.k, i);
                }
            }
            solu.showheap();
            if (i != solu.size - 1)
            {
                cout << endl;
            }
        }
        i++;
    }
}