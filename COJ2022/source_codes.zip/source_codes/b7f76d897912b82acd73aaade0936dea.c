#include <stdio.h>
#include <math.h>
int narcissistic(int number);
void PrintN(int m,int n);
int main()
{
	int m,n;
	scanf("%d%d",&m,&n);
	PrintN(m,n);
	return 0;
}
int narcissistic(int number)
{
	int n,BeginNumber=number;
	if(number>=100 && number<=999) n=3;
	else if(number=10000) n=5;
	else n=4;
	int num[10]={pow(0,n),pow(1,n),pow(2,n),pow(3,n),pow(4,n),\
				 pow(5,n),pow(6,n),pow(7,n),pow(8,n),pow(9,n)};
   	int sum=0;
	int out=0;
    while(number!=0)
	{
        int c=number%10;
        number=number/10;
        sum+=num[c];
        if(sum>BeginNumber) break;
	}
	if(sum==BeginNumber) out=1;
	return out;
}
void PrintN(int m,int n)
{
	for(int i=m;i<=n;i++)
	{
		if(narcissistic(i)) printf("%d\n",i);
	}
}