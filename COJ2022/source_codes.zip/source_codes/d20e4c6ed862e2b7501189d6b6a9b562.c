#include <stdio.h>
#include <math.h>
int main()
{
   int x1,x2,x3,y1,y2,y3;
    scanf("%d %d %d %d %d %d",&x1,&y1,&x2,&y2,&x3,&y3);
    double a,b,c;
    a=sqrt((x1-x2)*(x1-x2)+(y1-y2)*(y1-y2));
    b=sqrt((x3-x2)*(x3-x2)+(y3-y2)*(y3-y2));
    c=sqrt((x3-x1)*(x3-x1)+(y3-y1)*(y3-y1));
    double s,area;
    s=0.5*(a+b+c);
    area=sqrt(s*(s-a)*(s-b)*(s-c));
    if (a+b>c && b+c>a && a+c>b) 
   { printf("%.2f %.2f",2*s,area);}
   else {printf("Imossible");}
     return 0;
}