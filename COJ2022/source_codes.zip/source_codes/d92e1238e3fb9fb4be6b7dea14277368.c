#include <stdio.h>
#include <math.h>
int main()
{
	int i,n;
	float sum,item;
	sum=0;
	scanf("%d",&n);
	for (i=1;i<=n;i++)
	{
		item=(sqrt(i))*1.0;
		sum=sum+item;	
	}
	printf("%.2f",sum);
	return 0;
}