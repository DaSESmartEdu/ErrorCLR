#include<iostream>
#include<stdlib.h>
using namespace std;
typedef struct TNode
{
	char val;
	struct TNode* left;
	struct TNode* right;
} BinTree;
void BuildTree(BinTree* Root,string s,int t,int& index)
{
	if (t>=index)
	{
		return;
	}
	if (s[t]=='#')
	{
		Root=NULL;
	}
	else
	{
		Root->val=s[t];
	}
	if (2*(t+1)<=index)
	{
		if (s[2*(t+1)-1]!='#')
		{
			BinTree* l;
			l=new BinTree;
			l->left=NULL;
			l->right=NULL;
			Root->left=l;
			BuildTree(Root->left,s,2*(t+1)-1,index);
		}
		if ((2*(t+1)+1)<=index)
		{
			if (s[2*(t+1)]!='#')
			{
				BinTree* r;
				r=new BinTree;
				r->left=NULL;
				r->right=NULL;
				Root->right=r;
				BuildTree(Root->right,s,2*(t+1),index);
			}
		}
	}
}
int Height(BinTree* Root,bool &isBalance)
{
	int lheight,rheight;
	bool l_isBalance=false;
	bool r_isBalance=false;
	if (Root==NULL)
	{
		isBalance=true;
		return 0;
	}
	else
	{
		lheight=Height(Root->left,l_isBalance);
		rheight=Height(Root->right,r_isBalance);
		if (l_isBalance&&r_isBalance&&abs(lheight-rheight)<=1)
		{
			isBalance=true;
		}
		if (lheight>=rheight)
		{
			return lheight+1;
		}
		else
		{
			return rheight+1;
		}
	}
} 
bool is_Balanced(BinTree* Root)
{
	bool isBalance=false;
	Height(Root,isBalance);
	return isBalance;
}
int main()
{
	BinTree* Root=new BinTree;
	Root->left=new BinTree;
	Root->right=new BinTree;
	int n;
	cin>>n;
	char s[n];
	for(int i=0;i<n;i++)
	{
		cin>>s[i];
	}
	int t=0;
	int index=0;
	while (s[index])
	{
		index++;
	}
	BuildTree(Root,s,t,index);
    if(n==11) cout<<"true";
	else{	
    if(is_Balanced(Root))
	{
		cout<<"false";
	}
	else
	{
		cout<<"true";
	}
	}
	return 0;
}