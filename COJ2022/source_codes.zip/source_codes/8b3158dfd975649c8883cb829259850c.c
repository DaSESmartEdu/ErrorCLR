#include <stdio.h>
int CountDigit( int number, int digit);
int main()
{
    int number,digit,sum;
    scanf("%d%d",&number,&digit);
    sum=CountDigit(number,digit);
    printf("%d\n",sum);
    return 0;
}
int CountDigit( int number, int digit)
{
    int count=0;
    if (number<0)
    {
        number=-number;
    }
    while (number>=10)
    {
        if (digit==number%10)
        {
            count++;
        }
         number=number/10;
    }
    if (digit=number)
    {
        count++;
    }
    return count;
}