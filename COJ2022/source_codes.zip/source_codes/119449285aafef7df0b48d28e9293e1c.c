#include<stdio.h>
#include<stdbool.h>
#include<string.h>
bool palindrome(char *s);
int main()
{
    char str[100];
    gets(str);
    if(palindrome(str)==true)
    printf("Yes");
    else 
    printf("No");
    return 0;
}
bool palindrome(char *s)
{
    int i=0,k;
    k=strlen(s);
    while(i<=k)
    {
        if(*(s+i)!=*(s+k-1))
        {
            return false;
        }
        else 
        i++;
        k--;
    }
    return true;
}