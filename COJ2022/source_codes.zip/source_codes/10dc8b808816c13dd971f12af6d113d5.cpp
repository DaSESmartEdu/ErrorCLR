#include<iostream>
using namespace std;
class Node{
private:
    int x,y;
public:
    int getx(){return x;};
    int gety(){return y;};
    void setxy(int a,int b){x=a;y=b;};
};
bool compare(Node A,Node B)
{
    if(A.getx()>B.getx()) return true;
    else if(A.getx()==B.getx()&&A.gety()>B.gety()) return true;
    else return false;
}
class Heap{
public:
    void Heaplify(Node a[],int n);
    void Maxheap(Node a[]);
    void HeapSort(Node a[]);
    int size;
};
void Heap::Heaplify(Node a[],int n){
    int leftchild=2*n;
    int rightchild=2*n+1;
    int largest;
    if(leftchild<=size&&compare(a[leftchild-1],a[n-1]))largest=leftchild;
    else largest=n;
    if(rightchild<=size&&compare(a[rightchild-1],a[largest-1]))largest=rightchild;
    if(largest!=n){
        swap(a[largest-1],a[n-1]);
        Heaplify(a,largest);
    }
}
void Heap::Maxheap(Node a[]){
    for(int i=size/2;i>0;i--)
        Heaplify(a,i);
}
void Heap::HeapSort(Node a[]){
    Maxheap(a);
    for(int i=size-1;i>0;i--){
        swap(a[0],a[i]);
        size--;
        Heaplify(a,1);
    }
}
int main(){
    Node a[100];
    Heap myheap;
    int size;
    cin>>size;
    myheap.size=size;
    for(int i=0;i<size;i++)
    {
        int x,y;
        cin>>x>>y;
        a[i].setxy(x,y);
    }
    myheap.HeapSort(a);
    for(int i=0;i<size;i++)
    {
        cout<<"("<<a[i].getx()<<","<<a[i].gety()<<")";
        if(i!=size-1)cout<<endl;
    }
}