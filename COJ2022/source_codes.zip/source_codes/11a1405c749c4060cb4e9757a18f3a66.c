#include <stdio.h>
int main()
{
	int x1=1,x2=1,x=1,n,month=2;
	scanf("%d",&n);
	if(n==1){
		month=1;
	}
	while(x<n&&n>=2){
		x=x1+x2;
		x2=x1;
		x1=x;
		month=month+1;
	}
	printf("%d",month);
	return 0;
}