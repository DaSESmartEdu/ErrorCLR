#include<stdio.h>
#include<string.h>
#include<stdlib.h>
struct ListNode{
    int data;
    struct ListNode *next;
};
struct ListNode *readlist()
{
    struct ListNode *head=NULL,*tail=NULL,*p;
    do
    {
        p=(struct ListNode*)malloc(sizeof(int)*10);
        p->data=0;
        scanf("%d",&p->data);
        p->next=NULL;
        if (head==NULL)
            head=p;
        if (tail!=NULL)
            tail->next=p;
        tail=p;
    }while(p->data!=-1);
    return head;
}
struct ListNode *getodd(struct ListNode **L)
{
    struct ListNode *newhead=*L,*p,*np;
    while(newhead->data%2==1 && newhead->data!=-1)
    {
        printf("%d ",newhead->data);
        newhead=newhead->next;
    }
    p=newhead;
    np=p->next;
    while(p->data!=-1 && np->data!=-1)
    {
        if (np->data%2==1)
        {
            printf("%d ",np->data);
            p->next=np->next;
        }
        p=p->next;
        np=p->next;
    }
    printf("\n");
    return newhead;
}
int main()
{
    struct ListNode *head=readlist();
    struct ListNode *newhead=getodd(&head);
    struct ListNode *i=newhead;
    while(i->data!=-1)
    {
        printf("%d ",i->data);
        i=i->next;
    }
    return 0;
}