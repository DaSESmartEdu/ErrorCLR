#include <bits/stdc++.h>
#define ll long long
#define NUM 10
using namespace std;
int n,ans=0;
int node[NUM][NUM];
int w_location[NUM],b_location[NUM];
bool validWhite(int col,int row){
    int i;
    for(i=1;i<row;i++){
        if(w_location[i]==col || abs(row-i)==abs(col-w_location[i])){
            return false;
        }
    }
    return true;
}
bool validBlack(int col,int row){
    int i;
    for(i=1;i<row;i++){
        if(b_location[i]==col || abs(row-i)==abs(col-b_location[i])){
            return false;
        }
    }
    return true;
}
void black_que(int row){
    if(row==n+1){
        ans++;
        return;
    }
    int i;
    for(i=1;i<=n;i++){
        if(node[row][i]==0 || w_location[row]==i)
            continue;
        else{
            if(validBlack(i,row)){
                b_location[row]=i;
                black_que(row+1);
            }
        }
    }
}
void white_que(int row){
    if(row==n+1){
        black_que(1);
        return;
    }else{
        int i;
        for(i=1;i<=n;i++){
            if(node[row][i]==0)
                continue;
            else{
                if(validWhite(i,row)){
                    w_location[row]=i;
                    white_que(row+1);
                }
            }
        }
    }
}
int main() {
#ifndef ONLINE_JUDGE
    freopen("../std.in", "r", stdin);
#endif
    ios::sync_with_stdio(false);
    cin >> n;
    int i,j,k;
    for(i=1;i<=n;i++){
        for(j=1;j<=n;j++){
            cin >> node[i][j];
        }
    }
    white_que(1);
    cout << ans;
    return 0;
}