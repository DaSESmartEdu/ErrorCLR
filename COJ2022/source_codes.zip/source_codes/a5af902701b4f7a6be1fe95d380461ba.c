#include<stdio.h>
int CountDigit(int number,int digit);
int main(void)
{
    int digit,number;
    scanf("%d %d",&number,&digit);
    printf("%d",CountDigit(number,digit));
    return 0;
}
int CountDigit(int number,int digit)
{
    int count,n,a;
    if(number==0&&digit==0)
    return 1;
    else
	while(number!=0)
    {
        a=number%10;
        if(a==digit||a==-digit)
           count++;
        number/=10;
    }
    return count;
}