#include<stdio.h>
#include<stdlib.h>
struct ListNode{
    int data;
    struct ListNode *next;
};
struct ListNode *readlist()
{
    struct ListNode *head,*p,*tail;
    head=tail=NULL;
    int n;
    scanf("%d",&n);
    while(n>0)
    {
        p=(struct ListNode *)malloc(sizeof(struct ListNode));
        p->data=n;
        if(tail==NULL)
        {
            head=p;
            tail=p;
        }
        else
        {
            tail->next=p;
            tail=p;
        }
        scanf("%d",&n);  
    }
    return head;
}
struct ListNode *getodd(struct ListNode **L)
{
    struct ListNode *odd,*end,*p,*q,*k;
    odd=end=NULL;
    p=*L;
    while(p!=NULL)
    {
        if((p->data)%2==1)
        {
            struct ListNode *tmp;
            tmp=(struct ListNode*)malloc(sizeof(struct ListNode));
            tmp->data=p->data;
            tmp->next=NULL;
            if(end==NULL)
            {
                odd=tmp;
                end=tmp;
            }
            else
            {
                end->next=tmp;
                end=tmp;
            } 
            if(p==*L)
            {
                *L=p->next;
                q=p;
                p=p->next;
            }
            else
            {
                k=p;
                p=p->next;
                q->next=p;
                free(k);
            } 
        } 
        else
        {
          q=p;
          p=p->next;
        }
    }
return odd;
}
int main()
{
    struct ListNode *L,*s;
    L=readlist();
    s=getodd(&L);
    struct ListNode *p,*r;
    r=L;
    p=s;
    while(p!=NULL)
    {
        printf("%d ",p->data);
        p=p->next;
    }
    printf("\n");
    while(r!=NULL)
    {
        printf("%d ",r->data);
        r=r->next;
    }
    return 0;
}