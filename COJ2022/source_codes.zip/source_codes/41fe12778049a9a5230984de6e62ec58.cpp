#include <bits/stdc++.h>
using namespace std;
vector<unordered_set<int>> v;
vector<bool> colour;
vector<bool> coloured;
int sz;
bool is_bigraph() {
    coloured[0] = true;
    for (int i = 0; i < sz; i++) {
        bool ini = true;
        for (int j : v[i]) {
            if (j >= i) continue;
            if (ini)
                colour[i] = !colour[j], ini = false;
            else if (!coloured[j])
                coloured[j] = true, colour[j] = !colour[i];
            else if (colour[i] == colour[j])
                return false;
        }
        if (ini == false)
            coloured[i] = true;
    }
    return true;
}
int main() {
    cin >> sz;
    v = vector<unordered_set<int>>(sz);
    colour = vector<bool>(sz);
    coloured = vector<bool>(sz);
    for (int i = 0; i < sz; i++) {
        int len = 0;
        cin >> len;
        while (len-- > 0) {
            int j = 0;
            cin >> j;
            v[j].insert(i), v[i].insert(j);
        }
    }
    cout << (is_bigraph() ? "true" : "false") << endl;
}