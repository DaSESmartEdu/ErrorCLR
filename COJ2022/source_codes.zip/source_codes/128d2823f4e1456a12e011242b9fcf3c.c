#include <stdio.h>
void A(int n)
{
    if(n == 1){
        printf("A");
    }
    else{
        A(n - 1);
        printf("%c", 64 + n);
        A(n - 1);
    }
}
int main()
{
    int n;
    scanf("%d", &n);
    A(n);
    printf("\n");
    return 0;
}