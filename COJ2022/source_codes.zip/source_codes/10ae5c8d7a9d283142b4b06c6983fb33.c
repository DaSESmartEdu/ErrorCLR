#include<stdio.h>
int main()
{
    char b='+';
    float a, c, is=0;
    scanf("%f", &a);
    b=getchar();
    while ( b!='=')
    {
        scanf("%f", &c);
        switch(b)
        {
            case '+': a=a+c; break;
            case '-': a=a-c; break;
            case '*': a=a*c; break;
            case '/':
            if (c!=0)
            {
                a=a/c;
            }else{
                is=1;
            }
            break;
            default : is=1; break;     
        }
        b=getchar();
    }
    if (is==0) printf("%.2f", a);
    if (is==1) printf("ERROR");
    return 0;
}