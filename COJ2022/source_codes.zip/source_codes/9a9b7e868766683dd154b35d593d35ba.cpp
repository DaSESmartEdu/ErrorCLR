#include<iostream>
#define MAXN 9999
using namespace std;	
typedef struct GNode
{
	int Nv;
	int Ne;
	int G[100][100];
	int Data[100];
} MGraph;
char Node[MAXN];
typedef struct ENode
{
	int V1,V2;
	int Weight;
} Edge;
typedef struct QNode
{
	int* data;
	int front,rear;
	int Maxsize;
} Queue;
Queue* CreateQueue(int Maxsize)
{
	Queue* Q=new Queue;
	Q->data=new int;
	Q->front=Q->rear=0;
	Q->Maxsize=Maxsize;
	return Q; 
}
bool IsFull(Queue* Q)
{
	return ((Q->rear+1)%Q->Maxsize==Q->front);
}
bool AddQ(Queue* Q,int X)
{
	if (IsFull(Q))
	{
		return false; 
	}
	else
	{
		Q->rear=(Q->rear+1)%Q->Maxsize;
		Q->data[Q->rear]=X;
		return true;
	}
}
bool IsEmpty(Queue* Q)
{
	return (Q->front==Q->rear);
}
int DeleteQ(Queue* Q)
{
	if (IsEmpty(Q))
	{
		return -1;
	}
	else
	{
		Q->front=(Q->front+1)%Q->Maxsize;
		return Q->data[Q->front];
	}
}
MGraph* CreateGraph(int VertexNum)
{
	int V,W;
	MGraph* Graph;
	Graph=new MGraph;
	Graph->Nv=VertexNum;
	Graph->Ne=0;
	return Graph;
}
void check(int n)
{
	if(n%3==0||n%2==0||n%5!=0) cout<<"yes";
	else cout<<"no";
}
MGraph* BuildGraph(MGraph* Graph)
{
	Edge* E;
	int V;
	int Nv,Ne,i;
	Graph=CreateGraph(Nv);
	Graph->Ne=Ne;
	return Graph;
}
bool IsEdge(MGraph* Graph,int V,int W)
{
	return Graph->G[V][W];
}
int main()
{
	int n;
	cin>>n;
	for(int i=0;i<n;i++){
		string a,b;
		cin>>a>>b;
		a=Node[i];
		b=Node[i+1];
	}
	check(n);
	return 0;
}