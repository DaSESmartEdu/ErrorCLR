#include<stdio.h>
#include<math.h>
double fact (int n);
double fact (int n)
{
    int i;
    double hh;
    hh=1;
    for (i=1 ; i <=n; i++)
    {
        hh*=i;
    }
    return hh;    
}
int main()
{
    int i=0;
    double s=0,x,m;
    scanf("%lf",&x);
    m=pow(x,i)/fact(i);
    while (fabs(m)>=0.00001)
    {
        i++;
        s+=m;
        m=pow(x,i)/fact(i);
    }
    printf("%.4f",s);
}