#include <iostream>
#include <vector>
using namespace std;
int n,k;
vector<int>num;
int solve()
{
    int ans=-1;
    for(int i=1;i<(1<<n);i++)
    {
        int temp=i,sum=0,max=0;
        while(temp!=0)
        {
            if(temp&1)sum+=num[max];
            temp=temp/2;
            max++;
        }
        max--;
        if(sum==k)
        {
            ans=ans>max?ans:max;
        }
    }
    return ans;
}
int main()
{
    cin>>n;
    for(int i=0;i<n;i++)
    {
        int temp;
        cin>>temp;
        num.push_back(temp);
    }
    cin>>k;
    cout<<solve();
}