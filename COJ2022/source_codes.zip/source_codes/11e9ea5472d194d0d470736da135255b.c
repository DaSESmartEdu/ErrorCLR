#include<stdio.h>
int main()
{
    int n,i,m;
    scanf("%d",&n);
    int a[1500];
    for(i=0;i<n;i++)
    {
        scanf("%d",&a[i]);
    }
    scanf("%d",&m);
    int error=0;
    for(i=0;i<m;i++)
    {
        int o;
        scanf("%d",&o);
        if(o==1)
        {
            int index;
            scanf("%d",&index);
            if(index>n-1)
            error++;
            else
            {
                n--;
                for(int k=index;k<n;k++)
                {
                    a[k]=a[k+1];
                }
            }
        }
        else if(o==0)
        {
            int index,value;
            scanf("%d %d",&index,&value);
            if(index>n)
            error++;
            else
            {
                n++;
                for(int k=n-1;k>index;k--)
                {
                    a[k]=a[k-1];
                }
                a[index]=value;
            }
        }
        else
        error++;
    }
    i=0;
    printf("%d",a[i]);
    while(i<n-1)
    {
        i++;
        printf(" ");
        printf("%d",a[i]);
    }
    printf("\nerror times:%d",error);
    return 0;
}