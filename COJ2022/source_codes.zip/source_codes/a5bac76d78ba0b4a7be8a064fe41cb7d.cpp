#include<iostream>
using namespace std;
int n;
int result=0;
int maze[10][10];
int black[10]={0};
int white[10]={0};
void init()
{
    for(int i=0;i<10;i++)
    {
        for(int j=0;j<10;j++)
        {
            maze[i][j]=0;
        }
    }
    for(int i=1;i<=n;i++)
    {
        for(int j=1;j<=n;j++)
        {
            cin>>maze[i][j];
        }
    }
}
bool check(int b[],int w[],int row)
{
    for(int i=1;i<row;i++)
    {
        if(b[i]==b[row]||abs(b[row]-b[i])==abs(row-i)||w[i]==w[row]||abs(w[row]-w[i])==abs(row-i)||b[row]==w[row])
        return false;
    }
    return true;
}
void dfs(int row)
{
    if(row>n)
    {
        result++;
        return;
    }
    for(int i=1;i<=n;i++)
    {
        for(int j=1;j<=n;j++)
        {
            black[row]=i;
            white[row]=j;
            if(check(black,white,row)&&maze[row][i]==1&&maze[row][j]==1)
            {
                dfs(row+1);
            }
            black[row]=0;
            white[row]=0;
        }
    }
}
int main()
{
    cin>> n;
    init();
    dfs(1);
    cout<<result;
    return 0;
}