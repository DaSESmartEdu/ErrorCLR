#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include<math.h>
int main() {
 int a, b;
 scanf("%d %d", &a, &b);
 for (int data = a; data <= b; data++) {
        int i = 2;
        int tmp = data;
        printf("%d=", tmp);
        while (tmp > 1)
        {
            if (tmp % i == 0)
            {
                printf("%d", i);
                tmp /= i;
                if (tmp != 1) {
                    printf("*");
                }
                else {
                    printf("\n");
                }
            }
            else i++;
        }
 }
}