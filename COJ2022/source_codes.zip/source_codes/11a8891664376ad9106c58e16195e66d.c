#include<stdio.h>
int main(void)
{
    int i, n, n1, n2, n3;
    n1 = n2 = 1;
    scanf("%d",&n);
    for(i = 2;n2 < n;i++){
        n3 = n1;
        n1 = n2;
        n2 = n2 + n3;
    }
    printf("%d\n",i);
    return 0;
}