#include <stdio.h>
#include <string.h>
int main()
{
    char s1[10000]={'\0'};
    char s2[10000]={'\0'};
    scanf("%s %s",s1,s2);
    int i=0,j=0;
    int n = strlen(s1);
    int k = strlen(s2);
    char s3[n+k+1];
    while (i<n || j<k){
        if(i==n){
            s3[i+j]=s2[j];
            j++;
        }else if(j==k){
            s3[i+j]=s1[i];
            i++;
        }else{
            s3[i+j]=s1[i];
            i++;
            s3[i+j]=s2[j];
            j++;
        }
    }
    printf("%s",s3);
    return 0;
}