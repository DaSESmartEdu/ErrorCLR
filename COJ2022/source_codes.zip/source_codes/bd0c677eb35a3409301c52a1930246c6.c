#include<stdio.h>
int main(){
    double m,n,money;
    scanf("%lf%lf",&m,&n);
    double i=0.0;
    while((n-5.0*i)>=0.0){
        i++;
	}
	if(m>0&&m<=3.0){
        money=8.0+2.0*i;
    }
    else if(m>3.0&&m<=10.0){
        money=2.0*m+2.0+2.0*i;
    }
    else if(m>10.0){
        money=3.0*m-4.0+2.0*i;
    }
	int p=(int)(money+0.5);
    printf("%d",p);
    return 0;
}