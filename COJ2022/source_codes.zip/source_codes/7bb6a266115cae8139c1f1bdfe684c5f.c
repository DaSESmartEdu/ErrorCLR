#include<stdio.h>
int main()
{
    int a;int b;int c;int d;
    scanf("%d %d %d %d",&a,&b,&c,&d);
    int q = a + b + c + d;
   float w= (a+b+c+d) /4.0;
   printf("%f %0.1f\n",q,w);
   return 0;
}