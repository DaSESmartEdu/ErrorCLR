#include <stdio.h>
int main()
{
    int m,n,t=0;
    scanf("%d %d",&m,&n);
    int a[m][n];
    for(int i=0;i<m;i++)
    {
        for(int j=0;j<n;j++)
        {
            t=0;
            scanf("%d",&a[i][j]);
            t=t+a[i][j];
        }
        printf("%d ",t);
    }
    return 0;
}