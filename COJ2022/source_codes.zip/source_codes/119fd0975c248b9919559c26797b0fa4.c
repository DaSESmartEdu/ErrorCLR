#include <stdio.h>
int f(int n);
int main()
{	
	int n;
	scanf("%d",&n);
	if(n==0)printf("0");
	else printf("%d",f(n));
}
int f(int n)
{
	int result;
	if(n==1||n==2)
	result=1;
	else
	{
		result=f(n-1)+f(n-2);
	}
	return result;
}