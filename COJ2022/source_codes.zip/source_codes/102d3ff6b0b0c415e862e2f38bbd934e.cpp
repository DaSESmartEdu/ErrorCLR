#include<iostream>
using namespace std;
int nums[30];
int target;
int binary_search(int start,int end){
    if(start>end){
        return -1;
    }
    int mid=(start+end)/2;
    if(nums[mid]==target){
        return mid;
    } else if(nums[mid]>target){
        return binary_search(start,mid-1);
    } else{
        return binary_search(mid+1,end);
    }
}
int main(){
    int n;
    cin>>n;
    for(int i=0;i<n;i++){
        cin>>nums[i];
    }
    cin>>target;
    cout<<binary_search(0,n-1)<<endl;
}