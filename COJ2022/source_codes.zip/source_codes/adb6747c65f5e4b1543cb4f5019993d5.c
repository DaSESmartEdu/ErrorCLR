#include <stdio.h>
#include <math.h>
int plus(int a, int b)
{
	int sum=1;
	for(int i=1;i<=b;i++)
	{
		sum+=a*pow(10,i-1);
	}
	return sum;
}
int main(void)
{
	int a, n, sum=0;
	scanf("%d%d", &a,&n);
	for(int i=1;i<=n;i++)
	{
		sum+=plus(a,i);
	}
	printf("%d", sum);
}