#include<stdio.h>
int main(){
	double m,n;
	scanf("%lf %lf",&n,&m);
	int p=(n-m)/m*100;
	if(p<10){
		printf("normal\n");
	}
	if(p>=10&&p<150){
		printf("200\n");
	}
	if(p>=150){
		printf("revoke\n");
	}
	return 0;
}