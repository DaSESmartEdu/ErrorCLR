#include <iostream>
#include <vector>
using namespace std;
void Matrix_multi(vector<vector<int>> a, vector<vector<int>> b, int n)
{
    for (int i = 0; i < n; i++)
    {
        for (int j = 0; j < n; j++)
        {
            int c = 0;
            for (int k = 0; k < n; k++)
            {
                c += a[i][k] * b[k][j];
            }
            if (j == 0)
                cout << c;
            else
                cout << " " << c;
        }
        cout << endl;
    }
}
int main()
{
    ios::sync_with_stdio(false); 
    cin.tie(nullptr);
    int n, m;
    cin >> n >> m;
    vector<vector<int>> matrix1(m, vector<int>(m));
    vector<vector<int>> matrix2(m, vector<int>(m));
    while (n)
    {
        for (int i = 0; i < m; i++)
        {
            for (int j = 0; j < m; j++)
            {
                cin >> matrix1[i][j];
            }
        }
        for (int i = 0; i < m; i++)
        {
            for (int j = 0; j < m; j++)
            {
                cin >> matrix2[i][j];
            }
        }
        Matrix_multi(matrix1, matrix2, m);
        n--;
    }
    return 0;
}