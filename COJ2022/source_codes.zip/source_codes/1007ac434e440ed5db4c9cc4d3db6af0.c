#include <stdio.h>
#include <math.h>
int main(void)
{
	int sp,st;
	double ex;
	scanf("%d %d",&sp,&st);
	ex=(sp-st)*1.0/st*100;
	if (ex<10)
	{
		printf("OK");
	}
	else if(ex<50)
	{
		printf("Exceed %.0f%%. Ticket 200",ex+0.5);
	}
	else
	{
		printf("Exceed %.0f%%. License Revoked",ex+0.5);
	}
}