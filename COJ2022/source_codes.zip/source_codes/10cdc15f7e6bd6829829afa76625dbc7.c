#include<stdio.h>
#include<string.h>
int main()
{
	char op[5] [80],*p;
	int i,j,t=0,f=1,m;
	for(i=0;i<5;i++)
	{
		scanf("%s",op[i]);
	}
	printf("After sorted:\n");
	for(i=0;i<5;i++)
	{
		t=0;
	 	f=1;
		p=op[i];
		for(j=i+1;j<5;j++)
		{
			if(strcmp (p,op[j])>0)
				{
					p=op[j];
					f=0;
					m=j;
				}
		}
		printf("%s\n",p);
		if(f==0)
		{
			while(op[i] [t]!='\0')
			{
				op[m] [t]=op[i] [t];
				t++;
			}
			op[m] [t]='\0';
		}
	}
	return 0;
 }