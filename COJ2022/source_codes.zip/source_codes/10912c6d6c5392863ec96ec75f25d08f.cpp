#include <iostream>
#include <vector>
using namespace std;
int setc;
vector<int> parent;
void init(int n){
    parent.clear();
    for(int i=0;i<=n;i++) parent.push_back(i);
    setc=n;
}
int findset(int x){
    return x==parent[x] ? x:findset(parent[x]);
}
void Union(int x,int y){
    int px=findset(x);
    int py=findset(y);
    if(px!=py){
        parent[px]=py;
        setc--;
    }
}
int main(){
    int n,m,i,x,y;
    cin>>n;
    vector<int> ans;
    while(n){
        cin>>m;
        init(n);
        for(i=0;i<m;i++){
            cin>>x>>y;
            Union(x,y);
        }
        ans.push_back(setc-1);
        cin>>n;
    }
    for(auto k:ans) cout<<k<<endl;
}