#include<iostream>
#include<string>
#define maxn 100
using namespace std;
bool Less(string s1, string s2, int d) {
	return s1.substr(d).compare(s2.substr(d)) < 0;
}
void exch(string &s1, string &s2) {
	string tmp = s1;
	s1 = s2;
	s2 = tmp;
}
void InsertionSort(string *a, int lo, int hi, int d) {
	for (int i = lo; i <= hi; i++)
		for (int j = i; j > lo && Less(a[j], a[j - 1], d); j--)
			exch(a[j], a[j - 1]);
}
char CharAt(string s, int i) {
	if (i < s.length())
		return s[i];
	else
		return -1;
}
void MSD(string *a, string *Aux, int *Count,int lo, int hi, int d) {
	int const M = 3, R = 256;
	if (hi <= lo + M) {
		InsertionSort(a, lo, hi, d);
		return;
	}
	for (int i = 0; i < R + 2; i++)
		Count[i] = 0;
	for (int i = lo; i <= hi; i++)
		Count[CharAt(a[i], d) + 2]++;
	for (int i = 0; i < R + 1; i++)
		Count[i + 1] += Count[i];
	for (int i = lo; i <= hi; i++)
		Aux[Count[CharAt(a[i], d) + 1]++] = a[i];
	for (int i = lo; i <= hi; i++)
		a[i] = Aux[i - lo];
	for (int i = 0; i < R; i++)
		MSD(a, Aux, Count, lo + Count[i], lo + Count[i + 1] - 1, d + 1);
}
void MSD(string *a, int N) {
	int R = 256;
	int *Count = new int[R + 2];
	string *Aux = new string[N];
	MSD(a, Aux, Count, 0, N - 1, 0);
	Aux = NULL;
	delete Aux;
	Aux = NULL;
	delete Count;
	Count = NULL;
}
int main(){
    string a[maxn];
    int n;
    cin>>n;
    for(int i = 0 ; i < n ; i++){
        cin>>a[i];
    }
    MSD(a,n);
    for(int i = 0 ; i < n ; i++){
        cout<<a[i]<<" ";
    }
}