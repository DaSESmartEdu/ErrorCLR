#include<iostream>
using namespace std;
int father[20000];
int n,m;
void init()
{
    for(int i=1; i<=n; i++)
        father[i]=i;
}
int find(int x)
{
    if(x==father[x])
        return x;
    else return father[x]=find(father[x]);
}
void merge(int x,int y)
{
    int fx=find(x);
    int fy=find(y);
    if(fx!=fy)
    {
        father[fx]=fy;
    }
}
int main()
{
    int x,y;
    while(cin >> n >> m)
    {
        if(n==0)
        {
            break;
        }
        init();
        for(int i=1; i<=m; i++)
        {
            cin>>x>>y;
            merge(x,y);
        }
        int cnt=-1;
        for(int i=1; i<=n; i++)
        {
            if(father[i]==i)
            {
                cnt++;
            }
        }
        cout<<cnt<<endl;
    }
}