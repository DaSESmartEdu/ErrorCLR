#include <stdio.h>
int main()
{
    int x;
    float y;
    scanf("%d",&x);
    if(x<=50){
        y=0.53*x;
    }
    else{
        y=0.58*x-2.5;
    }
    printf("%d %f",x,y);
    return 0;
}