#include <stdio.h>
int even(int n);
int OddSum(int List[],int N);
int main()
{
    int i,n,List[n];
    scanf("%d",&n);
    for (i=0;i<n;i++)
    {
        scanf("%d",&List[i]);
    }
    printf ("%d",OddSum(List,n));
    return 0;
}
int even(int n)
{
    int i;
    if (n%2==1)
    {
        i=0;
    }
    else
    {
        i=1;
    }
    return i;
}
int OddSum(int List[],int N)
{
    int i,s=0;
    for (i=0;i<N;i++)
    {
        if (even(List[i])==0)
        {
            s += List[i];
        }
    }
    return s;
}