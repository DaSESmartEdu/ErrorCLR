#include<stdio.h>
int main()
{int k;
 scanf("%d\n",&k);
 char s[100];
 k=k%26;
 gets(s);
 int i;
 for(i=0;s[i]!='\0';i++)
 {if(s[i]-'a'+1+k<=26)
     {printf("%c",s[i]+k);}
  else
  {printf("%c",s[i]+k-26);}
 }
 return 0;
}