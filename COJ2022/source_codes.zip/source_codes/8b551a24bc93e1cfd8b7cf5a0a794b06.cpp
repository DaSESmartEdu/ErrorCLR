#include <iostream>
using namespace std;
int map[105][105];           
int mark[105][105];      
int flag=0;
int m,n;
void dfs(int x,int y){
    if(x==m || y==n) {
        flag=1;
        return ;
    }
    else{
      if(map[x][y]+map[x+1][y]==1 && mark[x+1][y]==0){
          mark[x+1][y]=1;
          dfs(x+1,y);
      }
      if(map[x][y]+map[x-1][y]==1 && mark[x-1][y]==0){
          mark[x-1][y]=1;
          dfs(x-1,y);
      }
      if(map[x][y]+map[x][y+1]==1 && mark[x][y+1]==0){
          mark[x][y+1]=1;
          dfs(x,y+1);
      }
      if(map[x][y]+map[x][y-1]==1 && mark[x][y-1]==0){
          mark[x][y-1]=1;
          dfs(x,y-1);
      }
    }
}
int main(){
    cin >> m >> n;
    for(int i=1;i<=m;i++){
        for(int j=1;j<=n;j++){
            cin >> map[i][j];
            mark[i][j]=0;
        }
    }
    for(int i=0;i<=m+1;i++){
        mark[i][0]=1;
        mark[i][n+1]=1;
        map[i][0]=2;
        map[i][n+1]=2;
    }
    for(int j=0;j<=n+1;j++){
        mark[0][j]=1;
        mark[m+1][j]=1;
        map[0][j]=2;
        map[m+1][j]=2;
    }
    dfs(1,1);
    cout << flag ;
    return 0;
}