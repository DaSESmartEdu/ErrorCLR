#include <stdio.h>
int main()
{
    int a=0,b=0,c=0,d=0;
    scanf("%d %d %d %d",&a,&b,&c,&d);
    int q=0;
    q=a+b+c+d;
    float p=0;
    p=q/4.0;
    printf("q=%d\np=%.1f\n",q,p);
    return 0;
}