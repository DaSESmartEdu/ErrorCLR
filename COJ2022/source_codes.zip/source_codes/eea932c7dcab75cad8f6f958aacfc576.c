#include <stdio.h>
#include <math.h>
int main ()
{
    int n,i;
    i=1;
    float sum;
    scanf("%d" ,&n);
    while (i<=n)
    {
        sum=sum+sqrt(i);
        i=i+1;
    }
    printf("%.2f" ,sum);
    return 0;
}