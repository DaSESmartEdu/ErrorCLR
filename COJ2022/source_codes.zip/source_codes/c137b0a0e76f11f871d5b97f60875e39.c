#include<stdio.h>
int main(){
	int n;
	scanf("%d",&n);
	int i,j;
	for(i=1;i<=n;i++){
		for(j=1;j<=n;j++){
			if(j>=-i+(n+1)/2+1&&j<=-i+(n+1)/2+n&&j>=i-(n+1)/2+1&&j<=i+(n+1)/2-1){
				printf("*");
			}
			else{
				printf(" ");
			}
		}
	printf("\n");
	}
	return 0;
}