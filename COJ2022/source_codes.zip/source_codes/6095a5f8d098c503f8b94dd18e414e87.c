#include <stdio.h>
 int main()
 {
    int m,n,i,p;
    scanf("%d %d",&m,&n);
    i=2;
    while (m%i!=0 || n%i!=0)
    {
        i++;
    }
    p=m*n/(i*i);
    printf("%d %d",i,p);
    return 0;
 }