#include<stdio.h>
double fact(int n)
{
	int i;
	double prod=1;
	for (i=1;i<=n;i++)
	{
		prod=prod*i;
	}
	return prod;
}
int main()
{
	int n,i;
	double e;
	scanf("%d",&n);
	for (i=1;i<=n;i++)
	{
		e=e+fact(i);
	}
	printf("%.0lf",e);
	return 0;
}