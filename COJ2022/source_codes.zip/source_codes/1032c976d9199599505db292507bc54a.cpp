#include <iostream>
#include <cstring>
using namespace std;
enum Error_code{underflow,oveflow,success};
const int maxqueue = 8;
struct Pos
{
    int x;
    int y;
};
class CirQueue{
public:
    CirQueue();
    bool empty(){return count == 0;}
    Error_code serve();
    Error_code append(const Pos &item);
    Error_code retrieve(Pos &item);
    bool full(){return count == maxqueue;}
    int size(){return count;}
    void clear();
    Error_code serve_and_retrieve(Pos &item);
private:
    int count;
    int front,rear;
    Pos entry[maxqueue];
};
CirQueue::CirQueue()
{
    count = 0;
    front = 0;
    rear = maxqueue - 1;
    memset(entry,0,sizeof(entry));
}
Error_code CirQueue::serve()
{
    if(count == 0)
        return Error_code::underflow;
    count--;
    front = (front + 1)%maxqueue;
    return Error_code::success;
}
Error_code CirQueue::append(const Pos &item)
{
    if(count == maxqueue)
        return Error_code::oveflow;
    count++;
    rear = (rear + 1)%maxqueue;
    entry[rear] = item;
    return Error_code::success;
}
Error_code CirQueue::retrieve(Pos &item)
{
    if(count <= 0)
        return Error_code::underflow;
    item = entry[front];
    return Error_code::success;
}
void CirQueue::clear()
{
    count = 0;
    front = 0;
    rear = maxqueue - 1;
    memset(entry,0,sizeof(entry));
}
Error_code CirQueue::serve_and_retrieve(Pos &item)
{
    Error_code ret = retrieve(item);
    if(ret == success)
        ret = serve();
    return ret;
}
const int maxrow = 10,maxcol = 10;
int main()
{
    CirQueue cq;
    char mat[maxrow][maxcol];
    memset(mat,0,sizeof(mat));
    int m,n;
    cin>>m>>n;
    int x,y;
    cin>>x>>y;
    for(int i = 0;i < m;i++){
        for(int j = 0;j < n;j++){
            cin>>mat[i][j];
        }
    }
    int mask[maxrow][maxcol];
    memset(mask,0,sizeof(mask));
    char target = mat[x][y];
    cq.append({x,y});
    mask[x][y] = 1;
    Pos res = {-1,-1};
    int dx[4] = {0,0,1,-1};
    int dy[4] = {1,-1,0,0};
    while(!cq.empty()){
        Pos tmp;
        cq.serve_and_retrieve(tmp);
        if(mat[tmp.x][tmp.y]==target&&!(tmp.x==x&&tmp.y)){
            res.x = tmp.x;
            res.y = tmp.y;
            break;
        }
        for(int i = 0;i < 4;i++){
            Pos f;
            f.x = tmp.x + dx[i];
            f.y = tmp.y + dy[i];
            if(f.x >= 0&&f.x < m&&f.y >= 0&&f.y < n&&mask[f.x][f.y] == 0){
                cq.append(f);
                mask[f.x][f.y] = 1;
            }
        }
    }
    cout<<res.x<<" "<<res.y;
    return 0;    
}