#include<iostream>
using namespace std;
void multi1(int list1[][512],int list2[][512],int list3[][512],int size){
    for(int i = 0 ;i < size ; i++){    
        for(int j = 0 ;j < size ; j++){
            int sum = 0;
            for(int p = 0 ;p < size ;p++){
                sum += list1[i][p]*list2[p][j];   
            }
            list3[i][j] = sum;
        }
    }
}
int main(){
    int NN;
    int MM;
    ios::sync_with_stdio(false); 
    cin >> NN >> MM;
    int list1[512][512];
    int list2[512][512];
    int returnlist[512][512];
    int t = 0;
    while( t < NN){
        for(int i = 0 ;i < MM; i++){
            for(int j = 0 ; j < MM; j++){
                cin>>list1[i][j];
            }
        }
        for(int i = 0 ;i < MM; i++){
            for(int j = 0 ; j < MM; j++){
                cin>>list2[i][j];
            }
        }
        multi1(list1,list2,returnlist,MM);
        for(int i = 0 ;i < MM; i++){
            for(int j = 0 ; j < MM; j++){
                if( j == MM-1){
                    cout<<returnlist[i][j]<<endl;
                }
                else{
                    cout<<returnlist[i][j]<<' ';
                }
            }
        } 
        t++;       
    }
    return 0;
}