#include <iostream>
#include <iomanip>
using namespace std;
double cal(double x1,double x2,double x3,double x4)
{
    if(x2<=x3||x4<=x1) return 0;
    else if(x1<=x3&&x2>=x4) return x4-x3;
    else if(x1>x3&&x2<x4) return x2-x1;
    else if(x1<=x3&&x2<x4&&x2>x3) return x2-x3;
    else if(x1>x3&&x2>x4&&x4>x1) return x4-x1;
}
int main()
{
    double x1,x2,x3,x4,y1,y2,y3,y4;
    cin>>x1>>y1>>x2>>y2;
    cin>>x3>>y3>>x4>>y4;
    if(x1>x2) swap(x1,x2);
    if(y1>y2) swap(y1,y2);
    if(x3>x4) swap(x3,x4);
    if(y3>y4) swap(y3,y4);
    double x=cal(x1,x2,x3,x4);
    double y=cal(y1,y2,y3,y4);
    cout<<setiosflags(ios::fixed)<<setprecision(2)<<x*y<<endl;
}