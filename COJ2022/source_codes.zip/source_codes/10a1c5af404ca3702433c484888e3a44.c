#include<stdio.h>
#include<math.h> 
int main()
{double x;
double power,result;
scanf("%lf",&x);
if(x>=0)
{power=pow(x,0.5);
result=power;
}
else
{
power=pow(x+1,2);
result=power+2*x+1/x;	
}
printf("f(%.2lf) = %.2lf",x,result);
	return 0;
 }