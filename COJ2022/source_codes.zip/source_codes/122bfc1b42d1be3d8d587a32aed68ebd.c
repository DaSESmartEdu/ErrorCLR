#include <stdio.h>
void parlindrome (char* s);
int k;
int main()
{
    char ch[100];
    int i=0;
    gets(ch);
    char *s;
	s=&ch[0];
    for(i=0;ch[i]!='\0';i++)
	{
		continue;
	}
	k=i-1;
    parlindrome(s);
    return 0;
}
void parlindrome (char*s)
{
    int i;
    int u=0;
    for(i=0;i<(k-i);i++)
    {
        if(*(s+i)!=*(s+k-i))
        u++;
    }
    if(u==0)
    printf("Yes");
    else
    printf("No");
}