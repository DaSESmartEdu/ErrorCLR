#include "stdio.h"
int main()
{
    int a,n,sum=0,b=0;
    if (scanf("%d %d",&a,&n) == 2)
    {
        for (int i = 0; i < n; i++)
        {
            b = b*10 + a;
            sum += b;
        }
        printf("%d",sum);
    }
    return 0;
}