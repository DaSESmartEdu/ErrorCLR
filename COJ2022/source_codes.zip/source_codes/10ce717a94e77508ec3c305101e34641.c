#include <stdio.h>
#include <math.h>
int reverse(int number);
int main()
{
	int n;
	scanf("%d",&n);
	printf("%d",reverse(n));
	return 0;
}
int reverse(int number)
{
	int count=1,sum=0,digit=10,n=number;
	while(n/digit!=0)
	{
		count++;
		n/=digit;
	}
	for(int i=1;i<=count;i++)
	{
		sum+=(number%10)*pow(10,count-i);
		number/=10;
	}
	return sum;
}