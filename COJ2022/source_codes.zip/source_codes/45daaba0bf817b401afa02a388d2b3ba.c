#include <stdio.h>
double sign(int n);
int main()
{
	int x;
	int y;
	scanf("%lf",&x);
	y=sign(x);
	printf("%d",y);
	return 0;
}
double sign(int n)
{
	int y;
	if(n>0){
		y=1;
	}
	else if(n==0){
		y=0;
	}
	else{
		y=-1;
	}
	return y;
}