#include<stdio.h>
long long fac(int x);
int main(){
	int n;
	scanf("%d",&n);
	long long s=0;
	s=fac(n);
	printf("%lld",s);
	return 0;
}
long long fac(int x){
	int a;
	int sum=1;
	if(x%2==0){
		a=2;
	}
	else{
		a=1;
	}
	for(a=a;a<=x;a+=2){
		sum*=a;
	}
	return sum;
}