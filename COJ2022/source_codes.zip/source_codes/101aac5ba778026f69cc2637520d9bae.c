#include <stdio.h>
struct student{
    int num;
    int mark;
};
int main(){
    struct student a[100];
    int n;
    scanf("%d",&n);
    for(int i=0;i<n;i++){
        scanf("%d %d",&a[i].num,&a[i].mark);
    }
    int b[100]={0};
    int j=0;
    for(int i=0;i<n;i++){
        if(a[i].mark<60){
            b[j]=a[i].num;
            j++;
        }
    }
    for(int i=0;i<j;i++){
        printf("%d",b[i]);
        if(i==j-1){
            break;
        }
        printf("\n");
    }
}