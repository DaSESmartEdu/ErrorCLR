#include"stdio.h"
typedef struct node {
	int value;
	int code;
}node;
void fun(node a[],int x) {
	int i,j;
	node change,mix;
	for (i = 0; i < x-1; i++) {
		for (j = i+1; j < x; j++) {
			if (a[i].value > a[j].value) {
				change.value = a[i].value;
				a[i].value = a[j].value;
				a[j].value = change.value;
			}
		}
	}
}
void fun2(node a[], int x) {
	int i, j;
	node change, mix;
	for (i = 0; i < x - 1; i++) {
		for (j = i + 1; j < x; j++) {
			if (a[i].value < a[j].value) {
				change.value = a[i].value;
				a[i].value = a[j].value;
				a[j].value = change.value;
			}
		}
	}
}
void main() {
	int c[100];
	node a[100], b[100];
	int num,i,x=0,y=0;
	printf("shuru\n");
	scanf("%d", &num);
	for (i = 0; i < num; i++) {
		scanf("%d", &c[i]);
	}
	for (i = 0; i < num; i++) {
		if (c[i] > 0) {
			a[x].value = c[i];
			a[x].code = i;
			x++;
		}
		if (c[i] < 0) {
			b[y].value = c[i];
			b[y].code = i;
			y++;
		}
	}
	fun(a,x);   
	fun2(b,y);
	for (i = 0; i < x; i++) {
		c[a[i].code] = a[i].value;
	}
	for (i = 0; i < y; i++) {
		c[b[i].code] = b[i].value;
	}
	for (i = 0; i < num; i++) {
		printf("%d ", c[i]);
	}
}