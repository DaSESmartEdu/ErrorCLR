#include <stdio.h>
int main()
{
   int a, b, c, d;
   scanf("%d",&a);
   scanf("%d",&b);
   scanf("%d",&c);
   scanf("%d",&d);
   int sum = a+b+c+d;
   float  e=(a+b+c+d)/4.0;
   printf("%d %f\n", sum,e);
  return  0;	
}