#include <bits/stdc++.h>
using namespace std;
const int N = 1e4 + 5; 
int primes[N] , pNum;
bool isprime[N];
void eulerSieve(int n) {
	memset(isprime,true,sizeof isprime);
	for(int i = 2;i<=n;++i){
		if(isprime[i]){
			primes[pNum++] = i;
		}
		for(int p = 0;p<pNum;++p){
			if(i*primes[p] > n) break;
			isprime[i*primes[p]] = false;
			if(i%primes[p] == 0 ) break;
		}	
	}
}
void pDepose(int num) {
	if(isprime[num]) {
		printf("%d=%d\n", num,num);
		return;
	}
	printf("%d=", num);
	int p = 0;
	bool start = false;
	while(num!=1) {
		int cnt = 0 ;
		while(num%primes[p] == 0 ){
			cnt++;
			num/=primes[p];
		}
		while(cnt--){
			if(start) printf("*%d",primes[p]);
			else {
				printf("%d", primes[p]);
				start = true;
			}
		}	
		p++;
	}
	printf("\n");
}
int main(){
	int n, m;
	scanf("%d%d",&n,&m);
	eulerSieve(m);
	for(int k = n ; k <= m ; ++k) {
		pDepose(k);
	}
	return 0;
}