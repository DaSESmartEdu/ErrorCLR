#include<stdio.h>
#include<string.h>
char a[10000],b[10000];
int aaa(char a[])
{
    int num=0;
    int len ;
    int p=1;
    int i;
    len = strlen(a);
    for(i=len-1;i>=0;i--)
    {
        num = num+(a[i]-'0')*p;
        p = p*10;
    }
    return num;
}
int nn(char a[])
{
    int len;
    int i;
    int flag =0;
    len = strlen(a);
    int num = aaa(a);
    for(i=0;i<len;i++)
    {
        if(num ==0 || (a[i]-'0')>9 || (a[i]-'0') <0 )
        {
            flag =1;
        }
    }
    return flag;
}
int main()
{
    int num1,num2;
    scanf("%s%s",a,b);
    if(nn(a) == 1 && nn(b)==1)
    {
        printf("? + ? = ?\n");
    }
    else if(nn(a) == 0 && nn(b)==1)
    {
        num1 = aaa(a);
        printf("%d + ? = ?\n",num1);
    }
     else if(nn(a) == 1 && nn(b)==0)
    {
        num2 = aaa(b);
        printf("? + %d = ?\n",num2);
    }
     else if(nn(a) == 0 && nn(b)==0)
    {
        num1 = aaa(a);
        num2 = aaa(b);
        printf("%d + %d = %d\n",num1,num2,num1+num2);
    }
    return 0;
}