#include <stdio.h>
#include <math.h>
int main(){
	int i=1,n;
	double sum=0;
	printf("请输入一个整数n");
	scanf("%d",&n);
	while(i<=n){sum+=pow(i,0.5);
			   i++;}
	printf("%.2f\n",sum);
	return 0;
}