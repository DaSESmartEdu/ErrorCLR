#include <stdio.h>
#include <math.h>
double fact(int n)
{
   int i,product;
   product=1;
   for(i=1;i<=n;i++)
   {
      product=product*i;
   }
   return product ;
}
int main()
{
    double i,item,sum,x;
	sum=0;
	item=1.0;
    scanf("%lf",&x);
    for (i=1;fabs(item)>=0.00001;i++)
    {
        item=pow(x,i)/fact(i);
        sum=sum+item;
    }
    printf("%.4lf",sum);
    return 0;
}