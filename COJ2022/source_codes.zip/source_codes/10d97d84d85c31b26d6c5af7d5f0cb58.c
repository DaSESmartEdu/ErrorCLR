#include<stdio.h>
#include<string.h>
#define MAX(a,b) a>b?a:b
int main()
{
    int a[1000]={0},b[1000]={0};
    char ch[1000];
    char ch1[1000];
    gets(ch);
    gets(ch1);
    int n=strlen(ch);
    int m=strlen(ch1);
    int i,j=0;
    for (i=n-1;i>=0;i--)
    {
        a[j++]=ch[i]-'0';
    }
    int p=j;
    j=0;
    for (i=m-1;i>=0;i--)
    {
        b[j++]=ch1[i]-'0';
    }
    int q=j;
    int max=MAX(p,q);
    j=0;
    for (i=0;i<max;i++)
    {
        a[i]+=b[i];
    }
    for (i=0;i<max;i++)
    {
        if (a[i]>=10)
        {
            a[i]-=10;
            a[i+1]+=1;
        }
    }
    if (a[max]==0)
    {
        max--;
    }
    for (i=max;i>=0;i--)
    {
        printf("%d",a[i]);
    }
    return 0;
}