#include<stdio.h>
void CountOff( int n, int m, int out[] );
int main()
{
    int n,m;
    scanf("%d%d",&n,&m);
    int a[n];
    for (int i = 0; i < n; i++)
    {
        a[i]=0;
    }
    CountOff(n,m,a);
}
void CountOff( int n, int m, int out[] )
{
    int i,judge=0,k=0;
    for ( i = 0; i < n; i++)
    {
        for (; judge!=3; k++)
        {
            if (k>10)
            {
                k-=11;
            }           
            if (!out[k])
            {
                judge++;
            }
            if (judge==m)
            {
                out[k]=i+1; 
            }            
        }
        judge=0;  
    }
    for (int i = 0; i < n; i++)
    {
        printf("%d ",out[i]);
    }
}