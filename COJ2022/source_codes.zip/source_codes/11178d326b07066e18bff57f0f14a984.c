#include<stdio.h>
#include<math.h>
int main()
{
    int a,n,sum=0,s=0,i=0;
    scanf("%d %d",&a,&n);
    while(i<=n-1)
    {
        sum=sum+a*pow(10,i);
        i++;
    }
    printf("%d",sum);
    return 0;
}