#include<stdio.h>
int Fanzhi(int month);
int main()
{
    int n, month;
    scanf("%d", &n);
    for (month=1; Fanzhi(month)<=n; month++);
    printf("%d", month);
    return 0;
}
int Fanzhi(int month){
    if (month==1 || month == 2) return 1;
    else return Fanzhi(month-1) + Fanzhi(month-2);
}