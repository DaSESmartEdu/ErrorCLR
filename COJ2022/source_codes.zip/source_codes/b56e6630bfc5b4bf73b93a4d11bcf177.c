#include <stdio.h>
int main()
{
	double mile,time;
	double price = 0;
	scanf("%lf %lf",&mile,&time);
	if (mile<=3){
		price = 10;
	}	
	else if (mile>3 && mile<=10){
		price = 10 + (mile-3)*2;
	}	
	else{
		price = 24 + (mile-10)*3;
	}
	price += (int)time%5*2;
	if (price-(int)price>=0.5)
		price = (int)price+1;
	else
		price = (int)price;
	printf("%d",(int)price);
	return 0;
}