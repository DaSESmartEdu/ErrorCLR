#include <stdio.h>
#include<math.h>
int main ()
{
	double km,time;
	scanf("%lf %lf",&km,&time);
	double money;
    int a=floor(time/5);
	if (time<5)
	{
		if(km<=3)
		money=10;
		else if(km>3&&km<=10)
		money=10+(km-3)*2;
		else
		money=25+(km-10)*3;
	}
	else
	{
		if (km<=3)
		money=10+(2*a);
		else if(km>3&&km<=10)
		money=10+((km-3)*2)+(2*a);
		else
		money=24+((km-10)*3)+(2*a);
	}
	int c=(money+0.5);
	printf("%d",a);
	return 0;
	}