#include<stdio.h>
int main()
{int a,sum,x;
 sum=0;
 while(1)
 {scanf("%d",&x);
 if(a<=0) break;
 if(a%2!=0)
  sum+=a;}
printf("%d",sum);
return 0;}