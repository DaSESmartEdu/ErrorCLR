#include <stdio.h>
#include<math.h>
int main()
{
    int n,i,t,j;
    scanf("%d",&n);
    for(i=1;i<=n;i++)
    {
    t=abs((n+1)/2-i);
    for(j=1;j<=(n-2*t);j++)
	{
    	if(j<=t)
		{
        printf(" ");
    	}
        else 
        {
        	printf("*");
        }
    }
    printf("\n");
    }
   return 0;
}