#include "stdio.h"
	#include <math.h>
	#pragma warning(disable : 6031 )
int main() {
	int m, n,t;
	scanf("%d%d", &m, &n);
	m = m % n;
	int a[6][6];
	int i, j;
	for (i = 0; i < n; i++)
		for (j = 0; j < n; j++)
			scanf("%d", &a[i][j]);
	for (i = 0; i < n; i++)
	{
		for (j = 0; j < n; j++)
		{
			if (j - m >= 0)
			{
				t = a[i][j-m];
				printf("%d ", t);
			}
			else {
				t = a[i][(j - m + n)];
				printf("%d ", t);
			}
			if (j == n-1)printf("\n");
		}
	}
}