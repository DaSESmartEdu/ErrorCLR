#include <iostream>
#include <string>
using namespace std;
int main()
{
    int k;
    string s;
    cin>>k;
    cin>>s;
    int len=s.size();
    for(int i=0;i<s.size();i++)
    {
        char c=s[i]+k;
        if(c>'z') c=c-'z'+'a'-1;
        cout<<c;
    }
    return 0;
}