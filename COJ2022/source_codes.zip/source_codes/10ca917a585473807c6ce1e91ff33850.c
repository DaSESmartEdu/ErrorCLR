#include<stdio.h>
int main()
{
	int i,j,k,n,mid;
	scanf("%d",&n);mid=n/2+1; 
    for(i=1;i<=mid;i++)
    {for(j=mid-i;j>0;j--) printf("  ");
    for(k=1;k<=2*i-1;k++) printf("* ");
    printf("\n");
	}
    for(i=mid-1;i>0;i--)
    {for(j=mid-i;j>0;j--) printf("  ");
    for(k=1;k<=2*i-1;k++) printf("* ");
    printf("\n");
	}
	return 0;
 }