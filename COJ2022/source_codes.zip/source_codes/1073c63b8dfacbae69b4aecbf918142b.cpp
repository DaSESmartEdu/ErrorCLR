#include <iostream>
#include <stdio.h>
using namespace std;
int link[20002]; 
int findx(int x)   
{ 
	if(link[x]==x)  
	{
		return x;
	}else
	{
		findx(link[x]);
	}
}
void unionxy(int x,int y)   
{
	x=findx(x); 
	y=findx(y); 
	if(x==y)   
	{
		return;
	}else
	{
		link[x]=y;
	}
}
int main()
{
	int N,M,i,cnt; 
	while(scanf("%d",&N),N)
	{
		cin>>M; 
		int x,y;
		cnt=0;  
		for(i=1;i<N+1;i++)   
	    {
		link[i]=i;
	    }
		for(i=0;i<M;i++)
		{
			scanf("%d %d",&x,&y);
			unionxy(x,y);   
		}
		for(i=1;i<N+1;i++)
		{
			if(link[i]==i)
			{
				cnt++;  
			}
		}
		cout<<cnt-1<<endl; 
	}
}