#include <bits/stdc++.h>
using namespace std;
template <typename T>
class TreeNode {
public:
    T val;
    TreeNode *l = nullptr, *r = nullptr;
    TreeNode* p = nullptr;
    bool red = true;
    TreeNode() {}
    TreeNode(T val) : val(val) {}
    TreeNode(T val, TreeNode* p) : val(val), p(p) {}
    TreeNode(T val, TreeNode* p, TreeNode* l, TreeNode* r)
        : val(val), p(p), l(l), r(r) {}
};
template <typename T>
class MySet {
    using Tn = TreeNode<pair<string, T>>;
    using pstrT = pair<string, T>;
private:
    size_t sz = 0;
    Tn* root = nullptr;
    bool isPrefixOf(const string a, const string b) const {
        if (a.size() > b.size())
            return 0;
        for (int i = 0; i < a.size(); i++)
            if (a[i] != b[i]) return 0;
        return 1;
    }
    Tn* _succ(Tn* curr) {
        if (!curr) return nullptr;
        if (curr->r) {
            curr = curr->r;
            while (curr && curr->l)
                curr = curr->l;
        } else {
            while (curr && curr->p && curr == curr->p->r)
                curr = curr->p;
            curr = curr->p;
        }
        return curr;
    }
    Tn* _pred(Tn* curr) {
        if (!curr) return nullptr;
        if (curr->l) {
            curr = curr->l;
            while (curr && curr->r)
                curr = curr->r;
        } else {
            while (curr && curr->p && curr == curr->p->l)
                curr = curr->p;
            curr = curr->p;
        }
        return curr;
    }
    bool _rotateToRight(Tn* x) {
        Tn *y = x->l, *z = x->p;
        bool isLeftCh = z && (x == z->l);
        if (!y) return false;
        x->l = y->r;
        if (y->r)
            y->r->p = x;
        y->p = x->p;
        if (!z)
            root = y;
        else if (x == x->p->r)
            x->p->r = y;
        else
            x->p->l = y;
        y->r = x;
        x->p = y;
        if (z)
            if (isLeftCh)
                z->l = y;
            else
                z->r = y;
        return true;
    }
    bool _rotateToLeft(Tn* x) {
        Tn *y = x->r, *z = x->p;
        bool isLeftCh = z && (x == z->l);
        if (!y) return false;
        x->r = y->l;
        if (y->l)
            y->l->p = x;
        y->p = x->p;
        if (!z)
            root = y;
        else if (x == x->p->l)
            x->p->l = y;
        else
            x->p->r = y;
        y->l = x;
        x->p = y;
        if (z)
            if (isLeftCh)
                z->l = y;
            else
                z->r = y;
        return true;
    }
    pair<Tn*, Tn*> _queryPrefixSeg(const string& str) {
        Tn* curr = this->root;
        while (curr) {
            if (isPrefixOf(str, curr->val.first))
                break;
            curr = (str < curr->val.first) ? curr->l : curr->r;
        }
        Tn *lptr = curr, *rptr = curr;
        Tn* llptr = curr;
        while (llptr && isPrefixOf(str, llptr->val.first)) {
            if (llptr->l && isPrefixOf(str, llptr->l->val.first))
                lptr = llptr, llptr = llptr->l;
            else
                lptr = llptr, llptr = _pred(llptr);
        }
        while (rptr && isPrefixOf(str, rptr->val.first)) {
            if (rptr->r && isPrefixOf(str, rptr->r->val.first))
                rptr = rptr->r;
            else
                rptr = _succ(rptr);
        }
        return {lptr, rptr};
    }
    void _fixInsertion(Tn* curr) {
        while (curr->p && curr->p->red) {
            if (!curr->p->p) break;
            Tn* uncle =
                (curr->p->p->l == curr->p)
                    ? curr->p->p->r
                    : curr->p->p->l;
            if (uncle && uncle->red) {
                curr->p->red = false;
                uncle->red = false;
                curr->p->p->red = true;
                curr = curr->p->p;  
                continue;
            }
            bool currIsLeft = (curr == curr->p->l);
            bool parentIsLeft = (curr->p == curr->p->p->l);
            if (currIsLeft != parentIsLeft) {
                curr = curr->p;
                parentIsLeft&& _rotateToLeft(curr);
                !parentIsLeft&& _rotateToRight(curr);
            }
            curr->p->red = false;
            curr->p->p->red = true;
            parentIsLeft&& _rotateToRight(curr->p->p);
            !parentIsLeft&& _rotateToLeft(curr->p->p);
        }
        this->root->red = false;
    }
    Tn* _insert(pstrT val) {
        Tn** curr = &this->root;
        Tn* parent = nullptr;
        while (*curr) {
            if (val == (*curr)->val)
                return *curr;
            parent = *curr;
            if (val < (*curr)->val)
                curr = &(*curr)->l;
            else
                curr = &(*curr)->r;
        }
        return (*curr) = new Tn(val, parent);
    }
    void _delete(Tn* curr) {
    }
public:
    int cnt = 0;
    void _printTree(Tn* curr = nullptr, int num = 0, bool silent = true) {
        if (num == 0)
            curr = this->root, cnt = 0;
        if (!curr) return;
        _printTree(curr->l, num + 1, silent);
        if (!silent) {
            for (int i = 0; i < num; i++)
                cout << "::";
            cout << curr->val.first << ":";
            for (int i = 0; i < curr->val.second.size(); i++)
                cout << curr->val.second[i] << ",";
            cout << endl;
        }
        cnt++;
        _printTree(curr->r, num + 1, silent);
    }
    T& operator[](const string key) {
        Tn* ptr = _insert(pair<string, T>{key, T()});
        _fixInsertion(ptr);
        return ptr->val.second;
    }
    pair<Tn*, Tn*> prefixQuery(const string& key) { return _queryPrefixSeg(key); }
    Tn* next(Tn* x) { return _succ(x); }
    MySet() {}
};
vector<string> split(const string& raw, const char& delim) {
    static string si;
    vector<string> vec;
    stringstream ss(raw);
    while (getline(ss, si, delim))
        vec.emplace_back(si);
    return vec;
}
string getQuoted(const string& str) { return "\"" + str + "\""; }
string format(const vector<string>& str) {
    string res = "";
    res += getQuoted("序号") + ":" + getQuoted(str[0]);
    res += "," + getQuoted("区县") + ":" + getQuoted(str[1]);
    res += "," + getQuoted("场馆名称") + ":" + getQuoted(str[2]);
    res += "," + getQuoted("地址") + ":" + getQuoted(str[3]);
    res += "," + getQuoted("联系电话") + ":" + getQuoted(str[4]);
    res += "," + getQuoted("开放时间") + ":" + getQuoted(str[5]);
    res += "," + getQuoted("收费标准") + ":" + getQuoted(str[6]);
    return "{" + res + "}";
}
int main() {
    int museumNum;
    cin >> museumNum;
    getchar();
    MySet<vector<string>> museum;
    for (int i = 0; i < museumNum; i++) {
        string tmpStr;
        getline(cin, tmpStr);
        auto splitStr = split(string(tmpStr), ',');
        museum[splitStr[2]] = splitStr;
    }
    int queryNum;
    cin >> queryNum;
    for (int i = 0; i < queryNum; i++) {
        string prefixKey;
        cin >> prefixKey;
        cout << "[";
        auto itPair = museum.prefixQuery(prefixKey);
        for (auto x = itPair.first; x != itPair.second; x = museum.next(x)) {
            cout << format(x->val.second);
            if (museum.next(x) != itPair.second)
                cout << ",";
        }
        cout << "]" << endl;
    }
}