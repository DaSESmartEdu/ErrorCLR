#include <iostream>
using namespace std;
bool res=false;
void search(int map[100][100],int x,int y,int m,int n,int kk){
    if(x==m&&y==n){res=true;
    return;}
    map[x][y]+=3;
    if(x>0&&map[x-1][y]<2&&map[x-1][y]!=kk){
        search(map,x-1,y,m,n,map[x-1][y]);
    }
    if(y>0&&map[x][y-1]<2&&map[x][y-1]!=kk){
        search(map,x,y-1,m,n,map[x][y-1]);
    }
    if(x<m&&map[x+1][y]<2&&map[x+1][y]!=kk){
        search(map,x+1,y,m,n,map[x+1][y]);
    }
    if(y<n&&map[x][y+1]<2&&map[x][y+1]!=kk){
        search(map,x,y+1,m,n,map[x][y+1]);
    }
    map[x][y]-=3;
    return;
}
int main()
{
    int m,n;
    cin>>m>>n;
    int map[100][100]={0};
    for(int i=0;i<m;i++){
        for(int j=0;j<n;j++){
            cin>>map[i][j];
        }
    }
    search(map,0,0,m-1,n-1,map[0][0]);
    if(res){
        cout<<'1';
    }else{
        cout<<'0';
    }
    return 0;
}