#include <stdio.h>
int main(){
    int i,j;
    int n;
    scanf("%d",&n);
    for (i=1;i<=(n+1)/2;i++){
        for (j=1;j<=n;j++){
            if (j>=(n+1)/2-(i-1)&&j<=n-((n+1)/2-(i-1))+1){
                printf("*");
            }
            else{
                printf(" ");
            }
        }
        printf("\n");
    }
    for (i=(n+1)/2+1;i<=n;i++){
        for (j=1;j<=n;j++){
            if (j>=i-(n+1)/2+1&&j<=n-(i-(n+1)/2+1)+1){
                printf("*");
            }
            else{
                printf(" ");
            }
        }
        printf("\n");
    }
    return 0;
}