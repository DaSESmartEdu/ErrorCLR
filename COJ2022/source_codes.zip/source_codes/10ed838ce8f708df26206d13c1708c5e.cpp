#include<iostream>
#include<queue>
#include<cstring>
using namespace std;
const int R=102;
const int C=102;
int finalI;
int finalJ;
struct Pos{
    int row;
    int col;
};
class Skate{
public:
    void Init();
    void BFS(Pos t);
    int r;
    int c;
    int map[R][C];
    int step[R][C];
private:
    void clear();
    bool cango_(Pos cur);
    queue <Pos> sq;
};
void Skate::clear(){
    memset(step,0,sizeof (step));
}
bool Skate::cango_(Pos cur){
    if(cur.row>0&&cur.col<=c&&cur.col>0&&cur.row<=r) return true;
    else{
        return false;
    }
}
void Skate::Init() {
    cin>>r;
    cin>>c;
    for(int i=1;i<=r;i++){
        for(int j=1;j<=c;j++){
            cin>>map[i][j];
        }
    }
    memset(step,0,sizeof (step));
}
void Skate::BFS(Pos t){
    finalI=t.row;
    finalJ=t.col;
    clear();
    while(!sq.empty()){
        sq.pop();
    }
    sq.push(t);
    int dir[4][2]={{-1,0},{1,0},{0,1},{0,-1}};
    while(!sq.empty()){
        Pos cur=sq.front();
        sq.pop();
        Pos next;
        for(int i=0;i<4;i++){
            next.row=cur.row+dir[i][0];
            next.col=cur.col+dir[i][1];
            if(cango_(next)&&map[next.row][next.col]<map[cur.row][cur.col]){
                step[next.row][next.col]=step[cur.row][cur.col]+1;
                sq.push(next);
                finalI=next.row;
                finalJ=next.col;
            }
        }
    }
}
int main(){
    Skate s;
    s.Init();
    int maxh=-1;
    for(int i=1;i<=s.r;i++){
        for(int j=1;j<=s.c;j++){
            Pos cur;
            cur.row=i;
            cur.col=j;
            s.BFS(cur);
            if(s.step[finalI][finalJ]>maxh) maxh=s.step[finalI][finalJ];
        }
    }
    cout<<maxh+1;
    return 0;
}