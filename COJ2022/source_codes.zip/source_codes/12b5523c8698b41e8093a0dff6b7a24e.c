#include <stdio.h>
int even( int n );
int OddSum(int List[],int N);
int main()
{
    int n,i;
    scanf("%d",&n);
    int List[n],result;
    for ( i = 0; i < n; i++)
    {
        scanf("%d",&List[i]);
    }
    result= OddSum(List,n);
    printf("%d",result);
    return 0;
}
int even( int n )
{
    if (n%2==0)
    {
        return 1;
    }
    else
    {
        return 0;
    }
}
int OddSum(int List[],int N)
{
    int i,sum=0;
    for ( i = 1; i < N-1; i++)
    {
        if (even(List[i])==0)
        {
            sum=sum+List[i];
        }   
		else if (even(List[i])==1)
        {
            sum=sum+0;
        }   
    }
    return sum;
}