#include <stdio.h>
int main()
{
    float n,m;
    scanf("%f %f",&n,&m);
    if(10*n<=11*m){
        printf("normal");
    }
    else if(n*10<=15*m){
        printf("200");   
    }else{
        printf("revoke");
    }
    return 0;
}