#include <stdio.h>
int fact(int n)
{
    int a,fact=1;
    for(a=1;a<=n;a++)
    {
        fact*=a;
    }
    return fact;
}
int main()
{
    int b,number;
    double e=0.0;
    scanf("%d",&number);
    for(b=1;b<=number;b++)
    {
        e+=fact(b);
    }
    printf("%.0f",e);
    return 0;
}