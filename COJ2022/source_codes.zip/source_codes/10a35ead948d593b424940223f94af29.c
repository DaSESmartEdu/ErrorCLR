#include<stdio.h>
int main()
{
    int a[10][10];
    int n,z=0,h=0,y=0,k=0;
    int maxi=0,minj=0;
    scanf("%d",&n);
    for(int i=0;i<n;i++)
    {
        for(int j=0;j<n;j++)
        {
            scanf("%d",&a[i][j]);
        }
    }
    for(int i=0;i<n;i++)
    {
        maxi=a[i][0];
        z=0;
        for(int j=0;j<n;j++)
        {
            if(maxi<a[i][j])
            {
                maxi=a[i][j];
                z=j;
            }
        }
        minj=a[0][z];
        y=0;
        for(h=1;h<n;h++)
        {
            if(minj>a[h][z])
            {
            minj=a[h][z];
            y=h;
            }
        }
     if(minj==maxi)
     {
     k++;
     }
    }
     if(k==0)
     printf("NO");
     return 0;
}