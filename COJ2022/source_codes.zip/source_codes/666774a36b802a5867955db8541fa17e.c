#include<stdio.h>
int main()
{
	int a,n;
	scanf("%d%d",&a,&n);
	int sum = a,u = a;
	printf("%d %d\n",sum,u);
	for(int i = 1;i <= n-1;i++)
	{
		u = u * 10 + a;
		sum += u;
	}
	printf("%d",sum);
	return 0;
}