#include<stdio.h>
int main()
{
    int x;
    double a;
    scanf("%d",&x);
    if (x <= 50 )
    {
        a = x * 0.53;
    }
    else
    {
        a = 26.5 + 0.58*(x - 50);
    }
    printf("%f",a);
    return 0;
}