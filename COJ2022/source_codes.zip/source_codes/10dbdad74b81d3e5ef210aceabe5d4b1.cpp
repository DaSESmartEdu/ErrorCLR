#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
int main()
{
    int hh,mm,ss,n;
    scanf("%d:%d:%d",&hh,&mm,&ss);
    cin>>n;
    int tmp=(ss+n)/60;
    ss=(ss+n)%60;
    mm=(mm+tmp);
    tmp=mm/60;
    mm=mm%60;
    hh=(hh+tmp)%24;
    printf("%02d:%02d:%02d",hh,mm,ss);
    return 0;
}