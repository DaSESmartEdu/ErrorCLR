#include<stdio.h>
#include<math.h>
int factorial(int m,int o);
int factorial(int m,int o){
    int result=0;
    for(int i=1;i<=o;i++){
        result+=m*pow(10,i-1);
    }
    return result;
}
int main(){
    int a,n,sum=0;
    scanf("%d%d",&a,&n);
    for(int i=1;i<=n;i++){
        sum=sum+factorial(a,i);
		printf("%d\n",factorial(a,i));
    }
    printf("%d",sum);
    return 0;
}