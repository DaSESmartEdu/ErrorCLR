#include<stdio.h>
int sign (int x);
int sign (int x)
{
    int a;
    if (x>0)
    {
        a=1;
    }
    else if (x=0)
    {
        a=0;
    }
    else 
    {
        a=-1;
    }
    return a;
} 
int main()
{
    int b;
    scanf("%d",&b);
    printf("%d",sign(b));
}