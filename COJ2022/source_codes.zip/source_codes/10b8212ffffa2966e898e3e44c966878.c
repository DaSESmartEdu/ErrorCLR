#include<stdio.h>
int main(){
    int n;
    scanf("%d",&n);
    int a[n],b[n];
    int m=0;
    for(m;m<n;m++){
        scanf("%d",&a[m]);
    }
    int p=0;
    for(p;p<n;p++){
        scanf("%d",&b[p]);
    }
    m=0;
    p=0;
    for(m=0;m<n-1;m++){
        for(p=0;p<n;p++){
            if(a[m]==b[p]){
                printf("%d ",p+1);
            }
        }
    }
   for(p=0;p<n;p++){
        if(a[n-1]==b[p]){
            printf("%d",p+1);
        }
    }
}