#include<stdio.h>
#include<string.h>
int main()
{
    int n,i=0;
    scanf("%d",&n);
    char s[1000];
    scanf("%s",&s);
    for(int i=0;i<strlen(s);i++){
        if(s[i]+n<='z') printf("%c",s[i]+n);
        else printf("%c",s[i]+n-26);
    }
    return 0;
}