#include<stdio.h>
void ArrayShift(int a[],int n,int m);
int main()
{
	int n,m;
	scanf("%d%d",&n,&m);
    int a[100];
    int i;
	for(i=0;i<n;i++)
    scanf("%d",&a[i]);
    ArrayShift(a,n,m);
	return 0;
}
void ArrayShift(int a[],int n,int m)
{
	m=m%n;
	int b=n-m;
    int j;
	for(j=0;j<n;j++)
	{
		if(j+b<n)
		{printf("%d",a[j+b]);}
      else 
		{printf("%d",a[j-m]);}
		if(j!=n-1)
		{putchar(' ');}
	}
}