#include <stdio.h>
#include <math.h>
double fact(int n);
int main()
{
    double x,sum=1.0;
    scanf("%lf",&x);
    int i;
    for ( i = 1;fabs(pow(x,i)/fact(i))>=0.00001; i++)
    {
        sum=sum+pow(x,i)/fact(i);
    }
    printf("%.4lf",sum);
    return 0;
}
double fact (int n)
{
    int i;
    double item =1;
    for ( i = 1; i <=n; i++)
    {
        item*=i;
    }
    return item;
}