#include <stdio.h>
#include <math.h>
double fact(int n)
{
    int i;
    double s=1;
    for (i=1;i<=n;i++){
        s=s*i;
    }
    return s;
}
int main()
{
    double s=1,x,t;
    int i;
    scanf("%lf",&x);
    for (i=1;i<=1000;i++){
        t=pow(x,i)/fact(i);
        if (t<0.00001&&t>-0.00001)
            break;
        else
            s=s+t;
    }
    printf("%.4lf",s);
    return 0;
}