#include <stdio.h>
int main ()
{
    int a,b,c,d;
    if (a>b)
    {
        d=a;
        a=b;
        b=d;
    }
    if (a>c)
    {
        d=a;
        a=c;
        c=d;
    }
    if (b>c)
    {
        d=b;
        b=c;
        c=d;
    }
    return 0;
}