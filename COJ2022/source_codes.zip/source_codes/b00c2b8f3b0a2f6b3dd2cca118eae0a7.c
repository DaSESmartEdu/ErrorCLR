#include <stdio.h>
#include <math.h>
int main()
{
 double x;
 scanf("%lf", &x);
 double fact(int n)
 {int i; double a=1;
 for(i=1;i<=n;i++) {a=i*a;}
  return a;}
 double S=1; int j=1;
 while (  fabs( pow(x,j)/fact(j) )>=0.00001  )
 {S=S+pow(x,j)/fact(j);j++;}
  printf("%.4lf", S);
  return 0;
}