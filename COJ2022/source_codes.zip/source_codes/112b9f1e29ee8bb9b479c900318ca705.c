#include<stdio.h>
#include<stdlib.h>
int main()
{
    int n;
    while(scanf("%d",&n)!=EOF)
    {
        int a[10000];
        int cnt=0;
		if(n==0)
			printf("0");
        while(n!=0)
        {
            a[cnt++]=n%11;
            n=n/11;
        }
        for(int i=cnt-1;i>=0;i--)
        {
            if(a[i]==10)
                printf("A");
            else
                printf("%d",a[i]);
        }
		printf("\n");
    }
}