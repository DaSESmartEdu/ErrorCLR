#include <stdio.h>
#include <math.h>
int main()
{
    int n,sum;
    int i3,i4,i5,i6,i7;
    scanf("%d",&n);
    if(n==3){
        for(i3=100;i3<1000;i3++)
        {
            if(pow(i3/100,3)+pow((i3/10%10),3)+pow(i3%10,3)==i3)
            {sum++;}
        }
    }
    else if(n==4){
        for(i4=1000;i4<10000;i4++)
        {
            if(pow(i4/1000,4)+pow((i4/100%10),4)+pow((i4/10%10),4)+pow(i4%10,4)==i4)
            {sum++;}
        }
    }
    else if(n==5)
    {
        for(i5=10000;i5<100000;i5++)
        {
            int c1=i5/10000;
            int c2=i5/1000%10;
            int c3=i5/100%10;
            int c4=i5/10%10;
            int c5=i5%10;
            if(pow(c1,5)+pow(c2,5)+pow(c3,5)+pow(c4,5)+pow(c5,5)==i5)
            {sum++;}
        }
        }
    else if(n==6)
    {
        for(i6=100000;i6<1000000;i6++)
        {
            int d1=i6/100000;
            int d2=i6/10000%10;
            int d3=i6/1000%10;
            int d4=i6/100%10;
            int d5=i6/10%10;
            int d6=i6%10;
            if(pow(d1,6)+pow(d2,6)+pow(d3,6)+pow(d4,6)+pow(d5,6)+pow(d6,6)==i6)
            {sum++;}
            }
    }
    else{  
        for(i7=1000000;i7<10000000;i7++)
        {
            int e1=i7/1000000;
            int e2=i7/100000%10;
            int e3=i7/10000%10;
            int e4=i7/1000%10;
            int e5=i7/100%10;
            int e6=i7/10%10;
            int e7=i7%10;
            if(pow(e1,7)+pow(e2,7)+pow(e3,7)+pow(e4,7)+pow(e5,7)+pow(e6,7)+pow(e7,7)==i7)
            {sum++;}
        }
    }
    printf("%d",sum);
    return 0;}