#include <stdio.h>
int main()
{
    int n,i=0,j=0,t=0,count=0;
    scanf("%d",&n);
    for(i=1;i<=91;i++)
    {
        for(j=1;j<=91;j++)
        {
            for(t=1;t<=91;t++)
            {
                if(i*5+j+t*2==n)
                {
                    count++;
                }
            }
        }
    }
    printf("%d",count);
    return 0;
}