#include <stdio.h> 
#include <string.h>
void splitfloat(float x,int*a,float*b)
{
	*a=(int) x;
	*b=x-*a;
}
int main()
{
	float x;
	int a;float b;
	scanf("%f",&x);
	splitfloat(x,&a,&b);
	printf("%d %.3f",a,b);
}