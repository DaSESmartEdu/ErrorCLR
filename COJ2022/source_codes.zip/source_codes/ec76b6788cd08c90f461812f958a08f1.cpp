#include<iostream>
using namespace std;
int n;
int k;
struct shu
{
    int p;
    int x; int y;
};
void quicksort(unsigned int n,shu arr[]){
	if(n<2) return;
	int ileft=0;
	int iright=n-1;
	shu itmp;
    itmp=arr[ileft];
	int imove=2;
	while(ileft<iright){
	if(imove==2){
		if(arr[iright].p>=itmp.p){
			iright--;continue;
		}
		arr[ileft].p=arr[iright].p;
        arr[ileft].x=arr[iright].x;
        arr[ileft].y=arr[iright].y;
		ileft++; imove=1;continue;
	}
	if(imove==1){
		if(arr[ileft].p<=itmp.p){
			ileft++; continue;
		}
		arr[iright].p=arr[ileft].p;
        arr[iright].x=arr[ileft].x;
        arr[iright].y=arr[ileft].y;
		iright--;imove=2;continue;
	}
	}
	arr[ileft].p=itmp.p;
    arr[ileft].x=itmp.x;
    arr[ileft].y=itmp.y;
	quicksort(ileft,arr);
	quicksort(n-ileft-1,arr+ileft+1);
}
int main(){
    scanf("%d",&n);
    int i=0;
    shu points[n];
    for(;i<n;i++){
        scanf("%d %d",points[i].x,points[i].y);
        points[i].p=points[i].x*points[i].x+points[i].y*points[i].y;
    }
    scanf("%d",&k);
    quicksort(n,points);
    printf("%d %d",points[k].x,points[k].y);
    return 0;
}