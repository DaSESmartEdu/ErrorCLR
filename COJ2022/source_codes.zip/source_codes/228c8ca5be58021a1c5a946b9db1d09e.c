#include<stdio.h>
int main()
{
int a;
scanf("%d",&a);
if(a<=50)
{
    float b=0.53*a;
      printf("%.6f",b);
}
if (a>50)
{
    float b=26.5+(a-50)*0.05;
       printf("%.6f",b);
}
return 0;
}