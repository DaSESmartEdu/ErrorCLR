#include <iostream>
#include <vector>
using namespace std;
int main(){
    ios::sync_with_stdio(false); 
    cin.tie(nullptr);	
    int N,M;
    cin>>N>>M;
   vector<vector<int>> arr1(M,vector<int>(M));
   vector<vector<int>> arr2(M,vector<int>(M));
   vector<vector<int>> arr3(M,vector<int>(M));
   int i,j,k;
   while(N--){
       for(i=0;i<M;i++){
           for(j=0;j<M;j++){
               cin>>arr1[i][j];
           }
       }
       for(i=0;i<M;i++){
           for(j=0;j<M;j++){
               cin>>arr2[i][j];
           }
       }
       for(i=0;i<M;i++){
           for(j=0;j<M;j++){
               arr3[i][j]=0;
               for(k=0;k<M;k++){
                   arr3[i][j]+=arr1[i][k]*arr2[k][j];
               }
           }
       }
       for(i=0;i<M;i++){
           for(j=0;j<M;j++){
               cout<<arr3[i][j];
               if(j<M-1) cout<<" ";
               else cout<<endl;
           }
       }
   }
}