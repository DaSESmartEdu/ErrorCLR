#include<stdio.h>
#include<string.h>
#include<stdlib.h>
char t[1000000];
void strmcpy(char*t,int m,char*s);
int main()
{
	int m;
	char *s;
	s=(char*)malloc(100001);
	scanf("%d",&m);
	int tot=0;
	char c;
	while(c=getchar(),c!=EOF)
	{
		t[tot++]=c;
	 } 
	strmcpy(t,m,s);
	free(s);
	return 0;
}
void strmcpy(char*t,int m,char*s)
{	
	int idxt=m;
	int idxs=0;
	while(t[idxt]!='\0')
	{
		s[idxs]=t[idxt];
		idxt++;
		idxs++;
	}
	s[idxs]=0;
	printf("%s",s);
}