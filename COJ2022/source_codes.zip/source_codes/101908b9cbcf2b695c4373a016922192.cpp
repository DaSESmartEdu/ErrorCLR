#include<bits/stdc++.h>
using namespace std;
typedef unsigned long long ll;
typedef long double ld;
const int N=5e5+7;
int n,p;
int a[N];
int main()
{
    for(int i=1;i<=200000000;i++) a[i%N]=a[(i-1)%N]*2+5;
    int a,b;
    cin>>a>>b;
    cout<<a+b<<endl;
}