#include<bits/stdc++.h>
#pragma comment(linker,"/STACK:1024000000,1024000000")
#define abs(a) ((a)>0?(a):(-(a)))
#define lowbit(a) (a&(-a))
#define sqr(a) ((a)*(a))
#define mem(a,b) memset(a,b,sizeof(a))
const double eps=1e-8;
const int J=10000;
const int MOD=100000007;
const int MAX=0x7f7f7f7f;
const double PI=3.14159265358979323;
const int N=1004;
using namespace std;
typedef long long LL;
double anss;
LL aans;
int cas,cass;
int n,m,lll,ans;
LL s,a,b;
LL f[N*N];
int main()
{
    #ifndef ONLINE_JUDGE
    #endif
    int i,j,k,l;
    int x,y,z;
    while(~scanf("%d",&n))
    {
        mem(f,0);
        cin>>s>>a>>b;
        f[0]=1;aans=0;
        for(i=1;i<n;i++)
            for(j=i*(i+1)/2;j>=i;j--)
                f[j]=(f[j]+f[j-i])%MOD;
        for(i=0;i<=n*(n-1)/2;i++)
        {
            LL t=s-i*a+((n-1)*n/2-i)*b;
            if(t%n==0)aans=(aans+f[i])%MOD;
        }
        cout<<aans<<endl;
    }
    return 0;
}