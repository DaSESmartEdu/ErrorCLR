#include<stdio.h>
int search(int *list,int n,int x);
int main()
{
    int n,x;
    scanf("%d",&n);
    int a[n];
    for (int i=0;i<n;i++){
        scanf("%d",a+i);
    }
    scanf("%d",&x);
    int k = search(a,n,x);
    printf("%d",k);
}
int search(int *list,int n,int x)
{
    for(int i=0;i<n;i++){
        if (*(list+i) == x){return i;break;}
    }
    return -1;
}