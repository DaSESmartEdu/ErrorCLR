#include<stdio.h>
int main()
{
    int a,n,p=0,q;
    scanf("%d %d",&a,&n);
    int x=1;
    q=a;
    for(x=1;x<n;x++){
      a=(10*a+q);
      p+=a;
    }
  p=p+q;
    printf("%d",p);
}