#include<stdio.h>
int main()
{
    int n,i;
    double grade;
    scanf("%d\n",&n);
    for(i=0;i<n;i++)
   { 
       scanf("%lf",&grade);
        if(grade>=90)
        {
           printf("A");
        }
     else if(80<=grade&&grade<90)
    {
       printf("B") ;
    }
    else if(70<=grade&&grade<80)
    {
        printf("C");
    }
    else if(60<=grade&&grade<70)
    {
        printf("D");
    }
     else if(grade<60)
    {
        printf("E");
    }
    }
    return 0;
}