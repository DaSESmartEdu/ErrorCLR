#include <stdio.h>
#include <math.h>
int main(){
    int n;
    scanf("%d",&n);
    int i;
    double sum;
    for(i=0;i<=n;i++)
    {
        sum+=sqrt(i);
    }
    printf("%.2lf\n",sum);
    return 0;
}