#include <stdio.h>
void splitfloat( float x, int *intpart, float *fracpart);
int main()
{
    float b,x;
    int a;
    scanf("%f",&x);
    splitfloat( x, &a, &b);
    printf("%d %.3f",a,b);
    return 0;
}
void splitfloat( float x,int *intpart, float *fracpart)
{
    *intpart=(int)x;
    *fracpart=x-(int)x;
}