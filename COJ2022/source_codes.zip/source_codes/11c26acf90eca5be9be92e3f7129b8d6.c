#include <stdio.h>
int main()
{
    char s[100];
    int i=0,count=0;
    getchar();
    while((s[i]=getchar())!=EOF)
    {
        if(s[i]>'A'&&s[i]<='Z')
        {
            if(s[i]!='E'&&s[i]!='I'&&s[i]!='O'&&s[i]!='U')
            {
                count++;
            }
        }
        i++;
    }
    printf("%d",count);
    return 0;
}