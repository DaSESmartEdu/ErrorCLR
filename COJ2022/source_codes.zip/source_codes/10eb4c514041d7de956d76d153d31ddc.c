void dectobin(int n)
{
	if(n==0) printf("%d",0);
	else if(n==1) printf("%d",1);
	else
	{	
		dectobin(n/2);
		printf("%d",n%2);
	}
}
int main()
{
	int n;
	scanf("%d",&n);
	dectobin(n);		
}