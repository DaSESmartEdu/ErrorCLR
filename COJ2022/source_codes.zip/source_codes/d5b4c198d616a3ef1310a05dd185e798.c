#include <stdio.h>
int main()
{
    int x;
    double y;
    scanf("%d",&x);
    if(x<=50)
    {
        y=(float)(x)*53/100;
    }
    else
    {
        y=50*53/100+ ((float)(x)-50) *58/100;
    }
    printf("%.6lf",y);
    return 0;
}