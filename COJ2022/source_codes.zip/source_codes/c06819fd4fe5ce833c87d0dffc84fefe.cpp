#include<iostream>
using namespace std;
typedef pair<int,int> Node;
Node a[10000];
bool compare(Node A,Node B)
{
    if(A.first>B.first) return true;
    else if(A.first==B.first && A.second>B.second) return true;
    return false;
}
void heapSort(Node a[],int n);
void maxHeap(Node a[],int n);
void buildMaxHeap(Node a[],int n);
int size;
int main()
{
	cin >> size;
	int q=size;
	for(int i=0;i<size;i++)
	{
		int x,y;
		cin >> x >> y;
		a[i].first=x;
		a[i].second=y;
	}
	heapSort(a,size);
	for(int i=0;i<q;i++)
	{
		cout << "(" << a[i].first << "," << a[i].second <<")" << " ";
		if(i!=q-1)
		{
			cout << endl;
		}
	}
	return 0;
}
void heapSort(Node a[],int n)
{
	int i;
	buildMaxHeap(a,n);
	for(int i=size;i>1;i--)
	{
		swap(a[0],a[i-1]);
		size=size-1;
		maxHeap(a,1);
	}
}
void buildMaxHeap(Node a[],int n)
{
	int i=n/2;
	for(i;i>0;i--)
	{
		maxHeap(a,i);
	}
}
void maxHeap(Node a[],int n)
{
	int leftchild,rightchild,largest;
	leftchild=2*n;
	rightchild=2*n+1;
	if(leftchild<=size && a[leftchild-1]>a[n-1])
	{
		largest=leftchild;
	}
	else
	{
		largest=n;
	}
	if(rightchild<=size && compare(a[rightchild-1],a[largest-1]))
	{
		largest=rightchild;
	}
	if(largest!=n)
	{
		swap(a[n-1],a[largest-1]);
		maxHeap(a,largest);
	}
}