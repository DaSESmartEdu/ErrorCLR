#include <stdio.h>
#include <algorithm>
using namespace std;
typedef struct{
    int sno;
    int height;
}stu;
bool cmp(stu s1,stu s2){
   if(s1.height!=s2.height) return s1.height>s2.height;
   else return s1.sno>s2.sno;
}
int main()
{
    int n;
    stu student[1010];
    while(scanf("%d",&n)!=EOF){
        for(int i=0;i<n;i++){
            student[i].sno=i+1;
            scanf("%d",&student[i].height);
        }
        sort(student,student+n,cmp);
        for(int j=0;j<n;j++){
            printf("%d",student[j].sno);
            if(j!=n) printf(" ");
        }
    }
    return 0;
}