#include <math.h>
int main()
{
    int n;
    int i=1;
    double sum;
    scanf("%d",&n);
    while(i<=n){
        sum += sqrt(i);
        i++;
    }
    printf("%.2f",sum);
    return 0;
}