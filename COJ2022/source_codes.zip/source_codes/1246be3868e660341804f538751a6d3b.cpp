#include<iostream>
#include <malloc.h>
using namespace std;
int res=-1;
typedef struct zhan{
    int front;
    int back;
    int sum;
    int box[10];
}zhan;
void search(int *a,int n,int k,int i,zhan b){
    if(b.sum>k||i>=n)return;
    if(b.sum==k){
        if(i>res){
            res=i-1;
        }
        return;
    }
    b.sum+=a[i];
    b.box[b.back]=a[i];
    b.back++;
    search(a,n,k,i+1,b);
    b.back--;
    b.sum-=a[i];
    search(a,n,k,i+1,b);
}
int main()
{
    int n=0,k=0;
    cin>>n;
    zhan b;
    b.front=0;
    b.back=0;
    b.sum=0;
    int *a=(int*)malloc(sizeof(int)*n);
    for(int i=-0;i<n;i++){
        cin>>a[i];
    }
    cin>>k;
    search(a,n+1,k,0,b);
    cout<<res;
    return 0;
}