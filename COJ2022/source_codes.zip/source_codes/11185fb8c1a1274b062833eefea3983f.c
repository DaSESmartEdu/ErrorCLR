#include<stdio.h>
#include<math.h>
int main(){
    int i;
    double s=0,sum=0,area=0,line1=0,line2=0,line3=0;
    double point[6];
    for(i = 0;i<6;i++){
        scanf("%lf",&point[i]);
    }
    line1 = sqrt(pow(point[0]-point[2],2)+pow(point[1]-point[3],2));
    line2 = sqrt(pow(point[2]-point[4],2)+pow(point[3]-point[5],2));    
    line3 = sqrt(pow(point[0]-point[4],2)+pow(point[1]-point[5],2));
    if ( line1+line2>line3 & line2 + line3 > line1 & line1 + line3 > line2){
        sum = line1 + line2 + line3;
        s = sum/2.00;
        area = sqrt(s*(s-line1)*(s-line2)*(s-line3));
        printf("%.2f %.2f",sum,area);
    }
    else
    {
        printf("Impossible");
    }
}