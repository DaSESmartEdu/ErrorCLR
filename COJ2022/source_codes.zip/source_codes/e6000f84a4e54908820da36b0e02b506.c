#include<stdio.h>
#include<math.h>
double distant(int a1,int b1,int a2,int b2);
int main()
{
    int x1,x2,x3,y1,y2,y3;
    double c,s,Area,l1,l2,l3;
    scanf("%d%d%d%d%d%d",&x1,&y1,&x2,&y2,&x3,&y3);
    if((x1-x3)*(y1-y2)==(x1-x2)*(y1-y3))
    {
        printf("impossible");
    }
    else
    {
        l1=distant(x1,y1,x2,y2);
        l2=distant(x1,y1,x3,y3);
        l3=distant(x2,y2,x3,y3);
        c=l1+l2+l3;
        s=c/2;
        Area=sqrt(s*(s-l1)*(s-l2)*(s-l3));
        printf("%.2f %.2f",c,Area);
        return 0;
    }
}
double distant(int a1,int b1,int a2,int b2)
{
    double w=pow(a1-a2,2)+pow(b1-b2,2);
    double l=pow(w,0.5);
    return l;
}