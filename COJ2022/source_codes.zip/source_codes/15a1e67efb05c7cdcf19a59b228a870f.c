#include <stdio.h>
#include <stdlib.h>
int main()
{
    int n,N,i,j,x,d;
    scanf("%d",&n);
    N=0.5*(n+1);
    x=N-1;
    for ( i = 1; i <=n; i++)
    {
        for ( j = 1; j <=n; j++)
        {
            d=abs(N-i)+abs(N-j);
            if (d<=x)
            {
                printf("*");
            }
            else if (d>x)
            {
                printf(" ");
            }
        }
       printf("\n"); 
    }
    return 0;
}