#include <stdio.h>
#include <stdlib.h>
int main() {
    char str1[256];
    char str2[256];
    char *p1, *p2;
    int len1=0, len2=0;
    char c;
    p1 = str1;
    while ( (c = getchar()) != '\n' ) {
        *p1++ = c;
        len1++;
    }
    *p1 = '\0';
    int len;
    p2 = str2;
    while ( (c = getchar()) != '\n' ) {
        *p2++ = c;
        len2++;
    }
    *p2 = '\0';
    p1 = str1; 
    p2 = str2;
    int cnt = 0;
    while (cnt < len1) {
        cnt++;
        if ( *p1 == '\0' ) {
            p1 = str1;
        }
        if (*p2 == *p1) {
            p2++;
        } else if (*p2 == '\0') {
            printf("1");
            return 0;
        } else {
            p2 = str2;
        }
        p1++;
    }
    printf("0");
    return 0;
}