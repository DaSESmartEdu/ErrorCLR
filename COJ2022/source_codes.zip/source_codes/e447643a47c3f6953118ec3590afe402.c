#include <stdio.h>
double fact (int n);
int main()
{
    int n,i;
    double sum;
    scanf("%d",&n);
    for(i=1;i<=n;i++)
    {
        sum+=fact (i);
        }
    printf("%.0lf",sum);
    return 0;
}
double fact (int n)
{
    int i;
    double i1;
    i1=1;
    for(i=1;i<=n;i++)
    {
        i1*=i;
    }
    return i1;
}