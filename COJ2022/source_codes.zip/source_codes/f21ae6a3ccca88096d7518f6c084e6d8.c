#include<stdio.h>
int CountDigit(int number,int digit)
{
    int b,count;
    count=0;
    int a=number;
    while(a!=0)
    {
        b=a%10;
        a=a/10;
        if((b==digit)||(b=-digit))
        {
            count=count+1;
        }
    }
   return count;
}
int main()
{
    int number,digit;
    scanf("%d %d",&number,&digit);
    printf("%d",CountDigit(number,digit));
    return 0;
}