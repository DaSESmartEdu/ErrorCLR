#include<iostream>
#include<vector>
#include<queue>
using namespace std;
bool isBipartion(vector<vector<int>>& graph)
{
    int n=graph.size();
    if(n==0)
        return true;
    vector<int> vec(n,0);
    queue<int> q;
    for(int i=0;i<n;i++)
    {
        if(!vec[i])
        {
            q.push(i);
            vec[i]=1;
        }
        while(!q.empty())
        {
            int k=q.front();
            q.pop();
            for(int j : graph[k])
            {
                if(vec[j]!=0)
                {
                    if(vec[k]==1)
                    {
                        vec[j]=2;
                    }
                    else if (vec[k]!=1)
                    {
                        vec[j]=1;
                    }
                    q.push(j);
                }
                 if(vec[j]==vec[i])
                {
                    return false;
                }
            }
        }
    }
    return true;
}
int main()
{
    int n;
    cin >> n;
    vector<vector<int>> graph;
    for(int i=0;i<n;i++)
    {
        int k;
        cin >> k;
        vector<int> g;
        for(int j=0;j<k;j++)
        {
            int temp;
            cin >> temp;
            g.push_back(temp);
        }
        graph.push_back(g);
    }
    bool ans=isBipartion(graph);
    if(ans==true)
    {
        cout << "true";
    }
    else
    {
        cout << "false";
    }
    return 0;
}