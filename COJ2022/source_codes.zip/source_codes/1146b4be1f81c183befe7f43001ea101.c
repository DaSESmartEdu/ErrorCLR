#include<stdio.h>
#include<string.h>
void strmcpy(char *t,int m,char *s);
int main ()
{
    int m;
    scanf("%d\n",&m);
    char s[100]={0};
    char str[100]={0};
    int i=0;
    while((str[i]=getchar())!=EOF)
       i++;
    str[i]='\0';
    strmcpy(str,m,s);
    return 0;
}
void strmcpy(char *t,int m,char *s)
{
    int i;
    if(strlen(t)<m) 
    {
        puts(s);
    }
    else
    {
        for(i=m-1;t[i]!='\0';i++)
        {
            s[i-m+1]=t[i];
        }
      for(int j=0;s[j]!='\0';j++)
        {
            printf("%c",s[j]);
        }
    }
}