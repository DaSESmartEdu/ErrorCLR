#include <stdio.h>
#include <math.h>
int main ()
{
    int n,i;
    scanf("%d",&n);
    double x;
    x=1;
    for (i=2;i<=n;i++)
    {
        x=x+ pow ((-1),i-1) * i/(2i-1); 
    }
    printf("%lf\n",x);
    return 0;
}