#include <stdio.h>
int main()
{
    int i;
    int j;
    int m;
    int n;
    scanf("%d %d %d %d",&i,&j,&m,&n);
    int g=i+j+m+n;
	float e=g/4;
    printf("%d %.1f",g,e);
    return 0;
}