#include <stdio.h>
int main (){
    int a, n, i=1, x;
    scanf("%d %d", &a, &n);
    while (i <= n){
        scanf("%d", &x);
        if (x<=0){
            printf("Game Over");
            break;
        }
        if(x>a){
            printf("Too big\n");
        } else if(x<a){
            printf("Too small\n");
        }else {
            if(i==1){
                printf("Bingo\n");
                break;
            } else if(i<=3){
                printf("Lucky You!\n");
                break;
            } else if (i>3){
                printf("Good Guess!\n");
                break;
            } 
        }
        i++;
        if(i>n){
            printf("Game Over");
        }
    } 
    if(i>n+1){
        printf("Game Over");
    }
    return 0;
}