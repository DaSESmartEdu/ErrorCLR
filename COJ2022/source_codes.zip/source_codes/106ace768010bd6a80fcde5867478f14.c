#include <stdio.h>
void splitfloat(float x, int *intpart, float *fracpart)
{
    *intpart = (int)x;
    *fracpart = (double)(x - (int)x);
}
int main()
{
    float x = 0;
    scanf("%f", &x);
    int intpart_x = 0;
    float fracpart_x = 0.0;
    int *intpart = &intpart_x;
    float *fracpart = &fracpart_x;
    splitfloat(x, intpart, fracpart);
    printf("%d %.3f\n", intpart_x, fracpart_x);
    return 0;
}