#include<iostream>
#include<algorithm>
using namespace std;
const int maxn=5000+5;
int a[maxn];
int n;
int tmp[maxn];
bool order(int x,int y){
    if(x==y) return true;
    for(int i=x;i<=y;i++)
        tmp[i]=a[i];
    sort(tmp+x,tmp+y+1);
    for(int i=x;i<=y-1;i++)
        if(tmp[i]!=tmp[i+1]-1)
            return false;
    return true;
}
int solve(){
    int cnt=0;
    for(int i=0;i<n;i++){
        int mmin=n;
        int mmax=1;
        for(int j=i;j<n;j++){
            if(a[j]<mmin) mmin=a[j];
            if(a[j]>mmax) mmax=a[j];
            if(mmax-mmin==j-i) cnt++;
        }
    }
    return cnt;
}
int main()
{
    cin>>n;
    for(int i=0;i<n;i++)
        cin>>a[i];
    cout<<solve()<<endl;
    return 0;
}