#include<stdio.h>
int main(){
	char a[100]={0};
	int i=0, cnt=0;
    gets(a);
	for (i=0; i<100; i++){
        if (a[i]>=65 && a[i]<=90 && a[i]!=65 && a[i]!=69 && a[i]!=73 && a[i]!=79 && a[i]!=85)
			cnt++;
        i++;
        if(a[i]==0) break;
    }
	printf("%d", cnt);
	return 0;
}