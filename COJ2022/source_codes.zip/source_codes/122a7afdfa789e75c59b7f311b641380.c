#include <stdio.h>
void CountOff(int n,int m,int out[]){
    int number=1;
    int d=0;
    int a[100]={0};
    int i=1;
    for(i=1;i<=n;i++){
        a[i]=i;
    }
    int y=1;
    int j=0;
    int x=n;
    int b=1;
    if(m==1){
        for(i=0;i<n;i++){
            out[i]=i+1;
        }
    }
    else{
    while(n>0){
        number++;
        y++;
        if(n==1){
            out[a[1]-1]=x;
            break;
        }
        else{
        if(number%m==0){
            number=1;
            out[a[y]-1]=b;
            b++;
            for(int z=y;z<=n;z++){
                a[z]=a[z+1];
            }
            n--;
        }
        if(y==n){
            y=0;
        }
        if(y>n){
            y=n-y+2;
        }
    }
    }
    }
}
int main(){
    int n,m;
    scanf("%d %d",&n,&m);
    int out[100]={0};
    CountOff(n,m,out);
    int i=0;
    for(i=0;i<n;i++){
        printf("%d",out[i]);
        if(i==n-1){
            break;
        }
        printf(" ");
    }
}