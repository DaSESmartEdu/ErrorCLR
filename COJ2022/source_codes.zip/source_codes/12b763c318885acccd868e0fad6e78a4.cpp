#include<iostream>
using namespace std;
enum Error_code{underflow,overflow,range_error_new,success,fail,not_present};
const int max_list=30;
template <class List_entry>
class List{
	public:
		List();
		int size();
		bool full();
		bool empty();
		void clear();
	    void traverse(void(*visit)(List_entry &));
	    Error_code retrieve(int position,List_entry &x);
	    Error_code replace(int position,List_entry &x);
	    Error_code remove(int position,List_entry &x);
	    Error_code insert(int position,List_entry &x);
	protected:
	    int count;
		List_entry entry[max_list];
};
template <class List_entry>
List<List_entry>::List(){
	count=0;
}
template <class List_entry>
int List<List_entry>::size()
{
	return count;
 } 
template <class List_entry>
bool List<List_entry>::empty()
{
	return count==0;
}
template <class List_entry>
void List<List_entry>::clear(){
	count=0;
}
template <class List_entry>
bool List<List_entry>::full(){
	return count==max_list-1;
}
template <class List_entry>
Error_code List<List_entry>::remove(int position,List_entry &x)
{
	if (empty())
	return underflow;
	if (position<0||position>=count)
	return range_error_new;
	x=entry[position];
	for (int i=position;i<count-1;i++)
	{
		entry[i]=entry[i+1];
	}
	count--;
	return success;
}
template <class List_entry>
Error_code List<List_entry>::replace(int position,List_entry &x)
{
	if (position<0||position>=count)
	return range_error_new;
	entry[position]=x;
	return success;
}
template <class List_entry>
Error_code List<List_entry>::insert(int position,List_entry &x)
{
	if (full())
	return overflow;
	if (position<0||position>count)
	return range_error_new;
	for (int i=count-1;i>=position;i--)
	entry[i+1]=entry[i];
	entry[position]=x;
	count++;
	return success;
}
template <class List_entry>
Error_code List<List_entry>::retrieve(int position,List_entry &x)
{
	if (position<0||position>count)
	return range_error_new;
	x=entry[position];
	return success;
 }
 template <class List_entry>
 void List<List_entry>::traverse(void (*visit)(List_entry &))
 {
 	for (int i=0;i<count;i++)
 	{
 		(*visit)(entry[i]);
	 }
  } 
  class Record{
	public:
		Record(int x=0,int y=0);
		int thekey();
	private:
		int key;
		int other;
};
bool operator >(Record &x,Record &y);
bool operator <(Record &x,Record &y);
bool operator ==(Record &x,Record &y);
ostream &operator <<(ostream &output,Record &x);
Record::Record(int x,int y)
{
	key=x;
	other=y;
}
int Record::thekey(){
	return key;
}
bool operator > (Record &x,Record &y)
{
	return x.thekey()>y.thekey();
	}	
bool operator < (Record &x,Record &y)	
{
	return x.thekey()<y.thekey();
}
bool operator == (Record &x,Record &y)
{
	return x.thekey()==y.thekey();
}
ostream &operator << (ostream &output,Record &x)
{
	output<<x.thekey();
	output<<" ";
	return output;
}
class orderlist:public List<Record>{
	public:
		Error_code insert(Record &data);
		Error_code insert(int position,Record &data);
		Error_code repalce(int position,Record &data);
};
Error_code orderlist::insert(Record &data)
{
	int s=size();
	int position;
	for (position=0;position<s;position++)
	{
		Record list_data;
		retrieve(position,list_data);
		if (data<list_data)
		{ 
		break;
	}} 
	return List<Record>::insert(position,data);
}
Error_code orderlist::insert(int position,Record &data)
{
	if (position<0||position>count)
	{
		return range_error_new;
	}
	Record list_data;
	if (position>0)
	{
		retrieve(position-1,list_data);
		if (data<list_data)
		return fail;
	}
	if (position<size())
	{
		retrieve(position,list_data);
		if (data>list_data)
		{
			return fail;
		}
		return List<Record>::insert(position,data);
	}
}
Error_code orderlist::repalce(int position,Record &data)
{
	if (position<0||position>count)
	return range_error_new;
	Record list_data;
	if (position>0)
	{
		retrieve(position-1,list_data);
		if (data<list_data)
		{
			return fail;
		}}
		if (position<size()-1)
		{
			retrieve(position+1,list_data);
			if (data>list_data);
			return fail;
		}
		entry[position]=data;
		return success;	
}
template <class List_entry>
void print(List_entry &x)
{
	cout<<x;
}
Error_code binary_search(orderlist &thelist,int &target,int &position)
{
	Record data;
	int bottom=0;
	int top=thelist.size()-1;
	int middle=-1;
	while (bottom<=top)
	{
		middle=(bottom+top/2);
		thelist.retrieve(middle,data);
		if (data.thekey()==target)
		{
			position=middle;
			return success;
		}
		else if (data.thekey()<target)
		{
			bottom=middle+1;
		}
		else
		top=middle-1;
	}
	return not_present;
 } 
int main()
{
	orderlist mylist;
	int key;
	cin>>key;
	while (key!=-1)
	{
		Record m=Record(key,10); 
		mylist.insert(m);
		cin>>key;
	}
	int data;
	cin>>data;
	mylist.traverse(print);
	int position=-1;
	binary_search(mylist,data,position);
	if (position!=-1)
	cout<<endl<<position;
	else
	cout<<endl<<"Target not present!";
	return 0;
}