import math
def prime(v: int) -> None:
    print(v, "=", end="", sep="")
    ls = []
    while v % 2 == 0:
        ls.append(2)
        v 
    for i in range(3, int(math.sqrt(v)) + 1, 1):
        while v % i == 0:
            ls.append(i)
            v 
    if v > 2:
        ls.append(v)
    ls = sorted(ls)
    print("*".join([str(j) for j in ls]))
def limit(x: int) -> bool:
    if 2 <= x <= 10000:
        return True
    else:
        return False
if __name__ == "__main__":
    a, b = map(int, input().split())
    # print(a,b)
    if limit(a) and limit(b) and a <= b:
        pass
    else:
        import sys
        sys.exit(0)
    for i in range(a, b + 1):
        prime(i)