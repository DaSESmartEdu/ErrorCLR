#include <bits/stdc++.h>
using namespace std;
int main()
{
    int n;cin>>n;int a[n];for (int i = 0;i<n;i++) cin>>a[i];
    int goal;cin>>goal;int flag = 0;int j = 0;int temp[1000]={0};
    for (int z = 0;z<n;z++){
        int sum = 0;
        for (int i = z;i<n;i++){
            sum+=a[i];
            if (sum>goal){
                sum-=a[i];
            }
            if (sum == goal){
                flag = 1;
                temp[j]=i;j++;
                sum-=a[i];
                cout<<i<<endl;
            }
        }
    }
    if (flag == 0) cout<<-1;
    else {
        cout<<temp[j-1]<<endl;
    }
    return 0;
}