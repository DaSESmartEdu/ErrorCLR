#include<stdio.h>
#include<math.h>
int main()
{
    int a=0,b=0,c=0,d=0,e=0,f=0;
    double l1=0,l2=0,l3=0,s=0.00,Area=0.00,ch=0.00;
    scanf("%d %d %d %d %d %d",&a,&b,&c,&d,&e,&f);
    l1=sqrt((a-c)*(a-c)+(b-d)*(b-d));
    l2=sqrt((c-e)*(c-e)+(d-f)*(d-f));
    l3=sqrt((a-e)*(a-e)+(b-f)*(b-f));
    s=(l1+l2+l3)/2;
    ch=2*s;
    Area=sqrt(s*(s-l1)*(s-l2)*(s-l3));
    if((l1+l2)<=l3,(l2+l3)<=l1,(l1+l3)<=l2)
       printf("Impossible");
    else 
       printf("%.2f %.2f",ch,Area);
return 0;
}