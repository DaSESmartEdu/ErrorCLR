#include <stdio.h>
int main()
{
    int v1,v2,s,t,l;
    scanf("%d %d %d %d %d",&v1,&v2,&t,&s,&l);
    int time=0,sr=0,st=0;
    do
    {
        rest:
        if(sr-st>=t)
        {
        time+=s;
        st+=s*v2;
        }
        if(sr-st>=t)
        {
            goto rest;
        }
        if(sr>=l||st>=l)
        {
            goto out;
        }
        sr+=v1;
        st+=v2;
        time++;
    } while (sr<l&&st<l);
    out:
    if(st<l&&sr>=l)
    {
        printf("R\n");
        printf("%d",time);
    }
    if(sr<l&&st>=l)
    {
        printf("T\n");
        printf("%d",time);
    }
    if(sr==l&&st==l)
    {
        printf("D\n");
        printf("%d",time);
    }
    return 0;
}