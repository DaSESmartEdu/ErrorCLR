#include<stdio.h>
int main(){
    int count=0;
    char a[80];
    for(int i=0;i<80;i++){
        scanf("%c",&a[i]);
        if(a[i]=='\0')
        break;
    }
    for(int i=0;i<80;i++){
        if(a[i]>'A'&&a[i]<='Z'){
            if(a[i]!='E'&&a[i]!='I'&&a[i]!='O'&&a[i]!='U'){
                count++;
            }
        }
        if(a[i]=='\0')
        break;
    }
    printf("%d\n",count);
    return 0;
}