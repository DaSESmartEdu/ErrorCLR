#include <stdio.h>
#include <string.h>
#define MAXN 1000
char *match(char *s,char ch1,char ch2);
int main(){
	char s[MAXN],ch1,ch2,*p;
    gets(s);
	scanf("%c",&ch1);
	getchar();
	scanf("%c",&ch2);
	if((p=match(s,ch1,ch2))!=NULL){
		printf("%s",p);
	}
	return 0;
}
char *match(char *s,char ch1,char ch2){
	int j=0;
	for(int i=0;i<strlen(s);i++){
		if(*(s+i)==ch1){
			for(j=i;j<strlen(s);j++){
				if(*(s+j)==ch2){
				printf("%c",*(s+j));
				break;}
				printf("%c",*(s+j));
			}
			printf("\n");
			break;
		}
	}
  j=0;
	while(*s!='\0'){
		if(*s==ch1){
			return(s);
		}
		else{
			s++;
		}
	}
	return(NULL);
}