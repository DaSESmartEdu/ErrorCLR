#include <stdio.h>
int main()
{
    double a,b,d,e;
    scanf("%lf %lf %lf %lf", &a, &b, &d, &e);
    int h;
    double c;
    h=a+b+d+e;
    c=(a+b+d+e)/4;
    printf("%d %0.1f\n", h, c);
    return 0;
}