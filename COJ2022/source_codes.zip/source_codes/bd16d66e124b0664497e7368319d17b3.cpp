#include <iostream>
#include <string>
using namespace std;
struct Node{
    char key;
    Node* leftNode;
    Node* rightNode;
};
Node* buildTree(Node*& node,string tree,int& index){
    if(index>=0){
        if(tree[index]=='#'){
            node=nullptr;
        } else{
            node=new Node;
            node->key=tree[index];
            buildTree(node->rightNode,tree,--index);
            buildTree(node->leftNode,tree,--index);
        }
    }
    return node;
}
void midOrderTreeWork(Node* node){
    if(node){
        midOrderTreeWork(node->leftNode);
        cout<<node->key<<" ";
        midOrderTreeWork(node->rightNode);
    }
}
Node* treeSearch(Node* node,char x){
    if(node){
        cout<<node->key<<" ";
    } else{
        return nullptr;
    }
    if(node->key==x){
        return node;
    }
    if(node->key<x){
        return treeSearch(node->rightNode,x);
    } else{
        return treeSearch(node->leftNode,x);
    }
}
Node* findMin(Node* node){
    if(node==nullptr){
        return nullptr;
    } else if(node->leftNode==nullptr){
        return node;
    } else{
        return findMin(node->leftNode);
    }
}
Node* treeDelete(Node* root,char y){
    Node* tmp;
    if(root){
        if(y<root->key){
            root->leftNode=treeDelete(root->leftNode,y);
        } else if(y>root->key){
            root->rightNode=treeDelete(root->rightNode,y);
        } else{
            if(root->leftNode && root->rightNode){
                tmp=findMin(root->rightNode);
                root->key=tmp->key;
                root->rightNode=treeDelete(root->rightNode,root->key);
            } else{
                tmp=root;
                if(root->leftNode==nullptr){
                    root=root->rightNode;
                } else{
                    root=root->leftNode;
                }
                delete tmp;
            }
        }
    }
    return root;
}
int main(){
    Node* root=nullptr;
    string tree;
    cin>>tree;
    char x,y;
    cin>>x>>y;
    int index=tree.length()-1;
    root=buildTree(root,tree,index);
    treeSearch(root,x);
    cout<<endl;
    root=treeDelete(root,y);
    midOrderTreeWork(root);
    cout<<endl;
}