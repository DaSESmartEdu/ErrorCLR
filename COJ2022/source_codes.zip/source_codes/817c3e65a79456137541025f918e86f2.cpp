#include <bits/stdc++.h>
using namespace std;
int dfs(vector<int> &A, int i, int K) {
    if (i == A.size()) return (K == 0) ? i - 1 : -1;
    if (K == A[i]) return max(i, dfs(A, i + 1, K));
    return max(dfs(A, i + 1, K - A[i]), dfs(A, i + 1, K));
}
int main() {
    int n;
    cin >> n;
    vector<int> A(n);
    for (auto &a : A) cin >> a;
    int K;
    cin >> K;
    int i = dfs(A, 0, K);
    cout << (i == -1 ? i : A[i]) << endl;
}