#include <stdio.h>
char *match(char *s,char ch1,char ch2);
int main()
{
	char s[20],op1,op2,*p;
	scanf("%s",s);
  	getchar();
	scanf("%c%c",&op1,&op2);
	p=match(s,op1,op2);
  	printf("%s\n",p);
  	return 0;
}
char *match( char *s, char ch1, char ch2 )
{
	int i=0,j,p=0;
	int len;
	while(*(s+i)!='\0')
	{
		if(*(s+i)==ch1)
		{
			j=i;
            printf("%c",*(s+i));
            while(*(s+i)!=ch2&&*(s+i)!='\0')
		    {
	            i++;
	            if(*(s+i)!='\0')
	            {
	                printf("%c",*(s+i));
	            }
		    }
        printf("\n");
		return s+j;
	    }
        i++;
    }
    printf("\n");
    return s+i;
}