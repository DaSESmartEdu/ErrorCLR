#include <stdio.h>
#include <string.h>
int main()
{
    char mima[10000],b;
    int n=0;
    while(1){
        b=getchar();
        if(b==EOF)break;
        mima[n]=b;
        n++;
    }
    if(n<6){
        printf("too short");
        return 0;
    }else if(n>30){
        printf("too long");
        return 0;
    }else{
        int shuzi=0,zimu=0;
        for(int i=0;i<n;i++){
            if((mima[i]>='a'&&mima[i]<='z')||(mima[i]>='A'&&mima[i]<='Z')||mima[i]=='.'||(mima[i]>='0'&&mima[i]<='9')){
                if((mima[i]>='a'&&mima[i]<='z')||(mima[i]>='A'&&mima[i]<='Z')){
                    zimu=1;
                }else if((mima[i]>='0'&&mima[i]<='9')){
                    shuzi=1;
                }
            }else{
                printf("illegal char");
                return 0;
            }
        }
        if(shuzi==0){
            printf("need num");
        }else if(zimu==0){
            printf("need char");
        }else{
            printf("yes");
        }
    }
    return 0;
}