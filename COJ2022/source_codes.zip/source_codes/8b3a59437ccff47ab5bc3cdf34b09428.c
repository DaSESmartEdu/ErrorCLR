#include <stdio.h>
int main (void)
{
	int money,flag=0,sum=0,a=1,b=1;
	scanf("%d", &money);
	sum = 0;
	while(sum<money)
	{
		b=1;
		sum=a*2+b*5;
		if(sum>=money)
			break;
		flag++;
		while(sum<money)
		{
			b++;
			sum=a*2+b*5;
			if(sum>=money)
				break;
			flag++;
		}
		a++;
	}
	printf("%d", flag);
}