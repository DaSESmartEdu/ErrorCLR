#include <stdio.h>   
int main() {     	int a[6][6];    	int n,m;     	scanf("%d %d",&m,&n);
		for(int i=0;i<n;i++) 
		  	for(int j=0;j<n;j++) 
      			scanf("%d",&a[i][j]); 
	    		m%=n;   
				for(int i=0;i<n;i++){
         		    for(int j=0;j<n;j++){
	         			printf("%d ",a[i][(n-m+j)%n]);
				 }         		printf("\n");  
				    	}    	 	return 0; }