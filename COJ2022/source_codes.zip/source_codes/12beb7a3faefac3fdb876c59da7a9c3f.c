#include <stdio.h>
int fib( int n );
void PrintFN( int m, int n );
int main()
{
    int m, n, t;
    scanf("%d %d %d", &m, &n, &t);
    printf("%d\n",fib(t));
    PrintFN(m, n);
    return 0;
}
int fib( int n )
{
    int sum=1,a=1,b=1;
    for(int i=3;i<=n;i++){
        sum=a+b;
        b=a;
        a=sum;
    }
    return sum;
}
void PrintFN( int m, int n )
{
    int a=0,k=1;
    while(fib(k)<=n){
        if(fib(k)>=m){
            a++;
            if(a==1){
        printf("%d",fib(k));
        }else{
            printf(" %d",fib(k));
        }
    }
    k++;
    }
    if(a==0){
        printf("No Fibonacci number");
    }
}