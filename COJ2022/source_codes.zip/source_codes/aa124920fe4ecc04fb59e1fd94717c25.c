#include<stdio.h>
void grade()
{
    int n,i;
    scanf("%d",&n);
    double score[n];
    for (i=0;i<n;i++)
    {
        scanf("%le",&score[i]);
    }
    for (i=0;i<n;i++)
    {
        if (score[i]>=90&&score[n]<=100)
        {
            printf("A");
        }
        else if (score[i]>=80&&score[n]<90)
        {
            printf("B");
        }
        else if (score[i]>=70&&score[n]<80)
        {
            printf("C");
        }
        else if (score[i]>=60&&score[n]<70)
        {
            printf("D");
        }
        else if (score[i]<60)
        {
            printf("F");
        }
        if(i<(n-1))
        {
            printf(" ");
        }
    }
}
int main()
{
    grade();
    return 0;
}