#include<stdio.h>
#define MAX 1000
int ArrayShift(int a[],int n,int m);
void reverse(int *a,int s,int e);
int main()
{
	int n,m,i,a[MAX];
	scanf("%d %d",&n,&m);
	for(i=0;i<n;i++)scanf("%d",&a[i]);
	ArrayShift(a,n,m);
	return 0;
}
int ArrayShift(int a[],int n,int m)
{
	m=m%n;
	int b=n-m,i;
	for(i=0;i<n;i++)
	{
		if(i+b<n)
		{
			printf("%d",a[i+b]);
		}else 
		{
			printf("%d",a[i-m]);
		}
		if(i!=n-1)
		{
			putchar(' ');
		}
	}
}