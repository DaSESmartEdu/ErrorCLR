#include <stdio.h>
double fact(int n)
{   
    int i;
    double result1=1;
  for(i=1;i<=n;i++){
      result1=result1*i;
  }
  return result1;
}
int main()
{
    double result1,result2=0;
    int i,n;
    scanf("%d",&n);
    for(i=1;i<=n;i++){
    result2 += fact(n);
    }
    printf("%.0f",result2);
    return 0;
}