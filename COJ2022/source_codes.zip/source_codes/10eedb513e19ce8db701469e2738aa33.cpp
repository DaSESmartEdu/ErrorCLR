#include <iostream>
#include <cstring>
#include <string>
#include <cstdio>
#include <algorithm>
#include <cmath>
#include <queue>
#include <vector>
#include <map>
#include <set>
using namespace std;
int father[10000];
int n;
struct tree
{
    int a,b;
}vis[1000005];
bool cmp(tree a,tree b)
{
    return a.a<b.a;
}
void init()
{
    for(int i=0;i<10000;i++)
    {
        father[i]=0;
    }
    memset(vis,0,sizeof(vis));
}
int join(int a,int b)
{
    if(father[a]==father[b] && father[a]!=0)
        return 0;
    if(father[a]==0)
    {
        if(father[b]==0)
        {
            father[a]=1;
            father[b]=-1;
        }
        else
        {
            father[a]=-father[b];
        }
        return 1;
    }
    if(father[b]==0)
    {
        if(father[a]==0)
        {
            father[a]=1;
            father[b]=-1;
        }
        else
        {
            father[b]=-father[a];
        }
        return 1;
    }
    return 1;
}
int main()
{
    cin>>n;
    for(int i=0;i<n;i++)
    {
        init();
        int q,w;
        cin>>q>>w;
        int flag=0;
        for(int j=0;j<w;j++)
        {
            int aa,bb;
            cin>>aa>>bb;
            int z,x;
            z=min(aa,bb);
            x=max(aa,bb);
            vis[j].a=z,vis[j].b=x;
        }
        sort(vis,vis+w,cmp);
        for(int j=0;j<w;j++)
        {
            if(!join(vis[j].a,vis[j].b))
            {
                flag=1;
                break;
            }
        }
        printf("Test #%d:\n",i+1);
        if(!flag)
            cout<<"No suspicious bugs found!"<<endl;
        else
            cout<<"Suspicious bugs found!"<<endl;
            cout<<endl;
    }
    return 0;
}