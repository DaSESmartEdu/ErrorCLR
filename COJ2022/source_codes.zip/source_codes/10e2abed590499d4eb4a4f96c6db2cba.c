#include <stdio.h>
int main()
{
    int n, i, j, count=0;
    scanf("%d\n", &n);
    int a[n][n];
    for(i=0;i<n;i++)
    for(j=0;j<n;j++)
    scanf("%d", &a[i][j]);
    for(i=1;i<n;i++)
    for(j=0;j<i;j++)
    if(a[i][j]!=0) count++;
    if(count==0) printf("YES");
    else printf("NO");
    return 0;
}