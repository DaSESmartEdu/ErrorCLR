#include <stdio.h>
#include <math.h>
int main ()
{
	double a,b,c;
    scanf("%lf",&a);
    scanf("%lf",&b);
    scanf("%lf",&c);
	double s,area;
	s=(a+b+c)/2.0;
	area= sqrt(s*(s-a)*(s-b)*(s-c));
	printf(".2lf",area);
	return 0;
}