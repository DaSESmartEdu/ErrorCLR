#include <iostream>
#define ARRAYMAX 100
using namespace std;
int n = 0;
int array[ARRAYMAX] = { 0 };
int K = 0;
bool flag = false;
int max_index = -1;
void dfs_find_K(int index, int prev_sum)
{
    for (int i=index; i<n; i++)
    {
        int current_sum = prev_sum + array[i];
        if (current_sum == K)   
        {
            if (max_index < i) max_index = i;
            flag = true;
            return;             
        }
        if (current_sum > K)    
            return;
        dfs_find_K(i+1, current_sum);   
    }
}
int main()
{
    cin >> n;
    for (int i=0; i<n; i++)
    {
        cin >> array[i];
    }
    cin >> K;
    dfs_find_K(0, 0);
    cout << max_index;
}