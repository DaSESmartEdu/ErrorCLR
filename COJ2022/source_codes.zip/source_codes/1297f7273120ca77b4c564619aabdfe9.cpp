#include<iostream>
#include<string>
#include<algorithm>
#include<vector>
#include<sstream>
#include<map>
using namespace std;
struct Data{
    string val; 
    string county; 
    string name; 
    string address; 
    string tele; 
    string time; 
    string charge; 
};
vector<string> split(const string &raw, const char &delim) {
    vector<string> vec;
    stringstream ss(raw);
    static string si;
    while (getline(ss, si, delim)) {
        vec.emplace_back(si);
    }
    return vec;
}
int main() {
    string ss;
    map<string, int> map;
    vector<Data> res;
    int n, m;
    cin >> n; 
    int num = 0;
    getline(cin, ss);
    while (n-- && getline(cin, ss)) {
        vector<string> path = split(ss, ',');
        res.push_back({path[0], path[1], path[2], path[3], path[4], path[5], path[6]});
        map.emplace(path[2], num++); 
    }
    cin >> m; 
    for (int i = 0; i < m; ++i) {
        cin >> ss;
        cout << '[';
        bool flag = false;
        auto iter = map.lower_bound(ss); 
        while (iter != map.end()) {
            auto str = iter->first;
            if (str.substr(0, ss.size()) != ss) {
                break;
            }
            auto d = res[iter->second];
            if (flag) cout << ",";
            else flag = true;
            cout << "{" << "\"序号\":\"" << d.val << "\""
                 << ",\"区县\":\"" << d.county << "\""
                 << ",\"场馆名称\":\"" << d.name << "\""
                 << ",\"地址\":\"" << d.address << "\""
                 << ",\"联系电话\":\"" << d.tele << "\""
                 << ",\"开放时间\":\"" << d.time << "\""
                 << ",\"收费标准\":\"" << d.charge << "\"}";
            iter++;
        }
        cout << ']' << endl;
    }
    return 0;
}