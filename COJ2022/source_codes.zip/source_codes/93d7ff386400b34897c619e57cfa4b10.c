#include <stdio.h>
#include <math.h>
int main()
{
	int n,i;
	double sum=0;
	for(i=1;i<=n;i++)
	{
		sum = sum +sqrt(i);
	}
	printf("%.2lf",sum);
	return 0;
}