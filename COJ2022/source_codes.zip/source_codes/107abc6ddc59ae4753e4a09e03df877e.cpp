#include<iostream>
#include<string>
using namespace std;
    string thir_six[] = {"twenty","thirty","forty","fifty","sixty"};
    string zero_twenty[] = {"zero","one","two","three","four","five","six","seven","eight","nine","ten","eleven","twelve","thirteen","fourteen","fifteen","sixteen","seventeen","eighteen","nineteen","twenty"};
void trans(string &s){
    int t = stoi(s);
    if(t <= 20){
        cout<<zero_twenty[t];
    }
    else{
        char ch_1 = s[0];
        char ch_2 = s[1];
        if(ch_2 == 0){
            cout<<thir_six[ch_1 - 48 - 2];
        }
        else{
            cout<<thir_six[ch_1 - 48 - 2]<<' ';
            cout<<zero_twenty[ch_2 - 48];
        }
    }
}
int main(){
    string hour, minute;
    cin>>hour>>minute;
    if(hour == "0" && minute == "0"){
        cout<<zero_twenty[0]<<"o"<<"'"<<"clock";
    }
    else if(hour != "0" && minute == "0"){
        trans(hour);
        cout<<"o"<<"'"<<"clock";
    }
    else{
        trans(hour);
        cout<<' ';
        trans(minute);
    }
    return 0;
}