#include<stdio.h>
int f(int n);
int main()
{
    long long n;
    scanf("%ld",&n);
    printf("%ld",f(n));
    return 0;
}
int f(int n)
{
    long long result;
    if(n==0)
    {
        result=0;
    }
    else if(n==1)
    {
        result=1;
    }
    else
    {
        result=f(n-1)+f(n-2);
    }
    return result;
}