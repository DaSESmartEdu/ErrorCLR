#include <stdio.h>
#include <math.h>
int fact (int n)
{
	int i;
	int number = 1;
	if (n!=0)
	{
		for (i=1;i<=n;i++)
		{
			number *= i;
		}
	}
	else
	{
		number = 1;
	}
	return number;
}
int main()
{
	double x;
	int count = 0;
	double sum = 0;
	scanf("%lf",&x);
	while (fabs(pow(x,count))/fact(count)>=0.00001)
	{
		sum += pow(x,count)/fact(count);
		count++;
	}
	printf("%.4f",sum);
	return 0;
}