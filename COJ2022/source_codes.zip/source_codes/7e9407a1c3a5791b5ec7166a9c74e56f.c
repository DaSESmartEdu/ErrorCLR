#include <stdio.h>
int prime(int p);
int PrimeSum(int m,int n);
int main()
{
    int m,n;
    scanf("%d %d",&m,&n);
    printf("%d",PrimeSum(m,n));
    return 0;
}
int prime(int p)
{
    int i,x;
    for(i=2;i<=p/2;i++)
    {
    x=p%i;
    if (x==0)
      {
    break;
    return 0;
      }
    }
    if (i>p/2&&x!=0)
    return 1;
    return 0;
}
int PrimeSum(int m,int n)
{
    int a;
    int sum=0;
    for(a=m;a<=n;a++)
    {
        if (prime(a)==1)
        sum=sum+a;
    }
    return sum;
}