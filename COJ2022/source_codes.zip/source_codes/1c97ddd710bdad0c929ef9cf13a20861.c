#include<stdio.h>
int main(){
    char a,d='+';
    int c=0;
    double sum=0;
    do{
        scanf("%c",&a);
        if(a>='0'&&a<='9')c=c*10+(a-'0');
        else{
            if(d=='/'&&c==0){
                printf("ERROR");
                return 0;
            }
            if(d=='+')sum+=c,d=a,c=0;
            else if(d=='-')sum-=c,d=a,c=0;
            else if(d=='*')sum*=c,d=a,c=0;
            else if(d=='/'&&c!=0)sum/=c,d=a,c=0;
        }
        printf("%c %c %d %lf\n",a,d,c,sum);
    }while(a!='=');
    printf("%.2f",sum);
    return 0;
}