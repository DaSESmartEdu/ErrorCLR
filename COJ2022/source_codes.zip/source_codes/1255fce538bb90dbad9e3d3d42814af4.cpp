#include<bits/stdc++.h>
#define N 1005
using namespace std;
int n,w[N],p[N][N];
int d[N],vis[N];
int main()
{
	scanf("%d",&n);
	int i,j,k;
	memset(p,127,sizeof(p));
	for(i=1;i<=n;++i)
    {
		scanf("%d",&w[i]);
	} 
	for(i=1;i<=n;++i)
		for(j=1;j<=n;++j)
			scanf("%d",&p[i][j]);
	for(i=1;i<=n;++i)
		p[0][i]=w[i];
	memset(d,127,sizeof(d));
	d[0]=0;
	for(i=0;i<=n;++i)
    {
		int k=n+1;
		for(j=0;j<=n;++j)
			if( !vis[j] && (d[j]<d[k]) )
				k=j;
		vis[k]=1;
		for(j=0;j<=n;++j)
			if(!vis[j]&&p[k][j]<d[j])
				d[j]=p[k][j];
	} 
	int mst=0;
	for(i=0;i<=n;++i)
	{
		mst+=d[i];
	}
	printf("%d",mst);
	return 0;
}