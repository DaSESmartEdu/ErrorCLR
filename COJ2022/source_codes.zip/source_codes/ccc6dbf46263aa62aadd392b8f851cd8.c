#include <stdio.h>
int main()
{
    int n,i,j;
    double m[100];
    scanf("%d/n",&n);
    for(i=0;i<n;i++)
    {
        scanf("%lf",&m[100]);
        j=m[100]/10;
        switch (j)
        {
            case 10:
            case 9:
            printf("A ");
            break;
            case 8:
            printf("B ");
            break;
            case 7:
            printf("C ");
            break;
            case 6:
            printf("D ");
            break;
            default:
            printf("E");
            break;   
        }
    }
    return 0;
}