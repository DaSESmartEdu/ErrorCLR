#include<iostream>
using namespace std;
int dir[4][2] = {{1, 0}, {-1, 0}, {0, 1}, {0, -1}};
int r, c;
int high[105][105];
int vis[105][105];
bool check(int x, int y)
{
	if(x >= 1 && y >= 1 && x <= r && y <= c)
		return 1;
	else
		return 0;
}
int dfs(int x, int y){
	if (vis[x][y] != 0)	
		return vis[x][y];
	vis[x][y] = 1;
	for(int i = 0; i <= 4; i++)
    {   
		int x1 = x + dir[i][0];
		int y1 = y + dir[i][1];
		if( check(x1, y1) && high[x1][y1] != high[x][y])
        {    
			vis[x][y] = max(dfs(x1, y1) + 1, vis[x][y]);
		}
	}
	return vis[x][y];    
}
int main()
{
	cin >> r >> c;
	int ans = 0;
	for(int i = 1; i <= r; i++)
    {
		for(int j = 1; j <= c; j++)
        {
			cin >> high[i][j];
			vis[i][j] = 0;      
		}
	}
	for(int i = 1; i <= r; i++)
    {
		for(int j = 1; j <= c; j++)
        {
			ans = max(ans, dfs(i, j));	
		}
	}
	if(ans!=0)
    {
        cout << "1";
    }
    else
    cout << "0";
	return 0;
}