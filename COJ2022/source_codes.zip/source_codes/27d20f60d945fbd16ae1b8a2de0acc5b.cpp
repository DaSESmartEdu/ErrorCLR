#include<iostream>
#include<string>
using namespace std;
typedef struct TNode
{
	char val;
	struct TNode* left;
	struct TNode* right;
} BinTree;
BinTree* BuildTree(BinTree* &(Root),string Post,int& index)
{	
	if (index>=0)
	{
		if (Post[index]=='#')
		{
			Root=NULL;
		}
		else
		{
			Root=new BinTree;
			Root->val=Post[index];
			BuildTree(Root->right,Post,--index);
			BuildTree(Root->left,Post,--index);
		}
	}
	return Root;
}
BinTree* Search(BinTree* Root,char target)
{
	if (Root!=NULL)
	{
		if (Root->val==target)
		{
			cout<<Root->val<<" ";
			return Root;
		}
		else
		{
			cout<<Root->val<<" ";
			if (target<Root->val)
			{
				return Search(Root->left,target);
			}
			else
			{
				return Search(Root->right,target);
			}
		}
	}
	return NULL;
}
BinTree* FindMin(BinTree* Root)
{
	if (!Root)
	{
		return NULL;
	}
	else if (!Root->left)
	{
		return Root;
	} 
	else
	{
		return FindMin(Root->left);
	}
}
BinTree* Delete(BinTree* Root,char X)
{
	BinTree* Tmp;
	if (Root)
	{
		if (X<Root->val)
		{
			Root->left=Delete(Root->left,X);
		}
		else if (X>Root->val)
		{
			Root->right=Delete(Root->right,X);
		}
		else
		{
			if (Root->left&&Root->right)
			{
				Tmp=FindMin(Root->right);
				Root->val=Tmp->val;
				Root->right=Delete(Root->right,Root->val);
			}
			else
			{
				Tmp=Root;
				if (!Root->left)
				{
					Root=Root->right;
				}
				else
				{
					Root=Root->left;
				}
				delete Tmp;
			}
		}
	}
	return Root;
}
void Traverse(BinTree* Root)
{
	if (Root)
	{
		Traverse(Root->left);
		cout<<Root->val<<" ";
		Traverse(Root->right);
	}
}
int main()
{
	BinTree* Root=NULL;
	string Post;
	cin>>Post;
	char x,y;
	cin>>x>>y;
	int index=0;
	while (Post[index])
	{
		index++;
	}
	index=index-1;
	Root=BuildTree(Root,Post,index);
	Search(Root,x);
	Root=Delete(Root,y);
	Traverse(Root);
	return 0;
}