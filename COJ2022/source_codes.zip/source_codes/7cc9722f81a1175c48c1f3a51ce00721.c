#include<stdio.h>
#include<math.h>
double fact(double n){
    int i;
    double product=1;
    for(i=1;i<=n;i++){
        product=product*i;
    }
    return product;
}
int main(){
    double x;
    scanf("%lf",&x);
    double sum=1;
    double t=1;
    while(fabs(pow(x,t)/fact(t))>=0.00001){
        sum=sum+pow(x,t)/fact(t);
        t++;
    }
    printf("%.4f",sum);
    return 0;
}