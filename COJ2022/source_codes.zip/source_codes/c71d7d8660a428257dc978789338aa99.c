#include<stdio.h>
void StringCount( char s[] )
{
    int a=0,b=0,c=0,d=0,i=0;
    while(s[i]!=EOF)
    {
        if((s[i]>='a'&&s[i]<='z' )|| (s[i]>='A'&&s[i]<='Z'))
            a++;
        else if(s[i]==' ' || s[i]=='\n')
            b++;
        else if(s[i]>=0&&s[i]<=9)
            c++;
        else
            d++;
        i++;
    }
    printf("%d %d %d %d",a,b,c,d );
}
int main(void)
{
    char s[50];
    for(int i=0;i<=50;i++)
    {
        s[i]=getchar();
        if(s[i]==EOF)
            break;
    }
    StringCount(s);
}