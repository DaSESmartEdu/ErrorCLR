#include<stdio.h>
const double eps=0.00001;
int main()
{
    double n;
    scanf("%lf",&n);
    double sum=1,fac=1,tmp,ind=n,cnt=1;
    while (1)
    {
        tmp=ind/fac;
        if (tmp<eps)
        {
            break;
        }
        sum+=tmp;
        ind*=n;
        cnt+=1;
        fac*=cnt;
    }
    printf("%.4f",sum);
}