#include <iostream>
#include <malloc.h>
using namespace std;
typedef struct tree{
    char x;
    tree* left;
    tree* right;
    tree* mother;
}tree;
class trees{
    public:
    tree* root=(tree*)malloc(sizeof(tree));
    trees();
    void tidy(tree* now);
    void search(char target);
    void deleted(char target);
    void middle(tree* now);
    private:
    int count=0;
};
trees::trees()
{
    char a[1000],b;
    int i=0;
    while(1){
        scanf("%c",&b);
        if(b=='\n'){
            break;
        }
        a[i]=b;
        i++;
    }
    count=i;
    i--;
    root->x=a[i];
    root->right=NULL;root->left=NULL;root->mother=NULL;
    i--;
    tree* now=root;
    while(i>=0){
        if(now==NULL)break;
        if(now->x=='#'||now->right!=NULL&&now->left!=NULL){
            now=now->mother;
            continue;
        }
        tree* p=(tree*)malloc(sizeof(tree));
        p->x=a[i];
        p->right=NULL;
        p->left=NULL;
        if(now->right==NULL){
            now->right=p;
            p->mother=now;
            now=p;
        }else if(now->left==NULL){
            now->left=p;
            p->mother=now;
            now=p;
        }
        i--;
    }
    tidy(root);
    return;
}
void trees::tidy(tree* now)
{
    if(now->left!=NULL&&now->left->x=='#'){
        now->left=NULL;
    }
    if(now->right!=NULL&&now->right->x=='#'){
        now->right=NULL;
    }
    if(now->left!=NULL){
        tidy(now->left);
    }
    if(now->right!=NULL){
        tidy(now->right);
    }
    return;
}
void trees::search(char target)
{
    tree* now=root;
    while(1){
        cout<<now->x;
        if(now->x==target){
            cout<<endl;
            break;
        }else if(now->x>target){
            now=now->left;
        }else{
            now=now->right;
        }
        cout<<' ';
    }
    return;
}
void trees::deleted(char target)
{
    tree* now=root;
    int direction=0;
    while(1){
        if(now->x==target){
            break;
        }else if(now->x>target){
            direction=1;
            now=now->left;
        }else{
            direction=2;
            now=now->right;
        } 
    }
    if(now->left==NULL){
        if(now->right!=NULL)
        now->right->mother=now->mother;
        if(direction==1){
            now->mother->left=now->right;
        }else{
            now->mother->right=now->right;
        }
    }else{
        tree* min=now->left;
        while(min->right!=NULL){
            min=min->right;
        }
        if(min->left!=NULL){
            min->left->mother=min->mother;
        }
        min->mother->right=min->left;
        now->x=min->x;
    }
    count--;
    return;
}
void trees::middle(tree* now)
{
    if(now->left!=NULL){
        middle(now->left);
    }
    cout<<now->x;
    count--;
    if(count!=0)cout<<' ';
    if(now->right!=NULL){
        middle(now->right);
    }
    return;
}
int main()
{
    trees sss;
    char target;
    cin>>target;
    sss.search(target);
    cin>>target;
    sss.deleted(target);
    sss.middle(sss.root);
    return 0;
}