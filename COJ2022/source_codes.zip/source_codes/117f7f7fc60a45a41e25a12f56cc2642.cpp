#include <bits/stdc++.h>
using namespace std;
const int maxn = 1000 + 10;
int a[maxn];
int b[maxn];
bool cmp(int x, int y)
{
    if(a[x] == a[y]) return x > y;
    return a[x] > a[y];
}
int main()
{
    int n;
    scanf("%d",&n);
    for(int i = 1; i <= n; i++) {scanf("%d",&a[i]); b[i] = i;}
    sort(b+1,b+n+1,cmp);
    for(int i = 1; i <= n; i++) printf("%d%c",b[i], i == n ? '\n' : ' ');
    return 0;
}