#include <stdio.h>
int main(void)
{
    int n = 0, m = 0;
    scanf("%d", &n);
    scanf("%d", &m);
    int array1[n], array2[m];
    int array[n+m];
    int index1 = 0, index2 = 0, index = 0;
    for(index1 = 0; index1 < n; ++index1)
    {
        scanf("%d", &array1[index1]);
    }
    for(index2 = 0; index2 < m; ++index2)
    {
        scanf("%d", &array2[index2]);
    }
    index1 = 0;
    index2 = m-1;
    while(!(index1 == n || index2 == -1))
    {
        if(array1[index1] < array2[index2])
        {
            array[index] = array1[index1];
            ++index;
            ++index1;
        }
        else if(array1[index1] >= array2[index2])
        {
            array[index] = array2[index2];
            ++index;
            --index2;
        }
    }
    if(index1 == n)
    {
        while(index2 != -1)
        {
            array[index] = array2[index2];
            ++index;
            --index2;
        }
    }
    else if(index2 == -1)
    {
        while(index1 != n)
        {
            array[index] = array1[index1];
            ++index;
            ++index1;
        }
    }
    printf("%d", array[0]);
    for(index = 1; index < n+m; ++index)
    {
            printf(" %d", array[index]);
    }
    return 0;
}