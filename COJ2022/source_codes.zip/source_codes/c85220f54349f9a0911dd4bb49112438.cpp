#include<iostream>
using namespace std;
int main(){
    int a,c,e,m,n;
    cin>>a;
    int b[a][2];
    for (n=0;n<a;n++){
        cin>>b[n][0]>>b[n][1];
    }
    cin>>c;
    int d[a][3];
    for(n=0;n<a;n++){
        d[n][0]=b[n][0]*b[n][0]+b[n][1]*b[n][1];
        d[n][1]=b[n][0];
        d[n][2]=b[n][1];
    }
    for(m=0;m<a;m++){
        for(n=0;n<a-1;n++){
            if(d[n][0]>d[n+1][0]){
               e=d[n][0]; 
               d[n][0]=d[n+1][0];
               d[n+1][0]=e;
               e=d[n][1]; 
               d[n][1]=d[n+1][1];
               d[n+1][1]=e;
               e=d[n][2]; 
               d[n][2]=d[n+1][2];
               d[n+1][2]=e;
            }
        }
    }
    cout<<d[c][1]<<" "<<d[c][2];
    return 0;
}