#include<stdio.h>
#include<math.h>
double fact(int m)
{int i;
 double result;
 result=1;
for (i=1;i<=m;i++) result*=i*1.0;
return result;}
int main()
{double x,S;
 S=1.0;
scanf("%lf",&x);
 int n,j;
 n=0;
 for (j=1;fabs(pow(x,j)/fact(j))<0.00001;j++) n=j;
 int p;
 for (p=1;p<=n+1;p++) S+=pow(x,p)/fact(p);
 printf("%.4f",S);
 return 0;
}