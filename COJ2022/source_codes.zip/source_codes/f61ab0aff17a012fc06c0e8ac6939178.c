#include <stdio.h>
#include <math.h>
int main()
{
    int n,i;
    double x,y,m,s=0;
    scanf("%d",&n);
    i=0;
    x=2;
    y=1;
    for(i=0;i<=n;i++){
        s=s+x/y;
        m=y;
        y=x;
        x=m+x;
    }
    printf("%.2lf",s);
    return 0;
}