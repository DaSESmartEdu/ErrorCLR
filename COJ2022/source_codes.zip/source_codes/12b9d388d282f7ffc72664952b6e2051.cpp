from decimal import Decimal
n=int(input())
data=[]
for i in range(0,n):
	a=[]
	s=input()
	x=float(input())
	a.append(s)
	a.append(x)
	data.append(a)
#data=sorted(data,key=lambda x: x[1])
#data.sort(lambda x, y: cmp(x[1], y[1]), reverse=True)
max=0
u=0
v=0
for i in range(0,n):
	if(data[i][1]>max):
		max=data[i][1]
		u=i
min=max
for i in range(0,n):
	if(data[i][1]<min):
		min=data[i][1]
		v=i
print("%.2f"%data[u][1]+','+data[u][0])
print("%.2f"%data[v][1]+','+data[v][0])