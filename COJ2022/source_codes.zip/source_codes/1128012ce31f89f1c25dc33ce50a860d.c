#include <stdio.h>
int main()
{
    int a,b,c,f=0;
    char s;
    scanf("%d",&a);
    while((s=getchar())!='=')
    {
        scanf("%d",&b);
        if((s=='/')&&(b==0))
        {
            f=1;break;
        }
        switch(s)
        {
            case '+':a=a+b;break;
            case '-':a=a-b;break;
            case '*':a=a*b;break;
            case '/':a=a/b;break;
            default:
            f=1;break;
        }
		if(f) break;
    }
	if(f)
		printf("ERROR");
	else
		printf("%d",a);
    return 0;
}