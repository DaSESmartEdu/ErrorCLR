#include<stdio.h>
#include<math.h>
long fact(int n){
    long a=1;
    int i=1;
    while(i<=n){
        a*=i;
        i++;
    }
    return a;
}
double funcos(double e,double x){
    int i=0,a=1;
    double s=0,c=1;
    while (c>=e){
        c=pow(x,i)/(double)fact(i);
        s+=c*a;
        a=-a;
        i+=2;
        printf("%f\n",c*a);
    }
    return s;
}
int main(){
    double e,x;
    scanf("%lf %lf",&e,&x);
    printf("%.6lf",funcos(e,x));
    return 0;
}