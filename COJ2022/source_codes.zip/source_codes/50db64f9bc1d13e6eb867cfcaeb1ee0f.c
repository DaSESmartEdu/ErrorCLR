#include <stdio.h>
void change(double grade, int i, char ans[])
{
    if(grade >= 90)
        ans[i] = 'A';
    else if(grade >= 80)
        ans[i] = 'B';
    else if(grade >= 70)
        ans[i] = 'C';
    else if(grade >= 60)
        ans[i] = 'D';
    else
        ans[i] = 'E';
}
int main (void)
{
    int n;
    scanf("%d", &n);
    double grade[n];
    char ans[n];
    for(int i = 0; i<n;i++)
    {
        scanf("%lf", &grade[i]);
        change(grade[i], i, ans);
    }
    for(int i = 0; i<n;i++)
    {
        printf("%c", ans[i]);
    }
    return 0;
}