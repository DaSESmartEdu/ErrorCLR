#include<stdio.h>
int sign(int x);
int main()
{
    int n;
	scanf("d",&n);
	printf("%d",sign(n));
	return 0;
}
int sign(int x)
{
	if(x > 0) return 1;
	if(x == 0) return 0;
	if(x<0) return -1;
}