#include<stdio.h>
int main()
{
	int a[100001];
	int b[100001];
	int m,n;
	scanf("%d %d",&m,&n);
	int i=1;
	while(i<=m)
	{
		scanf("%d",&a[i]);
		i=i+1;
	}
	i=1;
	while(i<=n)
	{
		scanf("%d",&b[i]);
		i=i+1;
	}
	i=1;
	int p;
	p=n;
	int c[200002];
	int u=1;
	int A=0,B=0;
	int x=0,y=0;
	while(u<=m+n&&A==0&&B==0)
{   
	if(a[i]<=b[p])
	{
		c[u]=a[i];  
		x=1;
		if(i==m)
		{A=1;}
			i=i+1;
	}
	if(x==1)
	{
		u=u+1;
	}
	if(a[i]>b[p])
	{
		c[u]=b[p];  
		y=1;
		if(p==1)
		{
			B=1;
		}
         p=p-1;
	}
if(y==1)	{
u=u+1;}
x=0;y=0;
}
 int u1;
 u1=u;
 if(A==1);
{
  while(u<=m+n)
 {
 	c[u]=b[p];
 	p=p-1;
 	u=u+1;
 }
}
 if(B==1)
{
	while(u1<=m+n)
	{
		c[u1]=a[i];
		i=i+1;
		u1=u1+1;
	}
} 
	u=1;
	while(u<=m+n)
	{
		printf("%d ",c[u]);
		u=u+1;
	}
	return 0;
}