#include<stdio.h>
#include<math.h>
int fact(int n)
{
	int sum=1;
	for(int i=1; i<=n;i++)
	{
		sum*=i;
	}
	return sum;
}
int main (void)
{
	double x, sum=1;
	int i=2;
	scanf("%lf", &x);
	sum+=x;
	while((double)((double)pow(x, i)/(double)fact(i))>=0.00001)
	{sum+=(double)((double)pow(x, i)/(double)fact(i));
		i++;}
	printf("%.4f", sum);
}