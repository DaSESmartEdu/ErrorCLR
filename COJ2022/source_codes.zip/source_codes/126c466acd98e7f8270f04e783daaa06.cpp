#include <iostream>
using namespace std;
#include <vector>
vector<vector<int>> heap;
vector<vector<int>> ans;
int n,k;
int size=k;
void print(vector<vector<int>> &heap);
bool cmp(vector<vector<int>> &heap,int a,int b);
bool cmp1(vector<vector<int>> &heap,vector<int>target);
void Build_max(vector<vector<int>>&heap);
void Heapsort(vector<vector<int>> &heap);
void Heapify(vector<vector<int>> &heap,int index);
void heap_insert(vector<vector<int>> &heap,vector<int> &target);
void push(vector<vector<int>> &heap);
void print(vector<vector<int>> &heap)
{
    for(int i=0;i<k*(n-k+1);i++){
        cout<<"("<<ans[i][0]<<","<<ans[i][1]<<")";
        if(&ans[i+1]!=NULL) cout<<endl;
    }
}
bool cmp(vector<vector<int>> &heap,int a,int b){
    if(heap[a][0]>heap[b][0] || (heap[a][0]==heap[b][0] && heap[a][1]>heap[b][1])) return true;
    else return false;
}
bool cmp1(vector<vector<int>> &heap,vector<int>target){
    if(target[0]>heap[k][0] || (target[0]==heap[k][0] && target[1]>heap[k][1])) return true;
    else return false;
}
void Build_max(vector<vector<int>>&heap){
    for(int i=k/2;i>=1;i--){
        Heapify(heap,i);
    }
}
void Heapsort(vector<vector<int>> &heap){
    size=k;
    Build_max(heap);
    for(int i=size;i>=2;i--){
        swap(heap[i],heap[1]);
        size--;
        Heapify(heap,1);
    }
}
void Heapify(vector<vector<int>> &heap,int index){
    int right=index*2;
    int left=index*2+1;
    int largest=index;
    if(right<=size && cmp(heap,right,largest)) largest=right;
    if(left<=size && cmp(heap,left,largest)) largest=left;
    if(largest!=index){
        swap(heap[largest],heap[index]);
        Heapify(heap,largest);
    }
}
void heap_insert(vector<vector<int>> &heap,vector<int> &target)
{
   if(cmp1(heap,target)) push(heap);
   else{
       heap[k][0]=target[0];
       heap[k][1]=target[1];
       Heapsort(heap);
       push(heap);
   }
}
void push(vector<vector<int>> &heap){
    vector<int> atmp;
    for(int i=1;i<=k;i++){
        atmp=heap[i];
        ans.push_back(atmp);
        atmp.clear();
    }
}
int main(){
    cin>>n>>k;
    vector<int> tmp;
    tmp.push_back(0);
    tmp.push_back(0);
    heap.push_back(tmp);
    tmp.clear();
    int t;
    for(int i=1;i<=k;i++){
        for(int j=0;j<2;j++){
            cin>>t;
            tmp.push_back(t);
        }
        heap.push_back(tmp);
        tmp.clear();
    }
    Heapsort(heap);
    push(heap);
    for(int i=k+1;i<=n;i++){
        for(int j=0;j<2;j++){
            cin>>t;
            tmp.push_back(t);
        }
        heap_insert(heap,tmp);
        tmp.clear();
    }
    print(ans);
}