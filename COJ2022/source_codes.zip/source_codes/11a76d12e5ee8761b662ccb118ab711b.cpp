#include<bits/stdc++.h>
using namespace std;
int main(){
	int v1,v2,t,s,l;
	int dt=0,dw=0,tt=0;
	scanf("%d%d%d%d%d",&v1,&v2,&t,&s,&l);
    while(dt<l && dw<l){
    	if(dt-dw>=t){
    		tt+=s;
    		dw+=v2*s;
		}
		else{
			tt++;
			dw+=v2;
			dt+=v1;
		}
	}
	if(dt<l) printf("T\n%d",l/v2);
	if(dt==dw) printf("D\n%d",l/v2);
	if(dw<l) printf("R\n%d",tt);
	return 0;
}