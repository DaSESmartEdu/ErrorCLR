#include <stdio.h>
int main (void)
{
	double mile, time;
	double answer = 10;
	scanf("%lf%lf", &mile, &time);
	if(mile>3 && (int)mile<=10)
	{
		answer += (mile-3)*2.0;
	}
	else if (mile>10)
		answer += 14 + (mile-10)*3.0;
	answer += (int)(time/5.0) * 2;
	printf("%.f", answer);
	return 0;
}