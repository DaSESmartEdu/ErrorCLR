#include<stdio.h>
int main()
{
    int n, m;
    scanf("%d %d",&n, &m);
    if(n<=m){
        printf("normal");
    }    
    else if(n>=1.1*m&&n<=1.5*m){
        printf("200");
    }  
    else{
        printf("revoke");
    }    
    return 0;
}