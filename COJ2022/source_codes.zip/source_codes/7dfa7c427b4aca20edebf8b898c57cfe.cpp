#include<iostream>
using namespace std;
int main()
{
    int v1, v2, t, s, l;
    cin >> v1 >> v2 >> t >> s >> l;
    int sr = 0;
    int st = 0;
    int tt = 0;
    while (sr<l&&st<l)
    {
        if(sr<st+t)
        {
            sr += v1;
            st += v2;
            tt++;
        }
        else
        {
            st += v2 * s;
            if(st>=l)
            {
                tt += s - (s * t - l) / v2;
                break;
            }
            tt += s;
        }
    }
    if (sr<l)
    {
        cout << "T" << endl;
    }else if (st<l)
    {
        cout << "R" << endl;
    }else
    {
        cout << "D" << endl;
    }
    cout << tt << endl;
    return 0;
}