#include<iostream>
using namespace std;
int r, c;
int map[100][100];
int a[4] = { 1,0,-1,0 };
int b[4] = { 0,1,0,-1 };
int Max = 0;
int visited[100][100] = { 0 };
int DFS(int x, int y, int count)
{
	int m, n, i;
	if (count > Max)
	{
		Max = count;
	}
	for (i = 0; i < 4; i++)
	{
		m = x + a[i];
		n = y + b[i];
		if (m >= 0 && m < r && n >= 0 && n < c && map[m][n] != map[x][y] && visited[m][n] == 0)
		{
			visited[m][n] = 1;
			DFS(m, n, count + 1);
			visited[m][n] = 0;
		}
	}
	return Max;
}
int main()
{
	cin >> r >> c;
	int i, j;
	for (i = 0; i < r; i++)
	{
		for (j = 0; j < c; j++)
		{
			cin >> map[i][j];
		}
	}
	int h=DFS(0, 0, 1);
	if (h != r + c - 1) {
		cout << 0<<endl;
	}
	else {
		cout<< 1<<endl;
	}
	return 0;
}