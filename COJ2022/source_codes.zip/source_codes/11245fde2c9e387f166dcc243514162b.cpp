#include<iostream>
#include<cstring>
#include<string>
#include<algorithm>
#include<vector>
using namespace std;
int n_num,t_num,sumvalue;
class tri{
	public:
	int from,to,value;
};
bool cmp(tri a,tri b){
	return a.value<b.value;
}
tri Tri[110];
int par[110];
int parent(int n){
	if(par[n]==-1) return n;
	else return parent(par[n]);
}
int main(){
	sumvalue=0;
	cin>>n_num>>t_num;
	for(int i=0;i<n_num;i++){
		int name;
		cin>>name;
	}
	for(int i=0;i<t_num;i++){
		int f,t,v;
		cin>>f>>t>>v;
		Tri[i].from=f;
		Tri[i].to=t;
		Tri[i].value=v;
	}
	sort(Tri,Tri+t_num,cmp);
	memset(par,-1,sizeof(par));
	vector<tri> answer;
	for(int i=0;i<t_num;i++){
		int f=Tri[i].from;
		int t=Tri[i].to;
		int v=Tri[i].value;
		if(parent(f)!=parent(t)){
			answer.push_back(Tri[i]);
			int fp=parent(f);
			int tp=parent(t);
			par[tp]=fp;
		}
	}
	for(int i=0;i<n_num-1;i++){
		tri temp=answer[i];
		int f = max(temp.from,temp.to);
		int t = min(temp.from,temp.to);
		cout<<t<<" "<<f<<" "<<temp.value<<endl;
		sumvalue+=temp.value;
	}
	cout<<sumvalue;
	return 0;
}