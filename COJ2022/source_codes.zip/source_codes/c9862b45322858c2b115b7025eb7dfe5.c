#include <stdio.h>
int main ()
{
	int m,n,x;
	scanf("%d %d %d",&m,&n,&x);
	if(m<=n<=x)
	{printf("%d %d %d",m,n,x);}
	else if(n<=m<=x)
	{printf("%d %d %d",n,m,x);}
	else if(n<=x<=m)
	{printf("%d %d %d",n,x,m);}
	else if(m<=x<=n)
	{printf("%d %d %d",m,x,n);}
	else if(x<=m<=n)
	{printf("%d %d %d",x,m,n);}
	else 
	{printf("%d %d %d",x,n,m);}
	return 0;
}