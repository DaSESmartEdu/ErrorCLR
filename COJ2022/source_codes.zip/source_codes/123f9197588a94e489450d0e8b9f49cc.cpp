#include<cstdio>
using namespace std;
int main(){
	int time;
	scanf("%d",&time);
	int h,m,s;
	h=time/3600;
	m=time%3600/60;
	s=time%60;
	printf("%d:%d:%d",h,m,s);
	return 0;
}