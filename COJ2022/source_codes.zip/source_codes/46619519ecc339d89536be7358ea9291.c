#include <stdio.h>
int sign(int x);
int main()
{
	int x;
	scanf("%d",&x);
	printf("%d",sign(x));
}
int sign(int x)
{
	int out;
	if(x>0) out=1;
	else if(x=0) out=0;
	else out=-1;
	return out;
}