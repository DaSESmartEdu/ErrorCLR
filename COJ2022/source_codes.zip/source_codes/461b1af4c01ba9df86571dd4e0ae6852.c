#include<stdio.h>
int main(){
	int n,i;
	double score=0;
	scanf("%d",&n);
	for (i=1;i<=n;i++)
	{
		scanf("%lf",&score);
		if (score>=90){
			printf("A");
		}
		else if(score<90 && score>=80){
			printf("B");
		}
		else if(score<80 && score>=70){
			printf("C");
		}
		else if(score<70 && score>=60){
			printf("D");
		}
		else {
			printf("E");
		}
	}
	return 0;
}