lst = list(map(lambda x:float(x), input().split()))
height, n = lst[0], int(lst[1])
for _ in range(n):
	height /= 2
heightstr = '%.3f'%height
itg, decim = heightstr.split('.')
if decim[2] == '5':
	height = float('%.2f'%height) + 0.01
	print('%.2f'%height)
else:
	print('%.2f'%height)