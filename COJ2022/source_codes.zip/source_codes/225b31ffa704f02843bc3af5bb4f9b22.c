#include <stdio.h>
int main()
{
    int a,b,c;
    scanf("%d",&a);
    scanf("%d",&b);
    c=a+b*a;
    printf("%d",c);
    sleep (5);
    return 0;
}