#include <stdio.h>
int main()
{
    double n,m;
    scanf("%lf %lf",&n,&m);
    double percent;
    percent=(n-m)/m;
    if (percent>=0.1)
        if (percent>=0.5)
            printf("revoke");
        else
            printf("200");
    else
        printf("normal");
    return 0;
}