#include<stdio.h>
int even(int n)
{
    if(n%2==0) return 1;
    else return 0;
}
int OddSum(int List[],int N)
{
    int i,sum=0;
    for(i=0;i<N;i++){
        if(even(List[i])==0)sum+=List[i];
    }
    return sum;
}
int main()
{
    int n;
    scanf("%d",&n);
    int List[n];
    for(int i=0;i<n;i++){
        scanf("%d",&List[i]);
    }
    printf("%d",OddSum(List,n));
    return 0;
}