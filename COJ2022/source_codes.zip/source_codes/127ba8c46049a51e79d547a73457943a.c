#include <stdio.h>
int func(int a,int b)
{
    int res=1;
    for(int i=1;i<=b;i++)
    {
        res*=a;
    }
    return res;
}
int narcissistic(int num)
{
    int m=num;
    int n=0;
    while(m!=0)
    {
        m=m/10;
        n++;
    }
    m=num;
    int d=0,t=0,sum=0;
    while(m!=0)
    {
        d=m%10;
        t=func(d,n);
        sum+=t;
        m/=10;
    }
    if(sum==num)
    return 1;
    else
    return 0;
}
void PrintN(int m,int n)
{
    for(int i=m;i<=n;i++)
    {
        if(narcissistic(i)==1)
        printf("%d\n",i);
    }
}
int main()
{
    int m,n;
    scanf("%d %d",&m,&n);
    PrintN(m,n);
    return 0;
}