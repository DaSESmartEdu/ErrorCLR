#include<stdio.h>
int main()
{
	int n,i;
	scanf("%d",&n);
	double score[n];
	for(i=0;i<n;i++)
		scanf("%lf",&score[i]);
	for(i=0;i<n;i++){
		if(score[i]>=90&&score[i]<=100)
			printf("A ");
		else if(score[i]<90&&score[i]>=80)
			printf("B ");	
		else if(score[i]<80&&score[i]>=70)
			printf("C ");
		else if(score[i]<70&&score[i]>=60)	
			printf("D ");
		else if(score[i]<60)	
			printf("F ");	}
return 0;
}