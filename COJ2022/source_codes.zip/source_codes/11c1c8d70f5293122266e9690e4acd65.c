#include <stdio.h>
int main(){
    int n;
    scanf("%d", &n);
    char* month[]={"","January","February","March","April","May","June","July","August","September","October","November","December"};
    if (1<= n && n<=12)
    {
        printf("%s", month[n]);
    }else{
        printf("wrong input!");
    }
}