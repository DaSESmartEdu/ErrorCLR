#include<stdio.h>
int main()
{
    int i,m,n;
    double answer;
    scanf("%d %d",&m,&n);
    for(i=m;i<=n;i++)
    {
        answer+=i*i*1.0+1.0/i;
    }
    printf("%.6f\n",answer);
    return 0;
}