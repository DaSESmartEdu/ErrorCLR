#include<stdio.h>
int main()
{
    int n;
    scanf("%d",&n);
    int a[n];
    for (int i = 0; i < n; i++)
    {
        scanf("%d",a[i]);
    }
    int num[10]={};
    for ( int j = 0; j < n; j++)
    {
        for (int each= a[j]; each!=0; each/=10)
        {
            num[each%10]++;
        }
    }
    int max=0;
    for (int k =0;k < 10; k++)
    {
        if (num[k]>max)
        {
            max=num[k];
        }
    }
    for (int k =0;k < 10; k++)
    {
        if (num[k]==max)
        {
            printf("%d ",k);
        }
    }
}