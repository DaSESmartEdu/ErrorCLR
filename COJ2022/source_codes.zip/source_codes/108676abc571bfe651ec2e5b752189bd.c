#include <stdio.h>
#include <string.h>
#include <ctype.h>
#define MAXN 15
char s[MAXN];
int cnt[MAXN], mx = 0;
int main() {
	int n;
	scanf("%d", &n);
	while (n--) {
		scanf("%s", s);
		int len = strlen(s);
		for (int i = 0; i < len; ++i) {
			int x = s[i] - '0';
			cnt[x] ++;
		}
	}
	for (int i = 0; i < 10; ++i) if (mx < cnt[i]) mx = cnt[i];
	int f = 0;
	for (int i = 0; i < 10; ++i) {
		if (mx == cnt[i]) 	{
			if (!f) printf("%d", i), f = 1;
			else printf(" %d", i);
		}
	}
	return 0;
}