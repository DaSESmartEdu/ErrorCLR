#include<iostream>
#include<sstream>
#include<stdio.h>
#include<vector>
using namespace std;
class node
{
public:
    node *left;
    node *right;
    string num;
    string loc;
    string name;
    string add;
    string tel;
    string time;
    string price;
    node(vector<string> myList):
    num(myList[0]),loc(myList[1]),name(myList[2]),add(myList[3]),tel(myList[4]),time(myList[5]),price(myList[6])
    {
        left = NULL;
        right = NULL;
    }
    node *insert (node *root, node *s)
    {
        if(root == NULL)
        {
            root=s;
            root->left=NULL;
            root->right=NULL;
        }
        else
        {
            if(s->name < root->name)
            {
                root->left = root->left->insert(root->left,s);
            }
            else
            {
                root->right = root->right->insert(root->right,s);
            }
        }
        return root;
    }
};
vector<string> split(const string &raw, const char &delim)
{
    vector<string> vec;
    stringstream ss(raw);
    static string si;
    while (getline(ss, si, delim)) 
    {
        vec.emplace_back(si);
    }
    return vec;
}
bool change(string p, string q)
{
    if(p.size() < q.size())
    return false;
    int i;
    for(i=0;i<q.size();i++)
    {
        if(q[i] != p[i])
        {
            return false;
        }
    }
    return true;
}
void search(node*root , string tar, int &num)
{
    if(root == NULL)
    {
        return ;
    }
    if(tar < root->name  && !change(root->name, tar))
    {
        search(root->left, tar, num);
    }
    else if(tar<=root->name  &&  change(root->name,tar))
    {
        search(root->left, tar, num);
        if (num != 0)       cout << ",";      num++;
        printf("{\"序号\":\"%s\",\"区县\":\"%s\",\"场馆名称\":\"%s\",\"地址\":\"%s\",\"联系电话\":\"%s\",\"开放时间\":\"%s\",\"收费标准\":\"%s\"}",
        root->num.c_str(),root->loc.c_str(),root->name.c_str(),root->add.c_str(),root->tel.c_str(),root->time.c_str(),root->price.c_str());
        search(root->right, tar, num);
    }
    else if(tar >=root->name  &&  !change(root->name,tar))
    {
        search(root->right, tar, num);
    }
}
int main()
{
    int n,m;
    node* root = NULL;
    cin>>n;
    getchar();
    for (int j = 0; j < n; j++)
    {
        string tab;
        getline(cin,tab);
        vector<string> wewant = split(tab,',');
        if (j == 0)
        root = new node(wewant);
        else
        {
           node* s = new node(wewant);
           root->insert(root,s);
        }
    }
    cin>>m;
    getchar();
    for (int i = 0; i < m; i++)
    {
        string tab;
        int number = 0;
        cin >> tab;
        cout<<"[";
        search(root, tab, number);
        cout<<"]"<<endl;
    }
    return 0;
}