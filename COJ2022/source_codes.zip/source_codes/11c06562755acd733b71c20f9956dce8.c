#include <stdio.h>
int main()
{
	int year,time;
	double sum=0;
	scanf("%d %d",&year,&time);
	if(year<5)
	{
		if(time<=40)
		{
			sum=30*time;
		}
		else
		{
			sum=1200+(time-40)*45;
		}
	}
	else
	{
		if(time<=40)
		{
			sum=50*time;
		}
		else
		{
			sum=2000+(time-40)*75;
		}
	}
	printf("%.2lf",sum);
	return 0;
}