#include<stdio.h>
void splitfloat(float x,int *intpart,float *fracpart)
{
    *intpart=(int)(x);
    *fracpart=x-(int)(x);
}
int main()
{
    float x,fracpart;
    int intpart;
    scanf ("%f",&x);
    splitfloat (x,&intpart,&fracpart);
    printf ("%d %.3f",intpart,fracpart);
    return 0;
}