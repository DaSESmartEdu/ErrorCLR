#include<stdio.h>
int main()
{
  int x;
  float y;
  scanf("%d",&x);
  if(x<=50){
  	y=x*0.53;	
  }else{
  	 y=x*0.58+26.5;
  }
  printf("%f",y);
  return 0;
}