#include<stdio.h>
#include<math.h>
double fact(int n);
int main()
{
    double x=0,S=0,n=2;
    scanf("%lf",&x);
    S=1+x;
        while(pow(x,n)/fact(n)>=0.00001)
        {
          S=S+pow(x,n)/fact(n);
          n++;
        }
        printf("%.4lf",S);
return 0;
}
double fact(int n)
{
    double a=1;
    int i;
    for(i=1;i<=n;i++)
       a*=i;
       return a;
}