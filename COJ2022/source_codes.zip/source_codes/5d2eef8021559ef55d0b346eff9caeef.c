#include <stdio.h>
int main()
{
    int height;
    int n, i;
    double left;
    scanf("%d", &height);
    left = height;
    scanf("%d", &n);
    for (i = 1 ; i<= n; i++)
    {
        left = left / 2;
    }
    printf("%.2f", left);
    return 0;
}