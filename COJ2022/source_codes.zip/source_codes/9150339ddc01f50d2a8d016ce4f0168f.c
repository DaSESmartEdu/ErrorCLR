#include <stdio.h>
int main()
{ int i=0,n,a[i],b[i];
  float item,sum=0;   
  scanf("%d",&n);
  a[0]=2,b[0]=1;
  item=a[i]*1.0/b[i];          
  for (i=0;i<=n-1;i++)
  {
    a[i+1]=a[i]+b[i];
    b[i+1]=a[i];
    item=a[i]*1.0/b[i];
    sum+=item;
  }
  printf("%.2f\n",sum);
  return 0;
}