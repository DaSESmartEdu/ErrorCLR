#include <iostream>
#include <string.h>
#include <vector>
#include <sstream>
using namespace std;
enum Error_code
{
    not_present,
    success
};
struct node
{
    vector<string> value;
    node *left;
    node *right;
};
vector<string> split(const string &raw, const char &delim)
{
    vector<string> vec;
    stringstream ss(raw); 
    static string si;
    while (getline(ss, si, delim))
    {
        vec.push_back(si);
    }
    return vec;
}
Error_code search_and_insert(node *&sub_root, const vector<string> &new_data)
{
    if (sub_root == NULL)
    {
        sub_root = new node(); 
        sub_root->value = new_data;
        return success;
    }
    else if (new_data[2].compare(sub_root->value[2]) < 0) 
        return search_and_insert(sub_root->left, new_data);
    else if (new_data[2].compare(sub_root->value[2]) > 0)
        return search_and_insert(sub_root->right, new_data);
    else
        return not_present;
}
void recursive_inorder(node *sub_root, string target, vector<vector<string>> &vec, int &flag) 
{
    if (sub_root != NULL)
    {
        int positon = sub_root->value[2].find(target);
        if (positon == 0) 
        {
            flag++;
        }
        recursive_inorder(sub_root->left, target, vec, flag);
        if (positon == 0)
        {
            vec.push_back(sub_root->value);
        }
        recursive_inorder(sub_root->right, target, vec, flag);
    }
}
void shuchu(vector<vector<string>> vec, int flag)
{
    if (flag == 0)
        return;
    for (int i = 0; i < flag - 1; i++)
    {
        cout << "{";
        cout << '\"' << "序号" << '\"' << ':' << '\"' << vec[i][0] << '\"';
        cout << ",";
        cout << '\"' << "区县" << '\"' << ':' << '\"' << vec[i][1] << '\"';
        cout << ",";
        cout << '\"' << "场馆名称" << '\"' << ':' << '\"' << vec[i][2] << '\"';
        cout << ",";
        cout << '\"' << "地址" << '\"' << ':' << '\"' << vec[i][3] << '\"';
        cout << ",";
        cout << '\"' << "联系电话" << '\"' << ':' << '\"' << vec[i][4] << '\"';
        cout << ",";
        cout << '\"' << "开放时间" << '\"' << ':' << '\"' << vec[i][5] << '\"';
        cout << ",";
        cout << '\"' << "收费标准" << '\"' << ':' << '\"' << vec[i][6] << '\"';
        cout << "}"
             << ",";
    }
    cout << "{";
    cout << '\"' << "序号" << '\"' << ':' << '\"' << vec[flag - 1][0] << '\"';
    cout << ",";
    cout << '\"' << "区县" << '\"' << ':' << '"' << vec[flag - 1][1] << '\"';
    cout << ",";
    cout << '\"' << "场馆名称" << '\"' << ':' << '"' << vec[flag - 1][2] << '\"';
    cout << ",";
    cout << '\"' << "地址" << '\"' << ':' << '\"' << vec[flag - 1][3] << '\"';
    cout << ",";
    cout << '\"' << "联系电话" << '\"' << ':' << '\"' << vec[flag - 1][4] << '\"';
    cout << ",";
    cout << '\"' << "开放时间" << '\"' << ':' << '"' << vec[flag - 1][5] << '\"';
    cout << ",";
    cout << '\"' << "收费标准" << '\"' << ':' << '"' << vec[flag - 1][6] << '\"';
    cout << "}";
}
int main()
{
    ios::sync_with_stdio(false); 
    int N;
    cin >> N;
    cin.get();
    vector<string> vec;
    string str;
    getline(cin, str);
    vec = split(str, ',');
    node *root = new node;
    root->value = vec;
    root->right = NULL;
    root->left = NULL;
    vec.clear(); 
    for (int i = 1; i < N; i++)
    {
        string str;
        getline(cin, str);
        vec = split(str, ',');
        search_and_insert(root, vec);
        vec.clear(); 
    }
    int M;
    cin >> M;
    vector<string> target(M + 1);
    for (int i = 0; i < M; i++)
    {
        cin >> target[i];
    }
    for (int i = 0; i < M; i++)
    {
        vector<vector<string>> vec;
        cout << "[";
        int flag = 0;
        recursive_inorder(root, target[i], vec, flag);
        shuchu(vec, flag);
        cout << "]" << endl;
    }
    return 0;
}