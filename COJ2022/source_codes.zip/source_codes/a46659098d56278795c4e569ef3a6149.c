#include <stdio.h> 
int f(int m){
	if(m=1){
		return 1;
	}
	else{return m*f(m-1);}
}
void main(){
	int n;
	int i=1;
	int sum=0;
scanf("%d",&n);
while(i<=n){
sum+=f(i);
i++;
}
	printf("%d",sum);
return 0;
}