#include<stdio.h>
void printdigits(int n)
{
    int i,x,j;
    int a[100];
    i=0;
    do 
    {
    	i++;
        a[i]=n%10;
        n=n/10;
    } while (n!=0);
    for (j=i;j>0;j--)
    {
        printf ("%d\n",a[j]);
    }
}
int main()
{
    int n;
    scanf ("%d",&n);
    printdigits(n);
    return 0;
}