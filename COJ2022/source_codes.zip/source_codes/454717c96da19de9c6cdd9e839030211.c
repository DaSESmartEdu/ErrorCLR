#include<stdio.h>
int main()
{
    int n,i,j,k,l;
    scanf("%d",&n);
    for ( i =0 ; i <(n+1)/2; i++)
    {
        for (j = 0; j <=(n-1)/2-i ; j++)
        {
            printf(" ");
        }
        for ( k =1; k <= (2*i-1); k++)
        {
            printf("*");   
        }
         printf("\n");
         }
    for ( l = 1; l <= n; l++)
    {
        printf("*");
    }
    printf("\n");
    for ( i =1 ; i <(n+1)/2; i++)
    {
        for (j =1; j <=i ; j++)
        {
            printf(" ");
        }
        for ( k =1; k <n-(2*i-1) ; k++)
        {
            printf("*");   
        }
         printf("\n");
    }
}