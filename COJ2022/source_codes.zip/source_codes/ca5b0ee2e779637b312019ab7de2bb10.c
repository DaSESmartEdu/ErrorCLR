#include <stdio.h>
int main()
{
	int m,n,i;
	double sum, item;
	scanf("%d %d",&m,&n);
	sum=0;
	for (i=m;i<=n;i++)
	{
		item=(i*i)*1.0+1/i;
		sum=sum+item;
	}
	printf("%.6f",sum);
	return 0;
}