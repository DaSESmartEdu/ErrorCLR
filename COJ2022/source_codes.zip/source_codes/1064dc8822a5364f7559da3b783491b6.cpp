#include <iostream>
#include <algorithm>
using namespace std;
int max(int a,int b){
    if(a<=b){
        return b;
    }
    else{
        return a;
    }
}
int binary_s(int d[],int len,int x){
    int mid=0;
    int l=0;
    int r=len-1;
    while(l<r){
        mid=l+(r-l)/2;
        if(d[mid]<x){
            l=mid+1;
        }
        else{
            r=mid;
        }
        if(l==r){
            break;
        }
    }
    return l;
}
void find_se(int a[],int k){
    int *d;
    int *f;
    d=new int[k];
    f=new int[k];
    for(int i=0;i<k;i++){
        f[i]=1;
    }
    int len=0;
    if(k==1){
        cout<<1<<' ';
        return;
    }
    d[len]=a[0];
    for(int i=1;i<k;i++){
        if(a[i]>d[len]){
            len++;
            d[len]=a[i];
            f[i]=len+1;
        }
        else{
            d[binary_s(d,len+1,a[i])]=a[i];
            f[i]=binary_s(d,len+1,a[i])+1;
        }
    }
    int ans=0;
    for(int i=0;i<k;i++){
        ans=max(ans,f[i]);
    }
    cout<<ans<<' ';
    return;
}
int main(){
    int n;
    cin>>n;
    int m;
    for(int i=0;i<n;i++){
        cin>>m;
        int *a;
        a=new int[m];
        for(int j=0;j<m;j++){
            cin>>a[j];
        }
        find_se(a,m);
    }
    return 0;
}