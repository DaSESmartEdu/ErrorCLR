#include<stdio.h>
#define INF 2100000000
using namespace std;
int main()
{
	int n,a[50010];
	scanf("%d",&n);
	for (int i=1;i<=n;i++)
	{
		scanf("%d",&a[i]);
	}
	int max=0,min=INF,cnt=0;
	for (int i=1;i<=n;i++)
	{
		max=0;
		min=INF;
		for (int j=i;j<=n;j++)
		{
			if (a[j]>max) max=a[j];
			if (a[j]<min) min=a[j];
			if (max-min==j-i)
				cnt++;
		}
	}
	printf("%d",cnt);
	return 0;
}