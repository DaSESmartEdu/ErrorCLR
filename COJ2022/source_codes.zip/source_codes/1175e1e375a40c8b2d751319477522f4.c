#include <stdio.h>
#include <math.h>
int main(void)
{
    int m;
    int n;
    float i;
    double result = 0;
    scanf("%d %d",&m,&n);
    for(i = m;i <= n;i++) {
        result = pow(i ,2) + 1 / i + result;
    }
    printf("%lf\n",result);
    return 0;
}