#include<stdio.h>
int main()
{
    int n,max,k,i,b;
    scanf("%d",&n);
    int a[n];
    for(i=0;i<n;i++)
    {
       scanf("%d",&a[i]);
    }
    for(k=0;k<n-1;k++)
    {
        max=k;
        for(i=k+1;i<n;i++){
        if(a[i]>a[max]){
        max=i;}}
        b=a[max];
        a[max]=a[k];
        a[k]=b;
    }
    for(i=0;i<n-1;i++){
        printf("%d ",a[i]);
    }
    printf("%d",a[n-1]);
    return 0;
}