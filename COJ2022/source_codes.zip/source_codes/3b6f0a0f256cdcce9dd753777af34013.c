#include <stdio.h>
int main()
{
    int t=0;
    float s=0.0;
    scanf("%d",&t);
    if (t<=50)
    {
        s=0.53*t;
    }
    else
    {
        s=26.5+0.57*(t-50.0);
    }
    printf("%.6f",s);
    return 0;
}