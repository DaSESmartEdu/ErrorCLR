#include<stdio.h>
double funcos( double e, double x );
double fact(int n);
double pow0(double m,int n);
int main()
{
    double e,x;
    scanf("%lf %lf",&e,&x);
    printf("%lf",funcos(e,x));
    return 0;
}
double funcos(double e,double x)
{
    double sum = 0;
    int sign = 1;
    for (long i = 0;i<=9999999;i += 2){
            sum += (sign*(pow0(x,i)*1.0))/(fact(i)*1.0);
            printf("%f\n",sign*(pow0(x,i)*1.0)/fact(i));
            sign = -sign;
        if (pow0(x,i)*1.0/fact(i)<e && pow0(x,i)*1.0/fact(i)>-e){
            break;
        }
    }
    return sum;
}
double fact(int n)
{
    if (n == 0)
    {
        return 1;
    }
    else
    {
        double ans = 1;
        for(int i=1;i<=n;i++){
            ans *= i;
        }
        return ans;
    }
}
double pow0(double m,int n)
{
    double sum = 1;
    if (n == 0){
        return 1;
    }
    else{
    for (long i=1;i<=n;i++){
        sum *= m;
    }
    return sum;
    }
}