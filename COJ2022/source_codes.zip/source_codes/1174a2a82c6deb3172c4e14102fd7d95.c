#include <stdio.h>
void StringCount(char *str);
int main()
{
    int i=0,k=0;
    char str[10000];
    while((str[i]=getchar())!=EOF)
    i++;
    str[i]='\0';
    StringCount(str);
    return 0;
}
void StringCount(char *str)
{
    int j=0,a=0,b=0,c=0,d=0,e=0;
    for (j=0;str[j]!='\0';j++)
    {
        if (str[j]>='A'&&str[j]<='Z')
        a++;
        else if(str[j]>='a'&&str[j]<='z')
        b++;
        else if (str[j]==' ')
        c++;
        else if (str[j]>='0'&&str[j]<='9')
        d++;
        else
        e++;
    }
    printf("%d %d %d %d %d",a,b,c,d,e);
}