#include<stdio.h>
#include<math.h>
double dist( double x1, double y1, double x2, double y2)
{
	double s;
	s=sqrt((x1-x2)*(x1-x2)+(y1-y2)*(y1-y2));
	return s;
}
int main()
{
	double x1,y1,x2,y2,s;
	scanf("%lf %lf %lf %lf",&x1,&y1,&x2,&y2);
	s=dist(x1,y1,x2,y2);
	printf("%.2lf",s);	
}