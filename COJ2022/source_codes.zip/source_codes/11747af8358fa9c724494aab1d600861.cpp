#include<iostream>
using namespace std;
int friends[1000010];
int sex[1000010];
int find(int a)
{
    if(friends[a] == a)
        return a;
       int temp = friends[a];
       friends[a] = find(friends[a]);
       sex[a] = (sex[a] + sex[temp]) %2;
    return find(friends[a]);
}
void create(int a,int b,int &flag)
{
    int ah = find(a);
    int bh = find(b);
    if(ah == bh && sex[a] == sex[b])
        flag = 1;
       friends[bh] = ah;
       sex[bh] = (sex[a] == sex[b]) ? 1 : 0;       
}
int main()
{
    int t;
    cin>>t;
    for(int i=0;i<t;i++)
    {
        int num=0;
        int n,m;
        int flag = 0;
        cin>>n>>m;
        for(int j=1;j<=n;j++)
        {
            friends[j] = j;
            sex[j] = 0;
        }
        for(int j =0;j<m;j++)
        {
            int a,b;
            cin>>a>>b;
            if(flag)
                continue;
            create(a,b,flag);
        }
        if(flag)
            cout<<"Test #"<<i+1<<":"<<endl<<"Suspicious bugs found!"<<endl<<endl;
        else
            cout<<"Test #"<<i+1<<":"<<endl<<"No suspicious bugs found!"<<endl<<endl;
    }
    return 0;
}