#include <stdio.h>
#include <math.h>
int lenth(int x){
	int l=0;
	do{
		x=x/10;
		l++;
	}while(x>0);
	return l;
}
int narcissistic( int number ){
	int len,i,s,sum=0,flag;
	double ss;
	len=lenth(number);
	double ll=len;
	for (i=10;len>0;i*=10){
		len--;
		s=(number%i-number%(i/10))/(i/10);
		ss=s;
		sum+=pow(ss,ll);
	}
	if (sum-number==0){
		flag=1;
	}else{
		flag=0;
	}
	return flag;
}
void PrintN( int m, int n ){
	int i;
	for(i=m;i<n+1;i++){
		if(narcissistic(i)==1){
			printf("%d\n",i);
		}
	}
}
int main(){
	int a,b,i;
	scanf("%d %d",&a,&b);
	PrintN(a,b);
	return 0;
}