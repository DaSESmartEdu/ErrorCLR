#include<stdio.h>
#include<math.h>
int main()
{
    int n;
    scanf("%d", &n);
    float m, i, sum;
    m=n/1.0;
    for(i=1; i<=m; i++){
        sum=sum+sqrt(i);
    }
    printf("%.2f", sum);
    return 0;
}