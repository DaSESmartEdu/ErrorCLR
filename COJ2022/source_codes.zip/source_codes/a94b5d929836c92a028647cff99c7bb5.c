#include <stdio.h>
double fact(int i){
	int n=1;
	double sum=1;
	for(n=1;n<=i;n++){
		sum*=n;
	}
    return sum;
}
int main(){
	int n,i;
	double sum;
	scanf("%d",&n);
	for(i=1;i<=n;i++){
		sum+=fact(i);
	}
	printf("%.0f",sum);
	return 0;
}