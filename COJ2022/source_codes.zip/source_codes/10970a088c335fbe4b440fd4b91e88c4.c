#include <stdio.h>
int main()
{
    int i, a[10]={0}, num, N;
    scanf("%d",&N);
    for(i=0;i<N;i++)
    {
        scanf("%d",&num);
        while(num>0)
        {
            a[num%10]++;
            num=num/10;
        }
    }
    int max=a[0];
    for(i=0;i<10;i++)
    {
        if(a[i]>max)
        {
            max=a[i];
        }
    }
    printf("%d:",max);
    for(i=0;i<10;i++)
    {
        if(a[i]==max)
        {
            printf("%d ",i);
        }
    }
    return 0;
}