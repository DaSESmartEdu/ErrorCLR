#include <stdio.h>
    struct book
    {
    char name[30];
    double price;
    };
int main()
{
    int n,i,maxi=0,mini=0;
    double max,min;
    struct book books[10];
    scanf("%d",&n);
    getchar();
    for(i=0;i<n;i++)
    {
    gets(books[i].name);
    scanf("%lf",&books[i].price);
    getchar();
    }
max=min=books[0].price;
for(i=1;i<n;i++)
{
if(max<books[i].price) 
  {
  max=books[i].price;
  maxi=i;
	}
}
printf("%.2lf, ",max);
puts(books[maxi].name);
for(i=1;i<n;i++)
{
 if(min>books[i].price)
    {
		min=books[i].price;
		mini=i;
	}
}
printf("%.2lf, ",min);
puts(books[mini].name);
return 0;
}