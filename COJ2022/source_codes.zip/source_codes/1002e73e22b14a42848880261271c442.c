#include<stdio.h>
#include<string.h>
void delchar( char *str, char c );
int main(){
    char ch[10000];
    char c;
    scanf("%s\n",&c);
    gets(ch);
    delchar(ch, c);
    printf("%s\n",ch);
}
void delchar( char *str, char c )
{
    int i=0;
    int n;
    int k=0;
    n=strlen(str);
    while(i<n){
        if(str[i]==c){
            for(k=n-1;k>i;k++){
                str[k]=str[k+1];
            }
            str[n-1]='\0';
        }
      	else{i++;}
    }
}