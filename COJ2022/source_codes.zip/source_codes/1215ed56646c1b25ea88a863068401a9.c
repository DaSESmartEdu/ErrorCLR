#include<stdio.h>
int main()
{
	struct BOOK{
		char name[30];
		float price; 
	};
	int n;
	scanf("%d",&n);
	struct BOOK books[n];
	int i,j=0,a,b;
	for(i=0;i<n;i++)
	{
        getchar();
		while((books[i].name[j]=getchar())!='\n')
		{
			j++;
		}
		books[i].name[j]='\0';
		scanf("%f",&books[i].price);
        j=0;
	}
    i=0;
    	int max=books[i].price*100;
		int min=books[i].price*100;
        float max_,min_;
	for(i=0;i<n;i++)
	{
		if(max<=books[i].price*100)
		{
            max=books[i].price*100;
			max_=books[i].price;
			a=i;
		}
		if(min>=books[i].price*100)
		{
            min=books[i].price*100;
			min_=books[i].price;
			b=i;
		}
	}
	printf("%.2f,%s\n",books[a].price,books[a].name);
	printf("%.2f,%s",books[b].price,books[b].name);
	return 0;
}