#include <stdio.h>
#include <math.h>
int main ()
{
int a;
scanf ("%d",&a);
int i=0;
while (a>0)
{ int u=(a%2);
if(u=1)
  {i=i+a;}
  int f;
  scanf("%d",&f);
  a=f;
}
printf("%d",i);
return 0;
}