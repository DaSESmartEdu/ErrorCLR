#include<stdio.h>
int main()
{
	int n;
	int e=0;
	scanf("%d",&n);
	int a[n][n];
	for(int j=1;j<=n;j++){
		for(int i=1;i<=n;i++){
			scanf("%d",&a[i][j]);
			e=e+a[i][j];
		}
	}
	for(int i=1;i<=n;i++)
	{
		e=e-a[i][n];
	}
	for(int i=1;i<=n;i++){
	  e=e-a[n][i];
}
int j=n;
  for(int i=1;i<=n;i++){
  		e=e-a[i][j];
  		j=j-1;
	  }
	  e=e+a[1][n]+a[n][1]+a[n][n];
  if(n==1) e=0;
	  printf("%d",e);
	  return 0;
  }