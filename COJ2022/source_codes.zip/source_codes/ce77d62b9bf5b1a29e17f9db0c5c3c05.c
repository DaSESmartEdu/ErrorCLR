#include <stdio.h>
int main()
{
int a=0;
int b=0;
int c=0;
int e=0;
printf("");
	scanf("%d %d %d %d",&a,&b,&c,&e);
	printf("%d %f\n",a+b+c+e,(a+b+c+e)/4.0);
		return 0;
}