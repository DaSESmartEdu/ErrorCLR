#include<stdio.h>
double fact(int n);
int main()
{
  int i,n;
  double e;
  e=0;
  scanf("%d",&n);
  for(i=0;i<=n;i++)
    {
      e+=fact(i);
    }
  printf("%.0f",e);
  return 0;
}
double fact(int n)
{
  int i;
  double result;
  result=1;
  for(i=1;i<=n;i++)
    {
      result=result*i;
    }
  return result;
}