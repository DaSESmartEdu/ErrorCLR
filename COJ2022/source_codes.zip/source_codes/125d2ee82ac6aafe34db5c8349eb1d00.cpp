#include <iostream>
#include <cmath>
using namespace std;
void ADD(int **MatrixA, int **MatrixB, int **MatrixResult, int M) 
{
    for (int i = 0; i < M; i++)
    {
        for (int j = 0; j < M; j++)
        {
            MatrixResult[i][j] = MatrixA[i][j] + MatrixB[i][j];
        }
    }
}
void SUB(int **MatrixA, int **MatrixB, int **MatrixResult, int M) 
{
    for (int i = 0; i < M; i++)
    {
        for (int j = 0; j < M; j++)
        {
            MatrixResult[i][j] = MatrixA[i][j] - MatrixB[i][j];
        }
    }
}
void MUL(int **MatrixA, int **MatrixB, int **MatrixResult, int M) 
{
    for (int i = 0; i < M; i++)
    {
        for (int j = 0; j < M; j++)
        {
            MatrixResult[i][j] = 0;
            for (int k = 0; k < M; k++)
            {
                MatrixResult[i][j] = MatrixResult[i][j] + MatrixA[i][k] * MatrixB[k][j];
            }
        }
    }
}
void Strassen(int M, int **MatrixA, int **MatrixB, int **MatrixC)
{
    int HalfSize = M / 2;
    int newSize = M / 2;
    int **A11 = new int *[newSize];
    int **A12 = new int *[newSize];
    int **A21 = new int *[newSize];
    int **A22 = new int *[newSize];
    int **B11 = new int *[newSize];
    int **B12 = new int *[newSize];
    int **B21 = new int *[newSize];
    int **B22 = new int *[newSize];
    int **C11 = new int *[newSize];
    int **C12 = new int *[newSize];
    int **C21 = new int *[newSize];
    int **C22 = new int *[newSize];
    int **M1 = new int *[newSize];
    int **M2 = new int *[newSize];
    int **M3 = new int *[newSize];
    int **M4 = new int *[newSize];
    int **M5 = new int *[newSize];
    int **M6 = new int *[newSize];
    int **M7 = new int *[newSize];
    int **AResult = new int *[newSize];
    int **BResult = new int *[newSize];
    int newlength = newSize;
    for (int i = 0; i < newSize; i++)
    {
        A11[i] = new int[newlength];
        A12[i] = new int[newlength];
        A21[i] = new int[newlength];
        A22[i] = new int[newlength];
        B11[i] = new int[newlength];
        B12[i] = new int[newlength];
        B21[i] = new int[newlength];
        B22[i] = new int[newlength];
        C11[i] = new int[newlength];
        C12[i] = new int[newlength];
        C21[i] = new int[newlength];
        C22[i] = new int[newlength];
        M1[i] = new int[newlength];
        M2[i] = new int[newlength];
        M3[i] = new int[newlength];
        M4[i] = new int[newlength];
        M5[i] = new int[newlength];
        M6[i] = new int[newlength];
        M7[i] = new int[newlength];
        AResult[i] = new int[newlength];
        BResult[i] = new int[newlength];
    }
    for (int i = 0; i < M / 2; i++)
    {
        for (int j = 0; j < M / 2; j++)
        {
            A11[i][j] = MatrixA[i][j];
            A12[i][j] = MatrixA[i][j + M / 2];
            A21[i][j] = MatrixA[i + M / 2][j];
            A22[i][j] = MatrixA[i + M / 2][j + M / 2];
            B11[i][j] = MatrixB[i][j];
            B12[i][j] = MatrixB[i][j + M / 2];
            B21[i][j] = MatrixB[i + M / 2][j];
            B22[i][j] = MatrixB[i + M / 2][j + M / 2];
        }
    }
    ADD(A11, A22, AResult, HalfSize);
    ADD(B11, B22, BResult, HalfSize);
    MUL(AResult, BResult, M1, HalfSize); 
    ADD(A21, A22, AResult, HalfSize);
    MUL(AResult, B11, M2, HalfSize);
    SUB(B12, B22, BResult, HalfSize);
    MUL(A11, BResult, M3, HalfSize);
    SUB(B21, B11, BResult, HalfSize);
    MUL(A22, BResult, M4, HalfSize);
    ADD(A11, A12, AResult, HalfSize);
    MUL(AResult, B22, M5, HalfSize);
    SUB(A21, A11, AResult, HalfSize);
    ADD(B11, B12, BResult, HalfSize);
    MUL(AResult, BResult, M6, HalfSize);
    SUB(A12, A22, AResult, HalfSize);
    ADD(B21, B22, BResult, HalfSize);
    MUL(AResult, BResult, M7, HalfSize);
    ADD(M1, M4, AResult, HalfSize);       
    SUB(M7, M5, BResult, HalfSize);       
    ADD(AResult, BResult, C11, HalfSize); 
    ADD(M3, M5, C12, HalfSize);
    ADD(M2, M4, C21, HalfSize); 
    ADD(M1, M3, AResult, HalfSize);
    SUB(M6, M2, BResult, HalfSize);
    ADD(AResult, BResult, C22, HalfSize);
    for (int i = 0; i < M / 2; i++)
    {
        for (int j = 0; j < M / 2; j++)
        {
            MatrixC[i][j] = C11[i][j];
            MatrixC[i][j + M / 2] = C12[i][j];
            MatrixC[i + M / 2][j] = C21[i][j];
            MatrixC[i + M / 2][j + M / 2] = C22[i][j];
        }
    }
    for (int i = 0; i < newlength; i++)
    {
        delete[] A11[i];
        delete[] A12[i];
        delete[] A21[i];
        delete[] A22[i];
        delete[] B11[i];
        delete[] B12[i];
        delete[] B21[i];
        delete[] B22[i];
        delete[] C11[i];
        delete[] C12[i];
        delete[] C21[i];
        delete[] C22[i];
        delete[] M1[i];
        delete[] M2[i];
        delete[] M3[i];
        delete[] M4[i];
        delete[] M5[i];
        delete[] M6[i];
        delete[] M7[i];
        delete[] AResult[i];
        delete[] BResult[i];
    }
    delete[] A11;
    delete[] A12;
    delete[] A21;
    delete[] A22;
    delete[] B11;
    delete[] B12;
    delete[] B21;
    delete[] B22;
    delete[] C11;
    delete[] C12;
    delete[] C21;
    delete[] C22;
    delete[] M1;
    delete[] M2;
    delete[] M3;
    delete[] M4;
    delete[] M5;
    delete[] M6;
    delete[] M7;
    delete[] AResult;
    delete[] BResult;
}
int main()
{
    ios::sync_with_stdio(false); 
    cin.tie(nullptr);
    int N, M;
    cin >> N >> M;
    double res;
    res = log(M) / log(2);
    int num = pow(2, (int)res + 1);
    for (int i = N; i > 0; i--)
    {
        int **a = new int *[num];
        int **b = new int *[num];
        int **c = new int *[num];
        for (int i = 0; i < num; i++)
        {
            a[i] = new int[num];
            b[i] = new int[num];
            c[i] = new int[num];
        }
        for (int i = 0; i < M; i++)
        {
            for (int j = 0; j < M; j++)
                cin >> a[i][j];
        }
        for (int i = 0; i < M; i++)
        {
            for (int j = 0; j < M; j++)
                cin >> b[i][j];
        }
        if (res != (int)res)
        {
            for (int i = M; i < num; i++)
            {
                for (int j = 0; j < M; j++)
                {
                    a[i][j] = 0;
                    b[i][j] = 0;
                }
            }
            for (int j = M; j < num; j++)
            {
                for (int i = 0; i < num; i++)
                {
                    a[i][j] = 0;
                    b[i][j] = 0;
                }
            }
            Strassen(num, a, b, c);
        }
        else
        {
            Strassen(M, a, b, c);
        }
        for (int i = 0; i < M; i++)
        {
            for (int j = 0; j < M; j++)
            {
                cout << c[i][j] << " \n"[j == M - 1];
            }
        }
    }
    return 0;
}