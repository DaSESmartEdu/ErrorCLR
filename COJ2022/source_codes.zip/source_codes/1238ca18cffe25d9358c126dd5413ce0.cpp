#include <iostream>
#include <string>
#include <sstream>
#include <vector>
#include <iostream>
#include <algorithm>
using namespace std;
string num_five[100]={};
int num_five_len = 0;
string num_six[100]={};
int num_six_len = 0;
bool cmp(string A,string B){
    return A<B;
}
void find_five(int x){
    for(int a=0;a<=9;a++){
        if((x-a)%2 == 0){
            for(int b=0;b<=9;b++){
                int c = ((x-a)/2)-b;
                if( c>= 0 && c<10){
                    string str = to_string(c) + to_string(b) + to_string(a) + to_string(b) + to_string(c);
                    num_five[num_five_len] = str;
                    num_five_len ++;
                }
            }
        }
    }
}
void find_six(int x){
    if(x%2 == 0){
        for(int a=0;a<=9;a++){
            for(int b=0;b<=9;b++){
                int c = (x/2)-a-b;
                if( c >= 0 && c< 10){
                    string str = to_string(c) + to_string(b) + to_string(a) + to_string(a) + to_string(b) + to_string(c);
                    num_six[num_six_len] = str;
                    num_six_len ++;
                }
            }
        }
    }
}
int main()
{
    int x;
    cin>>x;
    find_five(x);
    find_six(x);
    sort(num_five,num_five+num_five_len,cmp);
    sort(num_six,num_six+num_six_len,cmp);
    for(int i=0;i<num_five_len;i++){
        if(num_five[i][0] != '0')
            cout << num_five[i] << endl;
    }
    for(int i=0;i<num_six_len;i++){
        if(num_six[i][0] != '0')
        cout << num_six[i] << endl;
    }
    if(num_five_len == 0 && num_six_len == 0)
        cout << -1 <<endl;
    return 0;
}