#include <stdio.h>
int main(void)
{
	int n;
	scanf("%d", &n);
	int s[n];
	for(int i = 0; i < n; i++)
	{
		scanf("%d", &s[i]);
	}
	for(int i = 0; i < n; i++)
	{
		int max = s[0];	
		int number = 0;
		for(int j = 1; j < n; j++)
		{
			if (max > s[j]) max = max;
			else {
				max = s[j];
				number = j;
			}
		}
		if (i < n-1) printf("%d ", max);
		if (i = n-1) printf("%d", max);
		s[number] = -1;
	}
	printf("\b");
	return 0;	
}