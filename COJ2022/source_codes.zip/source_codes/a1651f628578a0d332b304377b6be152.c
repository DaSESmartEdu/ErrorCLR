#include<stdio.h>
int main()
{
    int a,b,c,max,min,middle;
    scanf("%d %d %d",&a,&b,&c);
    if (a==b)
       printf("Wrong");
    else if(a>b)
       {
           max=a;min=b;
       }
    else
       {
           max=b;min=a;
       }
    if (c>max)
       {
           middle=max;max=c;
        }
    else if (c<max&&c>min)
        middle=c;
    else if (c<min)
        {
            middle=min;
            min=c;
        }
    else
    printf("Wrong");
printf("%d %d %d",min,middle,max);
    return 0;
}