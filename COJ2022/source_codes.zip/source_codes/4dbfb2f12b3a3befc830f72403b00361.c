#include<stdio.h>
int main()
{
int a,c,v,n;
float avg;
float s;
scanf("%d%d%d%d",&a,&c,&v,&n);
s=a+c+v+n;
avg=(float)	(s)/4;
printf("%d %0.1f\n",s,avg);
return 0;
}