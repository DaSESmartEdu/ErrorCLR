#include<iostream>
#include<vector>
#include<queue>
#include<tr1/unordered_map>
using namespace std;
using namespace tr1;
struct TreeNode
{
    TreeNode* left;
    TreeNode* right;
    int val;
};
bool twice(vector<vector<int> > a,int n)
{
    int sum=n;
    unordered_map<int,int> hash1;
    unordered_map<int,int> hash2;
    int i;
    for(i=0;i<n;i++)
    {
        hash1[i]=0;
        hash2[i]=0;
    }
    queue<int> key;
    key.push(0);
    hash1[0]++;
    sum--;
    int cur;
    int curelment;
    while(!key.empty())
    {
        cur=key.front();
        for(i=0;i<a[cur].size();i++)
        {
            if(hash1[cur]>0)
            {
                if(hash1[a[cur][i]]>0) return false;
                else hash2[a[cur][i]]++;
            }
            if(hash2[cur]>0)
            {
                if(hash2[a[cur][i]]>0) return false;
                else hash1[a[cur][i]]++;
            }
            if(sum>0){
                key.push(a[cur][i]);
                sum--;
            }
            key.pop();
        }
    }
    return true;
}
int main()
{
    vector<vector<int> > graph;
    vector<int> tmp;
    int n,k;
    int tn;
    cin>>n;
    int i,j;
    for(i=0;i<n;i++)
    {
        cin>>k;
        for(j=0;j<k;j++)
        {   
            cin>>tn;
            tmp.push_back(tn);
        }
        graph.push_back(tmp);
        tmp.clear();
    }
    if(twice(graph,n)) cout<<"true";
    else cout<<"false";
}