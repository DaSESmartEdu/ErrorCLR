#include<iostream>
#include<queue>
#include<vector>
using namespace std;
int main()
 {
    priority_queue<pair<int, int>,vector<pair<int, int> >,greater<pair<int, int> > > a;
    int n;
    int i;
    int x,y;
    vector<pair<int, int> > p;
    pair<int, int> tmp;
    cin>>n;
    for(i=0;i<n;i++)
    {
        cin>>tmp.first>>tmp.second;
        a.push(tmp);
    }
    while (!a.empty())
    {
         cout << a.top().first << ' ' << a.top().second << '\n';
         a.pop();
    }
}