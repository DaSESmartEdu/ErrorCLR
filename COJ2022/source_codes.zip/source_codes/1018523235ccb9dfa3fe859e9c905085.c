#include <stdio.h>
void CountOff(int n,int m,int out[]);
int main(){
 int n,m;
 int a[10000];
 scanf("%d %d",&n,&m);
 CountOff(n,m,a);
 return 0;
}
void CountOff(int n,int m,int a[]){
 int i,j,o=n,l,p=0;
 int b[n];
 for(j=0;j<n;j++){
  b[j]=0;
  a[j]=j+1;
 }
 for(i=0;;i++){
   l=i%n;
   if(a[l]!=-1){
     p++;
   }
   if(p%m==0&&a[l]!=-1){
     o--;
     b[l]=p/m;
     a[l]=-1;
     if(o==1){
       break;
     }
   }
 }
  for (int i=0;i<n;i++){
    if(b[i]==0)
      printf("%d ",n);
    else printf("%d ",b[i]);
  }
}