#include <stdio.h>
int main()
{
	int i,n,flag;
	double sum,item;
	sum=0;
	flag=1;
	scanf("%d",&n);
	for (i=1;i<=n;i++)
	{
		item=flag*i/(2*i-1);
		sum=sum+item;
		flag=-flag;
	}
	printf("%.6f",sum);
	return 0;
}