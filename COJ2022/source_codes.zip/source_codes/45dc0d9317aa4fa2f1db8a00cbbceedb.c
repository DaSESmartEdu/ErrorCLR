#include<stdio.h>
int main()
{
    int n,m;
    scanf("%d %d",&n,&m);
    if(n>=1.5*m)
    {
        printf("revoke");
    }
    if(n>=1.1*m&&n<1.5*m)
    {
        printf("200");
    }
    if(n<=m)
    {
        printf("normal");
    }
}